<?php
// Load bootstrap
require_once __DIR__ . '/../private/bootstrap.php';

try {
    // Get the request URI and method
    $request_uri = $_SERVER['REQUEST_URI'];
    $request_method = $_SERVER['REQUEST_METHOD'];

    // Remove query string and trailing slash
    $path = parse_url($request_uri, PHP_URL_PATH);
    $path = rtrim($path, '/');

    // Define routes that require authentication
    $protected_routes = [
        '/games/ludo/game',
        '/games/ludo/lobby',
        '/games/aviator/game',
        '/user/wallet',
        '/user/profile'
    ];

    // Define admin routes
    $admin_routes = [
        '/admin',
        '/admin/dashboard',
        '/admin/users',
        '/admin/games',
        '/admin/transactions',
        '/admin/settings'
    ];

    // Check if accessing admin route
    if (strpos($path, '/admin') === 0) {
        requireAdmin();
    }

    // Check if route requires authentication
    if (in_array($path, $protected_routes)) {
        requireAuth();
    }

    // API Routes
    if (strpos($path, '/api/') === 0) {
        header('Content-Type: application/json');
        
        switch ($path) {
            case '/api/stats':
                require __DIR__ . '/api/stats.php';
                break;
                
            case '/api/winners':
                require __DIR__ . '/api/winners.php';
                break;
                
            case '/api/auth/login':
                if ($request_method !== 'POST') {
                    http_response_code(405);
                    echo json_encode(['error' => 'Method not allowed']);
                    break;
                }
                
                $data = json_decode(file_get_contents('php://input'), true);
                $result = $auth->login($data['username'], $data['password']);
                
                if ($result['success']) {
                    echo json_encode([
                        'success' => true,
                        'token' => $result['token'],
                        'user' => $result['user']
                    ]);
                } else {
                    http_response_code(401);
                    echo json_encode(['error' => $result['error']]);
                }
                break;

            case '/api/auth/register':
                if ($request_method !== 'POST') {
                    http_response_code(405);
                    echo json_encode(['error' => 'Method not allowed']);
                    break;
                }
                
                $data = json_decode(file_get_contents('php://input'), true);
                $result = $auth->register($data);
                
                if ($result['success']) {
                    echo json_encode([
                        'success' => true,
                        'message' => 'Registration successful'
                    ]);
                } else {
                    http_response_code(400);
                    echo json_encode(['error' => $result['error']]);
                }
                break;

            default:
                http_response_code(404);
                echo json_encode(['error' => 'API endpoint not found']);
                break;
        }
        exit;
    }

    // WebSocket endpoint
    if ($path === '/ws') {
        require_once __DIR__ . '/../private/controllers/WebSocket/GameServer.php';
        $gameServer = new GameServer();
        $gameServer->run();
        exit;
    }

    // Page Routes
    switch ($path) {
        case '':
        case '/':
            $currentPage = 'home';
            require __DIR__ . '/views/home.php';
            break;

        case '/login':
            if (isAuthenticated()) {
                redirect('/');
            }
            $currentPage = 'login';
            require __DIR__ . '/views/auth/login.php';
            break;

        case '/register':
            if (isAuthenticated()) {
                redirect('/');
            }
            $currentPage = 'register';
            require __DIR__ . '/views/auth/register.php';
            break;

        case '/logout':
            $auth->logout();
            redirect('/');
            break;

        case '/games/ludo/lobby':
            $currentPage = 'ludo';
            require __DIR__ . '/views/games/ludo/lobby.php';
            break;

        case '/games/ludo/game':
            $currentPage = 'ludo';
            require __DIR__ . '/views/games/ludo/game.php';
            break;

        case '/games/aviator/game':
            $currentPage = 'aviator';
            require __DIR__ . '/views/games/aviator/game.php';
            break;

        case '/user/wallet':
            $currentPage = 'wallet';
            require __DIR__ . '/views/user/wallet.php';
            break;

        case '/user/profile':
            $currentPage = 'profile';
            require __DIR__ . '/views/user/profile.php';
            break;

        case '/admin':
        case '/admin/dashboard':
            $currentPage = 'admin';
            require __DIR__ . '/admin/pages/dashboard.php';
            break;

        case '/admin/users':
            $currentPage = 'admin';
            require __DIR__ . '/admin/pages/users.php';
            break;

        case '/admin/games':
            $currentPage = 'admin';
            require __DIR__ . '/admin/pages/games.php';
            break;

        case '/admin/transactions':
            $currentPage = 'admin';
            require __DIR__ . '/admin/pages/transactions.php';
            break;

        case '/admin/settings':
            $currentPage = 'admin';
            require __DIR__ . '/admin/pages/settings.php';
            break;

        default:
            http_response_code(404);
            require __DIR__ . '/views/errors/404.php';
            break;
    }
} catch (Exception $e) {
    error_log("Fatal error: " . $e->getMessage());
    http_response_code(500);
    require __DIR__ . '/views/errors/500.php';
}
