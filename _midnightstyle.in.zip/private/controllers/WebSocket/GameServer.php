<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../Game/LudoController.php';

class GameServer {
    private $clients = [];
    private $games = [];
    private $db;
    private $ludoController;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->ludoController = new LudoController();
    }

    public function onOpen($client) {
        $this->clients[$client->resourceId] = [
            'client' => $client,
            'userId' => null,
            'gameId' => null
        ];
    }

    public function onMessage($from, $message) {
        $data = json_decode($message, true);
        
        if (!isset($data['action'])) {
            return;
        }

        switch ($data['action']) {
            case 'authenticate':
                $this->handleAuthentication($from, $data);
                break;

            case 'join_game':
                $this->handleJoinGame($from, $data);
                break;

            case 'game_action':
                $this->handleGameAction($from, $data);
                break;

            case 'leave_game':
                $this->handleLeaveGame($from, $data);
                break;

            case 'chat':
                $this->handleChat($from, $data);
                break;
        }
    }

    public function onClose($client) {
        if (isset($this->clients[$client->resourceId])) {
            $gameId = $this->clients[$client->resourceId]['gameId'];
            if ($gameId) {
                $this->handlePlayerDisconnect($client->resourceId, $gameId);
            }
            unset($this->clients[$client->resourceId]);
        }
    }

    private function handleAuthentication($clientId, $data) {
        try {
            // Verify token
            $token = $data['token'];
            $userId = $this->verifyToken($token);
            
            if ($userId) {
                $this->clients[$clientId]['userId'] = $userId;
                $this->sendToClient($clientId, [
                    'type' => 'auth_success',
                    'userId' => $userId
                ]);
            } else {
                $this->sendToClient($clientId, [
                    'type' => 'auth_failed',
                    'error' => 'Invalid token'
                ]);
            }
        } catch (Exception $e) {
            $this->sendToClient($clientId, [
                'type' => 'auth_failed',
                'error' => $e->getMessage()
            ]);
        }
    }

    private function handleJoinGame($clientId, $data) {
        try {
            $userId = $this->clients[$clientId]['userId'];
            if (!$userId) {
                throw new Exception('Not authenticated');
            }

            $gameId = $data['gameId'];
            $result = $this->ludoController->joinGame($gameId, $userId);

            if ($result['success']) {
                $this->clients[$clientId]['gameId'] = $gameId;
                
                // Add client to game room
                if (!isset($this->games[$gameId])) {
                    $this->games[$gameId] = [];
                }
                $this->games[$gameId][] = $clientId;

                // Notify all players in the game
                $this->broadcastToGame($gameId, [
                    'type' => 'player_joined',
                    'userId' => $userId,
                    'position' => $result['position']
                ]);
            } else {
                $this->sendToClient($clientId, [
                    'type' => 'join_failed',
                    'error' => $result['error']
                ]);
            }
        } catch (Exception $e) {
            $this->sendToClient($clientId, [
                'type' => 'join_failed',
                'error' => $e->getMessage()
            ]);
        }
    }

    private function handleGameAction($clientId, $data) {
        try {
            $userId = $this->clients[$clientId]['userId'];
            $gameId = $this->clients[$clientId]['gameId'];

            if (!$userId || !$gameId) {
                throw new Exception('Not in a game');
            }

            $result = $this->ludoController->handleGameAction(
                $data['gameAction'],
                array_merge($data, ['userId' => $userId, 'gameId' => $gameId])
            );

            if ($result['success']) {
                // Action was successful, broadcast updated game state
                $this->broadcastToGame($gameId, [
                    'type' => 'game_update',
                    'action' => $data['gameAction'],
                    'data' => $result
                ]);
            } else {
                $this->sendToClient($clientId, [
                    'type' => 'action_failed',
                    'error' => $result['error']
                ]);
            }
        } catch (Exception $e) {
            $this->sendToClient($clientId, [
                'type' => 'action_failed',
                'error' => $e->getMessage()
            ]);
        }
    }

    private function handleLeaveGame($clientId, $data) {
        try {
            $userId = $this->clients[$clientId]['userId'];
            $gameId = $this->clients[$clientId]['gameId'];

            if (!$userId || !$gameId) {
                throw new Exception('Not in a game');
            }

            $this->removePlayerFromGame($clientId, $gameId);
            
            // Notify other players
            $this->broadcastToGame($gameId, [
                'type' => 'player_left',
                'userId' => $userId
            ]);
        } catch (Exception $e) {
            $this->sendToClient($clientId, [
                'type' => 'leave_failed',
                'error' => $e->getMessage()
            ]);
        }
    }

    private function handleChat($clientId, $data) {
        try {
            $userId = $this->clients[$clientId]['userId'];
            $gameId = $this->clients[$clientId]['gameId'];

            if (!$userId || !$gameId) {
                throw new Exception('Not in a game');
            }

            // Get user details
            $stmt = $this->db->prepare("
                SELECT username FROM users WHERE id = ?
            ");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();

            // Broadcast chat message
            $this->broadcastToGame($gameId, [
                'type' => 'chat',
                'userId' => $userId,
                'username' => $user['username'],
                'message' => $data['message']
            ]);
        } catch (Exception $e) {
            $this->sendToClient($clientId, [
                'type' => 'chat_failed',
                'error' => $e->getMessage()
            ]);
        }
    }

    private function handlePlayerDisconnect($clientId, $gameId) {
        try {
            $this->removePlayerFromGame($clientId, $gameId);
            
            // Notify other players
            $this->broadcastToGame($gameId, [
                'type' => 'player_disconnected',
                'userId' => $this->clients[$clientId]['userId']
            ]);
        } catch (Exception $e) {
            error_log("Error handling player disconnect: " . $e->getMessage());
        }
    }

    private function removePlayerFromGame($clientId, $gameId) {
        // Remove from games array
        if (isset($this->games[$gameId])) {
            $index = array_search($clientId, $this->games[$gameId]);
            if ($index !== false) {
                unset($this->games[$gameId][$index]);
            }

            // Clean up empty game
            if (empty($this->games[$gameId])) {
                unset($this->games[$gameId]);
            }
        }

        // Update client data
        $this->clients[$clientId]['gameId'] = null;
    }

    private function verifyToken($token) {
        try {
            $stmt = $this->db->prepare("
                SELECT user_id 
                FROM sessions 
                WHERE token = ? AND expires_at > NOW()
            ");
            $stmt->execute([$token]);
            $result = $stmt->fetch();

            return $result ? $result['user_id'] : null;
        } catch (Exception $e) {
            error_log("Token verification error: " . $e->getMessage());
            return null;
        }
    }

    private function sendToClient($clientId, $data) {
        if (isset($this->clients[$clientId])) {
            $this->clients[$clientId]['client']->send(json_encode($data));
        }
    }

    private function broadcastToGame($gameId, $data) {
        if (isset($this->games[$gameId])) {
            $message = json_encode($data);
            foreach ($this->games[$gameId] as $clientId) {
                $this->sendToClient($clientId, $message);
            }
        }
    }

    public function broadcastToAll($data) {
        $message = json_encode($data);
        foreach ($this->clients as $clientData) {
            $clientData['client']->send($message);
        }
    }

    public function getOnlineCount() {
        return count($this->clients);
    }

    public function getGameCount() {
        return count($this->games);
    }

    public function cleanup() {
        // Cleanup inactive games
        try {
            $stmt = $this->db->prepare("
                UPDATE game_sessions 
                SET status = 'cancelled' 
                WHERE status = 'waiting' 
                AND waiting_until < NOW()
            ");
            $stmt->execute();

            // Cleanup expired sessions
            $stmt = $this->db->prepare("
                DELETE FROM sessions 
                WHERE expires_at < NOW()
            ");
            $stmt->execute();
        } catch (Exception $e) {
            error_log("Cleanup error: " . $e->getMessage());
        }
    }
}
