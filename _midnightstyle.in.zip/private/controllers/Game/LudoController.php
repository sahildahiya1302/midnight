<?php
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../classes/User/User.php';
require_once __DIR__ . '/../../classes/User/Wallet.php';

class LudoController {
    private $db;
    private $gameState;
    private $botProbabilities;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->initializeBotProbabilities();
    }

    private function initializeBotProbabilities() {
        // Bot win probabilities based on number of bots
        $this->botProbabilities = [
            1 => 0.40, // 40% win rate with 1 bot
            2 => 0.70, // 70% win rate with 2 bots
            3 => 0.95  // 95% win rate with 3 bots
        ];
    }

    public function createGame($entryFee) {
        try {
            $this->db->beginTransaction();

            // Create game session
            $stmt = $this->db->prepare("
                INSERT INTO game_sessions (
                    game_type, 
                    entry_fee, 
                    status, 
                    created_at
                ) VALUES (
                    'ludo',
                    ?,
                    'waiting',
                    NOW()
                )
            ");
            $stmt->execute([$entryFee]);
            $gameId = $this->db->lastInsertId();

            $this->db->commit();
            return $gameId;
        } catch (PDOException $e) {
            $this->db->rollBack();
            error_log("Error creating game: " . $e->getMessage());
            throw new Exception("Failed to create game");
        }
    }

    public function joinGame($gameId, $userId) {
        try {
            $this->db->beginTransaction();

            // Check if game exists and is joinable
            $stmt = $this->db->prepare("
                SELECT * FROM game_sessions 
                WHERE id = ? AND status = 'waiting'
            ");
            $stmt->execute([$gameId]);
            $game = $stmt->fetch();

            if (!$game) {
                throw new Exception("Game not available");
            }

            // Check if player has enough balance
            $wallet = new Wallet($userId);
            if ($wallet->getBalance() < $game['entry_fee']) {
                throw new Exception("Insufficient balance");
            }

            // Process entry fee
            $result = $wallet->processGameEntry($game['entry_fee'], $gameId);
            if (!$result['success']) {
                throw new Exception($result['error']);
            }

            // Add player to game
            $stmt = $this->db->prepare("
                INSERT INTO game_players (
                    session_id,
                    user_id,
                    position,
                    status,
                    joined_at
                ) VALUES (?, ?, ?, 'waiting', NOW())
            ");

            // Get next available position
            $position = $this->getNextPosition($gameId);
            $stmt->execute([$gameId, $userId, $position]);

            // Check if game should start
            $this->checkGameStart($gameId);

            $this->db->commit();
            return [
                'success' => true,
                'position' => $position
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    private function getNextPosition($gameId) {
        $stmt = $this->db->prepare("
            SELECT position 
            FROM game_players 
            WHERE session_id = ?
        ");
        $stmt->execute([$gameId]);
        $positions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        for ($i = 1; $i <= 4; $i++) {
            if (!in_array($i, $positions)) {
                return $i;
            }
        }
        throw new Exception("Game is full");
    }

    private function checkGameStart($gameId) {
        $stmt = $this->db->prepare("
            SELECT COUNT(*) as player_count 
            FROM game_players 
            WHERE session_id = ?
        ");
        $stmt->execute([$gameId]);
        $result = $stmt->fetch();

        if ($result['player_count'] === 4) {
            // Start game immediately
            $this->startGame($gameId);
        } else if ($result['player_count'] === 1) {
            // Start waiting period
            $this->startWaitingPeriod($gameId);
        }
    }

    private function startWaitingPeriod($gameId) {
        // Set 30-second timer
        $stmt = $this->db->prepare("
            UPDATE game_sessions 
            SET waiting_until = DATE_ADD(NOW(), INTERVAL 30 SECOND) 
            WHERE id = ?
        ");
        $stmt->execute([$gameId]);
    }

    private function startGame($gameId) {
        try {
            $this->db->beginTransaction();

            // Get game details
            $stmt = $this->db->prepare("
                SELECT * FROM game_sessions WHERE id = ?
            ");
            $stmt->execute([$gameId]);
            $game = $stmt->fetch();

            // Get players
            $stmt = $this->db->prepare("
                SELECT p.*, u.username, u.avatar 
                FROM game_players p 
                JOIN users u ON p.user_id = u.id 
                WHERE p.session_id = ?
            ");
            $stmt->execute([$gameId]);
            $players = $stmt->fetchAll();

            // Add bots if needed
            $botsNeeded = 4 - count($players);
            if ($botsNeeded > 0) {
                $this->addBots($gameId, $botsNeeded);
            }

            // Initialize game state
            $this->gameState = [
                'gameId' => $gameId,
                'status' => 'playing',
                'currentPlayer' => $players[0]['user_id'],
                'players' => $players,
                'pieces' => $this->initializePieces($players),
                'diceValue' => null,
                'turnTimeLeft' => 15,
                'botCount' => $botsNeeded
            ];

            // Update game status
            $stmt = $this->db->prepare("
                UPDATE game_sessions 
                SET status = 'playing', 
                    started_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$gameId]);

            $this->db->commit();

            // Broadcast game start
            $this->broadcastGameState();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error starting game: " . $e->getMessage());
            return false;
        }
    }

    private function addBots($gameId, $count) {
        $botNames = ['Alex Bot', 'Sam Bot', 'Max Bot', 'Jay Bot'];
        $position = $this->getNextPosition($gameId);

        for ($i = 0; $i < $count; $i++) {
            $stmt = $this->db->prepare("
                INSERT INTO game_players (
                    session_id,
                    is_bot,
                    bot_name,
                    position,
                    status,
                    joined_at
                ) VALUES (?, 1, ?, ?, 'playing', NOW())
            ");
            $stmt->execute([$gameId, $botNames[$i], $position + $i]);
        }
    }

    private function initializePieces($players) {
        $pieces = [];
        $homePositions = [
            1 => [[1,1], [1,4], [4,1], [4,4]],
            2 => [[10,1], [10,4], [13,1], [13,4]],
            3 => [[10,10], [10,13], [13,10], [13,13]],
            4 => [[1,10], [1,13], [4,10], [4,13]]
        ];

        foreach ($players as $player) {
            $color = $this->getPlayerColor($player['position']);
            for ($i = 0; $i < 4; $i++) {
                $pieceId = $player['user_id'] . '_' . $i;
                $pieces[$pieceId] = [
                    'position' => $homePositions[$player['position']][$i],
                    'color' => $color,
                    'isHome' => true,
                    'isComplete' => false
                ];
            }
        }

        return $pieces;
    }

    private function getPlayerColor($position) {
        $colors = [
            1 => 'red',
            2 => 'green',
            3 => 'yellow',
            4 => 'blue'
        ];
        return $colors[$position];
    }

    public function handleGameAction($action, $data) {
        switch ($action) {
            case 'roll_dice':
                return $this->handleDiceRoll($data);
            case 'move_piece':
                return $this->handlePieceMove($data);
            case 'chat':
                return $this->handleChat($data);
            default:
                return [
                    'success' => false,
                    'error' => 'Invalid action'
                ];
        }
    }

    private function handleDiceRoll($data) {
        if ($this->gameState['currentPlayer'] !== $data['userId']) {
            return ['success' => false, 'error' => 'Not your turn'];
        }

        $value = $this->rollDice();
        $this->gameState['diceValue'] = $value;
        $this->broadcastGameState();

        return [
            'success' => true,
            'value' => $value
        ];
    }

    private function rollDice() {
        return rand(1, 6);
    }

    private function handlePieceMove($data) {
        if ($this->gameState['currentPlayer'] !== $data['userId']) {
            return ['success' => false, 'error' => 'Not your turn'];
        }

        if (!$this->isValidMove($data['pieceId'], $data['to'])) {
            return ['success' => false, 'error' => 'Invalid move'];
        }

        $this->movePiece($data['pieceId'], $data['to']);
        $this->checkCaptures($data['to']);
        $this->checkWinCondition();
        $this->nextTurn();

        $this->broadcastGameState();

        return ['success' => true];
    }

    private function isValidMove($pieceId, $to) {
        $piece = $this->gameState['pieces'][$pieceId];
        
        // Check if piece can move out of home
        if ($piece['isHome'] && $this->gameState['diceValue'] !== 6) {
            return false;
        }

        // Check if destination is valid
        if (!$this->isValidDestination($to)) {
            return false;
        }

        // Check if move distance matches dice value
        if (!$piece['isHome'] && !$this->isValidDistance($piece['position'], $to)) {
            return false;
        }

        return true;
    }

    private function isValidDestination($position) {
        // Check if position is within board bounds
        if ($position[0] < 0 || $position[0] > 14 || 
            $position[1] < 0 || $position[1] > 14) {
            return false;
        }

        // Check if position is on valid path
        return true; // Implement path validation
    }

    private function isValidDistance($from, $to) {
        // Implement distance calculation based on game rules
        return true;
    }

    private function movePiece($pieceId, $to) {
        $this->gameState['pieces'][$pieceId]['position'] = $to;
        $this->gameState['pieces'][$pieceId]['isHome'] = false;
    }

    private function checkCaptures($position) {
        foreach ($this->gameState['pieces'] as $pieceId => $piece) {
            if ($piece['position'] === $position && 
                !$piece['isHome'] && 
                !$piece['isComplete']) {
                // Send piece back home
                $this->capturePiece($pieceId);
            }
        }
    }

    private function capturePiece($pieceId) {
        $piece = $this->gameState['pieces'][$pieceId];
        $player = $this->getPlayerByColor($piece['color']);
        $homePositions = $this->getHomePositions($player['position']);
        
        // Find first available home position
        foreach ($homePositions as $position) {
            if (!$this->isPositionOccupied($position)) {
                $this->gameState['pieces'][$pieceId]['position'] = $position;
                $this->gameState['pieces'][$pieceId]['isHome'] = true;
                break;
            }
        }
    }

    private function checkWinCondition() {
        foreach ($this->gameState['players'] as $player) {
            $completedPieces = 0;
            foreach ($this->gameState['pieces'] as $piece) {
                if ($piece['color'] === $this->getPlayerColor($player['position']) && 
                    $piece['isComplete']) {
                    $completedPieces++;
                }
            }
            
            if ($completedPieces === 4) {
                $this->endGame($player['user_id']);
                break;
            }
        }
    }

    private function endGame($winnerId) {
        try {
            $this->db->beginTransaction();

            // Update game session
            $stmt = $this->db->prepare("
                UPDATE game_sessions 
                SET status = 'completed',
                    winner_id = ?,
                    completed_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$winnerId, $this->gameState['gameId']]);

            // Process winnings
            $game = $this->getGameDetails($this->gameState['gameId']);
            $prizeAmount = $game['entry_fee'] * 4 * 0.8; // 80% of pool

            $wallet = new Wallet($winnerId);
            $wallet->processWinning($prizeAmount, $this->gameState['gameId']);

            $this->db->commit();

            // Broadcast game over
            $this->broadcastGameOver($winnerId, $prizeAmount);
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error ending game: " . $e->getMessage());
        }
    }

    private function nextTurn() {
        $currentIndex = array_search(
            $this->gameState['currentPlayer'], 
            array_column($this->gameState['players'], 'user_id')
        );
        
        $nextIndex = ($currentIndex + 1) % count($this->gameState['players']);
        $this->gameState['currentPlayer'] = $this->gameState['players'][$nextIndex]['user_id'];
        $this->gameState['turnTimeLeft'] = 15;
        $this->gameState['diceValue'] = null;

        // Handle bot turn if next player is bot
        if ($this->isBot($this->gameState['currentPlayer'])) {
            $this->handleBotTurn();
        }
    }

    private function handleBotTurn() {
        // Simulate thinking time
        sleep(1);

        // Roll dice
        $diceValue = $this->rollDice();
        $this->gameState['diceValue'] = $diceValue;
        $this->broadcastGameState();

        sleep(1);

        // Make move based on bot strategy
        $this->makeBotMove();
    }

    private function makeBotMove() {
        // Implement bot strategy based on probabilities
        $shouldWin = $this->shouldBotWin();
        
        if ($shouldWin) {
            // Make optimal move
            $this->makeOptimalBotMove();
        } else {
            // Make suboptimal move
            $this->makeSuboptimalBotMove();
        }
    }

    private function shouldBotWin() {
        $probability = $this->botProbabilities[$this->gameState['botCount']] ?? 0;
        return (mt_rand() / mt_getrandmax()) < $probability;
    }

    private function makeOptimalBotMove() {
        // Implement optimal bot move strategy
    }

    private function makeSuboptimalBotMove() {
        // Implement suboptimal bot move strategy
    }

    private function broadcastGameState() {
        // Implement WebSocket broadcast
    }

    private function broadcastGameOver($winnerId, $prizeAmount) {
        // Implement WebSocket broadcast
    }

    private function getGameDetails($gameId) {
        $stmt = $this->db->prepare("
            SELECT * FROM game_sessions WHERE id = ?
        ");
        $stmt->execute([$gameId]);
        return $stmt->fetch();
    }

    private function handleChat($data) {
        // Implement chat functionality
        return [
            'success' => true,
            'message' => $data['message']
        ];
    }
}
