<?php
abstract class BaseGame {
    protected $db;
    protected $gameType;
    protected $gameState;
    protected $roomManager;
    protected $config;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->roomManager = new RoomManager();
        $this->config = require __DIR__ . '/../../config/websocket.php';
    }

    /**
     * Initialize a new game session
     */
    abstract public function initializeGame($gameId);

    /**
     * Process a player's move
     */
    abstract public function processMove($gameId, $userId, $move);

    /**
     * Get current game state
     */
    abstract public function getGameState($gameId);

    /**
     * Check if game is over
     */
    abstract public function checkGameOver($gameId);

    /**
     * Handle player disconnection
     */
    abstract public function handleDisconnect($gameId, $userId);

    /**
     * Find or create a game room
     */
    public function findOrCreateRoom($entryFee, $userId) {
        return $this->roomManager->findOrCreateRoom($entryFee, $userId);
    }

    /**
     * Join an existing game
     */
    public function joinGame($gameId, $userId) {
        try {
            $this->db->beginTransaction();

            // Verify game exists and can be joined
            $stmt = $this->db->prepare("
                SELECT * FROM game_sessions 
                WHERE id = ? AND game_type = ? AND status = 'waiting'
            ");
            $stmt->execute([$gameId, $this->gameType]);
            $game = $stmt->fetch();

            if (!$game) {
                throw new Exception("Game not available");
            }

            // Process entry fee
            $wallet = new Wallet($userId);
            if ($wallet->getBalance() < $game['entry_fee']) {
                throw new Exception("Insufficient balance");
            }

            $result = $wallet->processGameEntry($game['entry_fee'], $gameId);
            if (!$result['success']) {
                throw new Exception($result['error']);
            }

            // Add player to game
            $position = $this->roomManager->getNextPosition($gameId);
            $stmt = $this->db->prepare("
                INSERT INTO game_players (
                    session_id,
                    user_id,
                    position,
                    status,
                    joined_at
                ) VALUES (?, ?, ?, 'waiting', NOW())
            ");
            $stmt->execute([$gameId, $userId, $position]);

            $this->db->commit();
            return [
                'success' => true,
                'position' => $position
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Leave a game
     */
    public function leaveGame($gameId, $userId) {
        try {
            $this->db->beginTransaction();

            // Check if game is still waiting
            $stmt = $this->db->prepare("
                SELECT * FROM game_sessions 
                WHERE id = ? AND status = 'waiting'
            ");
            $stmt->execute([$gameId]);
            $game = $stmt->fetch();

            if ($game) {
                // Refund entry fee
                $wallet = new Wallet($userId);
                $wallet->refundGameEntry($game['entry_fee'], $gameId);

                // Remove player from game
                $stmt = $this->db->prepare("
                    DELETE FROM game_players 
                    WHERE session_id = ? AND user_id = ?
                ");
                $stmt->execute([$gameId, $userId]);

                // If no players left, cancel game
                $stmt = $this->db->prepare("
                    SELECT COUNT(*) FROM game_players WHERE session_id = ?
                ");
                $stmt->execute([$gameId]);
                if ($stmt->fetchColumn() === 0) {
                    $stmt = $this->db->prepare("
                        UPDATE game_sessions 
                        SET status = 'cancelled' 
                        WHERE id = ?
                    ");
                    $stmt->execute([$gameId]);
                }
            } else {
                // Game already started, mark player as disconnected
                $stmt = $this->db->prepare("
                    UPDATE game_players 
                    SET status = 'disconnected' 
                    WHERE session_id = ? AND user_id = ?
                ");
                $stmt->execute([$gameId, $userId]);

                $this->handleDisconnect($gameId, $userId);
            }

            $this->db->commit();
            return ['success' => true];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * End game and process winnings
     */
    protected function endGame($gameId, $winnerId) {
        try {
            $this->db->beginTransaction();

            // Update game session
            $stmt = $this->db->prepare("
                UPDATE game_sessions 
                SET status = 'completed',
                    winner_id = ?,
                    completed_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$winnerId, $gameId]);

            // Get game details
            $stmt = $this->db->prepare("
                SELECT * FROM game_sessions WHERE id = ?
            ");
            $stmt->execute([$gameId]);
            $game = $stmt->fetch();

            // Process winnings
            $wallet = new Wallet($winnerId);
            $prizeAmount = $game['prize_pool'];
            $result = $wallet->processWinning($prizeAmount, $gameId);

            if (!$result['success']) {
                throw new Exception("Failed to process winnings");
            }

            // Update player statistics
            $stmt = $this->db->prepare("
                INSERT INTO game_statistics (
                    user_id,
                    game_type,
                    games_played,
                    games_won,
                    total_earnings,
                    highest_win,
                    last_played_at,
                    created_at
                ) VALUES (?, ?, 1, 1, ?, ?, NOW(), NOW())
                ON DUPLICATE KEY UPDATE
                    games_played = games_played + 1,
                    games_won = games_won + 1,
                    total_earnings = total_earnings + VALUES(total_earnings),
                    highest_win = GREATEST(highest_win, VALUES(highest_win)),
                    last_played_at = NOW()
            ");
            $stmt->execute([
                $winnerId,
                $this->gameType,
                $prizeAmount,
                $prizeAmount
            ]);

            // Update other players' statistics
            $stmt = $this->db->prepare("
                INSERT INTO game_statistics (
                    user_id,
                    game_type,
                    games_played,
                    games_won,
                    total_earnings,
                    last_played_at,
                    created_at
                )
                SELECT 
                    user_id,
                    ?,
                    1,
                    0,
                    0,
                    NOW(),
                    NOW()
                FROM game_players
                WHERE session_id = ? AND user_id != ?
                ON DUPLICATE KEY UPDATE
                    games_played = games_played + 1,
                    last_played_at = NOW()
            ");
            $stmt->execute([$this->gameType, $gameId, $winnerId]);

            // Check for achievements
            $this->checkAchievements($winnerId);

            $this->db->commit();
            return [
                'success' => true,
                'prizeAmount' => $prizeAmount
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Check and award achievements
     */
    protected function checkAchievements($userId) {
        try {
            // Get player statistics
            $stmt = $this->db->prepare("
                SELECT * FROM game_statistics 
                WHERE user_id = ? AND game_type = ?
            ");
            $stmt->execute([$userId, $this->gameType]);
            $stats = $stmt->fetch();

            // Get unearned achievements
            $stmt = $this->db->prepare("
                SELECT a.* 
                FROM game_achievements a
                LEFT JOIN user_achievements ua 
                    ON ua.achievement_id = a.id 
                    AND ua.user_id = ?
                WHERE ua.id IS NULL
            ");
            $stmt->execute([$userId]);
            $achievements = $stmt->fetchAll();

            foreach ($achievements as $achievement) {
                $criteria = json_decode($achievement['criteria'], true);
                $earned = true;

                foreach ($criteria as $key => $value) {
                    if (!isset($stats[$key]) || $stats[$key] < $value) {
                        $earned = false;
                        break;
                    }
                }

                if ($earned) {
                    // Award achievement
                    $stmt = $this->db->prepare("
                        INSERT INTO user_achievements (
                            user_id,
                            achievement_id,
                            achieved_at
                        ) VALUES (?, ?, NOW())
                    ");
                    $stmt->execute([$userId, $achievement['id']]);

                    // Process reward
                    $this->processAchievementReward($userId, $achievement);
                }
            }
        } catch (Exception $e) {
            error_log("Error checking achievements: " . $e->getMessage());
        }
    }

    /**
     * Process achievement reward
     */
    protected function processAchievementReward($userId, $achievement) {
        try {
            switch ($achievement['reward_type']) {
                case 'bonus':
                    $wallet = new Wallet($userId);
                    $wallet->addBonus(
                        floatval($achievement['reward_value']),
                        "Achievement: {$achievement['name']}"
                    );
                    break;

                case 'points':
                    // Add points to user profile
                    $stmt = $this->db->prepare("
                        UPDATE users 
                        SET points = points + ? 
                        WHERE id = ?
                    ");
                    $stmt->execute([
                        intval($achievement['reward_value']),
                        $userId
                    ]);
                    break;

                case 'badge':
                    // Badge is automatically added through user_achievements table
                    break;
            }
        } catch (Exception $e) {
            error_log("Error processing achievement reward: " . $e->getMessage());
        }
    }
}
