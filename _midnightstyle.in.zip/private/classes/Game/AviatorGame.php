<?php
require_once __DIR__ . '/BaseGame.php';

class AviatorGame extends BaseGame {
    protected $gameType = 'aviator';
    private $maxMultiplier = 100.0;
    private $minBet = 10;
    private $maxBet = 10000;
    private $crashPoints = [];

    public function __construct() {
        parent::__construct();
        $this->loadRecentCrashPoints();
    }

    /**
     * Initialize a new game session
     */
    public function initializeGame($gameId) {
        try {
            $this->db->beginTransaction();

            // Generate crash point for this round
            $crashPoint = $this->generateCrashPoint();
            
            $this->gameState = [
                'gameId' => $gameId,
                'status' => 'waiting',
                'currentMultiplier' => 1.00,
                'crashPoint' => $crashPoint,
                'startTime' => null,
                'endTime' => null,
                'players' => [],
                'cashouts' => []
            ];

            // Store crash point in database
            $stmt = $this->db->prepare("
                UPDATE game_sessions 
                SET metadata = JSON_SET(
                    COALESCE(metadata, '{}'),
                    '$.crashPoint', ?,
                    '$.startTime', NULL,
                    '$.endTime', NULL
                )
                WHERE id = ?
            ");
            $stmt->execute([$crashPoint, $gameId]);

            $this->db->commit();
            return true;
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Error initializing Aviator game: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Process player bet
     */
    public function placeBet($gameId, $userId, $amount, $autoCashoutAt = null) {
        try {
            $this->db->beginTransaction();

            // Validate bet amount
            if ($amount < $this->minBet || $amount > $this->maxBet) {
                throw new Exception("Invalid bet amount");
            }

            // Check if game is in waiting state
            $stmt = $this->db->prepare("
                SELECT status, metadata FROM game_sessions WHERE id = ?
            ");
            $stmt->execute([$gameId]);
            $game = $stmt->fetch();

            if ($game['status'] !== 'waiting') {
                throw new Exception("Game has already started");
            }

            // Process bet amount
            $wallet = new Wallet($userId);
            $result = $wallet->processGameEntry($amount, $gameId);
            if (!$result['success']) {
                throw new Exception($result['error']);
            }

            // Record player bet
            $stmt = $this->db->prepare("
                INSERT INTO game_players (
                    session_id,
                    user_id,
                    bet_amount,
                    auto_cashout_at,
                    status,
                    joined_at
                ) VALUES (?, ?, ?, ?, 'playing', NOW())
            ");
            $stmt->execute([$gameId, $userId, $amount, $autoCashoutAt]);

            $this->db->commit();
            return ['success' => true];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Process player cashout
     */
    public function processCashout($gameId, $userId) {
        try {
            $this->db->beginTransaction();

            // Get game state
            $stmt = $this->db->prepare("
                SELECT gs.status, gs.metadata, gp.bet_amount 
                FROM game_sessions gs
                JOIN game_players gp ON gs.id = gp.session_id
                WHERE gs.id = ? AND gp.user_id = ?
            ");
            $stmt->execute([$gameId, $userId]);
            $game = $stmt->fetch();

            if (!$game || $game['status'] !== 'playing') {
                throw new Exception("Invalid game state");
            }

            $metadata = json_decode($game['metadata'], true);
            $currentMultiplier = $metadata['currentMultiplier'];

            // Calculate winnings
            $winAmount = $game['bet_amount'] * $currentMultiplier;

            // Process winnings
            $wallet = new Wallet($userId);
            $result = $wallet->processWinning($winAmount, $gameId);
            if (!$result['success']) {
                throw new Exception($result['error']);
            }

            // Record cashout
            $stmt = $this->db->prepare("
                UPDATE game_players 
                SET 
                    status = 'cashed_out',
                    cashout_multiplier = ?,
                    winnings = ?,
                    cashout_time = NOW()
                WHERE session_id = ? AND user_id = ?
            ");
            $stmt->execute([
                $currentMultiplier,
                $winAmount,
                $gameId,
                $userId
            ]);

            $this->db->commit();
            return [
                'success' => true,
                'multiplier' => $currentMultiplier,
                'winAmount' => $winAmount
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Start the game round
     */
    public function startGame($gameId) {
        try {
            $this->db->beginTransaction();

            // Update game status
            $stmt = $this->db->prepare("
                UPDATE game_sessions 
                SET 
                    status = 'playing',
                    started_at = NOW(),
                    metadata = JSON_SET(
                        metadata,
                        '$.startTime', NOW(3)
                    )
                WHERE id = ?
            ");
            $stmt->execute([$gameId]);

            $this->db->commit();
            return ['success' => true];
        } catch (Exception $e) {
            $this->db->rollBack();
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Update game state
     */
    public function updateGameState($gameId) {
        try {
            $stmt = $this->db->prepare("
                SELECT metadata FROM game_sessions WHERE id = ?
            ");
            $stmt->execute([$gameId]);
            $game = $stmt->fetch();

            $metadata = json_decode($game['metadata'], true);
            $startTime = strtotime($metadata['startTime']);
            $crashPoint = $metadata['crashPoint'];
            
            $currentTime = microtime(true);
            $elapsed = $currentTime - $startTime;
            
            // Calculate current multiplier based on elapsed time
            $currentMultiplier = $this->calculateMultiplier($elapsed);

            // Check if game should crash
            if ($currentMultiplier >= $crashPoint) {
                return $this->endGame($gameId);
            }

            // Update current multiplier
            $stmt = $this->db->prepare("
                UPDATE game_sessions 
                SET metadata = JSON_SET(
                    metadata,
                    '$.currentMultiplier', ?
                )
                WHERE id = ?
            ");
            $stmt->execute([$currentMultiplier, $gameId]);

            // Process auto-cashouts
            $this->processAutoCashouts($gameId, $currentMultiplier);

            return [
                'success' => true,
                'multiplier' => $currentMultiplier
            ];
        } catch (Exception $e) {
            error_log("Error updating game state: " . $e->getMessage());
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }

    /**
     * Process auto-cashouts
     */
    private function processAutoCashouts($gameId, $currentMultiplier) {
        try {
            $stmt = $this->db->prepare("
                SELECT user_id 
                FROM game_players 
                WHERE session_id = ? 
                AND status = 'playing'
                AND auto_cashout_at <= ?
            ");
            $stmt->execute([$gameId, $currentMultiplier]);
            
            while ($player = $stmt->fetch()) {
                $this->processCashout($gameId, $player['user_id']);
            }
        } catch (Exception $e) {
            error_log("Error processing auto-cashouts: " . $e->getMessage());
        }
    }

    /**
     * Calculate current multiplier based on elapsed time
     */
    private function calculateMultiplier($elapsed) {
        // Use exponential growth function
        return pow(Math.E, 0.1 * $elapsed);
    }

    /**
     * Generate crash point
     */
    private function generateCrashPoint() {
        // Use house edge and random number to generate crash point
        $houseEdge = 0.05; // 5% house edge
        $r = random_int(0, PHP_INT_MAX) / PHP_INT_MAX;
        
        return max(1.00, (1 / $r) * (1 - $houseEdge));
    }

    /**
     * Load recent crash points
     */
    private function loadRecentCrashPoints() {
        try {
            $stmt = $this->db->prepare("
                SELECT metadata->>'$.crashPoint' as crash_point
                FROM game_sessions
                WHERE game_type = 'aviator'
                AND status = 'completed'
                ORDER BY completed_at DESC
                LIMIT 50
            ");
            $stmt->execute();
            $this->crashPoints = $stmt->fetchAll(PDO::FETCH_COLUMN);
        } catch (Exception $e) {
            error_log("Error loading crash points: " . $e->getMessage());
            $this->crashPoints = [];
        }
    }

    /**
     * Get recent crash points
     */
    public function getRecentCrashPoints() {
        return $this->crashPoints;
    }

    /**
     * Handle player disconnection
     */
    public function handleDisconnect($gameId, $userId) {
        // In Aviator, disconnections don't affect the game
        // Players can reconnect and continue playing
        return true;
    }

    /**
     * Get current game state
     */
    public function getGameState($gameId) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    gs.*,
                    JSON_ARRAYAGG(
                        JSON_OBJECT(
                            'userId', gp.user_id,
                            'betAmount', gp.bet_amount,
                            'status', gp.status,
                            'autoCashoutAt', gp.auto_cashout_at,
                            'cashoutMultiplier', gp.cashout_multiplier,
                            'winnings', gp.winnings
                        )
                    ) as players
                FROM game_sessions gs
                LEFT JOIN game_players gp ON gs.id = gp.session_id
                WHERE gs.id = ?
                GROUP BY gs.id
            ");
            $stmt->execute([$gameId]);
            return $stmt->fetch();
        } catch (Exception $e) {
            error_log("Error getting game state: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Check if game is over
     */
    public function checkGameOver($gameId) {
        try {
            $stmt = $this->db->prepare("
                SELECT COUNT(*) 
                FROM game_players 
                WHERE session_id = ? 
                AND status = 'playing'
            ");
            $stmt->execute([$gameId]);
            return $stmt->fetchColumn() === 0;
        } catch (Exception $e) {
            error_log("Error checking game over: " . $e->getMessage());
            return true;
        }
    }

    /**
     * Process move (not used in Aviator)
     */
    public function processMove($gameId, $userId, $move) {
        throw new Exception("Not applicable for Aviator game");
    }
}
