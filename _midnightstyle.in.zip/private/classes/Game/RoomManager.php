<?php
class RoomManager {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Find or create a game room for the given entry fee
     */
    public function findOrCreateRoom($entryFee, $userId) {
        try {
            $this->db->beginTransaction();

            // First, try to find an existing room with the same entry fee
            $stmt = $this->db->prepare("
                SELECT gs.id, COUNT(gp.id) as player_count
                FROM game_sessions gs
                LEFT JOIN game_players gp ON gs.id = gp.session_id
                WHERE gs.game_type = 'ludo'
                AND gs.entry_fee = ?
                AND gs.status = 'waiting'
                AND gs.waiting_until > NOW()
                GROUP BY gs.id
                HAVING player_count < 4
                ORDER BY gs.created_at ASC
                LIMIT 1
                FOR UPDATE
            ");
            $stmt->execute([$entryFee]);
            $existingRoom = $stmt->fetch();

            if ($existingRoom) {
                // Join existing room
                $gameId = $existingRoom['id'];
                $position = $this->getNextPosition($gameId);
                
                // Add player to room
                $this->addPlayerToRoom($gameId, $userId, $position);
                
                $this->db->commit();
                return [
                    'gameId' => $gameId,
                    'position' => $position,
                    'isNew' => false
                ];
            } else {
                // Create new room
                $stmt = $this->db->prepare("
                    INSERT INTO game_sessions (
                        game_type,
                        entry_fee,
                        prize_pool,
                        status,
                        waiting_until,
                        created_at
                    ) VALUES (
                        'ludo',
                        ?,
                        ?,
                        'waiting',
                        DATE_ADD(NOW(), INTERVAL 30 SECOND),
                        NOW()
                    )
                ");
                $stmt->execute([
                    $entryFee,
                    $entryFee * 4 * 0.8 // 80% of total pool
                ]);
                
                $gameId = $this->db->lastInsertId();
                
                // Add first player
                $this->addPlayerToRoom($gameId, $userId, 1);
                
                $this->db->commit();
                return [
                    'gameId' => $gameId,
                    'position' => 1,
                    'isNew' => true
                ];
            }
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Get next available position in room
     */
    private function getNextPosition($gameId) {
        $stmt = $this->db->prepare("
            SELECT position 
            FROM game_players 
            WHERE session_id = ?
        ");
        $stmt->execute([$gameId]);
        $positions = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        for ($i = 1; $i <= 4; $i++) {
            if (!in_array($i, $positions)) {
                return $i;
            }
        }
        throw new Exception("Room is full");
    }

    /**
     * Add player to room
     */
    private function addPlayerToRoom($gameId, $userId, $position) {
        // Process entry fee
        $stmt = $this->db->prepare("
            SELECT entry_fee FROM game_sessions WHERE id = ?
        ");
        $stmt->execute([$gameId]);
        $entryFee = $stmt->fetchColumn();

        $wallet = new Wallet($userId);
        $result = $wallet->processGameEntry($entryFee, $gameId);
        
        if (!$result['success']) {
            throw new Exception($result['error']);
        }

        // Add player to game
        $stmt = $this->db->prepare("
            INSERT INTO game_players (
                session_id,
                user_id,
                position,
                status,
                joined_at
            ) VALUES (?, ?, ?, 'waiting', NOW())
        ");
        $stmt->execute([$gameId, $userId, $position]);

        // Check if room is full
        $stmt = $this->db->prepare("
            SELECT COUNT(*) FROM game_players WHERE session_id = ?
        ");
        $stmt->execute([$gameId]);
        $playerCount = $stmt->fetchColumn();

        if ($playerCount === 4) {
            // Start game immediately
            $stmt = $this->db->prepare("
                UPDATE game_sessions 
                SET status = 'playing',
                    started_at = NOW() 
                WHERE id = ?
            ");
            $stmt->execute([$gameId]);
        }
    }

    /**
     * Clean up expired waiting rooms
     */
    public function cleanupExpiredRooms() {
        try {
            $this->db->beginTransaction();

            // Get expired rooms
            $stmt = $this->db->prepare("
                SELECT id, entry_fee 
                FROM game_sessions 
                WHERE status = 'waiting' 
                AND waiting_until < NOW()
            ");
            $stmt->execute();
            $expiredRooms = $stmt->fetchAll();

            foreach ($expiredRooms as $room) {
                // Refund entry fees
                $stmt = $this->db->prepare("
                    SELECT user_id 
                    FROM game_players 
                    WHERE session_id = ?
                ");
                $stmt->execute([$room['id']]);
                $players = $stmt->fetchAll();

                foreach ($players as $player) {
                    $wallet = new Wallet($player['user_id']);
                    $wallet->refundGameEntry($room['entry_fee'], $room['id']);
                }

                // Cancel room
                $stmt = $this->db->prepare("
                    UPDATE game_sessions 
                    SET status = 'cancelled' 
                    WHERE id = ?
                ");
                $stmt->execute([$room['id']]);
            }

            $this->db->commit();
        } catch (Exception $e) {
            $this->db->rollBack();
            throw $e;
        }
    }

    /**
     * Get active rooms with specific entry fee
     */
    public function getActiveRooms($entryFee = null) {
        $sql = "
            SELECT 
                gs.id,
                gs.entry_fee,
                gs.prize_pool,
                gs.status,
                gs.waiting_until,
                COUNT(gp.id) as player_count,
                GROUP_CONCAT(
                    JSON_OBJECT(
                        'userId', gp.user_id,
                        'position', gp.position,
                        'status', gp.status
                    )
                ) as players
            FROM game_sessions gs
            LEFT JOIN game_players gp ON gs.id = gp.session_id
            WHERE gs.game_type = 'ludo'
            AND gs.status IN ('waiting', 'playing')
        ";

        if ($entryFee !== null) {
            $sql .= " AND gs.entry_fee = ?";
        }

        $sql .= " GROUP BY gs.id ORDER BY gs.created_at DESC";

        $stmt = $this->db->prepare($sql);
        
        if ($entryFee !== null) {
            $stmt->execute([$entryFee]);
        } else {
            $stmt->execute();
        }

        return $stmt->fetchAll();
    }
}
