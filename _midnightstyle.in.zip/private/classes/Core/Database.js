<?php
class Database {
    private static $instance = null;
    private $connection = null;
    private $config;

    private function __construct() {
        $this->loadConfig();
        $this->connect();
    }

    private function loadConfig() {
        $configFile = __DIR__ . '/../../config/database.php';
        if (!file_exists($configFile)) {
            throw new Exception('Database configuration file not found');
        }
        $this->config = require $configFile;
    }

    private function connect() {
        try {
            $dsn = "mysql:host={$this->config['host']};dbname={$this->config['database']};charset=utf8mb4";
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];

            $this->connection = new PDO(
                $dsn,
                $this->config['username'],
                $this->config['password'],
                $options
            );
        } catch (PDOException $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new Exception('Database connection failed');
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        if ($this->connection === null) {
            $this->connect();
        }
        return $this->connection;
    }

    public function beginTransaction() {
        return $this->connection->beginTransaction();
    }

    public function commit() {
        return $this->connection->commit();
    }

    public function rollBack() {
        return $this->connection->rollBack();
    }

    public function prepare($query) {
        return $this->connection->prepare($query);
    }

    public function lastInsertId() {
        return $this->connection->lastInsertId();
    }

    public function quote($value) {
        return $this->connection->quote($value);
    }

    public function query($query) {
        return $this->connection->query($query);
    }

    public function exec($query) {
        return $this->connection->exec($query);
    }

    public function inTransaction() {
        return $this->connection->inTransaction();
    }

    public function setAttribute($attribute, $value) {
        return $this->connection->setAttribute($attribute, $value);
    }

    public function getAttribute($attribute) {
        return $this->connection->getAttribute($attribute);
    }

    public function errorCode() {
        return $this->connection->errorCode();
    }

    public function errorInfo() {
        return $this->connection->errorInfo();
    }

    // Prevent cloning of instance
    private function __clone() {}

    // Prevent unserialize of instance
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }

    // Helper methods for common operations
    public function fetchOne($query, $params = []) {
        try {
            $stmt = $this->prepare($query);
            $stmt->execute($params);
            return $stmt->fetch();
        } catch (PDOException $e) {
            error_log("Database query failed: " . $e->getMessage());
            throw new Exception('Database query failed');
        }
    }

    public function fetchAll($query, $params = []) {
        try {
            $stmt = $this->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            error_log("Database query failed: " . $e->getMessage());
            throw new Exception('Database query failed');
        }
    }

    public function execute($query, $params = []) {
        try {
            $stmt = $this->prepare($query);
            return $stmt->execute($params);
        } catch (PDOException $e) {
            error_log("Database query failed: " . $e->getMessage());
            throw new Exception('Database query failed');
        }
    }

    public function insert($table, $data) {
        try {
            $fields = array_keys($data);
            $values = array_values($data);
            $placeholders = array_fill(0, count($fields), '?');

            $query = sprintf(
                "INSERT INTO %s (%s) VALUES (%s)",
                $table,
                implode(', ', $fields),
                implode(', ', $placeholders)
            );

            $stmt = $this->prepare($query);
            $stmt->execute($values);
            return $this->lastInsertId();
        } catch (PDOException $e) {
            error_log("Database insert failed: " . $e->getMessage());
            throw new Exception('Database insert failed');
        }
    }

    public function update($table, $data, $where, $whereParams = []) {
        try {
            $fields = array_keys($data);
            $set = array_map(function($field) {
                return "$field = ?";
            }, $fields);

            $query = sprintf(
                "UPDATE %s SET %s WHERE %s",
                $table,
                implode(', ', $set),
                $where
            );

            $params = array_merge(array_values($data), $whereParams);
            $stmt = $this->prepare($query);
            return $stmt->execute($params);
        } catch (PDOException $e) {
            error_log("Database update failed: " . $e->getMessage());
            throw new Exception('Database update failed');
        }
    }

    public function delete($table, $where, $params = []) {
        try {
            $query = sprintf("DELETE FROM %s WHERE %s", $table, $where);
            $stmt = $this->prepare($query);
            return $stmt->execute($params);
        } catch (PDOException $e) {
            error_log("Database delete failed: " . $e->getMessage());
            throw new Exception('Database delete failed');
        }
    }
}
