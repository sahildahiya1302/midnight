<?php
class Session {
    private static $instance = null;
    private $config;
    private $started = false;

    private function __construct() {
        $this->loadConfig();
        $this->initialize();
    }

    private function loadConfig() {
        $configFile = __DIR__ . '/../../config/session.php';
        if (!file_exists($configFile)) {
            throw new Exception('Session configuration file not found');
        }
        $this->config = require $configFile;
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function initialize() {
        if ($this->started) {
            return;
        }

        // Set session handler
        if ($this->config['handler'] === 'files') {
            $this->initializeFileHandler();
        } elseif ($this->config['handler'] === 'database') {
            $this->initializeDatabaseHandler();
        }

        // Set session cookie parameters
        session_set_cookie_params([
            'lifetime' => $this->config['cookie']['lifetime'],
            'path' => $this->config['cookie']['path'],
            'domain' => $this->config['cookie']['domain'],
            'secure' => $this->config['cookie']['secure'],
            'httponly' => $this->config['cookie']['httponly'],
            'samesite' => $this->config['cookie']['samesite']
        ]);

        // Set session name
        session_name($this->config['name']);

        // Start session
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Set security headers
        $this->setSecurityHeaders();

        // Initialize session data
        $this->initializeSessionData();

        $this->started = true;
    }

    private function initializeFileHandler() {
        $fileConfig = $this->config['handlers']['files'];
        
        // Ensure session directory exists
        if (!file_exists($fileConfig['save_path'])) {
            mkdir($fileConfig['save_path'], 0755, true);
        }
        
        // Configure session settings
        ini_set('session.save_handler', 'files');
        ini_set('session.save_path', $fileConfig['save_path']);
        ini_set('session.gc_probability', $fileConfig['gc_probability']);
        ini_set('session.gc_divisor', $fileConfig['gc_divisor']);
        ini_set('session.gc_maxlifetime', $fileConfig['gc_maxlifetime']);
    }

    private function initializeDatabaseHandler() {
        $dbConfig = $this->config['handlers']['database'];
        
        $sessionHandler = new DatabaseSessionHandler(
            Database::getInstance(),
            $dbConfig['table'],
            $dbConfig['encrypt']
        );

        session_set_save_handler($sessionHandler, true);
    }

    private function setSecurityHeaders() {
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
    }

    private function initializeSessionData() {
        // Regenerate session ID periodically
        if (!isset($_SESSION['_last_regenerated']) ||
            (time() - $_SESSION['_last_regenerated']) > $this->config['security']['regenerate_interval']) {
            $this->regenerateId();
        }

        // Set session expiry
        if (!isset($_SESSION['_expires']) || time() > $_SESSION['_expires']) {
            $_SESSION['_expires'] = time() + $this->config['lifetime'];
        }

        // Validate session fingerprint
        if (isset($_SESSION['_fingerprint'])) {
            $currentFingerprint = $this->generateFingerprint();
            
            if ($_SESSION['_fingerprint'] !== $currentFingerprint) {
                $this->destroy();
                $this->start();
            }
        }

        // Set session fingerprint
        $_SESSION['_fingerprint'] = $this->generateFingerprint();
    }

    private function generateFingerprint() {
        $data = '';
        
        if ($this->config['security']['fingerprint']['include_ip']) {
            $data .= $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
        }
        
        if ($this->config['security']['fingerprint']['include_ua']) {
            $data .= $_SERVER['HTTP_USER_AGENT'] ?? 'CLI';
        }
        
        return hash('sha256', $data);
    }

    public function start() {
        if ($this->started) {
            return;
        }

        $this->initialize();
    }

    public function regenerateId($deleteOldSession = true) {
        session_regenerate_id($deleteOldSession);
        $_SESSION['_last_regenerated'] = time();
    }

    public function destroy() {
        if ($this->started) {
            session_unset();
            session_destroy();
            $this->started = false;
        }
    }

    public function get($key, $default = null) {
        return $_SESSION[$key] ?? $default;
    }

    public function set($key, $value) {
        $_SESSION[$key] = $value;
    }

    public function has($key) {
        return isset($_SESSION[$key]);
    }

    public function remove($key) {
        unset($_SESSION[$key]);
    }

    public function clear() {
        session_unset();
    }

    public function all() {
        return $_SESSION;
    }

    public function flash($key, $value) {
        $_SESSION['_flash'][$key] = $value;
    }

    public function getFlash($key, $default = null) {
        if (isset($_SESSION['_flash'][$key])) {
            $value = $_SESSION['_flash'][$key];
            unset($_SESSION['_flash'][$key]);
            return $value;
        }
        return $default;
    }

    public function hasFlash($key) {
        return isset($_SESSION['_flash'][$key]);
    }

    public function clearFlash() {
        unset($_SESSION['_flash']);
    }

    public function getId() {
        return session_id();
    }

    public function getName() {
        return session_name();
    }

    public function isStarted() {
        return $this->started;
    }

    public function getConfig() {
        return $this->config;
    }

    // Prevent cloning of instance
    private function __clone() {}

    // Prevent unserialize of instance
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

class DatabaseSessionHandler implements SessionHandlerInterface {
    private $db;
    private $table;
    private $encrypt;

    public function __construct($db, $table, $encrypt = true) {
        $this->db = $db;
        $this->table = $table;
        $this->encrypt = $encrypt;
    }

    public function open($savePath, $sessionName) {
        return true;
    }

    public function close() {
        return true;
    }

    public function read($id) {
        $stmt = $this->db->prepare("
            SELECT data FROM {$this->table}
            WHERE id = ? AND expires > ?
        ");
        $stmt->execute([$id, time()]);
        
        if ($row = $stmt->fetch()) {
            return $this->encrypt ? 
                   $this->decrypt($row['data']) : 
                   $row['data'];
        }
        
        return '';
    }

    public function write($id, $data) {
        $expires = time() + ini_get('session.gc_maxlifetime');
        $data = $this->encrypt ? $this->encrypt($data) : $data;
        
        $stmt = $this->db->prepare("
            REPLACE INTO {$this->table}
            (id, data, expires) VALUES (?, ?, ?)
        ");
        
        return $stmt->execute([$id, $data, $expires]);
    }

    public function destroy($id) {
        $stmt = $this->db->prepare("
            DELETE FROM {$this->table}
            WHERE id = ?
        ");
        
        return $stmt->execute([$id]);
    }

    public function gc($maxlifetime) {
        $stmt = $this->db->prepare("
            DELETE FROM {$this->table}
            WHERE expires < ?
        ");
        
        return $stmt->execute([time()]);
    }

    private function encrypt($data) {
        $key = $this->getEncryptionKey();
        $iv = random_bytes(16);
        $encrypted = openssl_encrypt(
            $data,
            'AES-256-CBC',
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );
        return base64_encode($iv . $encrypted);
    }

    private function decrypt($data) {
        $key = $this->getEncryptionKey();
        $data = base64_decode($data);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        return openssl_decrypt(
            $encrypted,
            'AES-256-CBC',
            $key,
            OPENSSL_RAW_DATA,
            $iv
        );
    }

    private function getEncryptionKey() {
        $keyFile = __DIR__ . '/../../config/encryption_key.php';
        if (!file_exists($keyFile)) {
            throw new Exception('Encryption key file not found');
        }
        return require $keyFile;
    }
}
