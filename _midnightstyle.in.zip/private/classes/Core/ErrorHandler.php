<?php
class ErrorHandler {
    private static $logFile;
    private static $displayErrors;
    
    public static function initialize($logFile = null, $displayErrors = false) {
        self::$logFile = $logFile ?: __DIR__ . '/../../logs/error.log';
        self::$displayErrors = $displayErrors;
        
        // Ensure log directory exists
        $logDir = dirname(self::$logFile);
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        // Set error handlers
        set_error_handler([self::class, 'handleError']);
        set_exception_handler([self::class, 'handleException']);
        register_shutdown_function([self::class, 'handleFatalError']);
        
        // Enable error logging
        ini_set('log_errors', 1);
        ini_set('error_log', self::$logFile);
        
        // Control error display
        ini_set('display_errors', self::$displayErrors ? 1 : 0);
        error_reporting(E_ALL);
    }
    
    public static function handleError($errno, $errstr, $errfile, $errline) {
        if (!(error_reporting() & $errno)) {
            return false;
        }
        
        $errorType = self::getErrorType($errno);
        $message = "[$errorType] $errstr in $errfile on line $errline";
        
        self::logError($message);
        
        if (self::$displayErrors) {
            echo self::formatErrorMessage($message);
        } else {
            self::showErrorPage(500);
        }
        
        return true;
    }
    
    public static function handleException($exception) {
        $message = "[Exception] {$exception->getMessage()} in {$exception->getFile()} on line {$exception->getLine()}\n";
        $message .= "Stack trace:\n{$exception->getTraceAsString()}";
        
        self::logError($message);
        
        if (self::$displayErrors) {
            echo self::formatErrorMessage($message);
        } else {
            self::showErrorPage(500);
        }
    }
    
    public static function handleFatalError() {
        $error = error_get_last();
        
        if ($error !== null && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
            $message = "[Fatal Error] {$error['message']} in {$error['file']} on line {$error['line']}";
            
            self::logError($message);
            
            if (self::$displayErrors) {
                echo self::formatErrorMessage($message);
            } else {
                self::showErrorPage(500);
            }
        }
    }
    
    private static function getErrorType($errno) {
        switch ($errno) {
            case E_ERROR:
                return 'Error';
            case E_WARNING:
                return 'Warning';
            case E_PARSE:
                return 'Parse Error';
            case E_NOTICE:
                return 'Notice';
            case E_CORE_ERROR:
                return 'Core Error';
            case E_CORE_WARNING:
                return 'Core Warning';
            case E_COMPILE_ERROR:
                return 'Compile Error';
            case E_COMPILE_WARNING:
                return 'Compile Warning';
            case E_USER_ERROR:
                return 'User Error';
            case E_USER_WARNING:
                return 'User Warning';
            case E_USER_NOTICE:
                return 'User Notice';
            case E_STRICT:
                return 'Strict';
            case E_RECOVERABLE_ERROR:
                return 'Recoverable Error';
            case E_DEPRECATED:
                return 'Deprecated';
            case E_USER_DEPRECATED:
                return 'User Deprecated';
            default:
                return 'Unknown Error';
        }
    }
    
    private static function logError($message) {
        $timestamp = date('Y-m-d H:i:s');
        $logMessage = "[$timestamp] $message\n";
        error_log($logMessage, 3, self::$logFile);
    }
    
    private static function formatErrorMessage($message) {
        return "<pre style='color: red; background: #ffebee; padding: 10px; border: 1px solid #ffcdd2; border-radius: 4px;'>" . 
               htmlspecialchars($message) . 
               "</pre>";
    }
    
    private static function showErrorPage($code) {
        http_response_code($code);
        
        if (file_exists($_SERVER['DOCUMENT_ROOT'] . "/views/errors/{$code}.php")) {
            require $_SERVER['DOCUMENT_ROOT'] . "/views/errors/{$code}.php";
        } else {
            echo "<h1>Error {$code}</h1>";
            echo "<p>An error occurred while processing your request.</p>";
        }
        
        exit;
    }
}
