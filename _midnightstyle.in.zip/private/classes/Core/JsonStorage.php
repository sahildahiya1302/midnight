<?php

class JsonStorage implements IStorage {
    private $dataPath;
    private $lockTimeout = 10; // seconds
    private $inTransaction = false;
    private $transactionData = [];
    
    public function __construct() {
        $this->dataPath = __DIR__ . '/../../storage/data/';
        $this->ensureDataDirectory();
    }

    private function ensureDataDirectory() {
        if (!file_exists($this->dataPath)) {
            if (!mkdir($this->dataPath, 0755, true)) {
                throw new Exception("Failed to create data directory");
            }
        }
    }

    private function getFilePath($table) {
        return $this->dataPath . $table . '.json';
    }

    private function loadData($table) {
        $filePath = $this->getFilePath($table);
        if (!file_exists($filePath)) {
            return ['data' => [], 'last_id' => 0];
        }

        $fp = fopen($filePath, 'r');
        if (!$fp) {
            throw new Exception("Cannot open file: $filePath");
        }

        if (!flock($fp, LOCK_SH)) {
            fclose($fp);
            throw new Exception("Cannot acquire shared lock");
        }

        $content = '';
        while (!feof($fp)) {
            $content .= fread($fp, 8192);
        }

        flock($fp, LOCK_UN);
        fclose($fp);

        $data = json_decode($content, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("JSON decode error: " . json_last_error_msg());
        }

        return $data;
    }

    private function saveData($table, $data) {
        $filePath = $this->getFilePath($table);
        $fp = fopen($filePath, 'w');
        if (!$fp) {
            throw new Exception("Cannot open file for writing: $filePath");
        }

        if (!flock($fp, LOCK_EX)) {
            fclose($fp);
            throw new Exception("Cannot acquire exclusive lock");
        }

        $encoded = json_encode($data, JSON_PRETTY_PRINT);
        if (json_last_error() !== JSON_ERROR_NONE) {
            flock($fp, LOCK_UN);
            fclose($fp);
            throw new Exception("JSON encode error: " . json_last_error_msg());
        }

        if (fwrite($fp, $encoded) === false) {
            flock($fp, LOCK_UN);
            fclose($fp);
            throw new Exception("Failed to write to file");
        }

        flock($fp, LOCK_UN);
        fclose($fp);
    }

    public function fetchOne($query, $params = []) {
        // Parse the query to determine table and conditions
        preg_match('/FROM\s+(\w+)/i', $query, $matches);
        if (empty($matches[1])) {
            throw new Exception("Invalid query format");
        }
        
        $table = $matches[1];
        $data = $this->loadData($table);
        
        // Parse WHERE clause to get column name
        preg_match('/WHERE\s+(\w+)\s*=\s*\?/i', $query, $whereMatches);
        if (!empty($whereMatches[1]) && !empty($params)) {
            $columnName = $whereMatches[1];
            $searchValue = $params[0];
            
            foreach ($data['data'] as $row) {
                if (isset($row[$columnName]) && $row[$columnName] == $searchValue) {
                    return $row;
                }
            }
        }
        
        return null;
    }

    public function fetchAll($query, $params = []) {
        preg_match('/FROM\s+(\w+)/i', $query, $matches);
        if (empty($matches[1])) {
            throw new Exception("Invalid query format");
        }
        
        $table = $matches[1];
        $data = $this->loadData($table);
        
        $results = [];
        foreach ($data['data'] as $row) {
            $match = true;
            if (!empty($params)) {
                foreach ($params as $key => $value) {
                    if (!isset($row[$key]) || $row[$key] != $value) {
                        $match = false;
                        break;
                    }
                }
            }
            if ($match) {
                $results[] = $row;
            }
        }
        
        return $results;
    }

    public function insert($table, $data) {
        $fileData = $this->loadData($table);
        
        // Generate new ID
        $newId = $fileData['last_id'] + 1;
        $data['id'] = $newId;
        
        if ($this->inTransaction) {
            if (!isset($this->transactionData[$table])) {
                $this->transactionData[$table] = $fileData;
            }
            $this->transactionData[$table]['data'][] = $data;
            $this->transactionData[$table]['last_id'] = $newId;
        } else {
            $fileData['data'][] = $data;
            $fileData['last_id'] = $newId;
            $this->saveData($table, $fileData);
        }
        
        return $newId;
    }

    public function update($table, $data, $where, $whereParams = []) {
        $fileData = $this->loadData($table);
        $updated = false;
        
        // Parse WHERE clause to get column name
        preg_match('/(\w+)\s*=\s*\?/', $where, $matches);
        if (!empty($matches[1]) && !empty($whereParams)) {
            $columnName = $matches[1];
            $searchValue = $whereParams[0];
            
            foreach ($fileData['data'] as &$row) {
                if (isset($row[$columnName]) && $row[$columnName] == $searchValue) {
                    foreach ($data as $key => $value) {
                        $row[$key] = $value;
                    }
                    $updated = true;
                    break;
                }
            }
            
            if ($updated) {
                if ($this->inTransaction) {
                    $this->transactionData[$table] = $fileData;
                } else {
                    $this->saveData($table, $fileData);
                }
            }
        }
        
        return $updated;
    }

    public function delete($table, $where, $params = []) {
        $fileData = $this->loadData($table);
        $initialCount = count($fileData['data']);
        
        // Parse WHERE clause to get column name
        preg_match('/(\w+)\s*=\s*\?/', $where, $matches);
        if (!empty($matches[1]) && !empty($params)) {
            $columnName = $matches[1];
            $searchValue = $params[0];
            
            $fileData['data'] = array_values(array_filter($fileData['data'], function($row) use ($columnName, $searchValue) {
                return !isset($row[$columnName]) || $row[$columnName] != $searchValue;
            }));
            
            if (count($fileData['data']) !== $initialCount) {
                if ($this->inTransaction) {
                    $this->transactionData[$table] = $fileData;
                } else {
                    $this->saveData($table, $fileData);
                }
                return true;
            }
        }
        
        return false;
    }

    public function beginTransaction() {
        if ($this->inTransaction) {
            throw new Exception("Transaction already in progress");
        }
        $this->inTransaction = true;
        $this->transactionData = [];
        return true;
    }

    public function commit() {
        if (!$this->inTransaction) {
            throw new Exception("No transaction in progress");
        }
        
        foreach ($this->transactionData as $table => $data) {
            $this->saveData($table, $data);
        }
        
        $this->inTransaction = false;
        $this->transactionData = [];
        return true;
    }

    public function rollBack() {
        if (!$this->inTransaction) {
            throw new Exception("No transaction in progress");
        }
        
        $this->inTransaction = false;
        $this->transactionData = [];
        return true;
    }

    public function lastInsertId() {
        // Return the last ID from the most recently modified table
        if ($this->inTransaction && !empty($this->transactionData)) {
            $lastTable = array_key_last($this->transactionData);
            return $this->transactionData[$lastTable]['last_id'];
        }
        return 0;
    }

    public function getStatus() {
        return [
            'mode' => 'json',
            'transaction' => $this->inTransaction,
            'data_path' => $this->dataPath
        ];
    }
}
