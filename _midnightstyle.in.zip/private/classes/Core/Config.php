<?php
class Config {
    private static $instance = null;
    private $config = [];

    private function __construct() {
        $this->loadConfigurations();
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function loadConfigurations() {
        try {
            // Load environment configuration
            $envFile = __DIR__ . '/../../config/env.php';
            if (file_exists($envFile)) {
                $this->config['env'] = require $envFile;
            } else {
                error_log("Environment config file not found: $envFile");
            }

            // Load database configuration
            $dbFile = __DIR__ . '/../../config/database.php';
            if (file_exists($dbFile)) {
                $this->config['database'] = require $dbFile;
            } else {
                error_log("Database config file not found: $dbFile");
            }

            // Load session configuration
            $sessionFile = __DIR__ . '/../../config/session.php';
            if (file_exists($sessionFile)) {
                $this->config['session'] = require $sessionFile;
            } else {
                error_log("Session config file not found: $sessionFile");
            }

            // Load WebSocket configuration
            $wsFile = __DIR__ . '/../../config/websocket.php';
            if (file_exists($wsFile)) {
                $this->config['websocket'] = require $wsFile;
            } else {
                error_log("WebSocket config file not found: $wsFile");
            }

            // Load payment configuration
            $paymentFile = __DIR__ . '/../../config/payment_credentials.php';
            if (file_exists($paymentFile)) {
                $this->config['payment'] = require $paymentFile;
            } else {
                error_log("Payment config file not found: $paymentFile");
            }

            // Load encryption key
            $encryptionFile = __DIR__ . '/../../config/encryption_key.php';
            if (file_exists($encryptionFile)) {
                $this->config['encryption'] = require $encryptionFile;
            } else {
                error_log("Encryption key file not found: $encryptionFile");
            }

            // Load .env file if exists
            $envFile = __DIR__ . '/../../.env';
            if (file_exists($envFile)) {
                $env = parse_ini_file($envFile);
                if ($env !== false) {
                    foreach ($env as $key => $value) {
                        putenv("$key=$value");
                    }
                } else {
                    error_log("Failed to parse .env file");
                }
            }
        } catch (Exception $e) {
            error_log("Error loading configurations: " . $e->getMessage());
            throw $e;
        }
    }

    public function get($key, $default = null) {
        $keys = explode('.', $key);
        $config = $this->config;

        foreach ($keys as $segment) {
            if (!isset($config[$segment])) {
                return $default;
            }
            $config = $config[$segment];
        }

        return $config;
    }

    public function set($key, $value) {
        $keys = explode('.', $key);
        $config = &$this->config;

        foreach ($keys as $i => $segment) {
            if ($i === count($keys) - 1) {
                $config[$segment] = $value;
                break;
            }

            if (!isset($config[$segment])) {
                $config[$segment] = [];
            }

            $config = &$config[$segment];
        }
    }

    public function has($key) {
        return $this->get($key) !== null;
    }

    public function all() {
        return $this->config;
    }

    public function getEnvironment() {
        return $this->get('env.app.env', 'production');
    }

    public function isDevelopment() {
        return $this->getEnvironment() === 'development';
    }

    public function isStaging() {
        return $this->getEnvironment() === 'staging';
    }

    public function isProduction() {
        return $this->getEnvironment() === 'production';
    }

    public function isDebugEnabled() {
        return $this->get('env.app.debug', false);
    }

    public function getAppUrl() {
        return $this->get('env.app.url', 'https://midnightstyle.in');
    }

    public function getTimezone() {
        return $this->get('env.app.timezone', 'UTC');
    }

    public function getDatabaseConfig() {
        return $this->get('database', []);
    }

    public function getSessionConfig() {
        return $this->get('session', []);
    }

    public function getWebSocketConfig() {
        return $this->get('websocket', []);
    }

    public function getPaymentConfig() {
        return $this->get('payment', []);
    }

    public function getEncryptionKey() {
        return $this->get('encryption', null);
    }

    public function getAdminIPs() {
        return $this->get('env.admin.ips', []);
    }

    public function getFeatureFlags() {
        return $this->get('env.features', []);
    }

    public function isFeatureEnabled($feature) {
        return $this->get("env.features.$feature", false);
    }

    public function getGameConfig() {
        return $this->get('env.game', []);
    }

    // Prevent cloning of instance
    private function __clone() {}

    // Prevent unserialize of instance
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}
