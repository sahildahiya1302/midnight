<?php

class StorageFactory {
    private static $instance = null;
    private static $mode = null;
    private static $lastError = null;

    public static function getStorage() {
        if (self::$instance === null) {
            self::$instance = self::initializeStorage();
        }
        return self::$instance;
    }

    private static function initializeStorage() {
        // First try database connection
        try {
            $db = Database::getInstance();
            // Test the connection with a simple query
            $db->fetchOne("SELECT 1");
            self::$mode = 'database';
            error_log("Successfully connected to database. Using database storage.");
            return $db;
        } catch (Exception $e) {
            self::$lastError = $e->getMessage();
            error_log("Database connection failed: " . $e->getMessage() . ". Falling back to JSON storage.");
            
            // Fallback to JSON storage
            try {
                $jsonStorage = new JsonStorage();
                self::$mode = 'json';
                return $jsonStorage;
            } catch (Exception $e) {
                self::$lastError = $e->getMessage();
                error_log("Critical error: Both database and JSON storage failed: " . $e->getMessage());
                throw new Exception("No storage method available");
            }
        }
    }

    public static function getMode() {
        return self::$mode;
    }

    public static function getLastError() {
        return self::$lastError;
    }

    public static function reset() {
        self::$instance = null;
        self::$mode = null;
        self::$lastError = null;
    }
}
