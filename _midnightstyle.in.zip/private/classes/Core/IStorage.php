<?php

interface IStorage {
    public function fetchOne($query, $params = []);
    public function fetchAll($query, $params = []);
    public function insert($table, $data);
    public function update($table, $data, $where, $whereParams = []);
    public function delete($table, $where, $params = []);
    public function beginTransaction();
    public function commit();
    public function rollBack();
    public function lastInsertId();
    public function getStatus();
}
