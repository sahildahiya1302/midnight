<?php
class WebSocket {
    private static $instance = null;
    private $config;
    private $server;
    private $clients = [];
    private $rooms = [];
    private $handlers = [];
    private $logger;

    private function __construct() {
        $this->config = Config::getInstance()->getWebSocketConfig();
        $this->initializeLogger();
        $this->initializeServer();
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function initializeLogger() {
        $logFile = $this->config['errors']['log_file'];
        $logDir = dirname($logFile);
        
        if (!file_exists($logDir)) {
            mkdir($logDir, 0755, true);
        }
        
        // Ensure the log file is writable and log any issues
        if (!is_writable($logFile)) {
            error_log("Log file is not writable: $logFile");
        }
        if (!is_writable($logFile)) {
            error_log("Log file is not writable: $logFile");
        }
        if (!file_exists($logFile)) {
            file_put_contents($logFile, ""); // Create the log file if it doesn't exist
        }

        $this->logger = new class($logFile) {
            private $file;
            
            public function __construct($file) {
                $this->file = $file;
            }
            
            public function log($level, $message, array $context = []) {
                $timestamp = date('Y-m-d H:i:s');
                $formatted = "[$timestamp] [$level] $message " . 
                           ($context ? json_encode($context) : '') . PHP_EOL;
                file_put_contents($this->file, $formatted, FILE_APPEND);
            }
        };
    }

    private function initializeServer() {
        $context = stream_context_create();
        
        if ($this->config['ssl']['enabled']) {
            stream_context_set_option($context, 'ssl', 'local_cert', $this->config['ssl']['cert_file']);
            stream_context_set_option($context, 'ssl', 'local_pk', $this->config['ssl']['key_file']);
            stream_context_set_option($context, 'ssl', 'verify_peer', $this->config['ssl']['verify_peer']);
            stream_context_set_option($context, 'ssl', 'allow_self_signed', $this->config['ssl']['allow_self_signed']);
        }

        $this->server = stream_socket_server(
            "tcp://{$this->config['server']['host']}:{$this->config['server']['port']}",
            $errno,
            $errstr,
            STREAM_SERVER_BIND | STREAM_SERVER_LISTEN,
            $context
        );

        if (!$this->server) {
            throw new Exception("Could not create WebSocket server: $errstr ($errno)");
        }

        stream_set_blocking($this->server, false);
    }

    public function run() {
        $this->logger->log('info', 'WebSocket server started');
        $this->logger->log('info', 'Test log entry to verify logging functionality.');
        $this->logger->log('info', 'Another test log entry to confirm logging is working.');
        $this->logger->log('info', 'Another test log entry to confirm logging is working.');

        while (true) {
            $read = $this->getReadSockets();
            $write = $this->getWriteSockets();
            $except = null;

            if (stream_select($read, $write, $except, 0, 200000) > 0) {
                foreach ($read as $socket) {
                    if ($socket === $this->server) {
                        $this->acceptNewConnection();
                    } else {
                        $this->handleClientData($socket);
                    }
                }

                foreach ($write as $socket) {
                    $this->processWriteBuffer($socket);
                }
            }

            $this->performMaintenance();
        }
    }

    private function getReadSockets() {
        $read = array($this->server);
        foreach ($this->clients as $client) {
            $read[] = $client->socket;
        }
        return $read;
    }

    private function getWriteSockets() {
        $write = array();
        foreach ($this->clients as $client) {
            if ($client->hasBufferedData()) {
                $write[] = $client->socket;
            }
        }
        return $write;
    }

    private function acceptNewConnection() {
        $socket = stream_socket_accept($this->server);
        if ($socket === false) {
            return;
        }

        stream_set_blocking($socket, false);

        if ($this->config['ssl']['enabled']) {
            stream_socket_enable_crypto(
                $socket,
                true,
                STREAM_CRYPTO_METHOD_TLSv1_2_SERVER |
                STREAM_CRYPTO_METHOD_TLSv1_3_SERVER
            );
        }

        $client = new WebSocketClient($socket);
        $this->clients[intval($socket)] = $client;

        $this->logger->log('info', 'New client connected', [
            'ip' => stream_socket_get_name($socket, true)
        ]);
    }

    private function handleClientData($socket) {
        $client = $this->clients[intval($socket)];
        
        $data = @fread($socket, 8192);
        
        if ($data === false || $data === '') {
            $this->disconnectClient($client);
            return;
        }

        try {
            if (!$client->isHandshakeCompleted()) {
                $this->performHandshake($client, $data);
            } else {
                $this->processClientMessage($client, $data);
            }
        } catch (Exception $e) {
            $this->logger->log('error', 'Error handling client data: ' . $e->getMessage());
            $this->disconnectClient($client);
        }
    }

    private function performHandshake($client, $data) {
        if (!preg_match('/Sec-WebSocket-Key: (.+)\r\n/', $data, $matches)) {
            throw new Exception('No Sec-WebSocket-Key found');
        }

        $key = base64_encode(sha1($matches[1] . '258EAFA5-E914-47DA-95CA-C5AB0DC85B11', true));
        
        $headers = "HTTP/1.1 101 Switching Protocols\r\n";
        $headers .= "Upgrade: websocket\r\n";
        $headers .= "Connection: Upgrade\r\n";
        $headers .= "Sec-WebSocket-Accept: $key\r\n";
        $headers .= "\r\n";

        fwrite($client->socket, $headers);
        $client->setHandshakeCompleted();
    }

    private function processClientMessage($client, $data) {
        $messages = $client->processData($data);
        
        foreach ($messages as $message) {
            try {
                $decoded = json_decode($message, true);
                if ($decoded === null) {
                    throw new Exception('Invalid JSON message');
                }

                if (!isset($decoded['type'])) {
                    throw new Exception('Message type not specified');
                }

                $this->handleMessage($client, $decoded);
            } catch (Exception $e) {
                $this->logger->log('error', 'Error processing message: ' . $e->getMessage());
                $this->sendError($client, $e->getMessage());
            }
        }
    }

    private function handleMessage($client, $message) {
        if (isset($this->handlers[$message['type']])) {
            call_user_func($this->handlers[$message['type']], $client, $message);
        } else {
            $this->logger->log('warning', 'Unknown message type', ['type' => $message['type']]);
        }
    }

    private function processWriteBuffer($socket) {
        $client = $this->clients[intval($socket)];
        $client->flush();
    }

    private function performMaintenance() {
        static $lastCheck = 0;
        $now = time();

        if ($now - $lastCheck >= $this->config['rooms']['cleanup_interval']) {
            $this->cleanupRooms();
            $this->checkHeartbeats();
            $lastCheck = $now;
        }
    }

    private function cleanupRooms() {
        foreach ($this->rooms as $roomId => $room) {
            if ($room->isEmpty() && $room->getLastActivity() < time() - $this->config['rooms']['timeout']) {
                unset($this->rooms[$roomId]);
                $this->logger->log('info', 'Room cleaned up', ['room_id' => $roomId]);
            }
        }
    }

    private function checkHeartbeats() {
        foreach ($this->clients as $client) {
            if ($this->config['heartbeat']['enabled'] &&
                $client->getLastHeartbeat() < time() - $this->config['heartbeat']['timeout']) {
                $this->disconnectClient($client);
            }
        }
    }

    private function disconnectClient($client) {
        $this->logger->log('info', 'Client disconnected', [
            'ip' => stream_socket_get_name($client->socket, true)
        ]);

        foreach ($this->rooms as $room) {
            $room->removeClient($client);
        }

        unset($this->clients[intval($client->socket)]);
        @fclose($client->socket);
    }

    public function on($type, callable $handler) {
        $this->handlers[$type] = $handler;
    }

    public function broadcast($message, $exclude = null) {
        $encoded = $this->encodeMessage($message);
        
        foreach ($this->clients as $client) {
            if ($client !== $exclude && $client->isHandshakeCompleted()) {
                $client->send($encoded);
            }
        }
    }

    private function encodeMessage($message) {
        if (is_string($message)) {
            return $message;
        }
        return json_encode($message);
    }

    private function sendError($client, $message) {
        $client->send(json_encode([
            'type' => 'error',
            'message' => $message
        ]));
    }

    public function createRoom($type, $options = []) {
        $roomId = uniqid($type . '_');
        $this->rooms[$roomId] = new WebSocketRoom($roomId, $type, $options);
        return $this->rooms[$roomId];
    }

    public function getRoom($roomId) {
        return $this->rooms[$roomId] ?? null;
    }

    public function getRooms($type = null) {
        if ($type === null) {
            return $this->rooms;
        }

        return array_filter($this->rooms, function($room) use ($type) {
            return $room->getType() === $type;
        });
    }

    // Prevent cloning of instance
    private function __clone() {}

    // Prevent unserialize of instance
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

class WebSocketClient {
    public $socket;
    private $handshakeCompleted = false;
    private $buffer = '';
    private $writeBuffer = '';
    private $lastHeartbeat;

    public function __construct($socket) {
        $this->socket = $socket;
        $this->lastHeartbeat = time();
    }

    public function isHandshakeCompleted() {
        return $this->handshakeCompleted;
    }

    public function setHandshakeCompleted() {
        $this->handshakeCompleted = true;
    }

    public function processData($data) {
        $this->buffer .= $data;
        $messages = [];

        while (($message = $this->extractMessage()) !== null) {
            $messages[] = $message;
        }

        return $messages;
    }

    private function extractMessage() {
        if (strlen($this->buffer) < 2) {
            return null;
        }

        $firstByte = ord($this->buffer[0]);
        $secondByte = ord($this->buffer[1]);
        
        $fin = ($firstByte & 0x80) !== 0;
        $opcode = $firstByte & 0x0F;
        $masked = ($secondByte & 0x80) !== 0;
        $length = $secondByte & 0x7F;

        $offset = 2;

        if ($length === 126) {
            if (strlen($this->buffer) < 4) {
                return null;
            }
            $length = unpack('n', substr($this->buffer, 2, 2))[1];
            $offset += 2;
        } elseif ($length === 127) {
            if (strlen($this->buffer) < 10) {
                return null;
            }
            $length = unpack('J', substr($this->buffer, 2, 8))[1];
            $offset += 8;
        }

        if ($masked) {
            if (strlen($this->buffer) < $offset + 4) {
                return null;
            }
            $mask = substr($this->buffer, $offset, 4);
            $offset += 4;
        }

        if (strlen($this->buffer) < $offset + $length) {
            return null;
        }

        $payload = substr($this->buffer, $offset, $length);
        $this->buffer = substr($this->buffer, $offset + $length);

        if ($masked) {
            $payload = $this->unmask($payload, $mask);
        }

        if ($opcode === 0x8) { // Close frame
            return null;
        }

        if ($opcode === 0x9) { // Ping frame
            $this->send($this->createFrame($payload, 0xA)); // Send pong
            return null;
        }

        if ($opcode === 0xA) { // Pong frame
            $this->lastHeartbeat = time();
            return null;
        }

        return $payload;
    }

    private function unmask($payload, $mask) {
        $unmasked = '';
        $length = strlen($payload);
        
        for ($i = 0; $i < $length; $i++) {
            $unmasked .= $payload[$i] ^ $mask[$i % 4];
        }
        
        return $unmasked;
    }

    public function send($data) {
        $this->writeBuffer .= $this->createFrame($data);
    }

    private function createFrame($payload, $opcode = 0x1) {
        $firstByte = 0x80 | $opcode; // FIN + opcode
        $length = strlen($payload);
        $frame = chr($firstByte);

        if ($length <= 125) {
            $frame .= chr($length);
        } elseif ($length <= 65535) {
            $frame .= chr(126) . pack('n', $length);
        } else {
            $frame .= chr(127) . pack('J', $length);
        }

        return $frame . $payload;
    }

    public function hasBufferedData() {
        return strlen($this->writeBuffer) > 0;
    }

    public function flush() {
        if ($this->writeBuffer !== '') {
            $written = @fwrite($this->socket, $this->writeBuffer);
            if ($written > 0) {
                $this->writeBuffer = substr($this->writeBuffer, $written);
            }
        }
    }

    public function getLastHeartbeat() {
        return $this->lastHeartbeat;
    }
}

class WebSocketRoom {
    private $id;
    private $type;
    private $clients = [];
    private $options;
    private $lastActivity;

    public function __construct($id, $type, $options = []) {
        $this->id = $id;
        $this->type = $type;
        $this->options = $options;
        $this->lastActivity = time();
    }

    public function addClient($client) {
        $this->clients[intval($client->socket)] = $client;
        $this->updateActivity();
    }

    public function removeClient($client) {
        unset($this->clients[intval($client->socket)]);
        $this->updateActivity();
    }

    public function broadcast($message, $exclude = null) {
        foreach ($this->clients as $client) {
            if ($client !== $exclude) {
                $client->send($message);
            }
        }
    }

    public function getClients() {
        return $this->clients;
    }

    public function getClientCount() {
        return count($this->clients);
    }

    public function isEmpty() {
        return empty($this->clients);
    }

    public function getId() {
        return $this->id;
    }

    public function getType() {
        return $this->type;
    }

    public function getLastActivity() {
        return $this->lastActivity;
    }

    private function updateActivity() {
        $this->lastActivity = time();
    }
}
