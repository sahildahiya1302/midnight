<?php

class Wallet {
    private $db;
    private $data;
    private $userId;

    public function __construct($walletData) {
        $this->db = Database::getInstance()->getConnection();
        $this->data = $walletData;
        $this->userId = $walletData['user_id'];
    }

    public function getBalance() {
        return floatval($this->data['balance']);
    }

    public function getBonusBalance() {
        return floatval($this->data['bonus_balance'] ?? 0);
    }

    public function addBalance($amount, $type = 'deposit', $reference = null) {
        try {
            $this->db->beginTransaction();

            // Update wallet balance
            $stmt = $this->db->prepare("
                UPDATE wallets 
                SET balance = balance + ?,
                    updated_at = NOW()
                WHERE user_id = ?
            ");
            $stmt->execute([$amount, $this->userId]);

            // Record transaction
            $stmt = $this->db->prepare("
                INSERT INTO transactions (
                    user_id,
                    type,
                    amount,
                    balance_before,
                    balance_after,
                    reference_id,
                    status,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, 'completed', NOW())
            ");

            $balanceBefore = $this->getBalance();
            $balanceAfter = $balanceBefore + $amount;

            $stmt->execute([
                $this->userId,
                $type,
                $amount,
                $balanceBefore,
                $balanceAfter,
                $reference
            ]);

            $this->db->commit();
            $this->data['balance'] = $balanceAfter;

            return [
                'success' => true,
                'message' => "Transaction completed successfully",
                'new_balance' => $balanceAfter
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Add balance error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to process transaction'
            ];
        }
    }

    public function deductBalance($amount, $type = 'withdrawal', $reference = null) {
        try {
            if ($this->getBalance() < $amount) {
                return [
                    'success' => false,
                    'error' => 'Insufficient balance'
                ];
            }

            $this->db->beginTransaction();

            // Update wallet balance
            $stmt = $this->db->prepare("
                UPDATE wallets 
                SET balance = balance - ?,
                    updated_at = NOW()
                WHERE user_id = ? AND balance >= ?
            ");
            $stmt->execute([$amount, $this->userId, $amount]);

            if ($stmt->rowCount() === 0) {
                $this->db->rollBack();
                return [
                    'success' => false,
                    'error' => 'Insufficient balance'
                ];
            }

            // Record transaction
            $stmt = $this->db->prepare("
                INSERT INTO transactions (
                    user_id,
                    type,
                    amount,
                    balance_before,
                    balance_after,
                    reference_id,
                    status,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, 'completed', NOW())
            ");

            $balanceBefore = $this->getBalance();
            $balanceAfter = $balanceBefore - $amount;

            $stmt->execute([
                $this->userId,
                $type,
                $amount,
                $balanceBefore,
                $balanceAfter,
                $reference
            ]);

            $this->db->commit();
            $this->data['balance'] = $balanceAfter;

            return [
                'success' => true,
                'message' => "Transaction completed successfully",
                'new_balance' => $balanceAfter
            ];
        } catch (Exception $e) {
            $this->db->rollBack();
            error_log("Deduct balance error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to process transaction'
            ];
        }
    }

    public function getTransactions($limit = 10, $offset = 0, $type = null) {
        try {
            $sql = "
                SELECT 
                    id,
                    type,
                    amount,
                    balance_before,
                    balance_after,
                    reference_id,
                    status,
                    created_at
                FROM transactions
                WHERE user_id = ?
            ";
            $params = [$this->userId];

            if ($type) {
                $sql .= " AND type = ?";
                $params[] = $type;
            }

            $sql .= " ORDER BY created_at DESC LIMIT ? OFFSET ?";
            $params[] = $limit;
            $params[] = $offset;

            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Exception $e) {
            error_log("Get transactions error: " . $e->getMessage());
            return [];
        }
    }

    public function refresh() {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM wallets 
                WHERE user_id = ?
            ");
            $stmt->execute([$this->userId]);
            
            if ($walletData = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $this->data = $walletData;
                return true;
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Wallet refresh error: " . $e->getMessage());
            return false;
        }
    }
}
