<?php
class User {
    private $db;
    private $data;
    private $wallet;

    public function __construct($userData) {
        $this->db = Database::getInstance()->getConnection();
        $this->data = $userData;
        $this->loadWallet();
    }

    private function loadWallet() {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM wallets 
                WHERE user_id = ? 
                LIMIT 1
            ");
            $stmt->execute([$this->data['id']]);
            
            if ($walletData = $stmt->fetch()) {
                $this->wallet = new Wallet($walletData);
            } else {
                // Create wallet if not exists
                $stmt = $this->db->prepare("
                    INSERT INTO wallets (
                        user_id, 
                        balance, 
                        created_at
                    ) VALUES (?, 0.00, CURRENT_TIMESTAMP)
                ");
                $stmt->execute([$this->data['id']]);
                
                $this->wallet = new Wallet([
                    'id' => $this->db->lastInsertId(),
                    'user_id' => $this->data['id'],
                    'balance' => 0.00
                ]);
            }
        } catch (Exception $e) {
            error_log("Wallet load error: " . $e->getMessage());
            throw new Exception('Failed to load wallet');
        }
    }

    public function getId() {
        return $this->data['id'];
    }

    public function getData() {
        return $this->data;
    }

    public function getWallet() {
        return $this->wallet;
    }

    public function updateProfile($data) {
        try {
            $allowedFields = ['avatar', 'phone'];
            $updates = [];
            $params = [];

            foreach ($allowedFields as $field) {
                if (isset($data[$field])) {
                    $updates[] = "$field = ?";
                    $params[] = $data[$field];
                }
            }

            if (empty($updates)) {
                return [
                    'success' => false,
                    'error' => 'No fields to update'
                ];
            }

            $params[] = $this->data['id'];
            
            $stmt = $this->db->prepare("
                UPDATE users 
                SET " . implode(', ', $updates) . ", 
                    updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            
            $stmt->execute($params);

            // Update local data
            foreach ($allowedFields as $field) {
                if (isset($data[$field])) {
                    $this->data[$field] = $data[$field];
                }
            }

            return [
                'success' => true,
                'message' => 'Profile updated successfully'
            ];
        } catch (Exception $e) {
            error_log("Profile update error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to update profile'
            ];
        }
    }

    public function updatePassword($currentPassword, $newPassword) {
        try {
            if (!password_verify($currentPassword, $this->data['password_hash'])) {
                return [
                    'success' => false,
                    'error' => 'Current password is incorrect'
                ];
            }

            $stmt = $this->db->prepare("
                UPDATE users 
                SET password_hash = ?,
                    updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            
            $stmt->execute([
                password_hash($newPassword, PASSWORD_DEFAULT),
                $this->data['id']
            ]);

            return [
                'success' => true,
                'message' => 'Password updated successfully'
            ];
        } catch (Exception $e) {
            error_log("Password update error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to update password'
            ];
        }
    }

    public function getTransactions($limit = 10, $offset = 0) {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM transactions 
                WHERE user_id = ? 
                ORDER BY created_at DESC 
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$this->data['id'], $limit, $offset]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Transaction fetch error: " . $e->getMessage());
            return [];
        }
    }

    public function getGameHistory($limit = 10, $offset = 0) {
        try {
            $stmt = $this->db->prepare("
                SELECT 
                    gp.*,
                    gs.game_type,
                    gs.entry_fee,
                    gs.prize_pool,
                    gs.started_at,
                    gs.completed_at
                FROM game_players gp
                JOIN game_sessions gs ON gp.session_id = gs.id
                WHERE gp.user_id = ?
                ORDER BY gp.joined_at DESC
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$this->data['id'], $limit, $offset]);
            
            return $stmt->fetchAll();
        } catch (Exception $e) {
            error_log("Game history fetch error: " . $e->getMessage());
            return [];
        }
    }

    public function updateKYC($data) {
        try {
            $stmt = $this->db->prepare("
                UPDATE users 
                SET kyc_status = 'pending',
                    kyc_data = ?,
                    updated_at = CURRENT_TIMESTAMP 
                WHERE id = ?
            ");
            
            $stmt->execute([
                json_encode($data),
                $this->data['id']
            ]);

            $this->data['kyc_status'] = 'pending';
            $this->data['kyc_data'] = $data;

            return [
                'success' => true,
                'message' => 'KYC information submitted successfully'
            ];
        } catch (Exception $e) {
            error_log("KYC update error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'Failed to update KYC information'
            ];
        }
    }

    public function isKYCVerified() {
        return $this->data['kyc_status'] === 'verified';
    }

    public function canWithdraw() {
        return $this->isKYCVerified() && $this->wallet->getBalance() > 0;
    }

    public function getStats() {
        try {
            // Get game statistics
            $stmt = $this->db->prepare("
                SELECT 
                    COUNT(*) as total_games,
                    SUM(CASE WHEN status = 'finished' THEN 1 ELSE 0 END) as games_completed,
                    SUM(CASE WHEN win_amount > 0 THEN 1 ELSE 0 END) as games_won,
                    SUM(bet_amount) as total_bets,
                    SUM(win_amount) as total_wins
                FROM game_players
                WHERE user_id = ?
            ");
            $stmt->execute([$this->data['id']]);
            $gameStats = $stmt->fetch();

            // Get transaction statistics
            $stmt = $this->db->prepare("
                SELECT 
                    SUM(CASE WHEN type = 'deposit' THEN amount ELSE 0 END) as total_deposits,
                    SUM(CASE WHEN type = 'withdrawal' THEN amount ELSE 0 END) as total_withdrawals,
                    COUNT(DISTINCT CASE WHEN type = 'deposit' THEN id END) as deposit_count,
                    COUNT(DISTINCT CASE WHEN type = 'withdrawal' THEN id END) as withdrawal_count
                FROM transactions
                WHERE user_id = ?
            ");
            $stmt->execute([$this->data['id']]);
            $txStats = $stmt->fetch();

            return array_merge($gameStats, $txStats);
        } catch (Exception $e) {
            error_log("Stats fetch error: " . $e->getMessage());
            return [];
        }
    }
}
