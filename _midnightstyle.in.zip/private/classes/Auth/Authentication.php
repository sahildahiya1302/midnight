<?php
class Authentication {
    private static $instance = null;
    private $db;
    private $config;
    private $user = null;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
        $this->config = Config::getInstance();
        $this->initializeSession();
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function initializeSession() {
        if (isset($_SESSION['user_id'])) {
            try {
                $stmt = $this->db->prepare("
                    SELECT * FROM users 
                    WHERE id = ? AND status = 'active'
                    LIMIT 1
                ");
                $stmt->execute([$_SESSION['user_id']]);
                
                if ($userData = $stmt->fetch()) {
                    $this->user = new User($userData);
                } else {
                    // Invalid session, clear it
                    $this->logout();
                }
            } catch (Exception $e) {
                error_log("Auth error: " . $e->getMessage());
                $this->logout();
            }
        }
    }

    public function login($username, $password) {
        try {
            $stmt = $this->db->prepare("
                SELECT * FROM users 
                WHERE (username = ? OR email = ?) 
                AND status = 'active'
                LIMIT 1
            ");
            $stmt->execute([$username, $username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password_hash'])) {
                // Update last login
                $this->db->prepare("
                    UPDATE users 
                    SET last_login = CURRENT_TIMESTAMP 
                    WHERE id = ?
                ")->execute([$user['id']]);

                // Create session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['last_activity'] = time();
                
                // Log login
                $this->logAuth($user['id'], 'login', true);
                
                $this->user = new User($user);
                
                return [
                    'success' => true,
                    'user' => [
                        'id' => $user['id'],
                        'username' => $user['username'],
                        'email' => $user['email'],
                        'role' => $user['role_id']
                    ]
                ];
            }

            // Log failed attempt
            $this->logAuth(null, 'login', false, ['username' => $username]);
            
            return [
                'success' => false,
                'error' => 'Invalid credentials'
            ];
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'An error occurred during login'
            ];
        }
    }

    public function register($data) {
        try {
            // Validate required fields
            $required = ['username', 'email', 'password'];
            foreach ($required as $field) {
                if (empty($data[$field])) {
                    return [
                        'success' => false,
                        'error' => ucfirst($field) . ' is required'
                    ];
                }
            }

            // Validate username
            if (!preg_match('/^[a-zA-Z0-9_]{3,20}$/', $data['username'])) {
                return [
                    'success' => false,
                    'error' => 'Username must be 3-20 characters and contain only letters, numbers, and underscores'
                ];
            }

            // Validate email
            if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
                return [
                    'success' => false,
                    'error' => 'Invalid email address'
                ];
            }

            // Check if username exists
            $stmt = $this->db->prepare("SELECT id FROM users WHERE username = ?");
            $stmt->execute([$data['username']]);
            if ($stmt->fetch()) {
                return [
                    'success' => false,
                    'error' => 'Username already taken'
                ];
            }

            // Check if email exists
            $stmt = $this->db->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$data['email']]);
            if ($stmt->fetch()) {
                return [
                    'success' => false,
                    'error' => 'Email already registered'
                ];
            }

            // Start transaction
            $this->db->beginTransaction();

            try {
                // Create user
                $stmt = $this->db->prepare("
                    INSERT INTO users (
                        username, 
                        email, 
                        password_hash,
                        role_id,
                        status,
                        created_at
                    ) VALUES (?, ?, ?, 2, 'active', CURRENT_TIMESTAMP)
                ");

                $stmt->execute([
                    $data['username'],
                    $data['email'],
                    password_hash($data['password'], PASSWORD_DEFAULT)
                ]);

                $userId = $this->db->lastInsertId();

                // Create wallet
                $stmt = $this->db->prepare("
                    INSERT INTO wallets (
                        user_id,
                        balance,
                        created_at
                    ) VALUES (?, 0.00, CURRENT_TIMESTAMP)
                ");
                $stmt->execute([$userId]);

                $this->db->commit();

                // Log registration
                $this->logAuth($userId, 'register', true);

                return [
                    'success' => true,
                    'user_id' => $userId
                ];
            } catch (Exception $e) {
                $this->db->rollBack();
                throw $e;
            }
        } catch (Exception $e) {
            error_log("Registration error: " . $e->getMessage());
            return [
                'success' => false,
                'error' => 'An error occurred during registration'
            ];
        }
    }

    public function logout() {
        if (isset($_SESSION['user_id'])) {
            $this->logAuth($_SESSION['user_id'], 'logout', true);
        }
        
        session_unset();
        session_destroy();
        $this->user = null;
    }

    public function isAuthenticated() {
        return $this->user !== null;
    }

    public function getUser() {
        return $this->user;
    }

    public function isAdmin() {
        return $this->user && $this->user->getData()['role_id'] === 1;
    }

    private function logAuth($userId, $action, $status, $details = []) {
        try {
            $stmt = $this->db->prepare("
                INSERT INTO auth_logs (
                    user_id,
                    ip_address,
                    user_agent,
                    action,
                    status,
                    details,
                    created_at
                ) VALUES (?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ");

            $stmt->execute([
                $userId,
                $_SERVER['REMOTE_ADDR'],
                $_SERVER['HTTP_USER_AGENT'] ?? null,
                $action,
                $status ? 1 : 0,
                json_encode($details)
            ]);
        } catch (Exception $e) {
            error_log("Auth log error: " . $e->getMessage());
        }
    }

    public function validateToken($token) {
        try {
            $stmt = $this->db->prepare("
                SELECT user_id FROM auth_tokens
                WHERE token = ?
                AND is_revoked = 0
                AND expires_at > CURRENT_TIMESTAMP
                LIMIT 1
            ");
            $stmt->execute([$token]);
            
            if ($result = $stmt->fetch()) {
                return $result['user_id'];
            }
            
            return false;
        } catch (Exception $e) {
            error_log("Token validation error: " . $e->getMessage());
            return false;
        }
    }

    public function createToken($userId, $type = 'access', $expiresIn = 3600) {
        try {
            $token = bin2hex(random_bytes(32));
            $expiresAt = date('Y-m-d H:i:s', time() + $expiresIn);

            $stmt = $this->db->prepare("
                INSERT INTO auth_tokens (
                    user_id,
                    token,
                    type,
                    expires_at,
                    created_at
                ) VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ");

            $stmt->execute([
                $userId,
                $token,
                $type,
                $expiresAt
            ]);

            return $token;
        } catch (Exception $e) {
            error_log("Token creation error: " . $e->getMessage());
            return false;
        }
    }

    public function revokeToken($token) {
        try {
            $stmt = $this->db->prepare("
                UPDATE auth_tokens
                SET is_revoked = 1
                WHERE token = ?
            ");
            return $stmt->execute([$token]);
        } catch (Exception $e) {
            error_log("Token revocation error: " . $e->getMessage());
            return false;
        }
    }
}
