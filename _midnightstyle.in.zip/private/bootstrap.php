<?php
// Define application root path
define('APP_ROOT', __DIR__);

// Load core classes
require_once APP_ROOT . '/classes/Core/Config.php';
require_once APP_ROOT . '/classes/Core/ErrorHandler.php';
require_once APP_ROOT . '/classes/Core/IStorage.php';
require_once APP_ROOT . '/classes/Core/Database.php';
require_once APP_ROOT . '/classes/Core/JsonStorage.php';
require_once APP_ROOT . '/classes/Core/StorageFactory.php';
require_once APP_ROOT . '/classes/Core/Session.php';

// Initialize configuration
$config = Config::getInstance();

// Set error reporting based on environment
if ($config->isDevelopment()) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', 0);
}

// Initialize error handler
ErrorHandler::initialize(
    APP_ROOT . '/logs/error.log',
    $config->isDebugEnabled()
);

// Set timezone
date_default_timezone_set($config->getTimezone());

// Set character encoding
mb_internal_encoding('UTF-8');

// Initialize session handler
Session::getInstance()->start();

// Initialize storage system
try {
    $storage = StorageFactory::getStorage();
    // Make storage instance globally available
    function storage() {
        return StorageFactory::getStorage();
    }
} catch (Exception $e) {
    error_log("Storage initialization failed: " . $e->getMessage());
    http_response_code(500);
    if (file_exists(APP_ROOT . '/../public_html/views/errors/500.php')) {
        require APP_ROOT . '/../public_html/views/errors/500.php';
    } else {
        echo "<h1>500 Internal Server Error</h1>";
        echo "<p>Storage system initialization failed. Please try again later.</p>";
    }
    exit;
}

// Security headers
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
if ($config->get('env.app.secure', true)) {
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
}

// CORS headers for API endpoints
if (strpos($_SERVER['REQUEST_URI'], '/api/') === 0) {
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
    header('Access-Control-Allow-Headers: Content-Type, Authorization');
    
    if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        http_response_code(204);
        exit;
    }
}

// Initialize authentication
require_once APP_ROOT . '/classes/Auth/Authentication.php';
$auth = new Authentication();

// Define common functions
function h($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function redirect($url) {
    header("Location: $url");
    exit;
}

function getCurrentUser() {
    global $auth;
    return $auth->getUser();
}

function getCurrentWallet() {
    $user = getCurrentUser();
    return $user ? $user->getWallet() : null;
}

function isAdmin() {
    global $auth;
    return $auth->isAdmin();
}

function isAuthenticated() {
    global $auth;
    return $auth->isAuthenticated();
}

function requireAuth() {
    if (!isAuthenticated()) {
        $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
        redirect('/login');
    }
}

function requireAdmin() {
    if (!isAdmin()) {
        http_response_code(403);
        include APP_ROOT . '/../public_html/views/errors/403.php';
        exit;
    }
}

function csrf_token() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function verify_csrf_token() {
    if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
        http_response_code(403);
        include APP_ROOT . '/../public_html/views/errors/403.php';
        exit;
    }
}

function formatMoney($amount) {
    return '₹' . number_format($amount, 2);
}

function formatDate($date, $format = 'Y-m-d H:i:s') {
    return date($format, strtotime($date));
}

function getTimeAgo($timestamp) {
    $difference = time() - strtotime($timestamp);
    
    if ($difference < 60) {
        return "Just now";
    }
    
    $intervals = [
        31536000 => 'year',
        2592000 => 'month',
        604800 => 'week',
        86400 => 'day',
        3600 => 'hour',
        60 => 'minute'
    ];
    
    foreach ($intervals as $seconds => $label) {
        $quotient = floor($difference / $seconds);
        if ($quotient > 0) {
            return $quotient . ' ' . $label . ($quotient > 1 ? 's' : '') . ' ago';
        }
    }
}

// Make config globally available
function config($key = null, $default = null) {
    $config = Config::getInstance();
    return $key ? $config->get($key, $default) : $config;
}

// Check maintenance mode
if (config('env.maintenance_mode', false)) {
    $allowedIPs = config('env.maintenance_ips', []);
    $clientIP = $_SERVER['REMOTE_ADDR'];
    
    if (!in_array($clientIP, $allowedIPs)) {
        http_response_code(503);
        include APP_ROOT . '/../public_html/views/errors/maintenance.php';
        exit;
    }
}

// Return the config instance
return $config;
