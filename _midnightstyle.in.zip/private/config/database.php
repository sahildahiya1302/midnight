<?php
return [
    'database' => __DIR__ . '/../storage/database/my_database.db', // Update to the correct SQLite database file path
    // 'host' => 'srv1326.hstgr.io',
    // 'username' => 'u185229455_u185229455',
    // 'password' => 'Sahil@hostinger#ssh2025',
    'charset' => 'utf8mb4',
    'collation' => 'utf8mb4_unicode_ci',
    'prefix' => '',
    'options' => [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        // Remove MySQL specific attribute as it's causing issues
        // PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
    ],
    'pool' => [
        'min_connections' => 1,
        'max_connections' => 10,
        'idle_timeout' => 60,
        'wait_timeout' => 5
    ],
    'debug' => true, // Enable debug for troubleshooting
    'log_queries' => true, // Enable query logging
    'log_slow_queries' => true,
    'slow_query_threshold' => 1.0,
    'backup' => [
        'enabled' => true,
        'directory' => __DIR__ . '/../storage/backups/database',
        'filename_prefix' => 'backup_',
        'compress' => true,
        'retention_days' => 7
    ],
    'maintenance' => [
        'enabled' => false,
        'allowed_ips' => [
            '127.0.0.1',
            $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1'
        ]
    ],
    'replication' => [
        'enabled' => false,
        'write' => [
            'host' => 'srv1326.hstgr.io',
            'port' => 3306
        ],
        'read' => [
            [
                'host' => 'srv1326.hstgr.io',
                'port' => 3306
            ]
        ]
    ],
    'cache' => [
        'enabled' => true,
        'driver' => 'file', // Using file-based caching instead of Redis
        'prefix' => 'db_',
        'ttl' => 3600,
        'directory' => __DIR__ . '/../storage/cache'
    ]
];
