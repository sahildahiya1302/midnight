<?php
return [
    // Server configuration
    'server' => [
        'host' => '0.0.0.0',
        'port' => 8080,
        'secure' => true,
        'cert_file' => __DIR__ . '/../ssl/cert.pem',
        'key_file' => __DIR__ . '/../ssl/key.pem',
        'verify_peer' => false
    ],

    // Client configuration
    'client' => [
        'url' => 'wss://midnightstyle.in/ws',
        'options' => [
            'timeout' => 5,
            'fragment_size' => 4096,
            'compression' => true
        ]
    ],

    // Authentication
    'auth' => [
        'enabled' => true,
        'timeout' => 60,
        'max_attempts' => 3,
        'block_duration' => 300 // 5 minutes
    ],

    // Game rooms
    'rooms' => [
        'max_rooms' => 1000,
        'players_per_room' => [
            'ludo' => 4,
            'aviator' => 100
        ],
        'timeout' => 300, // 5 minutes
        'cleanup_interval' => 60 // 1 minute
    ],

    // Rate limiting
    'rate_limit' => [
        'enabled' => true,
        'max_connections' => 10000,
        'max_messages' => 100,
        'interval' => 60 // 1 minute
    ],

    // Message handling
    'messages' => [
        'max_size' => 65536, // 64KB
        'queue_size' => 1000,
        'compression' => true,
        'validation' => true
    ],

    // Monitoring
    'monitoring' => [
        'enabled' => true,
        'metrics' => [
            'connections',
            'messages',
            'rooms',
            'memory',
            'errors'
        ],
        'log_level' => 'warning',
        'alert_channels' => [
            'email' => true,
            'slack' => false
        ]
    ],

    // Game specific settings
    'games' => [
        'ludo' => [
            'turn_timeout' => 30,
            'game_timeout' => 1800, // 30 minutes
            'min_players' => 2,
            'max_players' => 4,
            'bot_enabled' => true,
            'bot_delay' => [2, 5] // Random delay between 2-5 seconds
        ],
        'aviator' => [
            'round_interval' => 30,
            'min_bet' => 10,
            'max_bet' => 10000,
            'max_multiplier' => 100.0,
            'house_edge' => 0.05
        ]
    ],

    // Performance tuning
    'performance' => [
        'worker_processes' => 4,
        'worker_connections' => 1024,
        'buffer_size' => 8192,
        'backlog' => 512,
        'keep_alive' => 60
    ],

    // Error handling
    'errors' => [
        'log_file' => __DIR__ . '/../logs/websocket.log',
        'max_retries' => 3,
        'retry_delay' => 1000 // milliseconds
    ],

    // Broadcast channels
    'channels' => [
        'game_updates' => [
            'type' => 'public',
            'history_size' => 100
        ],
        'user_notifications' => [
            'type' => 'private',
            'history_size' => 50
        ],
        'admin_updates' => [
            'type' => 'private',
            'auth_required' => true,
            'roles' => ['admin']
        ]
    ],

    // Client heartbeat
    'heartbeat' => [
        'enabled' => true,
        'interval' => 30,
        'timeout' => 60
    ],

    // SSL/TLS settings
    'ssl' => [
        'enabled' => true,
        'verify_peer' => false,
        'allow_self_signed' => true,
        'cert_file' => __DIR__ . '/../ssl/cert.pem',
        'key_file' => __DIR__ . '/../ssl/key.pem',
        'protocols' => ['TLSv1.2', 'TLSv1.3']
    ],

    // Origin restrictions
    'origins' => [
        'allowed' => [
            'https://midnightstyle.in',
            'https://www.midnightstyle.in'
        ],
        'blocked' => []
    ]
];
