<?php
return [
    // Session configuration
    'name' => 'GAMESESSID',
    'lifetime' => 7200, // 2 hours
    'path' => '/',
    'domain' => '.midnightstyle.in',
    'secure' => true,
    'httponly' => true,
    'samesite' => 'Lax',

    // Session handler
    'handler' => 'files', // Options: files, redis, database
    'handlers' => [
        'files' => [
            'save_path' => __DIR__ . '/../storage/sessions',
            'gc_probability' => 1,
            'gc_divisor' => 100,
            'gc_maxlifetime' => 7200
        ],
        'redis' => [
            'host' => 'localhost',
            'port' => 6379,
            'database' => 1,
            'prefix' => 'session:',
            'timeout' => 2.5,
            'auth' => [
                'enabled' => false,
                'password' => null
            ]
        ],
        'database' => [
            'table' => 'sessions',
            'connection' => 'default',
            'encrypt' => true
        ]
    ],

    // Session security
    'security' => [
        'regenerate_id' => true,
        'regenerate_interval' => 300, // 5 minutes
        'rotate_on_login' => true,
        'validate_ip' => true,
        'validate_ua' => true,
        'fingerprint' => [
            'include_ip' => true,
            'include_ua' => true
        ]
    ],

    // Session storage
    'storage' => [
        'encrypt' => true,
        'compress' => true
    ],

    // Rate limiting
    'rate_limiting' => [
        'enabled' => true,
        'max_requests' => 100,
        'decay_minutes' => 1,
        'block_duration' => 15 // minutes
    ],

    // Session cleanup
    'cleanup' => [
        'enabled' => true,
        'probability' => 2,
        'divisor' => 100,
        'lifetime' => 7200 // 2 hours
    ],

    // Logging
    'logging' => [
        'enabled' => true,
        'channel' => 'session',
        'level' => 'warning',
        'events' => [
            'login' => true,
            'logout' => true,
            'timeout' => true,
            'blocked' => true
        ]
    ],

    // Cookie configuration
    'cookie' => [
        'lifetime' => 0, // Until browser closes
        'path' => '/',
        'domain' => '.midnightstyle.in',
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Lax'
    ],

    // Remember me functionality
    'remember_me' => [
        'enabled' => true,
        'cookie_name' => 'remember_token',
        'lifetime' => 2592000, // 30 days
        'secure' => true,
        'httponly' => true,
        'samesite' => 'Lax'
    ],

    // Session monitoring
    'monitoring' => [
        'enabled' => true,
        'threshold_warnings' => [
            'session_count' => 1000,
            'storage_usage' => 80 // percentage
        ],
        'alert_channels' => [
            'email' => true,
            'slack' => false,
            'log' => true
        ]
    ],

    // Cross-site request forgery (CSRF) protection
    'csrf' => [
        'enabled' => true,
        'token_length' => 32,
        'token_lifetime' => 7200, // 2 hours
        'cookie_name' => 'XSRF-TOKEN',
        'header_name' => 'X-XSRF-TOKEN'
    ],

    // Session initialization
    'initialize' => function($session) {
        // Set session cookie parameters
        session_set_cookie_params([
            'lifetime' => 0,
            'path' => '/',
            'domain' => '.midnightstyle.in',
            'secure' => true,
            'httponly' => true,
            'samesite' => 'Lax'
        ]);

        // Set custom session name
        session_name('GAMESESSID');

        // Start session
        if (session_status() === PHP_SESSION_NONE) {
            session_start();
        }

        // Set session security headers
        header('X-Frame-Options: DENY');
        header('X-XSS-Protection: 1; mode=block');
        header('X-Content-Type-Options: nosniff');
        header('Referrer-Policy: strict-origin-when-cross-origin');
        
        // Regenerate session ID periodically
        if (!isset($_SESSION['_last_regenerated']) ||
            (time() - $_SESSION['_last_regenerated']) > 300) {
            session_regenerate_id(true);
            $_SESSION['_last_regenerated'] = time();
        }

        // Set session expiry
        if (!isset($_SESSION['_expires']) || time() > $_SESSION['_expires']) {
            $_SESSION['_expires'] = time() + 7200;
        }

        // Validate session
        if (isset($_SESSION['_fingerprint'])) {
            $currentFingerprint = sha1(
                ($_SESSION['validate_ip'] ? $_SERVER['REMOTE_ADDR'] : '') .
                ($_SESSION['validate_ua'] ? $_SERVER['HTTP_USER_AGENT'] : '')
            );
            
            if ($_SESSION['_fingerprint'] !== $currentFingerprint) {
                session_unset();
                session_destroy();
                session_start();
            }
        }

        // Set session fingerprint
        $_SESSION['_fingerprint'] = sha1(
            ($_SESSION['validate_ip'] ? $_SERVER['REMOTE_ADDR'] : '') .
            ($_SESSION['validate_ua'] ? $_SERVER['HTTP_USER_AGENT'] : '')
        );
    }
];
