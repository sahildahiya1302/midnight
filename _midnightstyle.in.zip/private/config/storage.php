<?php
return [
    // Storage mode: 'auto', 'database', or 'json'
    'mode' => 'auto',
    
    // JSON storage settings
    'json' => [
        'data_path' => __DIR__ . '/../storage/data/',
        'backup_enabled' => true,
        'backup_interval' => 86400, // 24 hours
    ],
    
    // Monitoring settings
    'monitoring' => [
        'log_errors' => true,
        'log_path' => __DIR__ . '/../logs/storage.log',
        'alert_threshold' => 5 // Number of errors before alerting
    ]
];
