# Gaming Platform - Ludo Game Server

A real-time multiplayer gaming platform featuring Ludo with real-money prizes.

## System Requirements

- PHP 8.0 or higher
- MySQL 8.0 or higher
- Node.js 16.x or higher
- Composer
- Redis (for session management)
- SSL certificate (for secure WebSocket connections)

## Installation

1. Clone the repository:
```bash
git clone https://github.com/midnightstyle/gaming-platform.git
cd gaming-platform
```

2. Install PHP dependencies:
```bash
composer install
```

3. Set up the database:
```bash
mysql -u root -p
CREATE DATABASE gaming_platform;
USE gaming_platform;
source private/database/schema.sql;
```

4. Configure the environment:
```bash
cp .env.example .env
# Edit .env with your configuration
```

5. Set up SSL certificates:
```bash
# Place your SSL certificates in the appropriate directory
cp /path/to/your/certificates/* /etc/ssl/certs/midnightstyle.in/
```

6. Install system services:
```bash
# Copy service files to systemd
sudo cp private/bin/game-server.service /etc/systemd/system/
sudo cp private/bin/monitor-server.service /etc/systemd/system/

# Reload systemd
sudo systemctl daemon-reload

# Enable services
sudo systemctl enable game-server
sudo systemctl enable monitor-server
```

## Server Management

The platform includes several management scripts:

### Game Server Control

```bash
# Start the game server
./private/bin/manage-server.sh start

# Stop the game server
./private/bin/manage-server.sh stop

# Restart the game server
./private/bin/manage-server.sh restart

# Check server status
./private/bin/manage-server.sh status

# View server logs
./private/bin/manage-server.sh logs

# Rotate log files
./private/bin/manage-server.sh rotate-logs
```

### Monitoring

The monitoring system tracks various metrics:

- Active connections
- Game statistics
- Server performance
- Error rates
- Resource usage

Monitor data is available in `/var/log/gaming-platform/metrics.json`

### Configuration

Key configuration files:

- `private/config/websocket.php`: WebSocket server settings
- `private/config/database.php`: Database connection settings
- `private/config/payment_credentials.php`: Payment gateway credentials
- `private/config/session.php`: Session management settings

## Architecture

### Components

1. **WebSocket Server**
   - Handles real-time game communications
   - Manages game state
   - Processes player actions
   - Implements game logic

2. **Monitor Server**
   - Tracks server health
   - Collects performance metrics
   - Sends alerts on issues
   - Manages log rotation

3. **Game Controller**
   - Implements game rules
   - Manages player turns
   - Handles game progression
   - Processes game outcomes

4. **Payment System**
   - Processes deposits
   - Handles withdrawals
   - Manages transaction history
   - Implements security measures

### Security Features

- SSL/TLS encryption for all communications
- Token-based authentication
- Rate limiting
- Input validation
- Anti-cheat measures
- Transaction verification

## Game Rules

### Ludo

1. **Setup**
   - 2-4 players
   - Each player has 4 tokens
   - Entry fee required to join

2. **Gameplay**
   - Roll 6 to move token out
   - Move tokens clockwise
   - Capture opponent tokens
   - First to finish wins

3. **Timing**
   - 15 seconds per turn
   - 30 seconds waiting period
   - 3 skipped turns = elimination

4. **Prizes**
   - Winner gets 80% of pool
   - Platform fee: 20%
   - Minimum 2 players required

## Error Handling

Errors are logged to:
- `/var/log/gaming-platform/game-server.error.log`
- `/var/log/gaming-platform/monitor.error.log`

Alert notifications are sent for:
- High memory usage (>90%)
- High error rate (>50/min)
- Server crashes
- Connection issues

## Maintenance

Regular maintenance tasks:
```bash
# Check server health
./private/bin/monitor-server.php --check

# Clean up old data
./private/bin/cleanup.php

# Backup database
./private/bin/backup.php
```

## Troubleshooting

Common issues and solutions:

1. **Server Won't Start**
   - Check error logs
   - Verify port availability
   - Check permissions

2. **Connection Issues**
   - Verify SSL certificates
   - Check firewall settings
   - Validate WebSocket URL

3. **Game Errors**
   - Check game logs
   - Verify database connection
   - Validate game state

## Support

For technical support:
- Email: support@midnightstyle.in
- Phone: +91-XXXXXXXXXX
- Hours: 24/7

## License

Proprietary software. All rights reserved.
