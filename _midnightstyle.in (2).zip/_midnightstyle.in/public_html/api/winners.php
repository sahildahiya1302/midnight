<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../../private/config/database.php';
require_once __DIR__ . '/../../private/classes/Auth/Authentication.php';

try {
    $db = Database::getInstance()->getConnection();
    
    // Get recent winners
    $stmt = $db->prepare("
        SELECT 
            u.username,
            u.avatar,
            gs.game_type as game,
            gs.prize_pool as amount,
            gs.completed_at as time
        FROM game_sessions gs
        JOIN users u ON gs.winner_id = u.id
        WHERE gs.status = 'completed'
        AND gs.completed_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)
        ORDER BY gs.completed_at DESC
        LIMIT 10
    ");
    $stmt->execute();
    $winners = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Format winners data
    $winners = array_map(function($winner) {
        return [
            'username' => $winner['username'],
            'avatar' => $winner['avatar'] ?? '/assets/images/default-avatar.png',
            'game' => ucfirst($winner['game']),
            'amount' => number_format($winner['amount'], 2),
            'time' => date('Y-m-d H:i:s', strtotime($winner['time'])),
            'timeAgo' => getTimeAgo(strtotime($winner['time']))
        ];
    }, $winners);

    echo json_encode([
        'success' => true,
        'winners' => $winners
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Internal server error'
    ]);
    error_log("Winners API error: " . $e->getMessage());
}

function getTimeAgo($timestamp) {
    $difference = time() - $timestamp;
    
    if ($difference < 60) {
        return "Just now";
    }
    
    $intervals = [
        31536000 => 'year',
        2592000 => 'month',
        604800 => 'week',
        86400 => 'day',
        3600 => 'hour',
        60 => 'minute'
    ];
    
    foreach ($intervals as $seconds => $label) {
        $quotient = floor($difference / $seconds);
        if ($quotient > 0) {
            return $quotient . ' ' . $label . ($quotient > 1 ? 's' : '') . ' ago';
        }
    }
}
