<?php
header('Content-Type: application/json');

require_once __DIR__ . '/../../private/config/database.php';
require_once __DIR__ . '/../../private/classes/Auth/Authentication.php';

try {
    $db = Database::getInstance()->getConnection();
    
    // Get online players count
    $stmt = $db->prepare("
        SELECT COUNT(DISTINCT user_id) as count 
        FROM user_sessions 
        WHERE last_activity > DATE_SUB(NOW(), INTERVAL 5 MINUTE)
    ");
    $stmt->execute();
    $onlinePlayers = $stmt->fetchColumn();

    // Get active games count
    $stmt = $db->prepare("
        SELECT 
            COUNT(*) as total,
            SUM(CASE WHEN game_type = 'ludo' THEN 1 ELSE 0 END) as ludo,
            SUM(CASE WHEN game_type = 'aviator' THEN 1 ELSE 0 END) as aviator
        FROM game_sessions 
        WHERE status IN ('waiting', 'playing')
    ");
    $stmt->execute();
    $games = $stmt->fetch(PDO::FETCH_ASSOC);

    // Get active players per game
    $stmt = $db->prepare("
        SELECT 
            gs.game_type,
            COUNT(DISTINCT gp.user_id) as players
        FROM game_sessions gs
        JOIN game_players gp ON gs.id = gp.session_id
        WHERE gs.status IN ('waiting', 'playing')
        GROUP BY gs.game_type
    ");
    $stmt->execute();
    $activePlayers = [];
    while ($row = $stmt->fetch()) {
        $activePlayers[$row['game_type']] = $row['players'];
    }

    // Get total prize pool
    $stmt = $db->prepare("
        SELECT SUM(prize_pool) as total 
        FROM game_sessions 
        WHERE status IN ('waiting', 'playing')
    ");
    $stmt->execute();
    $totalPrizes = $stmt->fetchColumn() ?: 0;

    echo json_encode([
        'success' => true,
        'onlinePlayers' => $onlinePlayers,
        'activeGames' => $games['total'],
        'ludoGames' => $games['ludo'],
        'aviatorGames' => $games['aviator'],
        'ludoPlayers' => $activePlayers['ludo'] ?? 0,
        'aviatorPlayers' => $activePlayers['aviator'] ?? 0,
        'totalPrizes' => number_format($totalPrizes, 2)
    ]);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'error' => 'Internal server error'
    ]);
    error_log("Stats API error: " . $e->getMessage());
}
