<?php
require_once __DIR__ . '/../../private/classes/Auth/Authentication.php';

// Check admin authentication
$auth = new Authentication();
if (!$auth->isAdmin()) {
    header('Location: /login');
    exit();
}

$activePage = $_GET['page'] ?? 'dashboard';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Gaming Platform</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/responsive.css">
    <link rel="stylesheet" href="/admin/assets/css/admin.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="admin-body">
    <!-- Admin Sidebar -->
    <aside class="admin-sidebar">
        <div class="sidebar-header">
            <img src="/assets/images/logo.png" alt="Gaming Platform" class="logo">
            <h1>Admin Panel</h1>
        </div>

        <nav class="sidebar-nav">
            <a href="/admin?page=dashboard" class="nav-item <?= $activePage === 'dashboard' ? 'active' : '' ?>">
                <i class="icon-dashboard"></i>
                <span>Dashboard</span>
            </a>
            <a href="/admin?page=users" class="nav-item <?= $activePage === 'users' ? 'active' : '' ?>">
                <i class="icon-users"></i>
                <span>Users</span>
            </a>
            <a href="/admin?page=games" class="nav-item <?= $activePage === 'games' ? 'active' : '' ?>">
                <i class="icon-games"></i>
                <span>Games</span>
            </a>
            <a href="/admin?page=transactions" class="nav-item <?= $activePage === 'transactions' ? 'active' : '' ?>">
                <i class="icon-wallet"></i>
                <span>Transactions</span>
            </a>
            <a href="/admin?page=withdrawals" class="nav-item <?= $activePage === 'withdrawals' ? 'active' : '' ?>">
                <i class="icon-money"></i>
                <span>Withdrawals</span>
            </a>
            <a href="/admin?page=reports" class="nav-item <?= $activePage === 'reports' ? 'active' : '' ?>">
                <i class="icon-chart"></i>
                <span>Reports</span>
            </a>
            <a href="/admin?page=settings" class="nav-item <?= $activePage === 'settings' ? 'active' : '' ?>">
                <i class="icon-settings"></i>
                <span>Settings</span>
            </a>
            <a href="/admin?page=logs" class="nav-item <?= $activePage === 'logs' ? 'active' : '' ?>">
                <i class="icon-logs"></i>
                <span>Logs</span>
            </a>
        </nav>

        <div class="sidebar-footer">
            <a href="/admin/logout" class="logout-btn">
                <i class="icon-logout"></i>
                <span>Logout</span>
            </a>
        </div>
    </aside>

    <!-- Main Content -->
    <main class="admin-main">
        <!-- Top Bar -->
        <header class="admin-header">
            <div class="header-left">
                <button class="menu-toggle">
                    <i class="icon-menu"></i>
                </button>
                <h2><?= ucfirst($activePage) ?></h2>
            </div>
            <div class="header-right">
                <div class="server-status">
                    <span class="status-dot online"></span>
                    <span>Server Online</span>
                </div>
                <div class="admin-profile">
                    <img src="<?= $auth->getUser()->getData()['avatar'] ?? '/assets/images/default-avatar.png' ?>" 
                         alt="Admin">
                    <span><?= $auth->getUser()->getData()['username'] ?></span>
                </div>
            </div>
        </header>

        <!-- Page Content -->
        <div class="admin-content">
            <?php
            switch ($activePage) {
                case 'dashboard':
                    include 'pages/dashboard.php';
                    break;
                case 'users':
                    include 'pages/users.php';
                    break;
                case 'games':
                    include 'pages/games.php';
                    break;
                case 'transactions':
                    include 'pages/transactions.php';
                    break;
                case 'withdrawals':
                    include 'pages/withdrawals.php';
                    break;
                case 'reports':
                    include 'pages/reports.php';
                    break;
                case 'settings':
                    include 'pages/settings.php';
                    break;
                case 'logs':
                    include 'pages/logs.php';
                    break;
                default:
                    echo '<div class="error-message">Page not found</div>';
            }
            ?>
        </div>
    </main>

    <!-- Notification Modal -->
    <div class="modal" id="notificationModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Notifications</h2>
                <button class="close-modal">&times;</button>
            </div>
            <div class="modal-body">
                <div class="notification-list" id="notificationList"></div>
            </div>
        </div>
    </div>

    <script src="/admin/assets/js/admin.js"></script>
    <script>
        // Initialize admin panel
        const admin = new AdminPanel({
            wsUrl: `wss://${window.location.hostname}/admin/ws`,
            userId: '<?= $auth->getUser()->getId() ?>',
            token: '<?= $auth->getToken() ?>'
        });

        // Connect to WebSocket server
        admin.connect();

        // Handle menu toggle
        document.querySelector('.menu-toggle').addEventListener('click', () => {
            document.body.classList.toggle('sidebar-collapsed');
        });

        // Handle notifications
        document.querySelector('.notifications-toggle').addEventListener('click', () => {
            document.getElementById('notificationModal').classList.add('active');
        });

        // Close modals
        document.querySelectorAll('.close-modal').forEach(btn => {
            btn.addEventListener('click', () => {
                btn.closest('.modal').classList.remove('active');
            });
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth < 768) {
                document.body.classList.add('sidebar-collapsed');
            }
        });

        // Initial resize check
        if (window.innerWidth < 768) {
            document.body.classList.add('sidebar-collapsed');
        }
    </script>
</body>
</html>
