class AdminPanel {
    constructor(config) {
        this.config = config;
        this.notifications = [];
        this.charts = new Map();
        this.activeMonitoring = false;
    }

    connect() {
        this.ws = new WebSocket(this.config.wsUrl);
        
        this.ws.onopen = () => {
            this.authenticate();
            console.log('Connected to admin WebSocket server');
        };

        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleServerMessage(data);
        };

        this.ws.onclose = () => {
            console.log('Disconnected from admin WebSocket server. Reconnecting...');
            setTimeout(() => this.connect(), 1000);
        };
    }

    authenticate() {
        this.ws.send(JSON.stringify({
            action: 'admin_auth',
            userId: this.config.userId,
            token: this.config.token
        }));
    }

    handleServerMessage(data) {
        switch (data.type) {
            case 'server_metrics':
                this.updateServerMetrics(data.metrics);
                break;

            case 'game_update':
                this.updateGameStats(data.stats);
                break;

            case 'user_activity':
                this.updateUserActivity(data.activity);
                break;

            case 'transaction_update':
                this.updateTransactions(data.transactions);
                break;

            case 'system_alert':
                this.handleSystemAlert(data.alert);
                break;

            case 'notification':
                this.showNotification(data.notification);
                break;
        }
    }

    updateServerMetrics(metrics) {
        // Update CPU usage
        this.updateMetricProgress('cpu-usage', metrics.cpu);
        this.updateChart('cpuChart', metrics.cpu_history);

        // Update memory usage
        this.updateMetricProgress('memory-usage', metrics.memory);
        this.updateChart('memoryChart', metrics.memory_history);

        // Update network stats
        this.updateMetricProgress('network-usage', metrics.network);
        this.updateChart('networkChart', metrics.network_history);

        // Update server status
        const statusDot = document.querySelector('.server-status .status-dot');
        if (metrics.status === 'online') {
            statusDot.classList.remove('offline');
            statusDot.classList.add('online');
        } else {
            statusDot.classList.remove('online');
            statusDot.classList.add('offline');
        }
    }

    updateMetricProgress(id, value) {
        const progressBar = document.querySelector(`#${id} .progress`);
        const valueDisplay = document.querySelector(`#${id} .value`);
        
        if (progressBar && valueDisplay) {
            progressBar.style.width = `${value}%`;
            valueDisplay.textContent = `${value}%`;

            // Update color based on threshold
            if (value > 90) {
                progressBar.classList.add('critical');
            } else if (value > 70) {
                progressBar.classList.add('warning');
            } else {
                progressBar.classList.remove('critical', 'warning');
            }
        }
    }

    updateChart(chartId, data) {
        const chart = this.charts.get(chartId);
        if (chart) {
            chart.data.labels = data.labels;
            chart.data.datasets[0].data = data.values;
            chart.update();
        }
    }

    updateGameStats(stats) {
        // Update active games count
        document.getElementById('activeGames').textContent = stats.active;

        // Update games list
        const gamesList = document.getElementById('gamesList');
        if (gamesList) {
            gamesList.innerHTML = stats.games.map(game => `
                <div class="game-item">
                    <div class="game-info">
                        <img src="/assets/images/games/${game.type}-icon.png" alt="${game.type}">
                        <div class="details">
                            <h5>${game.type}</h5>
                            <span>${game.players} players</span>
                        </div>
                    </div>
                    <div class="game-status">
                        <span class="status ${game.status}">${game.status}</span>
                        <span class="time">${game.duration}</span>
                    </div>
                </div>
            `).join('');
        }

        // Update game statistics
        if (stats.statistics) {
            this.updateGameStatistics(stats.statistics);
        }
    }

    updateGameStatistics(statistics) {
        // Update revenue stats
        document.getElementById('totalRevenue').textContent = 
            '₹' + statistics.revenue.toFixed(2);
        document.getElementById('revenueChange').textContent = 
            `${statistics.revenue_change >= 0 ? '+' : ''}${statistics.revenue_change}%`;

        // Update games played
        document.getElementById('gamesPlayed').textContent = 
            statistics.games_played.toLocaleString();
        document.getElementById('gamesChange').textContent = 
            `${statistics.games_change >= 0 ? '+' : ''}${statistics.games_change}%`;

        // Update charts
        this.updateChart('revenueChart', statistics.revenue_chart);
        this.updateChart('gamesChart', statistics.games_chart);
    }

    updateUserActivity(activity) {
        // Update online users count
        document.getElementById('onlineUsers').textContent = activity.online;

        // Update active sessions
        document.getElementById('activeSessions').textContent = activity.sessions;

        // Update user locations on map
        if (this.userMap) {
            this.userMap.updateMarkers(activity.locations);
        }

        // Update user activity chart
        this.updateChart('userActivityChart', activity.chart);
    }

    updateTransactions(transactions) {
        const transactionsList = document.getElementById('recentTransactions');
        if (transactionsList) {
            transactionsList.innerHTML = transactions.map(tx => `
                <div class="transaction-item">
                    <div class="transaction-icon ${tx.type}">
                        <i class="icon-${tx.type}"></i>
                    </div>
                    <div class="transaction-info">
                        <div class="user-info">
                            <img src="${tx.user_avatar}" alt="${tx.username}">
                            <span>${tx.username}</span>
                        </div>
                        <div class="amount ${tx.type}">
                            ${tx.type === 'deposit' ? '+' : '-'}₹${tx.amount.toFixed(2)}
                        </div>
                    </div>
                    <div class="transaction-status">
                        <span class="status ${tx.status}">${tx.status}</span>
                        <span class="time">${tx.time}</span>
                    </div>
                </div>
            `).join('');
        }
    }

    handleSystemAlert(alert) {
        const alertsList = document.getElementById('systemAlerts');
        if (alertsList) {
            const alertElement = document.createElement('div');
            alertElement.className = `alert-item ${alert.level}`;
            alertElement.innerHTML = `
                <div class="alert-icon">
                    <i class="icon-${alert.icon}"></i>
                </div>
                <div class="alert-content">
                    <h4>${alert.title}</h4>
                    <p>${alert.message}</p>
                    <span class="time">${alert.time}</span>
                </div>
                <button class="dismiss-alert" onclick="dismissAlert(${alert.id})">
                    &times;
                </button>
            `;
            alertsList.insertBefore(alertElement, alertsList.firstChild);
        }

        // Show notification if critical
        if (alert.level === 'critical') {
            this.showNotification({
                title: 'Critical Alert',
                message: alert.message,
                type: 'error'
            });
        }
    }

    showNotification(notification) {
        const notificationElement = document.createElement('div');
        notificationElement.className = `notification ${notification.type}`;
        notificationElement.innerHTML = `
            <div class="notification-content">
                <h4>${notification.title}</h4>
                <p>${notification.message}</p>
            </div>
            <button class="close-notification">&times;</button>
        `;

        document.body.appendChild(notificationElement);

        // Add to notifications list
        this.notifications.push({
            id: Date.now(),
            ...notification
        });
        this.updateNotificationsList();

        // Auto dismiss after 5 seconds
        setTimeout(() => {
            notificationElement.classList.add('fade-out');
            setTimeout(() => {
                notificationElement.remove();
            }, 300);
        }, 5000);
    }

    updateNotificationsList() {
        const notificationsList = document.getElementById('notificationList');
        if (notificationsList) {
            notificationsList.innerHTML = this.notifications.map(notification => `
                <div class="notification-item ${notification.type}">
                    <h4>${notification.title}</h4>
                    <p>${notification.message}</p>
                    <span class="time">${new Date(notification.id).toLocaleTimeString()}</span>
                </div>
            `).join('');
        }
    }

    startMonitoring() {
        if (!this.activeMonitoring) {
            this.activeMonitoring = true;
            this.ws.send(JSON.stringify({
                action: 'start_monitoring'
            }));
        }
    }

    stopMonitoring() {
        if (this.activeMonitoring) {
            this.activeMonitoring = false;
            this.ws.send(JSON.stringify({
                action: 'stop_monitoring'
            }));
        }
    }

    dismissAlert(alertId) {
        this.ws.send(JSON.stringify({
            action: 'dismiss_alert',
            alertId: alertId
        }));
    }

    clearAllAlerts() {
        this.ws.send(JSON.stringify({
            action: 'clear_alerts'
        }));
    }

    initializeCharts() {
        // Initialize all charts with default configuration
        const chartElements = document.querySelectorAll('[data-chart]');
        chartElements.forEach(element => {
            const chartId = element.id;
            const chartType = element.dataset.chart;
            const chartConfig = this.getChartConfig(chartType);
            
            const chart = new Chart(element, chartConfig);
            this.charts.set(chartId, chart);
        });
    }

    getChartConfig(type) {
        const defaultConfig = {
            responsive: true,
            maintainAspectRatio: false,
            animation: {
                duration: 1000,
                easing: 'easeInOutQuart'
            },
            plugins: {
                legend: {
                    display: false
                }
            }
        };

        switch (type) {
            case 'line':
                return {
                    ...defaultConfig,
                    type: 'line',
                    data: {
                        labels: [],
                        datasets: [{
                            data: [],
                            borderColor: '#3b82f6',
                            tension: 0.4,
                            fill: false
                        }]
                    }
                };

            case 'bar':
                return {
                    ...defaultConfig,
                    type: 'bar',
                    data: {
                        labels: [],
                        datasets: [{
                            data: [],
                            backgroundColor: '#3b82f6'
                        }]
                    }
                };

            default:
                return defaultConfig;
        }
    }
}
