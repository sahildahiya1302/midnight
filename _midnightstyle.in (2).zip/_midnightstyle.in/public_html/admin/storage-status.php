<?php
require_once __DIR__ . '/../../private/bootstrap.php';

// Get storage instance and status
$storage = StorageFactory::getStorage();
$status = $storage->getStatus();

// Get recent error logs
function getRecentLogs($limit = 10) {
    $logFile = __DIR__ . '/../../private/logs/error.log';
    $logs = [];
    
    if (file_exists($logFile)) {
        $lines = array_reverse(file($logFile));
        $logs = array_slice($lines, 0, $limit);
    }
    
    return $logs;
}

// If this is an AJAX request
if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && $_SERVER['HTTP_X_REQUESTED_WITH'] === 'XMLHttpRequest') {
    header('Content-Type: application/json');
    echo json_encode([
        'status' => $status,
        'logs' => getRecentLogs()
    ]);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Storage Status - Admin Dashboard</title>
    <link rel="stylesheet" href="assets/css/admin.css">
    <link rel="stylesheet" href="assets/css/storage-status.css">
</head>
<body>
    <div class="storage-status">
        <h1>Storage Status Dashboard</h1>
        
        <div class="status-banner <?php echo $status['mode']; ?>" id="statusBanner">
            <div>
                <span class="status-indicator <?php echo isset($status['connected']) && $status['connected'] ? 'active' : 'inactive'; ?>"></span>
                <strong>Current Mode: <?php echo ucfirst($status['mode']); ?></strong>
            </div>
            <button class="refresh-button" onclick="refreshStatus()">Refresh Status</button>
        </div>

        <div class="status-grid">
            <div class="status-card">
                <h3>Storage Details</h3>
                <div id="storageDetails">
                    <p><strong>Mode:</strong> <?php echo ucfirst($status['mode']); ?></p>
                    <?php if ($status['mode'] === 'database'): ?>
                    <p><strong>Connection:</strong> <?php echo isset($status['connected']) && $status['connected'] ? 'Connected' : 'Disconnected'; ?></p>
                    <p><strong>Transaction Active:</strong> <?php echo $status['in_transaction'] ? 'Yes' : 'No'; ?></p>
                    <?php else: ?>
                    <p><strong>Data Path:</strong> <?php echo $status['data_path']; ?></p>
                    <p><strong>Transaction Active:</strong> <?php echo $status['transaction'] ? 'Yes' : 'No'; ?></p>
                    <?php endif; ?>
                </div>
            </div>

            <div class="status-card">
                <h3>Recent Error Logs</h3>
                <div class="log-entries" id="logEntries">
                    <?php foreach (getRecentLogs() as $log): ?>
                    <div class="log-entry"><?php echo htmlspecialchars($log); ?></div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
    function refreshStatus() {
        fetch('storage-status.php', {
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            }
        })
        .then(response => response.json())
        .then(data => {
            // Update storage details
            const storageDetails = document.getElementById('storageDetails');
            let detailsHtml = `<p><strong>Mode:</strong> ${data.status.mode}</p>`;
            
            if (data.status.mode === 'database') {
                detailsHtml += `
                    <p><strong>Connection:</strong> ${data.status.connected ? 'Connected' : 'Disconnected'}</p>
                    <p><strong>Transaction Active:</strong> ${data.status.in_transaction ? 'Yes' : 'No'}</p>
                `;
            } else {
                detailsHtml += `
                    <p><strong>Data Path:</strong> ${data.status.data_path}</p>
                    <p><strong>Transaction Active:</strong> ${data.status.transaction ? 'Yes' : 'No'}</p>
                `;
            }
            storageDetails.innerHTML = detailsHtml;

            // Update status banner
            const banner = document.getElementById('statusBanner');
            banner.className = `status-banner ${data.status.mode}`;
            
            // Update log entries
            const logEntries = document.getElementById('logEntries');
            logEntries.innerHTML = data.logs.map(log => 
                `<div class="log-entry">${log}</div>`
            ).join('');
        })
        .catch(error => {
            console.error('Error refreshing status:', error);
            alert('Failed to refresh status. Please try again.');
        });
    }

    // Auto-refresh every 30 seconds
    setInterval(refreshStatus, 30000);
    </script>
</body>
</html>
