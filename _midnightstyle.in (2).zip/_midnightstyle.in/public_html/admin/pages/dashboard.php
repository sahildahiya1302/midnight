<?php
require_once __DIR__ . '/../../../private/classes/Admin/DashboardStats.php';

$stats = new DashboardStats();
$todayStats = $stats->getTodayStats();
$weeklyStats = $stats->getWeeklyStats();
$monthlyStats = $stats->getMonthlyStats();
?>

<div class="dashboard-grid">
    <!-- Quick Stats -->
    <div class="stats-cards">
        <!-- Revenue Stats -->
        <div class="stat-card">
            <div class="stat-header">
                <h3>Revenue</h3>
                <div class="stat-period">
                    <button class="active" data-period="today">Today</button>
                    <button data-period="week">Week</button>
                    <button data-period="month">Month</button>
                </div>
            </div>
            <div class="stat-body">
                <div class="stat-value">₹<?= number_format($todayStats['revenue'], 2) ?></div>
                <div class="stat-change <?= $todayStats['revenue_change'] >= 0 ? 'positive' : 'negative' ?>">
                    <?= $todayStats['revenue_change'] >= 0 ? '+' : '' ?><?= $todayStats['revenue_change'] ?>%
                </div>
            </div>
            <div class="stat-chart">
                <canvas id="revenueChart"></canvas>
            </div>
        </div>

        <!-- User Stats -->
        <div class="stat-card">
            <div class="stat-header">
                <h3>Active Users</h3>
                <div class="stat-period">
                    <button class="active" data-period="today">Today</button>
                    <button data-period="week">Week</button>
                    <button data-period="month">Month</button>
                </div>
            </div>
            <div class="stat-body">
                <div class="stat-value"><?= number_format($todayStats['active_users']) ?></div>
                <div class="stat-change <?= $todayStats['user_change'] >= 0 ? 'positive' : 'negative' ?>">
                    <?= $todayStats['user_change'] >= 0 ? '+' : '' ?><?= $todayStats['user_change'] ?>%
                </div>
            </div>
            <div class="stat-chart">
                <canvas id="usersChart"></canvas>
            </div>
        </div>

        <!-- Game Stats -->
        <div class="stat-card">
            <div class="stat-header">
                <h3>Games Played</h3>
                <div class="stat-period">
                    <button class="active" data-period="today">Today</button>
                    <button data-period="week">Week</button>
                    <button data-period="month">Month</button>
                </div>
            </div>
            <div class="stat-body">
                <div class="stat-value"><?= number_format($todayStats['games_played']) ?></div>
                <div class="stat-change <?= $todayStats['games_change'] >= 0 ? 'positive' : 'negative' ?>">
                    <?= $todayStats['games_change'] >= 0 ? '+' : '' ?><?= $todayStats['games_change'] ?>%
                </div>
            </div>
            <div class="stat-chart">
                <canvas id="gamesChart"></canvas>
            </div>
        </div>

        <!-- Transaction Stats -->
        <div class="stat-card">
            <div class="stat-header">
                <h3>Transactions</h3>
                <div class="stat-period">
                    <button class="active" data-period="today">Today</button>
                    <button data-period="week">Week</button>
                    <button data-period="month">Month</button>
                </div>
            </div>
            <div class="stat-body">
                <div class="stat-value"><?= number_format($todayStats['transactions']) ?></div>
                <div class="stat-change <?= $todayStats['transaction_change'] >= 0 ? 'positive' : 'negative' ?>">
                    <?= $todayStats['transaction_change'] >= 0 ? '+' : '' ?><?= $todayStats['transaction_change'] ?>%
                </div>
            </div>
            <div class="stat-chart">
                <canvas id="transactionsChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Real-time Monitoring -->
    <div class="monitoring-section">
        <div class="section-header">
            <h3>Real-time Monitoring</h3>
            <div class="header-actions">
                <button class="refresh-btn" onclick="refreshMonitoring()">
                    <i class="icon-refresh"></i>
                </button>
                <select id="updateInterval">
                    <option value="5">Update every 5s</option>
                    <option value="10">Update every 10s</option>
                    <option value="30">Update every 30s</option>
                </select>
            </div>
        </div>

        <div class="monitoring-grid">
            <!-- Server Status -->
            <div class="monitor-card">
                <div class="card-header">
                    <h4>Server Status</h4>
                    <span class="status-dot online"></span>
                </div>
                <div class="server-metrics">
                    <div class="metric">
                        <span class="label">CPU Usage</span>
                        <div class="progress-bar">
                            <div class="progress" style="width: <?= $stats->getServerMetrics()['cpu_usage'] ?>%"></div>
                        </div>
                        <span class="value"><?= $stats->getServerMetrics()['cpu_usage'] ?>%</span>
                    </div>
                    <div class="metric">
                        <span class="label">Memory Usage</span>
                        <div class="progress-bar">
                            <div class="progress" style="width: <?= $stats->getServerMetrics()['memory_usage'] ?>%"></div>
                        </div>
                        <span class="value"><?= $stats->getServerMetrics()['memory_usage'] ?>%</span>
                    </div>
                    <div class="metric">
                        <span class="label">Network Load</span>
                        <div class="progress-bar">
                            <div class="progress" style="width: <?= $stats->getServerMetrics()['network_load'] ?>%"></div>
                        </div>
                        <span class="value"><?= $stats->getServerMetrics()['network_load'] ?>%</span>
                    </div>
                </div>
            </div>

            <!-- Active Games -->
            <div class="monitor-card">
                <div class="card-header">
                    <h4>Active Games</h4>
                    <span class="count"><?= $stats->getActiveGamesCount() ?></span>
                </div>
                <div class="games-list">
                    <?php foreach ($stats->getActiveGames() as $game): ?>
                        <div class="game-item">
                            <div class="game-info">
                                <img src="/assets/images/games/<?= $game['type'] ?>-icon.png" alt="<?= $game['type'] ?>">
                                <div class="details">
                                    <h5><?= ucfirst($game['type']) ?></h5>
                                    <span><?= $game['players'] ?> players</span>
                                </div>
                            </div>
                            <div class="game-status">
                                <span class="status <?= $game['status'] ?>"><?= ucfirst($game['status']) ?></span>
                                <span class="time"><?= $game['duration'] ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Active Users -->
            <div class="monitor-card">
                <div class="card-header">
                    <h4>Online Users</h4>
                    <span class="count"><?= $stats->getOnlineUsersCount() ?></span>
                </div>
                <div class="users-map" id="usersMap"></div>
            </div>

            <!-- Recent Transactions -->
            <div class="monitor-card">
                <div class="card-header">
                    <h4>Recent Transactions</h4>
                    <a href="/admin?page=transactions" class="view-all">View All</a>
                </div>
                <div class="transactions-list">
                    <?php foreach ($stats->getRecentTransactions() as $transaction): ?>
                        <div class="transaction-item">
                            <div class="transaction-icon <?= $transaction['type'] ?>">
                                <i class="icon-<?= $transaction['type'] ?>"></i>
                            </div>
                            <div class="transaction-info">
                                <div class="user-info">
                                    <img src="<?= $transaction['user_avatar'] ?>" alt="<?= $transaction['username'] ?>">
                                    <span><?= $transaction['username'] ?></span>
                                </div>
                                <div class="amount <?= $transaction['type'] ?>">
                                    <?= $transaction['type'] === 'deposit' ? '+' : '-' ?>
                                    ₹<?= number_format($transaction['amount'], 2) ?>
                                </div>
                            </div>
                            <div class="transaction-status">
                                <span class="status <?= $transaction['status'] ?>">
                                    <?= ucfirst($transaction['status']) ?>
                                </span>
                                <span class="time"><?= $transaction['time'] ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- System Alerts -->
    <div class="alerts-section">
        <div class="section-header">
            <h3>System Alerts</h3>
            <div class="header-actions">
                <button class="clear-all" onclick="clearAllAlerts()">Clear All</button>
            </div>
        </div>
        <div class="alerts-list" id="systemAlerts">
            <?php foreach ($stats->getSystemAlerts() as $alert): ?>
                <div class="alert-item <?= $alert['level'] ?>">
                    <div class="alert-icon">
                        <i class="icon-<?= $alert['icon'] ?>"></i>
                    </div>
                    <div class="alert-content">
                        <h4><?= $alert['title'] ?></h4>
                        <p><?= $alert['message'] ?></p>
                        <span class="time"><?= $alert['time'] ?></span>
                    </div>
                    <button class="dismiss-alert" onclick="dismissAlert(<?= $alert['id'] ?>)">
                        &times;
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
// Initialize charts
const revenueChart = new Chart(document.getElementById('revenueChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($stats->getRevenueChartData()['labels']) ?>,
        datasets: [{
            label: 'Revenue',
            data: <?= json_encode($stats->getRevenueChartData()['data']) ?>,
            borderColor: 'rgb(75, 192, 192)',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

const usersChart = new Chart(document.getElementById('usersChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($stats->getUsersChartData()['labels']) ?>,
        datasets: [{
            label: 'Active Users',
            data: <?= json_encode($stats->getUsersChartData()['data']) ?>,
            borderColor: 'rgb(54, 162, 235)',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

const gamesChart = new Chart(document.getElementById('gamesChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($stats->getGamesChartData()['labels']) ?>,
        datasets: [{
            label: 'Games Played',
            data: <?= json_encode($stats->getGamesChartData()['data']) ?>,
            borderColor: 'rgb(153, 102, 255)',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

const transactionsChart = new Chart(document.getElementById('transactionsChart'), {
    type: 'line',
    data: {
        labels: <?= json_encode($stats->getTransactionsChartData()['labels']) ?>,
        datasets: [{
            label: 'Transactions',
            data: <?= json_encode($stats->getTransactionsChartData()['data']) ?>,
            borderColor: 'rgb(255, 159, 64)',
            tension: 0.4
        }]
    },
    options: {
        responsive: true,
        maintainAspectRatio: false
    }
});

// Initialize users map
const usersMap = new UsersMap('usersMap', {
    users: <?= json_encode($stats->getOnlineUsersLocations()) ?>,
    mapStyle: 'dark'
});

// Update monitoring data
let updateInterval = 5000;
let updateTimer;

function refreshMonitoring() {
    fetch('/admin/api/monitoring')
        .then(response => response.json())
        .then(data => {
            updateServerMetrics(data.server);
            updateActiveGames(data.games);
            updateOnlineUsers(data.users);
            updateTransactions(data.transactions);
            updateSystemAlerts(data.alerts);
        })
        .catch(console.error);
}

function updateServerMetrics(metrics) {
    document.querySelectorAll('.server-metrics .metric').forEach(metric => {
        const type = metric.querySelector('.label').textContent.toLowerCase().replace(' ', '_');
        const value = metrics[type];
        metric.querySelector('.progress').style.width = value + '%';
        metric.querySelector('.value').textContent = value + '%';
    });
}

function updateActiveGames(games) {
    const list = document.querySelector('.games-list');
    list.innerHTML = games.map(game => `
        <div class="game-item">
            <div class="game-info">
                <img src="/assets/images/games/${game.type}-icon.png" alt="${game.type}">
                <div class="details">
                    <h5>${game.type.charAt(0).toUpperCase() + game.type.slice(1)}</h5>
                    <span>${game.players} players</span>
                </div>
            </div>
            <div class="game-status">
                <span class="status ${game.status}">${game.status.charAt(0).toUpperCase() + game.status.slice(1)}</span>
                <span class="time">${game.duration}</span>
            </div>
        </div>
    `).join('');
}

function updateOnlineUsers(users) {
    usersMap.updateUsers(users);
    document.querySelector('.monitor-card .count').textContent = users.length;
}

function updateTransactions(transactions) {
    const list = document.querySelector('.transactions-list');
    list.innerHTML = transactions.map(tx => `
        <div class="transaction-item">
            <div class="transaction-icon ${tx.type}">
                <i class="icon-${tx.type}"></i>
            </div>
            <div class="transaction-info">
                <div class="user-info">
                    <img src="${tx.user_avatar}" alt="${tx.username}">
                    <span>${tx.username}</span>
                </div>
                <div class="amount ${tx.type}">
                    ${tx.type === 'deposit' ? '+' : '-'}₹${Number(tx.amount).toFixed(2)}
                </div>
            </div>
            <div class="transaction-status">
                <span class="status ${tx.status}">${tx.status.charAt(0).toUpperCase() + tx.status.slice(1)}</span>
                <span class="time">${tx.time}</span>
            </div>
        </div>
    `).join('');
}

function updateSystemAlerts(alerts) {
    const list = document.getElementById('systemAlerts');
    list.innerHTML = alerts.map(alert => `
        <div class="alert-item ${alert.level}">
            <div class="alert-icon">
                <i class="icon-${alert.icon}"></i>
            </div>
            <div class="alert-content">
                <h4>${alert.title}</h4>
                <p>${alert.message}</p>
                <span class="time">${alert.time}</span>
            </div>
            <button class="dismiss-alert" onclick="dismissAlert(${alert.id})">
                &times;
            </button>
        </div>
    `).join('');
}

// Handle update interval change
document.getElementById('updateInterval').addEventListener('change', (e) => {
    updateInterval = e.target.value * 1000;
    clearInterval(updateTimer);
    updateTimer = setInterval(refreshMonitoring, updateInterval);
});

// Handle stat period change
document.querySelectorAll('.stat-period button').forEach(button => {
    button.addEventListener('click', async (e) => {
        const card = e.target.closest('.stat-card');
        const period = e.target.dataset.period;
        
        // Update active state
        card.querySelectorAll('.stat-period button').forEach(btn => 
            btn.classList.remove('active'));
        e.target.classList.add('active');

        // Fetch and update stats
        try {
            const response = await fetch(`/admin/api/stats?type=${card.querySelector('h3').textContent.toLowerCase()}&period=${period}`);
            const data = await response.json();
            
            card.querySelector('.stat-value').textContent = 
                data.value.toString().includes('.') 
                    ? '₹' + Number(data.value).toFixed(2)
                    : Number(data.value).toLocaleString();
            
            const changeEl = card.querySelector('.stat-change');
            changeEl.textContent = (data.change >= 0 ? '+' : '') + data.change + '%';
            changeEl.className = `stat-change ${data.change >= 0 ? 'positive' : 'negative'}`;

            // Update chart
            const chartId = card.querySelector('canvas').id;
            const chart = Chart.getChart(chartId);
            chart.data.labels = data.chart.labels;
            chart.data.datasets[0].data = data.chart.data;
            chart.update();
        } catch (error) {
            console.error('Error updating stats:', error);
        }
    });
});

// Handle alert dismissal
function dismissAlert(alertId) {
    fetch(`/admin/api/alerts/${alertId}/dismiss`, { method: 'POST' })
        .then(() => {
            document.querySelector(`.alert-item[data-id="${alertId}"]`).remove();
        })
        .catch(console.error);
}

// Handle clear all alerts
function clearAllAlerts() {
    fetch('/admin/api/alerts/clear', { method: 'POST' })
        .then(() => {
            document.getElementById('systemAlerts').innerHTML = '';
        })
        .catch(console.error);
}

// Start monitoring updates
updateTimer = setInterval(refreshMonitoring, updateInterval);

// Initial refresh
refreshMonitoring();
</script>
