
const App = (() => {
    // App Configuration
    const config = {
        apiBaseUrl: '/api',
        websocketUrl: 'wss://midnightstyle.in/ws',
        refreshInterval: 30000, // 30 seconds
        maxReconnectAttempts: 5,
        toastDuration: 3000
    };

    // Utility Functions
    const utils = {
        formatCurrency: (amount) => {
            return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR' }).format(amount);
        },
        formatDate: (date) => {
            return new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(new Date(date));
        },
        showToast: (message, type = 'info') => {
            const toast = document.createElement('div');
            toast.className = `toast toast-${type}`;
            toast.textContent = message;
            document.body.appendChild(toast);
            setTimeout(() => toast.classList.add('show'), 100);
            setTimeout(() => {
                toast.classList.remove('show');
                setTimeout(() => toast.remove(), 300);
            }, config.toastDuration);
        },
        copyToClipboard: async (text) => {
            try {
                await navigator.clipboard.writeText(text);
                utils.showToast('Copied to clipboard!', 'success');
            } catch (err) {
                utils.showToast('Failed to copy text', 'error');
            }
        },
        validateForm: (formData, rules) => {
            const errors = {};
            for (const [field, value] of formData.entries()) {
                if (rules[field]) {
                    const fieldRules = rules[field];
                    if (fieldRules.required && !value) {
                        errors[field] = `${field} is required`;
                    }
                    if (fieldRules.min && value.length < fieldRules.min) {
                        errors[field] = `${field} must be at least ${fieldRules.min} characters`;
                    }
                    if (fieldRules.max && value.length > fieldRules.max) {
                        errors[field] = `${field} must be less than ${fieldRules.max} characters`;
                    }
                    if (fieldRules.pattern && !fieldRules.pattern.test(value)) {
                        errors[field] = `${field} format is invalid`;
                    }
                }
            }
            return errors;
        }
    };

    // API Service
    const api = {
        fetch: async (endpoint, options = {}) => {
            try {
                const response = await fetch(`${config.apiBaseUrl}${endpoint}`, {
                    ...options,
                    headers: {
                        'Content-Type': 'application/json',
                        ...options.headers
                    },
                    credentials: 'include'
                });
                if (!response.ok) {
                    throw new Error(response.statusText);
                }
                const data = await response.json();
                return data;
            } catch (error) {
                console.error('API Error:', error);
                throw error;
            }
        },
        user: {
            getProfile: () => api.fetch('/user/profile'),
            updateProfile: (data) => api.fetch('/user/profile', { method: 'PUT', body: JSON.stringify(data) }),
            getWallet: () => api.fetch('/user/wallet'),
            getTransactions: () => api.fetch('/user/transactions')
        },
        wallet: {
            deposit: (amount, gateway) => api.fetch('/wallet/deposit', { method: 'POST', body: JSON.stringify({ amount, gateway }) }),
            withdraw: (amount, details) => api.fetch('/wallet/withdraw', { method: 'POST', body: JSON.stringify({ amount, ...details }) })
        },
        game: {
            joinLobby: (gameType, entryFee) => api.fetch('/games/join', { method: 'POST', body: JSON.stringify({ gameType, entryFee }) }),
            getGameState: (gameId) => api.fetch(`/games/${gameId}/state`),
            makeMove: (gameId, move) => api.fetch(`/games/${gameId}/move`, { method: 'POST', body: JSON.stringify(move) })
        }
    };

    // WebSocket Service
    class WebSocketService {
        constructor() {
            this.ws = null;
            this.reconnectAttempts = 0;
            this.handlers = new Map();
            this.reconnectTimeout = null;
        }

        connect() {
            if (this.ws) {
                this.ws.close();
            }

            this.ws = new WebSocket(config.websocketUrl);

            this.ws.onopen = () => {
                console.log('WebSocket connected');
                this.reconnectAttempts = 0;
                if (this.reconnectTimeout) {
                    clearTimeout(this.reconnectTimeout);
                }
            };

            this.ws.onmessage = (event) => {
                try {
                    const data = JSON.parse(event.data);
                    if (this.handlers.has(data.type)) {
                        this.handlers.get(data.type).forEach(handler => handler(data.payload));
                    }
                } catch (error) {
                    console.error('WebSocket message parsing error:', error, event.data);
                }
            };

            this.ws.onclose = (event) => {
                console.log('WebSocket disconnected', event.code, event.reason);
                this.reconnect();
            };

            this.ws.onerror = (error) => {
                console.error('WebSocket error:', error);
                this.reconnect();
            };
        }

        reconnect() {
            if (this.reconnectAttempts < config.maxReconnectAttempts) {
                this.reconnectAttempts++;
                const delay = 1000 * Math.pow(2, this.reconnectAttempts - 1);
                console.log(`Attempting WebSocket reconnection in ${delay / 1000} seconds`);
                this.reconnectTimeout = setTimeout(() => {
                    this.connect();
                }, delay);
            } else {
                console.error('Max WebSocket reconnection attempts reached.');
            }
        }

        on(type, handler) {
            if (!this.handlers.has(type)) {
                this.handlers.set(type, []);
            }
            this.handlers.get(type).push(handler);
        }

        off(type, handler) {
            if (this.handlers.has(type)) {
                const handlers = this.handlers.get(type).filter(h => h !== handler);
                this.handlers.set(type, handlers);
            }
        }

        send(type, payload) {
            if (this.ws && this.ws.readyState === WebSocket.OPEN) {
                this.ws.send(JSON.stringify({ type, payload }));
            } else {
                console.error('WebSocket is not open');
            }
        }
    }

    return { config, utils, api, WebSocketService };
})();

// Initialize App
document.addEventListener('DOMContentLoaded', () => {
    const ws = new App.WebSocketService();
    ws.connect();

    const walletBalance = document.querySelector('.wallet-balance .amount');
    if (walletBalance) {
        const updateWallet = async () => {
            try {
                const data = await App.api.user.getWallet();
                walletBalance.textContent = App.utils.formatCurrency(data.balance);
            } catch (error) {
                console.error('Error updating wallet:', error);
            }
        };

        ws.on('wallet_update', (data) => {
            walletBalance.textContent = App.utils.formatCurrency(data.balance);
            App.utils.showToast(data.message, data.type);
        });

        updateWallet();
        setInterval(updateWallet, App.config.refreshInterval);
    }
});
