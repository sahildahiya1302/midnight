class AviatorGame {
    constructor(config) {
        this.config = config;
        this.canvas = document.getElementById('gameCanvas');
        this.ctx = this.canvas.getContext('2d');
        this.gameState = {
            status: 'waiting',
            currentMultiplier: 1.00,
            hasActiveBet: false,
            autoCashoutAt: null,
            betAmount: 0,
            players: new Map(),
            history: []
        };

        // Animation properties
        this.planePos = { x: 50, y: this.canvas.height - 50 };
        this.planeAngle = 0;
        this.animationFrame = null;
        this.lastTimestamp = 0;

        // Initialize
        this.initializeCanvas();
        this.loadAssets();
    }

    initializeCanvas() {
        // Set canvas size
        this.resizeCanvas();

        // Create gradient background
        this.gradient = this.ctx.createLinearGradient(0, 0, 0, this.canvas.height);
        this.gradient.addColorStop(0, '#1a1a2e');
        this.gradient.addColorStop(1, '#16213e');
    }

    resizeCanvas() {
        const container = this.canvas.parentElement;
        this.canvas.width = container.clientWidth;
        this.canvas.height = container.clientHeight;
    }

    async loadAssets() {
        this.planeImage = new Image();
        this.planeImage.src = '/assets/games/aviator/plane.png';
        await new Promise(resolve => this.planeImage.onload = resolve);
    }

    connect() {
        // Connect to WebSocket server
        this.ws = new WebSocket(`wss://${window.location.hostname}/ws`);
        
        this.ws.onopen = () => {
            this.authenticate();
        };

        this.ws.onmessage = (event) => {
            const data = JSON.parse(event.data);
            this.handleServerMessage(data);
        };

        this.ws.onclose = () => {
            utils.showToast('Connection lost. Reconnecting...', 'error');
            setTimeout(() => this.connect(), 1000);
        };
    }

    authenticate() {
        this.ws.send(JSON.stringify({
            action: 'authenticate',
            token: localStorage.getItem('auth_token')
        }));
    }

    handleServerMessage(data) {
        switch (data.type) {
            case 'game_state':
                this.updateGameState(data.state);
                break;

            case 'round_started':
                this.startRound();
                break;

            case 'multiplier_update':
                this.updateMultiplier(data.multiplier);
                break;

            case 'round_ended':
                this.endRound(data.crashPoint);
                break;

            case 'bet_result':
                this.handleBetResult(data);
                break;

            case 'cashout_result':
                this.handleCashoutResult(data);
                break;

            case 'player_update':
                this.updatePlayer(data.player);
                break;

            case 'chat_message':
                this.addChatMessage(data);
                break;
        }
    }

    updateGameState(state) {
        this.gameState = {
            ...this.gameState,
            ...state
        };

        // Update UI
        this.updateUI();

        // Start animation if game is playing
        if (state.status === 'playing' && !this.animationFrame) {
            this.startAnimation();
        }
    }

    startRound() {
        // Reset game state
        this.gameState.status = 'playing';
        this.gameState.currentMultiplier = 1.00;
        this.planePos = { x: 50, y: this.canvas.height - 50 };
        this.planeAngle = 0;

        // Update UI
        document.getElementById('placeBetBtn').disabled = true;
        if (this.gameState.hasActiveBet) {
            document.getElementById('cashoutBtn').disabled = false;
        }

        // Start animation
        this.startAnimation();

        // Play start sound
        this.playSound('start');
    }

    updateMultiplier(multiplier) {
        this.gameState.currentMultiplier = multiplier;
        document.getElementById('currentMultiplier').textContent = 
            multiplier.toFixed(2) + 'x';

        // Check for auto cashout
        if (this.gameState.hasActiveBet && 
            this.gameState.autoCashoutAt && 
            multiplier >= this.gameState.autoCashoutAt) {
            this.cashout();
        }
    }

    endRound(crashPoint) {
        // Update game state
        this.gameState.status = 'ended';
        this.gameState.hasActiveBet = false;

        // Stop animation
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
            this.animationFrame = null;
        }

        // Update history
        this.updateHistory(crashPoint);

        // Show game over modal
        this.showGameOverModal(crashPoint);

        // Play crash sound
        this.playSound('crash');

        // Reset UI
        document.getElementById('placeBetBtn').disabled = false;
        document.getElementById('cashoutBtn').disabled = true;
    }

    startAnimation() {
        const animate = (timestamp) => {
            if (!this.lastTimestamp) this.lastTimestamp = timestamp;
            const deltaTime = timestamp - this.lastTimestamp;
            this.lastTimestamp = timestamp;

            // Clear canvas
            this.ctx.fillStyle = this.gradient;
            this.ctx.fillRect(0, 0, this.canvas.width, this.canvas.height);

            // Update plane position
            this.updatePlanePosition(deltaTime);

            // Draw flight path
            this.drawFlightPath();

            // Draw plane
            this.drawPlane();

            // Continue animation
            if (this.gameState.status === 'playing') {
                this.animationFrame = requestAnimationFrame(animate);
            }
        };

        this.animationFrame = requestAnimationFrame(animate);
    }

    updatePlanePosition(deltaTime) {
        // Calculate new position based on current multiplier
        const speed = 0.1 * deltaTime;
        const angle = Math.atan2(this.gameState.currentMultiplier - 1, 1);
        
        this.planePos.x += Math.cos(angle) * speed;
        this.planePos.y -= Math.sin(angle) * speed;
        this.planeAngle = angle;
    }

    drawFlightPath() {
        this.ctx.beginPath();
        this.ctx.moveTo(50, this.canvas.height - 50);
        this.ctx.quadraticCurveTo(
            this.planePos.x - 100,
            this.planePos.y + 50,
            this.planePos.x,
            this.planePos.y
        );
        
        this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
    }

    drawPlane() {
        this.ctx.save();
        this.ctx.translate(this.planePos.x, this.planePos.y);
        this.ctx.rotate(this.planeAngle);
        this.ctx.drawImage(
            this.planeImage,
            -25, -25,
            50, 50
        );
        this.ctx.restore();
    }

    placeBet() {
        const amount = parseFloat(document.getElementById('betAmount').value);
        const autoCashout = parseFloat(document.getElementById('autoCashout').value);

        if (this.validateBet(amount)) {
            this.ws.send(JSON.stringify({
                action: 'place_bet',
                amount: amount,
                autoCashoutAt: autoCashout
            }));

            this.gameState.betAmount = amount;
            this.gameState.autoCashoutAt = autoCashout;
        }
    }

    validateBet(amount) {
        if (isNaN(amount) || amount < this.config.minBet) {
            utils.showToast(`Minimum bet is ₹${this.config.minBet}`, 'error');
            return false;
        }

        if (amount > this.config.maxBet) {
            utils.showToast(`Maximum bet is ₹${this.config.maxBet}`, 'error');
            return false;
        }

        if (amount > this.config.balance) {
            utils.showToast('Insufficient balance', 'error');
            return false;
        }

        return true;
    }

    handleBetResult(data) {
        if (data.success) {
            this.gameState.hasActiveBet = true;
            utils.showToast('Bet placed successfully', 'success');
        } else {
            utils.showToast(data.error, 'error');
        }
    }

    cashout() {
        if (this.gameState.hasActiveBet) {
            this.ws.send(JSON.stringify({
                action: 'cashout'
            }));
        }
    }

    handleCashoutResult(data) {
        if (data.success) {
            this.gameState.hasActiveBet = false;
            document.getElementById('cashoutBtn').disabled = true;

            // Update balance
            this.config.balance += data.winAmount;
            document.querySelector('.wallet-info .amount').textContent = 
                '₹' + this.config.balance.toFixed(2);

            // Show success message
            utils.showToast(
                `Cashed out at ${data.multiplier}x (₹${data.winAmount.toFixed(2)})`,
                'success'
            );

            // Play win sound
            this.playSound('win');
        } else {
            utils.showToast(data.error, 'error');
        }
    }

    updatePlayer(player) {
        this.gameState.players.set(player.userId, player);
        this.updatePlayersList();
    }

    updatePlayersList() {
        const tbody = document.getElementById('playersList');
        tbody.innerHTML = '';

        Array.from(this.gameState.players.values())
            .sort((a, b) => b.betAmount - a.betAmount)
            .forEach(player => {
                const tr = document.createElement('tr');
                tr.className = player.status;
                
                const profit = player.status === 'cashed_out' 
                    ? (player.betAmount * player.cashoutMultiplier) - player.betAmount
                    : -player.betAmount;

                tr.innerHTML = `
                    <td>
                        <div class="player-info">
                            <img src="${player.avatar}" alt="${player.username}">
                            <span>${player.username}</span>
                        </div>
                    </td>
                    <td>₹${player.betAmount.toFixed(2)}</td>
                    <td>${player.status === 'cashed_out' 
                        ? player.cashoutMultiplier.toFixed(2) + 'x'
                        : '-'}</td>
                    <td class="${profit >= 0 ? 'profit' : 'loss'}">
                        ${profit >= 0 ? '+' : ''}₹${profit.toFixed(2)}
                    </td>
                `;
                
                tbody.appendChild(tr);
            });
    }

    updateHistory(crashPoint) {
        this.gameState.history.unshift(crashPoint);
        if (this.gameState.history.length > 50) {
            this.gameState.history.pop();
        }

        const container = document.getElementById('crashHistory');
        container.innerHTML = '';

        this.gameState.history.forEach(point => {
            const div = document.createElement('div');
            div.className = `crash-point ${point >= 2 ? 'high' : 'low'}`;
            div.textContent = point.toFixed(2) + 'x';
            container.appendChild(div);
        });
    }

    showGameOverModal(crashPoint) {
        const modal = document.getElementById('gameOverModal');
        const multiplier = document.getElementById('finalMultiplier');
        const message = document.getElementById('resultMessage');

        multiplier.textContent = crashPoint.toFixed(2);
        multiplier.className = crashPoint >= 2 ? 'high' : 'low';

        if (this.gameState.hasActiveBet) {
            message.textContent = 'Better luck next time!';
            message.className = 'lost';
        }

        modal.classList.add('active');

        // Start countdown for next round
        let countdown = 5;
        const timer = document.getElementById('nextRoundTimer');
        
        const updateTimer = () => {
            timer.textContent = countdown;
            if (countdown > 0) {
                countdown--;
                setTimeout(updateTimer, 1000);
            } else {
                modal.classList.remove('active');
            }
        };
        
        updateTimer();
    }

    addChatMessage(data) {
        const messages = document.getElementById('chatMessages');
        const div = document.createElement('div');
        div.className = `chat-message ${data.type}`;
        
        if (data.type === 'system') {
            div.innerHTML = `<span class="message">${data.message}</span>`;
        } else {
            div.innerHTML = `
                <span class="username">${data.username}:</span>
                <span class="message">${data.message}</span>
            `;
        }
        
        messages.appendChild(div);
        messages.scrollTop = messages.scrollHeight;
    }

    sendChatMessage(message) {
        this.ws.send(JSON.stringify({
            action: 'chat',
            message: message
        }));
    }

    playSound(type) {
        const sounds = {
            start: '/assets/games/aviator/sounds/start.mp3',
            crash: '/assets/games/aviator/sounds/crash.mp3',
            win: '/assets/games/aviator/sounds/win.mp3'
        };

        if (sounds[type]) {
            const audio = new Audio(sounds[type]);
            audio.play().catch(() => {});
        }
    }

    onPageHidden() {
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
            this.animationFrame = null;
        }
    }

    onPageVisible() {
        if (this.gameState.status === 'playing') {
            this.startAnimation();
        }
    }
}
