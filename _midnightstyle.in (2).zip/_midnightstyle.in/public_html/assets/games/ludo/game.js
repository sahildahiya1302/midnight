class LudoGame {
    constructor(config) {
        this.gameId = config.gameId;
        this.userId = config.userId;
        this.username = config.username;
        this.avatar = config.avatar;
        
        // Game state
        this.gameState = {
            status: 'waiting',
            currentPlayer: null,
            players: [],
            pieces: {},
            diceValue: null,
            turnTimeLeft: 0,
            winner: null
        };

        // Board configuration
        this.boardConfig = {
            size: 15, // 15x15 grid
            cellSize: 40,
            colors: {
                red: '#ef4444',
                green: '#22c55e',
                yellow: '#eab308',
                blue: '#3b82f6'
            },
            playerColors: ['red', 'green', 'yellow', 'blue'],
            paths: this.initializePaths()
        };

        // Game timers
        this.turnTimer = null;
        this.gameTimer = null;

        // Audio effects
        this.sounds = {
            dice: new Audio('/assets/games/ludo/sounds/dice.mp3'),
            move: new Audio('/assets/games/ludo/sounds/move.mp3'),
            capture: new Audio('/assets/games/ludo/sounds/capture.mp3'),
            win: new Audio('/assets/games/ludo/sounds/win.mp3')
        };

        // Initialize board
        this.initializeBoard();
    }

    // Initialize game paths for each player
    initializePaths() {
        return {
            red: [
                // Main path coordinates for red player
                [6, 13], [6, 12], [6, 11], [6, 10], [6, 9],
                [5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8],
                [0, 7], [0, 6],
                [1, 6], [2, 6], [3, 6], [4, 6], [5, 6],
                [6, 5], [6, 4], [6, 3], [6, 2], [6, 1], [6, 0],
                [7, 0], [8, 0],
                [8, 1], [8, 2], [8, 3], [8, 4], [8, 5],
                [9, 6], [10, 6], [11, 6], [12, 6], [13, 6], [14, 6],
                [14, 7], [14, 8],
                [13, 8], [12, 8], [11, 8], [10, 8], [9, 8],
                [8, 9], [8, 10], [8, 11], [8, 12], [8, 13], [8, 14],
                [7, 14], [7, 13], [7, 12], [7, 11], [7, 10], [7, 9]
            ],
            // Similar paths for other colors...
        };
    }

    // Initialize game board
    initializeBoard() {
        const board = document.getElementById('ludoBoard');
        board.style.width = `${this.boardConfig.size * this.boardConfig.cellSize}px`;
        board.style.height = `${this.boardConfig.size * this.boardConfig.cellSize}px`;

        // Create board cells
        for (let y = 0; y < this.boardConfig.size; y++) {
            for (let x = 0; x < this.boardConfig.size; x++) {
                const cell = document.createElement('div');
                cell.className = 'board-cell';
                cell.dataset.x = x;
                cell.dataset.y = y;
                cell.style.width = `${this.boardConfig.cellSize}px`;
                cell.style.height = `${this.boardConfig.cellSize}px`;
                
                // Add cell color based on position
                this.setCellColor(cell, x, y);
                
                board.appendChild(cell);
            }
        }

        // Add piece holders
        this.addPieceHolders();
    }

    // Set cell color based on position
    setCellColor(cell, x, y) {
        // Home areas
        if (this.isHomeArea(x, y, 'red')) {
            cell.style.backgroundColor = this.boardConfig.colors.red;
        } else if (this.isHomeArea(x, y, 'green')) {
            cell.style.backgroundColor = this.boardConfig.colors.green;
        } else if (this.isHomeArea(x, y, 'yellow')) {
            cell.style.backgroundColor = this.boardConfig.colors.yellow;
        } else if (this.isHomeArea(x, y, 'blue')) {
            cell.style.backgroundColor = this.boardConfig.colors.blue;
        }
        
        // Path cells
        if (this.isPathCell(x, y)) {
            cell.classList.add('path-cell');
        }
    }

    // Check if coordinates are in home area
    isHomeArea(x, y, color) {
        const areas = {
            red: { x: [0, 5], y: [0, 5] },
            green: { x: [9, 14], y: [0, 5] },
            yellow: { x: [9, 14], y: [9, 14] },
            blue: { x: [0, 5], y: [9, 14] }
        };

        const area = areas[color];
        return x >= area.x[0] && x <= area.x[1] && y >= area.y[0] && y <= area.y[1];
    }

    // Check if coordinates are part of the path
    isPathCell(x, y) {
        return Object.values(this.boardConfig.paths).some(path => 
            path.some(([px, py]) => px === x && py === y)
        );
    }

    // Add piece holders for each player
    addPieceHolders() {
        const holders = {
            red: [[1, 1], [1, 4], [4, 1], [4, 4]],
            green: [[10, 1], [10, 4], [13, 1], [13, 4]],
            yellow: [[10, 10], [10, 13], [13, 10], [13, 13]],
            blue: [[1, 10], [1, 13], [4, 10], [4, 13]]
        };

        Object.entries(holders).forEach(([color, positions]) => {
            positions.forEach(([x, y], index) => {
                const holder = document.createElement('div');
                holder.className = `piece-holder ${color}`;
                holder.dataset.color = color;
                holder.dataset.index = index;
                
                const cell = document.querySelector(`.board-cell[data-x="${x}"][data-y="${y}"]`);
                if (cell) {
                    cell.appendChild(holder);
                }
            });
        });
    }

    // Connect to game server
    connect() {
        // Initialize WebSocket connection
        this.initializeWebSocket();
        
        // Join game room
        this.sendGameAction('join', {
            gameId: this.gameId,
            userId: this.userId,
            username: this.username,
            avatar: this.avatar
        });
    }

    // Initialize WebSocket handlers
    initializeWebSocket() {
        ws.on('game_state', (data) => this.handleGameState(data));
        ws.on('player_joined', (data) => this.handlePlayerJoined(data));
        ws.on('player_left', (data) => this.handlePlayerLeft(data));
        ws.on('game_started', (data) => this.handleGameStarted(data));
        ws.on('turn_started', (data) => this.handleTurnStarted(data));
        ws.on('dice_rolled', (data) => this.handleDiceRolled(data));
        ws.on('piece_moved', (data) => this.handlePieceMoved(data));
        ws.on('piece_captured', (data) => this.handlePieceCaptured(data));
        ws.on('game_over', (data) => this.handleGameOver(data));
        ws.on('chat_message', (data) => this.handleChatMessage(data));
    }

    // Send game action to server
    sendGameAction(action, data = {}) {
        ws.send('game_action', {
            action,
            gameId: this.gameId,
            ...data
        });
    }

    // Handle game state update
    handleGameState(state) {
        this.gameState = state;
        this.updateUI();
    }

    // Handle player joined
    handlePlayerJoined(data) {
        const panel = document.querySelector(`.player-panel[data-player="${data.position}"]`);
        if (panel) {
            panel.querySelector('.player-avatar img').src = data.avatar;
            panel.querySelector('.player-name').textContent = data.username;
            panel.querySelector('.player-status').textContent = 'Ready';
            panel.classList.add('active');
        }

        this.addChatMessage({
            type: 'system',
            message: `${data.username} joined the game`
        });
    }

    // Handle player left
    handlePlayerLeft(data) {
        const panel = document.querySelector(`.player-panel[data-player="${data.position}"]`);
        if (panel) {
            panel.querySelector('.player-avatar img').src = '/assets/images/default-avatar.png';
            panel.querySelector('.player-name').textContent = 'Player ' + data.position;
            panel.querySelector('.player-status').textContent = 'Waiting...';
            panel.classList.remove('active');
        }

        this.addChatMessage({
            type: 'system',
            message: `${data.username} left the game`
        });
    }

    // Handle game started
    handleGameStarted(data) {
        this.gameState.status = 'playing';
        this.updateUI();
        this.addChatMessage({
            type: 'system',
            message: 'Game started!'
        });
        this.sounds.dice.play();
    }

    // Handle turn started
    handleTurnStarted(data) {
        this.gameState.currentPlayer = data.playerId;
        this.gameState.turnTimeLeft = data.timeLeft;
        
        this.updateTurnIndicator();
        this.startTurnTimer();

        if (data.playerId === this.userId) {
            this.enableDice();
        }
    }

    // Handle dice rolled
    handleDiceRolled(data) {
        this.gameState.diceValue = data.value;
        this.animateDice(data.value);
        this.sounds.dice.play();

        if (data.playerId === this.userId) {
            this.highlightValidMoves();
        }
    }

    // Handle piece moved
    handlePieceMoved(data) {
        this.movePiece(data.pieceId, data.from, data.to);
        this.sounds.move.play();
    }

    // Handle piece captured
    handlePieceCaptured(data) {
        this.capturePiece(data.pieceId);
        this.sounds.capture.play();
    }

    // Handle game over
    handleGameOver(data) {
        this.gameState.status = 'completed';
        this.gameState.winner = data.winner;
        
        this.showGameOverModal(data);
        this.sounds.win.play();
    }

    // Handle chat message
    handleChatMessage(data) {
        this.addChatMessage(data);
    }

    // Update UI elements
    updateUI() {
        this.updateBoard();
        this.updatePlayers();
        this.updateGameInfo();
    }

    // Update board state
    updateBoard() {
        // Clear existing pieces
        document.querySelectorAll('.game-piece').forEach(piece => piece.remove());
        
        // Place pieces according to game state
        Object.entries(this.gameState.pieces).forEach(([pieceId, piece]) => {
            this.placePiece(pieceId, piece.position, piece.color);
        });
    }

    // Update player panels
    updatePlayers() {
        this.gameState.players.forEach((player, index) => {
            const panel = document.querySelector(`.player-panel[data-player="${index + 1}"]`);
            if (panel) {
                panel.querySelector('.player-name').textContent = player.username;
                panel.querySelector('.player-avatar img').src = player.avatar;
                panel.querySelector('.player-status').textContent = 
                    this.gameState.currentPlayer === player.id ? 'Playing' : 'Waiting';
                
                if (this.gameState.currentPlayer === player.id) {
                    panel.classList.add('active');
                } else {
                    panel.classList.remove('active');
                }
            }
        });
    }

    // Update game information
    updateGameInfo() {
        document.getElementById('entryFee').textContent = this.gameState.entryFee;
        document.getElementById('prizePool').textContent = this.gameState.prizePool;
    }

    // Place a piece on the board
    placePiece(pieceId, position, color) {
        const piece = document.createElement('div');
        piece.className = `game-piece ${color}`;
        piece.dataset.pieceId = pieceId;
        
        const cell = document.querySelector(`.board-cell[data-x="${position[0]}"][data-y="${position[1]}"]`);
        if (cell) {
            cell.appendChild(piece);
        }
    }

    // Animate dice roll
    animateDice(value) {
        const dice = document.querySelector('.dice');
        dice.classList.add('rolling');
        
        setTimeout(() => {
            dice.classList.remove('rolling');
            dice.querySelector('.dice-inner').textContent = value;
        }, 1000);
    }

    // Highlight valid moves
    highlightValidMoves() {
        const validMoves = this.calculateValidMoves();
        validMoves.forEach(move => {
            const cell = document.querySelector(`.board-cell[data-x="${move.x}"][data-y="${move.y}"]`);
            if (cell) {
                cell.classList.add('valid-move');
            }
        });
    }

    // Calculate valid moves
    calculateValidMoves() {
        // Implementation depends on game rules
        return [];
    }

    // Move piece animation
    movePiece(pieceId, from, to) {
        const piece = document.querySelector(`.game-piece[data-pieceId="${pieceId}"]`);
        if (piece) {
            const fromCell = document.querySelector(`.board-cell[data-x="${from[0]}"][data-y="${from[1]}"]`);
            const toCell = document.querySelector(`.board-cell[data-x="${to[0]}"][data-y="${to[1]}"]`);
            
            if (fromCell && toCell) {
                const fromRect = fromCell.getBoundingClientRect();
                const toRect = toCell.getBoundingClientRect();
                
                piece.style.transition = 'transform 0.5s ease';
                piece.style.transform = `translate(${toRect.left - fromRect.left}px, ${toRect.top - fromRect.top}px)`;
                
                setTimeout(() => {
                    piece.style.transition = '';
                    piece.style.transform = '';
                    toCell.appendChild(piece);
                }, 500);
            }
        }
    }

    // Capture piece animation
    capturePiece(pieceId) {
        const piece = document.querySelector(`.game-piece[data-pieceId="${pieceId}"]`);
        if (piece) {
            piece.classList.add('captured');
            setTimeout(() => piece.remove(), 500);
        }
    }

    // Show game over modal
    showGameOverModal(data) {
        const modal = document.getElementById('gameOverModal');
        const winnerAvatar = modal.querySelector('.winner-avatar img');
        const winnerName = modal.querySelector('.winner-name');
        const prizeWon = modal.querySelector('#prizeWon');
        const standings = modal.querySelector('#finalStandings');
        
        winnerAvatar.src = data.winner.avatar;
        winnerName.textContent = data.winner.username;
        prizeWon.textContent = data.prizeAmount;
        
        standings.innerHTML = data.standings.map((player, index) => `
            <div class="standing-item">
                <span class="position">${index + 1}</span>
                <div class="player-info">
                    <img src="${player.avatar}" alt="${player.username}">
                    <span>${player.username}</span>
                </div>
                <span class="prize">${player.prize ? '₹' + player.prize : '-'}</span>
            </div>
        `).join('');
        
        modal.classList.add('active');
    }

    // Add chat message
    addChatMessage(data) {
        const messages = document.getElementById('chatMessages');
        const message = document.createElement('div');
        message.className = `chat-message ${data.type}`;
        
        if (data.type === 'system') {
            message.innerHTML = `<span class="message">${data.message}</span>`;
        } else {
            message.innerHTML = `
                <span class="username">${data.username}:</span>
                <span class="message">${data.message}</span>
            `;
        }
        
        messages.appendChild(message);
        messages.scrollTop = messages.scrollHeight;
    }

    // Send chat message
    sendChatMessage(message) {
        this.sendGameAction('chat', { message });
    }

    // Leave game
    leaveGame() {
        this.sendGameAction('leave');
    }

    // Check if game is active
    isGameActive() {
        return this.gameState.status === 'playing';
    }

    // Handle page visibility change
    onPageHidden() {
        // Pause timers and sounds
        if (this.turnTimer) clearInterval(this.turnTimer);
        Object.values(this.sounds).forEach(sound => sound.pause());
    }

    onPageVisible() {
        // Resume game state
        if (this.isGameActive()) {
            this.startTurnTimer();
        }
    }

    // Start turn timer
    startTurnTimer() {
        if (this.turnTimer) clearInterval(this.turnTimer);
        
        const updateTimer = () => {
            this.gameState.turnTimeLeft--;
            
            document.querySelectorAll('.player-time').forEach(timer => {
                timer.textContent = this.gameState.turnTimeLeft + 's';
            });
            
            if (this.gameState.turnTimeLeft <= 0) {
                clearInterval(this.turnTimer);
            }
        };
        
        this.turnTimer = setInterval(updateTimer, 1000);
        updateTimer();
    }

    // Enable dice for current player
    enableDice() {
        const dice = document.querySelector('.dice');
        dice.disabled = false;
        dice.classList.add('enabled');
    }

    // Disable dice
    disableDice() {
        const dice = document.querySelector('.dice');
        dice.disabled = true;
        dice.classList.remove('enabled');
    }
}
