<?php
require_once __DIR__ . '/../../../layouts/main.php';

$user = getCurrentUser();
$gameId = $_GET['id'] ?? null;

if (!$gameId) {
    header('Location: /games/ludo');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ludo Game - Gaming Platform</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/responsive.css">
    <link rel="stylesheet" href="/assets/games/ludo/style.css">
</head>
<body class="game-body">
    <div class="game-container">
        <!-- Game Header -->
        <div class="game-header">
            <div class="game-info">
                <h1>Ludo Game</h1>
                <div class="game-meta">
                    <span class="game-id">Game ID: <?= $gameId ?></span>
                    <span class="entry-fee">Entry: ₹<span id="entryFee">0</span></span>
                    <span class="prize-pool">Prize: ₹<span id="prizePool">0</span></span>
                </div>
            </div>
            <div class="game-actions">
                <button class="btn btn-secondary" onclick="showGameRules()">
                    <i class="icon-info"></i> Rules
                </button>
                <button class="btn btn-danger" onclick="showLeaveGameModal()">
                    <i class="icon-exit"></i> Leave Game
                </button>
            </div>
        </div>

        <!-- Game Board -->
        <div class="game-board-container">
            <div class="game-board" id="ludoBoard">
                <!-- Board will be rendered via JavaScript -->
            </div>

            <!-- Player Panels -->
            <div class="player-panels">
                <!-- Player 1 (Bottom) -->
                <div class="player-panel bottom" data-player="1">
                    <div class="player-info">
                        <div class="player-avatar">
                            <img src="/assets/images/default-avatar.png" alt="Player 1">
                        </div>
                        <div class="player-details">
                            <h3 class="player-name">Player 1</h3>
                            <span class="player-status">Waiting...</span>
                        </div>
                        <div class="player-time">30s</div>
                    </div>
                    <div class="player-dice">
                        <button class="dice" disabled>
                            <div class="dice-inner">1</div>
                        </button>
                    </div>
                </div>

                <!-- Player 2 (Right) -->
                <div class="player-panel right" data-player="2">
                    <div class="player-info">
                        <div class="player-avatar">
                            <img src="/assets/images/default-avatar.png" alt="Player 2">
                        </div>
                        <div class="player-details">
                            <h3 class="player-name">Player 2</h3>
                            <span class="player-status">Waiting...</span>
                        </div>
                        <div class="player-time">30s</div>
                    </div>
                    <div class="player-dice">
                        <button class="dice" disabled>
                            <div class="dice-inner">1</div>
                        </button>
                    </div>
                </div>

                <!-- Player 3 (Top) -->
                <div class="player-panel top" data-player="3">
                    <div class="player-info">
                        <div class="player-avatar">
                            <img src="/assets/images/default-avatar.png" alt="Player 3">
                        </div>
                        <div class="player-details">
                            <h3 class="player-name">Player 3</h3>
                            <span class="player-status">Waiting...</span>
                        </div>
                        <div class="player-time">30s</div>
                    </div>
                    <div class="player-dice">
                        <button class="dice" disabled>
                            <div class="dice-inner">1</div>
                        </button>
                    </div>
                </div>

                <!-- Player 4 (Left) -->
                <div class="player-panel left" data-player="4">
                    <div class="player-info">
                        <div class="player-avatar">
                            <img src="/assets/images/default-avatar.png" alt="Player 4">
                        </div>
                        <div class="player-details">
                            <h3 class="player-name">Player 4</h3>
                            <span class="player-status">Waiting...</span>
                        </div>
                        <div class="player-time">30s</div>
                    </div>
                    <div class="player-dice">
                        <button class="dice" disabled>
                            <div class="dice-inner">1</div>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Game Chat -->
        <div class="game-chat">
            <div class="chat-header">
                <h3>Game Chat</h3>
                <button class="toggle-chat" onclick="toggleChat()">
                    <i class="icon-chat"></i>
                </button>
            </div>
            <div class="chat-messages" id="chatMessages"></div>
            <div class="chat-input">
                <input type="text" id="messageInput" placeholder="Type a message...">
                <button onclick="sendMessage()">
                    <i class="icon-send"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Game Rules Modal -->
    <div class="modal" id="rulesModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Ludo Rules</h2>
                <button class="close-modal" onclick="closeModal('rulesModal')">&times;</button>
            </div>
            <div class="modal-body">
                <div class="rules-content">
                    <h3>Basic Rules</h3>
                    <ul>
                        <li>Each player has 4 tokens</li>
                        <li>Roll a 6 to move a token out of home</li>
                        <li>Roll dice and move tokens clockwise</li>
                        <li>Land on opponent's token to send it home</li>
                        <li>Get all 4 tokens to center to win</li>
                    </ul>

                    <h3>Turn Rules</h3>
                    <ul>
                        <li>15 seconds per turn</li>
                        <li>Roll 6 to get an extra turn</li>
                        <li>Three 6s in a row forfeits turn</li>
                        <li>Must move if possible</li>
                    </ul>

                    <h3>Winning & Prizes</h3>
                    <ul>
                        <li>First to finish wins 80% of pool</li>
                        <li>Game ends when winner is decided</li>
                        <li>Disconnection = automatic loss</li>
                        <li>3 skipped turns = elimination</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>

    <!-- Leave Game Modal -->
    <div class="modal" id="leaveGameModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Leave Game?</h2>
                <button class="close-modal" onclick="closeModal('leaveGameModal')">&times;</button>
            </div>
            <div class="modal-body">
                <p class="warning-text">
                    Are you sure you want to leave the game?<br>
                    You will forfeit the game and lose your entry fee.
                </p>
                <div class="modal-actions">
                    <button class="btn btn-secondary" onclick="closeModal('leaveGameModal')">
                        Cancel
                    </button>
                    <button class="btn btn-danger" onclick="leaveGame()">
                        Leave Game
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Game Over Modal -->
    <div class="modal" id="gameOverModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Game Over</h2>
            </div>
            <div class="modal-body">
                <div class="game-result">
                    <div class="result-icon">🏆</div>
                    <h3>Winner</h3>
                    <div class="winner-info">
                        <div class="winner-avatar">
                            <img src="/assets/images/default-avatar.png" alt="Winner">
                        </div>
                        <div class="winner-details">
                            <h4 class="winner-name">Player Name</h4>
                            <p class="prize-won">Won ₹<span id="prizeWon">0</span></p>
                        </div>
                    </div>
                </div>
                <div class="final-standings">
                    <h4>Final Standings</h4>
                    <div class="standings-list" id="finalStandings"></div>
                </div>
                <div class="modal-actions">
                    <button class="btn btn-secondary" onclick="playAgain()">
                        Play Again
                    </button>
                    <button class="btn btn-primary" onclick="goToLobby()">
                        Back to Lobby
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="/assets/js/app.js"></script>
    <script src="/assets/games/ludo/game.js"></script>
    <script>
        // Initialize game with configuration
        const gameConfig = {
            gameId: '<?= $gameId ?>',
            userId: '<?= $user->getId() ?>',
            username: '<?= h($user->getData()['username']) ?>',
            avatar: '<?= $user->getData()['avatar'] ?? '/assets/images/default-avatar.png' ?>'
        };

        // Initialize game instance
        const game = new LudoGame(gameConfig);

        // Connect to game server
        game.connect();

        // UI Functions
        function showGameRules() {
            document.getElementById('rulesModal').classList.add('active');
        }

        function showLeaveGameModal() {
            document.getElementById('leaveGameModal').classList.add('active');
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }

        function toggleChat() {
            document.querySelector('.game-chat').classList.toggle('active');
        }

        function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            
            if (message) {
                game.sendChatMessage(message);
                input.value = '';
            }
        }

        function leaveGame() {
            game.leaveGame();
            window.location.href = '/games/ludo';
        }

        function playAgain() {
            window.location.href = '/games/ludo/lobby';
        }

        function goToLobby() {
            window.location.href = '/games/ludo';
        }

        // Handle chat input
        document.getElementById('messageInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });

        // Handle page unload
        window.addEventListener('beforeunload', (e) => {
            if (game.isGameActive()) {
                e.preventDefault();
                e.returnValue = 'Are you sure you want to leave the game?';
            }
        });

        // Handle visibility change
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                game.onPageHidden();
            } else {
                game.onPageVisible();
            }
        });
    </script>
</body>
</html>
