<?php
require_once __DIR__ . '/../../../layouts/main.php';

$user = getCurrentUser();
$wallet = getCurrentWallet();
?>

<div class="lobby-container">
    <!-- Game Header -->
    <div class="game-header">
        <div class="game-info">
            <img src="/assets/images/games/ludo-icon.png" alt="Ludo" class="game-icon">
            <div class="game-details">
                <h1>Ludo</h1>
                <p>Classic multiplayer board game</p>
            </div>
        </div>
        <div class="player-info">
            <div class="wallet-balance">
                <span class="balance-label">Balance:</span>
                <span class="balance-amount">₹<?= number_format($wallet->getBalance(), 2) ?></span>
            </div>
            <div class="player-stats">
                <div class="stat">
                    <span class="stat-label">Games</span>
                    <span class="stat-value"><?= $user->getStats()['ludo_games'] ?></span>
                </div>
                <div class="stat">
                    <span class="stat-label">Wins</span>
                    <span class="stat-value"><?= $user->getStats()['ludo_wins'] ?></span>
                </div>
            </div>
        </div>
    </div>

    <!-- Entry Fee Selection -->
    <div class="entry-selection">
        <h2>Select Entry Fee</h2>
        <div class="fee-grid">
            <?php
            $entryFees = [10, 20, 50, 100, 500, 1000];
            foreach ($entryFees as $fee):
            ?>
                <div class="fee-card" data-fee="<?= $fee ?>">
                    <div class="fee-amount">₹<?= $fee ?></div>
                    <div class="prize-pool">
                        <span class="prize-label">Prize Pool</span>
                        <span class="prize-amount">₹<?= $fee * 4 ?></span>
                    </div>
                    <div class="players-info">
                        <span class="players-count" id="players-<?= $fee ?>">0 Playing</span>
                    </div>
                    <button class="join-btn" onclick="joinGame(<?= $fee ?>)"
                            <?= $wallet->getBalance() < $fee ? 'disabled' : '' ?>>
                        <?= $wallet->getBalance() < $fee ? 'Add Money' : 'Join Game' ?>
                    </button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Active Games -->
    <div class="active-games">
        <div class="section-header">
            <h2>Active Games</h2>
            <div class="game-filters">
                <button class="filter-btn active" data-filter="all">All</button>
                <button class="filter-btn" data-filter="waiting">Waiting</button>
                <button class="filter-btn" data-filter="playing">Playing</button>
            </div>
        </div>

        <div class="games-list" id="gamesList">
            <!-- Games will be populated via JavaScript -->
        </div>
    </div>
</div>

<!-- Game Join Modal -->
<div class="modal" id="joinModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Join Game</h2>
            <button class="close-modal" onclick="closeModal('joinModal')">&times;</button>
        </div>
        <div class="modal-body">
            <div class="join-info">
                <div class="entry-info">
                    <span class="label">Entry Fee:</span>
                    <span class="value">₹<span id="modalEntryFee">0</span></span>
                </div>
                <div class="prize-info">
                    <span class="label">Prize Pool:</span>
                    <span class="value">₹<span id="modalPrizePool">0</span></span>
                </div>
                <div class="wallet-info">
                    <span class="label">Your Balance:</span>
                    <span class="value">₹<?= number_format($wallet->getBalance(), 2) ?></span>
                </div>
            </div>
            <div class="confirmation-text">
                Are you sure you want to join this game?
            </div>
            <div class="modal-actions">
                <button class="btn btn-secondary" onclick="closeModal('joinModal')">Cancel</button>
                <button class="btn btn-primary" id="confirmJoinBtn">Join Game</button>
            </div>
        </div>
    </div>
</div>

<style>
/* Lobby Styles */
.lobby-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 1rem;
}

/* Game Header */
.game-header {
    background: var(--background-primary);
    border-radius: 1rem;
    padding: 1.5rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 2rem;
    box-shadow: var(--shadow);
}

.game-info {
    display: flex;
    align-items: center;
    gap: 1rem;
}

.game-icon {
    width: 64px;
    height: 64px;
    border-radius: 1rem;
}

.game-details h1 {
    font-size: 1.5rem;
    margin-bottom: 0.25rem;
}

.game-details p {
    color: var(--text-secondary);
}

.player-info {
    display: flex;
    align-items: center;
    gap: 2rem;
}

.wallet-balance {
    background: var(--background-secondary);
    padding: 0.75rem 1.5rem;
    border-radius: 0.75rem;
}

.balance-label {
    color: var(--text-secondary);
    margin-right: 0.5rem;
}

.balance-amount {
    font-weight: 600;
    color: var(--primary-color);
}

.player-stats {
    display: flex;
    gap: 1rem;
}

.stat {
    text-align: center;
}

.stat-label {
    display: block;
    font-size: 0.875rem;
    color: var(--text-secondary);
    margin-bottom: 0.25rem;
}

.stat-value {
    font-weight: 600;
}

/* Entry Fee Selection */
.entry-selection {
    margin-bottom: 2rem;
}

.entry-selection h2 {
    font-size: 1.25rem;
    margin-bottom: 1rem;
}

.fee-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
}

.fee-card {
    background: var(--background-primary);
    border-radius: 1rem;
    padding: 1.5rem;
    text-align: center;
    box-shadow: var(--shadow);
    transition: transform 0.2s;
}

.fee-card:hover {
    transform: translateY(-4px);
}

.fee-amount {
    font-size: 2rem;
    font-weight: 600;
    color: var(--primary-color);
    margin-bottom: 1rem;
}

.prize-pool {
    margin-bottom: 1rem;
}

.prize-label {
    display: block;
    font-size: 0.875rem;
    color: var(--text-secondary);
    margin-bottom: 0.25rem;
}

.prize-amount {
    font-weight: 600;
}

.players-info {
    margin-bottom: 1rem;
}

.players-count {
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.join-btn {
    width: 100%;
    padding: 0.75rem;
    border: none;
    border-radius: 0.5rem;
    background: var(--primary-color);
    color: white;
    font-weight: 500;
    cursor: pointer;
    transition: background-color 0.2s;
}

.join-btn:hover {
    background: var(--secondary-color);
}

.join-btn:disabled {
    background: var(--text-light);
    cursor: not-allowed;
}

/* Active Games */
.active-games {
    background: var(--background-primary);
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: var(--shadow);
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.section-header h2 {
    font-size: 1.25rem;
}

.game-filters {
    display: flex;
    gap: 0.5rem;
}

.filter-btn {
    padding: 0.5rem 1rem;
    border: none;
    border-radius: 0.5rem;
    background: var(--background-secondary);
    color: var(--text-secondary);
    cursor: pointer;
    transition: all 0.2s;
}

.filter-btn.active {
    background: var(--primary-color);
    color: white;
}

.games-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.game-item {
    background: var(--background-secondary);
    border-radius: 0.75rem;
    padding: 1rem;
    display: flex;
    align-items: center;
    gap: 1rem;
}

.game-status {
    width: 10px;
    height: 10px;
    border-radius: 50%;
}

.status-waiting {
    background: var(--warning-color);
}

.status-playing {
    background: var(--success-color);
}

.game-players {
    flex: 1;
    display: flex;
    gap: 1rem;
}

.player-avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    overflow: hidden;
}

.player-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.empty-slot {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    border: 2px dashed var(--border-color);
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--text-light);
}

.game-meta {
    text-align: right;
}

.entry-fee {
    font-weight: 600;
    margin-bottom: 0.25rem;
}

.time-left {
    font-size: 0.875rem;
    color: var(--text-secondary);
}

/* Modal Styles */
.join-info {
    background: var(--background-secondary);
    border-radius: 0.75rem;
    padding: 1rem;
    margin-bottom: 1.5rem;
}

.join-info > div {
    display: flex;
    justify-content: space-between;
    margin-bottom: 0.5rem;
}

.join-info > div:last-child {
    margin-bottom: 0;
    padding-top: 0.5rem;
    border-top: 1px solid var(--border-color);
}

.confirmation-text {
    text-align: center;
    margin-bottom: 1.5rem;
    color: var(--text-secondary);
}

.modal-actions {
    display: flex;
    gap: 1rem;
}

.modal-actions button {
    flex: 1;
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .game-header {
        flex-direction: column;
        gap: 1rem;
        text-align: center;
    }

    .game-info {
        flex-direction: column;
    }

    .player-info {
        flex-direction: column;
        gap: 1rem;
    }

    .fee-grid {
        grid-template-columns: repeat(2, 1fr);
    }

    .game-filters {
        display: none;
    }

    .game-item {
        flex-wrap: wrap;
    }

    .game-meta {
        width: 100%;
        text-align: left;
        margin-top: 1rem;
    }
}

@media (max-width: 480px) {
    .fee-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<script>
let selectedFee = 0;
let gameUpdateInterval;

// Initialize WebSocket connection
document.addEventListener('DOMContentLoaded', () => {
    // Connect to game server
    ws.on('player_count_update', updatePlayerCounts);
    ws.on('game_list_update', updateGamesList);
    ws.on('game_joined', handleGameJoined);
    
    // Initial updates
    updatePlayerCounts();
    updateGamesList();
    
    // Start periodic updates
    gameUpdateInterval = setInterval(() => {
        updatePlayerCounts();
        updateGamesList();
    }, 30000);
});

// Update player counts for each entry fee
async function updatePlayerCounts() {
    try {
        const response = await fetch('/api/games/ludo/player-counts');
        const data = await response.json();
        
        Object.entries(data.counts).forEach(([fee, count]) => {
            document.getElementById(`players-${fee}`).textContent = 
                `${count} Playing`;
        });
    } catch (error) {
        console.error('Error updating player counts:', error);
    }
}

// Update active games list
async function updateGamesList() {
    try {
        const response = await fetch('/api/games/ludo/active-games');
        const data = await response.json();
        
        const gamesList = document.getElementById('gamesList');
        gamesList.innerHTML = data.games.map(game => `
            <div class="game-item">
                <div class="game-status status-${game.status}"></div>
                <div class="game-players">
                    ${renderPlayers(game.players)}
                </div>
                <div class="game-meta">
                    <div class="entry-fee">₹${game.entry_fee}</div>
                    ${game.status === 'waiting' ? 
                        `<div class="time-left">${game.time_left}s left</div>` : 
                        ''}
                </div>
            </div>
        `).join('');
    } catch (error) {
        console.error('Error updating games list:', error);
    }
}

// Render player slots
function renderPlayers(players) {
    const slots = Array(4).fill(null);
    players.forEach((player, index) => {
        slots[index] = player;
    });
    
    return slots.map(player => player ? `
        <div class="player-avatar">
            <img src="${player.avatar || '/assets/images/default-avatar.png'}" 
                 alt="${player.username}">
        </div>
    ` : `
        <div class="empty-slot">
            <i class="icon-user"></i>
        </div>
    `).join('');
}

// Show join game modal
function joinGame(fee) {
    if (fee > <?= $wallet->getBalance() ?>) {
        window.location.href = '/wallet?action=deposit';
        return;
    }
    
    selectedFee = fee;
    document.getElementById('modalEntryFee').textContent = fee;
    document.getElementById('modalPrizePool').textContent = fee * 4;
    document.getElementById('joinModal').classList.add('active');
}

// Handle game join confirmation
document.getElementById('confirmJoinBtn').addEventListener('click', async () => {
    try {
        const response = await fetch('/api/games/ludo/join', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                entry_fee: selectedFee
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            window.location.href = `/games/ludo/game?id=${data.game_id}`;
        } else {
            utils.showToast(data.error, 'error');
        }
    } catch (error) {
        utils.showToast('Failed to join game', 'error');
    }
});

// Handle game joined event
function handleGameJoined(data) {
    window.location.href = `/games/ludo/game?id=${data.game_id}`;
}

// Filter games
document.querySelectorAll('.filter-btn').forEach(btn => {
    btn.addEventListener('click', () => {
        document.querySelectorAll('.filter-btn').forEach(b => 
            b.classList.remove('active'));
        btn.classList.add('active');
        
        const filter = btn.dataset.filter;
        document.querySelectorAll('.game-item').forEach(item => {
            if (filter === 'all' || item.querySelector(`.status-${filter}`)) {
                item.style.display = 'flex';
            } else {
                item.style.display = 'none';
            }
        });
    });
});

// Close modal
function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Cleanup on page unload
window.addEventListener('unload', () => {
    clearInterval(gameUpdateInterval);
});
</script>
