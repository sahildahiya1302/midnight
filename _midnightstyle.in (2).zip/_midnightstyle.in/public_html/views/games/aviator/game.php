<?php
require_once __DIR__ . '/../../../layouts/main.php';

$user = getCurrentUser();
$wallet = getCurrentWallet();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aviator - Gaming Platform</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/responsive.css">
    <link rel="stylesheet" href="/assets/games/aviator/style.css">
</head>
<body class="game-body">
    <div class="game-container">
        <!-- Game Header -->
        <div class="game-header">
            <div class="game-info">
                <img src="/assets/images/games/aviator-icon.png" alt="Aviator" class="game-icon">
                <div class="game-details">
                    <h1>Aviator</h1>
                    <div class="stats">
                        <span class="players-online">
                            <i class="icon-users"></i> <span id="onlinePlayers">0</span> Playing
                        </span>
                        <span class="total-bets">
                            <i class="icon-coins"></i> ₹<span id="totalBets">0</span>
                        </span>
                    </div>
                </div>
            </div>
            <div class="wallet-info">
                <div class="balance">
                    <span class="label">Balance:</span>
                    <span class="amount">₹<?= number_format($wallet->getBalance(), 2) ?></span>
                </div>
                <button class="btn btn-primary" onclick="window.location.href='/wallet'">
                    <i class="icon-plus"></i> Add Money
                </button>
            </div>
        </div>

        <!-- Game Area -->
        <div class="game-area">
            <!-- Multiplier Display -->
            <div class="multiplier-display">
                <div class="current-multiplier" id="currentMultiplier">1.00x</div>
                <canvas id="gameCanvas"></canvas>
            </div>

            <!-- Betting Controls -->
            <div class="betting-controls">
                <div class="bet-form">
                    <div class="input-group">
                        <label for="betAmount">Bet Amount</label>
                        <div class="amount-input">
                            <input type="number" id="betAmount" min="10" max="10000" step="10" value="100">
                            <div class="amount-controls">
                                <button onclick="adjustBet('half')">½</button>
                                <button onclick="adjustBet('double')">2×</button>
                                <button onclick="adjustBet('max')">Max</button>
                            </div>
                        </div>
                    </div>
                    <div class="input-group">
                        <label for="autoCashout">Auto Cashout At</label>
                        <div class="amount-input">
                            <input type="number" id="autoCashout" min="1.01" step="0.01" value="2.00">
                            <span class="suffix">x</span>
                        </div>
                    </div>
                    <button id="placeBetBtn" class="btn btn-primary btn-large" onclick="placeBet()">
                        Place Bet
                    </button>
                    <button id="cashoutBtn" class="btn btn-success btn-large" onclick="cashout()" disabled>
                        Cashout
                    </button>
                </div>
            </div>

            <!-- Game Stats -->
            <div class="game-stats">
                <div class="stats-header">
                    <h3>Recent Results</h3>
                    <div class="stats-filters">
                        <button class="active" data-filter="all">All</button>
                        <button data-filter="high">2x+</button>
                        <button data-filter="low">&lt;2x</button>
                    </div>
                </div>
                <div class="crash-history" id="crashHistory"></div>
            </div>
        </div>

        <!-- Players List -->
        <div class="players-list">
            <div class="list-header">
                <h3>Active Players</h3>
                <div class="list-filters">
                    <button class="active" data-filter="all">All</button>
                    <button data-filter="playing">Playing</button>
                    <button data-filter="cashed">Cashed Out</button>
                </div>
            </div>
            <div class="players-table">
                <table>
                    <thead>
                        <tr>
                            <th>Player</th>
                            <th>Bet</th>
                            <th>Multiplier</th>
                            <th>Profit</th>
                        </tr>
                    </thead>
                    <tbody id="playersList"></tbody>
                </table>
            </div>
        </div>

        <!-- Game Chat -->
        <div class="game-chat">
            <div class="chat-header">
                <h3>Game Chat</h3>
                <button class="toggle-chat" onclick="toggleChat()">
                    <i class="icon-chat"></i>
                </button>
            </div>
            <div class="chat-messages" id="chatMessages"></div>
            <div class="chat-input">
                <input type="text" id="messageInput" placeholder="Type a message...">
                <button onclick="sendMessage()">
                    <i class="icon-send"></i>
                </button>
            </div>
        </div>
    </div>

    <!-- Game Over Modal -->
    <div class="modal" id="gameOverModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>Game Over!</h2>
            </div>
            <div class="modal-body">
                <div class="crash-result">
                    <div class="crash-multiplier">
                        <span id="finalMultiplier">0.00</span>x
                    </div>
                    <div class="result-message" id="resultMessage"></div>
                </div>
                <div class="next-round">
                    <span>Next round in:</span>
                    <span id="nextRoundTimer">5</span>
                </div>
            </div>
        </div>
    </div>

    <!-- How to Play Modal -->
    <div class="modal" id="helpModal">
        <div class="modal-content">
            <div class="modal-header">
                <h2>How to Play Aviator</h2>
                <button class="close-modal" onclick="closeModal('helpModal')">&times;</button>
            </div>
            <div class="modal-body">
                <div class="help-content">
                    <section>
                        <h3>Game Rules</h3>
                        <ul>
                            <li>Place your bet before the round starts</li>
                            <li>Watch the multiplier increase</li>
                            <li>Cash out before the plane flies away</li>
                            <li>The longer you wait, the higher the potential winnings</li>
                            <li>But wait too long and you might lose everything!</li>
                        </ul>
                    </section>

                    <section>
                        <h3>Betting</h3>
                        <ul>
                            <li>Minimum bet: ₹10</li>
                            <li>Maximum bet: ₹10,000</li>
                            <li>Set auto cashout to automatically secure your winnings</li>
                            <li>Your winnings = Bet Amount × Cashout Multiplier</li>
                        </ul>
                    </section>

                    <section>
                        <h3>Tips</h3>
                        <ul>
                            <li>Use auto cashout for consistent results</li>
                            <li>Watch the game history to spot patterns</li>
                            <li>Start with smaller bets to learn the game</li>
                            <li>Don't chase losses - stick to your strategy</li>
                        </ul>
                    </section>
                </div>
            </div>
        </div>
    </div>

    <script src="/assets/js/app.js"></script>
    <script src="/assets/games/aviator/game.js"></script>
    <script>
        // Initialize game with configuration
        const gameConfig = {
            userId: '<?= $user->getId() ?>',
            username: '<?= h($user->getData()['username']) ?>',
            avatar: '<?= $user->getData()['avatar'] ?? '/assets/images/default-avatar.png' ?>',
            balance: <?= $wallet->getBalance() ?>,
            minBet: 10,
            maxBet: 10000
        };

        // Initialize game instance
        const game = new AviatorGame(gameConfig);

        // Connect to game server
        game.connect();

        // UI Functions
        function adjustBet(type) {
            const input = document.getElementById('betAmount');
            const currentValue = parseFloat(input.value);
            
            switch (type) {
                case 'half':
                    input.value = Math.max(gameConfig.minBet, currentValue / 2);
                    break;
                case 'double':
                    input.value = Math.min(gameConfig.maxBet, currentValue * 2);
                    break;
                case 'max':
                    input.value = Math.min(gameConfig.maxBet, gameConfig.balance);
                    break;
            }
        }

        function placeBet() {
            const amount = parseFloat(document.getElementById('betAmount').value);
            const autoCashout = parseFloat(document.getElementById('autoCashout').value);
            
            if (amount < gameConfig.minBet || amount > gameConfig.maxBet) {
                utils.showToast('Invalid bet amount', 'error');
                return;
            }

            if (amount > gameConfig.balance) {
                utils.showToast('Insufficient balance', 'error');
                return;
            }

            game.placeBet(amount, autoCashout);
        }

        function cashout() {
            game.cashout();
        }

        function toggleChat() {
            document.querySelector('.game-chat').classList.toggle('active');
        }

        function sendMessage() {
            const input = document.getElementById('messageInput');
            const message = input.value.trim();
            
            if (message) {
                game.sendChatMessage(message);
                input.value = '';
            }
        }

        // Handle chat input
        document.getElementById('messageInput').addEventListener('keypress', (e) => {
            if (e.key === 'Enter') {
                sendMessage();
            }
        });

        // Handle visibility change
        document.addEventListener('visibilitychange', () => {
            if (document.hidden) {
                game.onPageHidden();
            } else {
                game.onPageVisible();
            }
        });

        // Handle window resize
        window.addEventListener('resize', () => {
            game.resizeCanvas();
        });
    </script>
</body>
</html>
