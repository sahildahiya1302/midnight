<?php
require_once __DIR__ . '/../../layouts/main.php';

$user = getCurrentUser();
$userStats = $user->getStats();
?>

<div class="profile-container">
    <!-- Profile Header -->
    <div class="profile-header">
        <div class="profile-cover">
            <div class="profile-avatar">
                <img src="<?= $user->getData()['avatar'] ?? '/assets/images/default-avatar.png' ?>" 
                     alt="<?= h($user->getData()['username']) ?>">
                <button class="change-avatar" onclick="document.getElementById('avatarInput').click()">
                    <i class="icon-camera"></i>
                </button>
                <input type="file" id="avatarInput" hidden accept="image/*" onchange="updateAvatar(this)">
            </div>
        </div>
        <div class="profile-info">
            <h1><?= h($user->getData()['username']) ?></h1>
            <p class="member-since">Member since <?= date('F Y', strtotime($user->getData()['created_at'])) ?></p>
        </div>
    </div>

    <!-- Profile Content -->
    <div class="profile-content">
        <!-- Profile Navigation -->
        <div class="profile-nav">
            <button class="nav-item active" data-tab="personal">
                <i class="icon-user"></i> Personal Info
            </button>
            <button class="nav-item" data-tab="gaming">
                <i class="icon-gamepad"></i> Gaming Stats
            </button>
            <button class="nav-item" data-tab="security">
                <i class="icon-shield"></i> Security
            </button>
            <button class="nav-item" data-tab="preferences">
                <i class="icon-settings"></i> Preferences
            </button>
        </div>

        <!-- Profile Sections -->
        <div class="profile-sections">
            <!-- Personal Info Section -->
            <div class="profile-section active" id="personal">
                <h2>Personal Information</h2>
                <form id="personalInfoForm" class="profile-form">
                    <div class="form-grid">
                        <div class="form-group">
                            <label for="fullName">Full Name</label>
                            <input type="text" id="fullName" name="full_name" 
                                   value="<?= h($user->getData()['full_name'] ?? '') ?>" 
                                   placeholder="Enter your full name">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" id="email" value="<?= h($user->getData()['email']) ?>" 
                                   readonly>
                            <button type="button" class="btn-link" onclick="showChangeEmailModal()">
                                Change Email
                            </button>
                        </div>
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" 
                                   value="<?= h($user->getData()['phone'] ?? '') ?>" 
                                   placeholder="Enter your phone number">
                        </div>
                        <div class="form-group">
                            <label for="dob">Date of Birth</label>
                            <input type="date" id="dob" name="dob" 
                                   value="<?= h($user->getData()['dob'] ?? '') ?>">
                        </div>
                        <div class="form-group">
                            <label for="country">Country</label>
                            <select id="country" name="country">
                                <option value="">Select country</option>
                                <option value="IN" <?= ($user->getData()['country'] ?? '') === 'IN' ? 'selected' : '' ?>>India</option>
                                <!-- Add more countries as needed -->
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="state">State</label>
                            <select id="state" name="state">
                                <option value="">Select state</option>
                                <!-- States will be populated via JavaScript -->
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </form>
            </div>

            <!-- Gaming Stats Section -->
            <div class="profile-section" id="gaming">
                <h2>Gaming Statistics</h2>
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-header">
                            <i class="icon-games"></i>
                            <h3>Total Games</h3>
                        </div>
                        <div class="stat-value"><?= $userStats['total_games'] ?></div>
                        <div class="stat-footer">
                            <span class="stat-label">Games Played</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <i class="icon-trophy"></i>
                            <h3>Wins</h3>
                        </div>
                        <div class="stat-value"><?= $userStats['games_won'] ?></div>
                        <div class="stat-footer">
                            <span class="stat-label">Games Won</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <i class="icon-chart"></i>
                            <h3>Win Rate</h3>
                        </div>
                        <div class="stat-value">
                            <?= $userStats['total_games'] > 0 
                                ? round(($userStats['games_won'] / $userStats['total_games']) * 100) 
                                : 0 ?>%
                        </div>
                        <div class="stat-footer">
                            <span class="stat-label">Success Rate</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-header">
                            <i class="icon-coins"></i>
                            <h3>Total Earnings</h3>
                        </div>
                        <div class="stat-value">₹<?= number_format($userStats['total_winnings'], 2) ?></div>
                        <div class="stat-footer">
                            <span class="stat-label">Lifetime Winnings</span>
                        </div>
                    </div>
                </div>

                <div class="game-stats">
                    <h3>Game-wise Statistics</h3>
                    <div class="game-stats-grid">
                        <!-- Ludo Stats -->
                        <div class="game-stat-card">
                            <div class="game-icon">
                                <img src="/assets/images/games/ludo-icon.png" alt="Ludo">
                            </div>
                            <div class="game-stat-info">
                                <h4>Ludo</h4>
                                <div class="game-stat-details">
                                    <div class="stat-item">
                                        <span class="label">Games</span>
                                        <span class="value"><?= $userStats['ludo_games'] ?></span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="label">Wins</span>
                                        <span class="value"><?= $userStats['ludo_wins'] ?></span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="label">Win Rate</span>
                                        <span class="value">
                                            <?= $userStats['ludo_games'] > 0 
                                                ? round(($userStats['ludo_wins'] / $userStats['ludo_games']) * 100) 
                                                : 0 ?>%
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Aviator Stats -->
                        <div class="game-stat-card">
                            <div class="game-icon">
                                <img src="/assets/images/games/aviator-icon.png" alt="Aviator">
                            </div>
                            <div class="game-stat-info">
                                <h4>Aviator</h4>
                                <div class="game-stat-details">
                                    <div class="stat-item">
                                        <span class="label">Games</span>
                                        <span class="value"><?= $userStats['aviator_games'] ?></span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="label">Wins</span>
                                        <span class="value"><?= $userStats['aviator_wins'] ?></span>
                                    </div>
                                    <div class="stat-item">
                                        <span class="label">Avg. Multiplier</span>
                                        <span class="value"><?= number_format($userStats['aviator_avg_multiplier'], 2) ?>x</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Security Section -->
            <div class="profile-section" id="security">
                <h2>Security Settings</h2>
                <div class="security-options">
                    <div class="security-card">
                        <div class="security-header">
                            <i class="icon-lock"></i>
                            <h3>Password</h3>
                        </div>
                        <p>Change your account password</p>
                        <button class="btn btn-secondary" onclick="showChangePasswordModal()">
                            Change Password
                        </button>
                    </div>

                    <div class="security-card">
                        <div class="security-header">
                            <i class="icon-shield"></i>
                            <h3>Two-Factor Authentication</h3>
                        </div>
                        <p>Add an extra layer of security</p>
                        <button class="btn btn-secondary" onclick="setup2FA()">
                            <?= $user->getData()['2fa_enabled'] ? 'Manage 2FA' : 'Enable 2FA' ?>
                        </button>
                    </div>

                    <div class="security-card">
                        <div class="security-header">
                            <i class="icon-devices"></i>
                            <h3>Active Sessions</h3>
                        </div>
                        <p>Manage your logged-in devices</p>
                        <button class="btn btn-secondary" onclick="showActiveSessions()">
                            View Sessions
                        </button>
                    </div>
                </div>
            </div>

            <!-- Preferences Section -->
            <div class="profile-section" id="preferences">
                <h2>Account Preferences</h2>
                <form id="preferencesForm" class="preferences-form">
                    <div class="preference-group">
                        <h3>Notifications</h3>
                        <div class="preference-options">
                            <label class="toggle-switch">
                                <input type="checkbox" name="email_notifications" 
                                       <?= $user->getData()['email_notifications'] ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                                Email Notifications
                            </label>
                            <label class="toggle-switch">
                                <input type="checkbox" name="push_notifications"
                                       <?= $user->getData()['push_notifications'] ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                                Push Notifications
                            </label>
                            <label class="toggle-switch">
                                <input type="checkbox" name="game_invites"
                                       <?= $user->getData()['game_invites'] ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                                Game Invites
                            </label>
                        </div>
                    </div>

                    <div class="preference-group">
                        <h3>Privacy</h3>
                        <div class="preference-options">
                            <label class="toggle-switch">
                                <input type="checkbox" name="profile_visible"
                                       <?= $user->getData()['profile_visible'] ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                                Public Profile
                            </label>
                            <label class="toggle-switch">
                                <input type="checkbox" name="show_game_history"
                                       <?= $user->getData()['show_game_history'] ? 'checked' : '' ?>>
                                <span class="toggle-slider"></span>
                                Show Game History
                            </label>
                        </div>
                    </div>

                    <div class="preference-group">
                        <h3>Appearance</h3>
                        <div class="theme-selector">
                            <label>
                                <input type="radio" name="theme" value="light"
                                       <?= ($user->getData()['theme'] ?? 'light') === 'light' ? 'checked' : '' ?>>
                                <span class="theme-option">
                                    <i class="icon-sun"></i>
                                    Light
                                </span>
                            </label>
                            <label>
                                <input type="radio" name="theme" value="dark"
                                       <?= ($user->getData()['theme'] ?? 'light') === 'dark' ? 'checked' : '' ?>>
                                <span class="theme-option">
                                    <i class="icon-moon"></i>
                                    Dark
                                </span>
                            </label>
                            <label>
                                <input type="radio" name="theme" value="system"
                                       <?= ($user->getData()['theme'] ?? 'light') === 'system' ? 'checked' : '' ?>>
                                <span class="theme-option">
                                    <i class="icon-display"></i>
                                    System
                                </span>
                            </label>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Save Preferences</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Change Password Modal -->
<div class="modal" id="changePasswordModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Change Password</h2>
            <button class="close-modal" onclick="closeModal('changePasswordModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form id="changePasswordForm">
                <div class="form-group">
                    <label for="currentPassword">Current Password</label>
                    <input type="password" id="currentPassword" name="current_password" required>
                </div>
                <div class="form-group">
                    <label for="newPassword">New Password</label>
                    <input type="password" id="newPassword" name="new_password" required>
                </div>
                <div class="form-group">
                    <label for="confirmPassword">Confirm New Password</label>
                    <input type="password" id="confirmPassword" name="confirm_password" required>
                </div>
                <button type="submit" class="btn btn-primary">Update Password</button>
            </form>
        </div>
    </div>
</div>

<style>
/* Profile Styles */
.profile-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 1rem;
}

/* Profile Header */
.profile-header {
    margin-bottom: 2rem;
}

.profile-cover {
    height: 200px;
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    border-radius: 1rem;
    position: relative;
    margin-bottom: 4rem;
}

.profile-avatar {
    position: absolute;
    bottom: -3rem;
    left: 2rem;
    width: 150px;
    height: 150px;
    border-radius: 50%;
    border: 4px solid var(--background-primary);
    overflow: hidden;
}

.profile-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.change-avatar {
    position: absolute;
    bottom: 0.5rem;
    right: 0.5rem;
    width: 2.5rem;
    height: 2.5rem;
    border-radius: 50%;
    background: var(--primary-color);
    border: none;
    color: white;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.profile-info {
    padding-left: 2rem;
}

.profile-info h1 {
    font-size: 1.5rem;
    margin-bottom: 0.5rem;
}

.member-since {
    color: var(--text-secondary);
}

/* Profile Navigation */
.profile-nav {
    display: flex;
    gap: 1rem;
    margin-bottom: 2rem;
    border-bottom: 1px solid var(--border-color);
    padding-bottom: 1rem;
}

.nav-item {
    background: none;
    border: none;
    padding: 0.75rem 1.5rem;
    border-radius: 0.5rem;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    color: var(--text-secondary);
}

.nav-item.active {
    background: var(--primary-color);
    color: white;
}

/* Profile Sections */
.profile-section {
    display: none;
    animation: fadeIn 0.3s ease;
}

.profile-section.active {
    display: block;
}

.profile-section h2 {
    font-size: 1.5rem;
    margin-bottom: 1.5rem;
}

/* Forms */
.profile-form,
.preferences-form {
    max-width: 800px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
    margin-bottom: 1.5rem;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.form-group label {
    font-weight: 500;
}

.form-group input,
.form-group select {
    padding: 0.75rem;
    border: 1px solid var(--border-color);
    border-radius: 0.5rem;
    font-size: 1rem;
}

.btn-link {
    background: none;
    border: none;
    color: var(--primary-color);
    padding: 0;
    font-size: 0.875rem;
    cursor: pointer;
}

/* Stats Grid */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}

.stat-card {
    background: var(--background-primary);
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: var(--shadow);
}

.stat-header {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 1rem;
}

.stat-header i {
    font-size: 1.5rem;
    color: var(--primary-color);
}

.stat-value {
    font-size: 2rem;
    font-weight: 600;
    margin-bottom: 0.5rem;
}

.stat-footer {
    color: var(--text-secondary);
    font-size: 0.875rem;
}

/* Game Stats */
.game-stats {
    margin-top: 2rem;
}

.game-stats h3 {
    margin-bottom: 1.5rem;
}

.game-stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 1.5rem;
}

.game-stat-card {
    background: var(--background-primary);
    border-radius: 1rem;
    padding: 1.5rem;
    display: flex;
    gap: 1.5rem;
    box-shadow: var(--shadow);
}

.game-icon {
    width: 64px;
    height: 64px;
    border-radius: 1rem;
    overflow: hidden;
}

.game-icon img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.game-stat-info {
    flex: 1;
}

.game-stat-info h4 {
    margin-bottom: 1rem;
}

.game-stat-details {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
}

.stat-item {
    text-align: center;
}

.stat-item .label {
    display: block;
    font-size: 0.875rem;
    color: var(--text-secondary);
    margin-bottom: 0.25rem;
}

.stat-item .value {
    font-weight: 600;
}

/* Security Section */
.security-options {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 1.5rem;
}

.security-card {
    background: var(--background-primary);
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: var(--shadow);
}

.security-header {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    margin-bottom: 1rem;
}

.security-header i {
    font-size: 1.5rem;
    color: var(--primary-color);
}

.security-card p {
    color: var(--text-secondary);
    margin-bottom: 1.5rem;
}

/* Preferences Section */
.preference-group {
    margin-bottom: 2rem;
}

.preference-group h3 {
    margin-bottom: 1rem;
}

.preference-options {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.toggle-switch {
    display: flex;
    align-items: center;
    gap: 1rem;
    cursor: pointer;
}

.toggle-slider {
    position: relative;
    width: 3rem;
    height: 1.5rem;
    background: var(--border-color);
    border-radius: 1rem;
    transition: background-color 0.2s;
}

.toggle-slider:before {
    content: '';
    position: absolute;
    width: 1.25rem;
    height: 1.25rem;
    border-radius: 50%;
    background: white;
    top: 0.125rem;
    left: 0.125rem;
    transition: transform 0.2s;
}

.toggle-switch input:checked + .toggle-slider {
    background: var(--primary-color);
}

.toggle-switch input:checked + .toggle-slider:before {
    transform: translateX(1.5rem);
}

.theme-selector {
    display: flex;
    gap: 1rem;
}

.theme-option {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    border-radius: 0.5rem;
    background: var(--background-secondary);
    cursor: pointer;
}

input[type="radio"]:checked + .theme-option {
    background: var(--primary-color);
    color: white;
}

/* Animations */
@keyframes fadeIn {
    from { opacity: 0; }
    to { opacity: 1; }
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .profile-cover {
        height: 150px;
        margin-bottom: 3rem;
    }

    .profile-avatar {
        width: 120px;
        height: 120px;
        left: 50%;
        transform: translateX(-50%);
    }

    .profile-info {
        text-align: center;
        padding-left: 0;
    }

    .profile-nav {
        overflow-x: auto;
        padding-bottom: 0.5rem;
    }

    .nav-item {
        white-space: nowrap;
    }

    .game-stat-card {
        flex-direction: column;
        text-align: center;
    }

    .game-icon {
        margin: 0 auto;
    }

    .theme-selector {
        flex-direction: column;
    }
}
</style>

<script>
// Tab Navigation
document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
        // Remove active class from all tabs and sections
        document.querySelectorAll('.nav-item').forEach(tab => tab.classList.remove('active'));
        document.querySelectorAll('.profile-section').forEach(section => section.classList.remove('active'));
        
        // Add active class to clicked tab and corresponding section
        item.classList.add('active');
        document.getElementById(item.dataset.tab).classList.add('active');
    });
});

// Avatar Update
async function updateAvatar(input) {
    if (input.files && input.files[0]) {
        const formData = new FormData();
        formData.append('avatar', input.files[0]);
        
        try {
            const response = await fetch('/api/user/update-avatar', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                document.querySelector('.profile-avatar img').src = data.avatar_url;
                utils.showToast('Avatar updated successfully', 'success');
            } else {
                utils.showToast(data.error, 'error');
            }
        } catch (error) {
            utils.showToast('Failed to update avatar', 'error');
        }
    }
}

// Personal Info Form
document.getElementById('personalInfoForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    
    try {
        const response = await fetch('/api/user/update-profile', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        
        if (data.success) {
            utils.showToast('Profile updated successfully', 'success');
        } else {
            utils.showToast(data.error, 'error');
        }
    } catch (error) {
        utils.showToast('Failed to update profile', 'error');
    }
});

// Preferences Form
document.getElementById('preferencesForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const preferences = Object.fromEntries(formData);
    
    try {
        const response = await fetch('/api/user/update-preferences', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(preferences)
        });
        
        const data = await response.json();
        
        if (data.success) {
            utils.showToast('Preferences updated successfully', 'success');
            if (preferences.theme !== currentTheme) {
                applyTheme(preferences.theme);
            }
        } else {
            utils.showToast(data.error, 'error');
        }
    } catch (error) {
        utils.showToast('Failed to update preferences', 'error');
    }
});

// Change Password Form
document.getElementById('changePasswordForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    
    if (formData.get('new_password') !== formData.get('confirm_password')) {
        utils.showToast('Passwords do not match', 'error');
        return;
    }
    
    try {
        const response = await fetch('/api/user/change-password', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                current_password: formData.get('current_password'),
                new_password: formData.get('new_password')
            })
        });
        
        const data = await response.json();
        
        if (data.success) {
            utils.showToast('Password updated successfully', 'success');
            closeModal('changePasswordModal');
            e.target.reset();
        } else {
            utils.showToast(data.error, 'error');
        }
    } catch (error) {
        utils.showToast('Failed to update password', 'error');
    }
});

// Theme Management
let currentTheme = '<?= $user->getData()['theme'] ?? 'light' ?>';

function applyTheme(theme) {
    if (theme === 'system') {
        const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        document.documentElement.setAttribute('data-theme', prefersDark ? 'dark' : 'light');
    } else {
        document.documentElement.setAttribute('data-theme', theme);
    }
    currentTheme = theme;
}

// Apply theme on load
applyTheme(currentTheme);

// Listen for system theme changes
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
    if (currentTheme === 'system') {
        applyTheme('system');
    }
});

// Modal Management
function showChangePasswordModal() {
    document.getElementById('changePasswordModal').classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Close modals when clicking outside
window.addEventListener('click', (e) => {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});
</script>
