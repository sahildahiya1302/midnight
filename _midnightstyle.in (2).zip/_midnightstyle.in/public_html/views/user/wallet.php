<?php
require_once __DIR__ . '/../../layouts/main.php';

$user = getCurrentUser();
$wallet = getCurrentWallet();
$transactions = $wallet->getTransactions(10);
?>

<div class="wallet-container">
    <!-- Wallet Overview -->
    <div class="wallet-overview">
        <div class="balance-card">
            <div class="balance-info">
                <h2>Wallet Balance</h2>
                <div class="balance-amount">
                    <span class="currency">₹</span>
                    <span class="amount"><?= number_format($wallet->getBalance(), 2) ?></span>
                </div>
            </div>
            <div class="wallet-actions">
                <button class="btn btn-primary" onclick="showDepositModal()">
                    <i class="icon-plus"></i> Add Money
                </button>
                <button class="btn btn-secondary" onclick="showWithdrawModal()">
                    <i class="icon-withdraw"></i> Withdraw
                </button>
            </div>
        </div>

        <!-- Quick Stats -->
        <div class="wallet-stats">
            <div class="stat-card">
                <div class="stat-icon">💰</div>
                <div class="stat-info">
                    <h3>Total Deposits</h3>
                    <p>₹<?= number_format($user->getStats()['total_deposits'], 2) ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">💸</div>
                <div class="stat-info">
                    <h3>Total Withdrawals</h3>
                    <p>₹<?= number_format($user->getStats()['total_withdrawals'], 2) ?></p>
                </div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">🏆</div>
                <div class="stat-info">
                    <h3>Total Winnings</h3>
                    <p>₹<?= number_format($user->getStats()['total_winnings'], 2) ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Transaction History -->
    <div class="transactions-section">
        <div class="section-header">
            <h2>Transaction History</h2>
            <div class="filter-options">
                <select id="transactionType" onchange="filterTransactions()">
                    <option value="all">All Transactions</option>
                    <option value="deposit">Deposits</option>
                    <option value="withdrawal">Withdrawals</option>
                    <option value="game_entry">Game Entries</option>
                    <option value="winning">Winnings</option>
                </select>
            </div>
        </div>

        <div class="transaction-list" id="transactionList">
            <?php foreach ($transactions as $transaction): ?>
                <div class="transaction-item" data-type="<?= $transaction['type'] ?>">
                    <div class="transaction-icon">
                        <?php
                        switch ($transaction['type']) {
                            case 'deposit':
                                echo '💰';
                                break;
                            case 'withdrawal':
                                echo '💸';
                                break;
                            case 'game_entry':
                                echo '🎮';
                                break;
                            case 'winning':
                                echo '🏆';
                                break;
                        }
                        ?>
                    </div>
                    <div class="transaction-details">
                        <h4><?= ucfirst($transaction['type']) ?></h4>
                        <p class="transaction-date">
                            <?= date('d M Y, h:i A', strtotime($transaction['created_at'])) ?>
                        </p>
                        <?php if ($transaction['game_session_id']): ?>
                            <p class="game-info">Game ID: <?= $transaction['game_session_id'] ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="transaction-amount <?= in_array($transaction['type'], ['deposit', 'winning']) ? 'positive' : 'negative' ?>">
                        <?= in_array($transaction['type'], ['deposit', 'winning']) ? '+' : '-' ?>₹<?= number_format($transaction['amount'], 2) ?>
                    </div>
                    <div class="transaction-status">
                        <span class="status-badge status-<?= $transaction['status'] ?>">
                            <?= ucfirst($transaction['status']) ?>
                        </span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="load-more">
            <button class="btn btn-secondary" onclick="loadMoreTransactions()">Load More</button>
        </div>
    </div>
</div>

<!-- Deposit Modal -->
<div class="modal" id="depositModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Add Money</h2>
            <button class="close-modal" onclick="closeModal('depositModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form id="depositForm" class="payment-form">
                <div class="form-group">
                    <label for="depositAmount">Amount (₹)</label>
                    <input type="number" id="depositAmount" name="amount" min="10" max="50000" 
                           step="1" required placeholder="Enter amount">
                    <p class="input-hint">Min: ₹10, Max: ₹50,000</p>
                </div>

                <div class="form-group">
                    <label>Select Payment Method</label>
                    <div class="payment-methods">
                        <label class="payment-method">
                            <input type="radio" name="gateway" value="razorpay" checked>
                            <img src="/assets/images/payment/razorpay.png" alt="Razorpay">
                        </label>
                        <label class="payment-method">
                            <input type="radio" name="gateway" value="payu">
                            <img src="/assets/images/payment/payu.png" alt="PayU">
                        </label>
                        <label class="payment-method">
                            <input type="radio" name="gateway" value="stripe">
                            <img src="/assets/images/payment/stripe.png" alt="Stripe">
                        </label>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Proceed to Pay</button>
            </form>
        </div>
    </div>
</div>

<!-- Withdraw Modal -->
<div class="modal" id="withdrawModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Withdraw Money</h2>
            <button class="close-modal" onclick="closeModal('withdrawModal')">&times;</button>
        </div>
        <div class="modal-body">
            <form id="withdrawForm" class="payment-form">
                <div class="form-group">
                    <label for="withdrawAmount">Amount (₹)</label>
                    <input type="number" id="withdrawAmount" name="amount" 
                           min="100" max="10000" step="1" required 
                           placeholder="Enter amount">
                    <p class="input-hint">Min: ₹100, Max: ₹10,000</p>
                </div>

                <div class="form-group">
                    <label for="withdrawMethod">Select Withdrawal Method</label>
                    <select id="withdrawMethod" name="method" required>
                        <option value="">Select method</option>
                        <option value="bank">Bank Transfer</option>
                        <option value="upi">UPI</option>
                    </select>
                </div>

                <div id="bankDetails" class="withdrawal-details" style="display: none;">
                    <div class="form-group">
                        <label for="accountNumber">Account Number</label>
                        <input type="text" id="accountNumber" name="account_number" 
                               pattern="[0-9]{9,18}" placeholder="Enter account number">
                    </div>
                    <div class="form-group">
                        <label for="ifscCode">IFSC Code</label>
                        <input type="text" id="ifscCode" name="ifsc_code" 
                               pattern="^[A-Z]{4}0[A-Z0-9]{6}$" 
                               placeholder="Enter IFSC code">
                    </div>
                    <div class="form-group">
                        <label for="accountName">Account Holder Name</label>
                        <input type="text" id="accountName" name="account_name" 
                               placeholder="Enter account holder name">
                    </div>
                </div>

                <div id="upiDetails" class="withdrawal-details" style="display: none;">
                    <div class="form-group">
                        <label for="upiId">UPI ID</label>
                        <input type="text" id="upiId" name="upi_id" 
                               pattern="[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}" 
                               placeholder="Enter UPI ID">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-block">Request Withdrawal</button>
            </form>
        </div>
    </div>
</div>

<style>
/* Wallet Page Styles */
.wallet-container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 1rem;
}

/* Wallet Overview */
.wallet-overview {
    margin-bottom: 2rem;
}

.balance-card {
    background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
    border-radius: 1rem;
    padding: 2rem;
    color: white;
    margin-bottom: 1.5rem;
}

.balance-info h2 {
    font-size: 1.25rem;
    margin-bottom: 0.5rem;
}

.balance-amount {
    font-size: 2.5rem;
    font-weight: 600;
    margin-bottom: 1.5rem;
}

.wallet-actions {
    display: flex;
    gap: 1rem;
}

/* Wallet Stats */
.wallet-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 1rem;
}

.stat-card {
    background: var(--background-primary);
    border-radius: 1rem;
    padding: 1.5rem;
    display: flex;
    align-items: center;
    gap: 1rem;
    box-shadow: var(--shadow);
}

.stat-icon {
    font-size: 2rem;
}

.stat-info h3 {
    font-size: 0.875rem;
    color: var(--text-secondary);
    margin-bottom: 0.25rem;
}

.stat-info p {
    font-size: 1.25rem;
    font-weight: 600;
}

/* Transactions Section */
.transactions-section {
    background: var(--background-primary);
    border-radius: 1rem;
    padding: 1.5rem;
    box-shadow: var(--shadow);
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1.5rem;
}

.filter-options select {
    padding: 0.5rem;
    border: 1px solid var(--border-color);
    border-radius: 0.5rem;
    background: var(--background-primary);
}

.transaction-list {
    display: flex;
    flex-direction: column;
    gap: 1rem;
}

.transaction-item {
    display: flex;
    align-items: center;
    gap: 1rem;
    padding: 1rem;
    background: var(--background-secondary);
    border-radius: 0.75rem;
}

.transaction-icon {
    font-size: 1.5rem;
}

.transaction-details {
    flex: 1;
}

.transaction-details h4 {
    font-size: 1rem;
    margin-bottom: 0.25rem;
}

.transaction-date {
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.game-info {
    font-size: 0.75rem;
    color: var(--text-secondary);
}

.transaction-amount {
    font-weight: 600;
    font-size: 1.125rem;
}

.transaction-amount.positive {
    color: var(--success-color);
}

.transaction-amount.negative {
    color: var(--danger-color);
}

.status-badge {
    padding: 0.25rem 0.75rem;
    border-radius: 1rem;
    font-size: 0.75rem;
    font-weight: 500;
}

.status-completed {
    background: #dcfce7;
    color: #166534;
}

.status-pending {
    background: #fef9c3;
    color: #854d0e;
}

.status-failed {
    background: #fee2e2;
    color: #991b1b;
}

.load-more {
    text-align: center;
    margin-top: 1.5rem;
}

/* Modal Styles */
.modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    z-index: 1000;
    align-items: center;
    justify-content: center;
}

.modal.active {
    display: flex;
}

.modal-content {
    background: var(--background-primary);
    border-radius: 1rem;
    width: 90%;
    max-width: 500px;
    max-height: 90vh;
    overflow-y: auto;
}

.modal-header {
    padding: 1.5rem;
    border-bottom: 1px solid var(--border-color);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.modal-header h2 {
    font-size: 1.25rem;
}

.close-modal {
    background: none;
    border: none;
    font-size: 1.5rem;
    cursor: pointer;
    color: var(--text-secondary);
}

.modal-body {
    padding: 1.5rem;
}

/* Form Styles */
.payment-form {
    display: flex;
    flex-direction: column;
    gap: 1.5rem;
}

.form-group {
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
}

.form-group label {
    font-weight: 500;
}

.form-group input,
.form-group select {
    padding: 0.75rem;
    border: 1px solid var(--border-color);
    border-radius: 0.5rem;
    font-size: 1rem;
}

.input-hint {
    font-size: 0.875rem;
    color: var(--text-secondary);
}

.payment-methods {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
    gap: 1rem;
}

.payment-method {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.5rem;
    padding: 1rem;
    border: 1px solid var(--border-color);
    border-radius: 0.5rem;
    cursor: pointer;
}

.payment-method input[type="radio"] {
    display: none;
}

.payment-method img {
    height: 24px;
    object-fit: contain;
}

.payment-method.selected {
    border-color: var(--primary-color);
    background: var(--background-secondary);
}

/* Responsive Adjustments */
@media (max-width: 768px) {
    .wallet-actions {
        flex-direction: column;
    }

    .transaction-item {
        flex-wrap: wrap;
    }

    .transaction-amount {
        width: 100%;
        text-align: right;
        margin-top: 0.5rem;
    }

    .modal-content {
        width: 95%;
    }
}
</style>

<script>
let currentPage = 1;
const itemsPerPage = 10;

// Show deposit modal
function showDepositModal() {
    document.getElementById('depositModal').classList.add('active');
}

// Show withdraw modal
function showWithdrawModal() {
    document.getElementById('withdrawModal').classList.add('active');
}

// Close modal
function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

// Handle withdrawal method change
document.getElementById('withdrawMethod').addEventListener('change', function(e) {
    const bankDetails = document.getElementById('bankDetails');
    const upiDetails = document.getElementById('upiDetails');
    
    if (e.target.value === 'bank') {
        bankDetails.style.display = 'block';
        upiDetails.style.display = 'none';
    } else if (e.target.value === 'upi') {
        bankDetails.style.display = 'none';
        upiDetails.style.display = 'block';
    } else {
        bankDetails.style.display = 'none';
        upiDetails.style.display = 'none';
    }
});

// Handle deposit form submission
document.getElementById('depositForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const amount = formData.get('amount');
    const gateway = formData.get('gateway');
    
    try {
        const response = await api.wallet.deposit(amount, gateway);
        if (response.success) {
            closeModal('depositModal');
            utils.showToast('Redirecting to payment gateway...', 'info');
            window.location.href = response.redirect_url;
        } else {
            utils.showToast(response.error, 'error');
        }
    } catch (error) {
        utils.showToast('Failed to process deposit', 'error');
    }
});

// Handle withdraw form submission
document.getElementById('withdrawForm').addEventListener('submit', async function(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const amount = formData.get('amount');
    const method = formData.get('method');
    
    try {
        const response = await api.wallet.withdraw(amount, {
            method,
            account_number: formData.get('account_number'),
            ifsc_code: formData.get('ifsc_code'),
            account_name: formData.get('account_name'),
            upi_id: formData.get('upi_id')
        });
        
        if (response.success) {
            closeModal('withdrawModal');
            utils.showToast('Withdrawal request submitted successfully', 'success');
            setTimeout(() => location.reload(), 2000);
        } else {
            utils.showToast(response.error, 'error');
        }
    } catch (error) {
        utils.showToast('Failed to process withdrawal', 'error');
    }
});

// Filter transactions
function filterTransactions() {
    const type = document.getElementById('transactionType').value;
    const items = document.querySelectorAll('.transaction-item');
    
    items.forEach(item => {
        if (type === 'all' || item.dataset.type === type) {
            item.style.display = 'flex';
        } else {
            item.style.display = 'none';
        }
    });
}

// Load more transactions
async function loadMoreTransactions() {
    try {
        currentPage++;
        const response = await fetch(`/api/user/transactions?page=${currentPage}&limit=${itemsPerPage}`);
        const data = await response.json();
        
        if (data.transactions.length === 0) {
            document.querySelector('.load-more').style.display = 'none';
            return;
        }
        
        const transactionList = document.getElementById('transactionList');
        data.transactions.forEach(transaction => {
            const element = createTransactionElement(transaction);
            transactionList.appendChild(element);
        });
    } catch (error) {
        utils.showToast('Failed to load more transactions', 'error');
    }
}

// Create transaction element
function createTransactionElement(transaction) {
    const div = document.createElement('div');
    div.className = 'transaction-item';
    div.dataset.type = transaction.type;
    
    // Add transaction content (similar to PHP template)
    div.innerHTML = `
        <div class="transaction-icon">
            ${getTransactionIcon(transaction.type)}
        </div>
        <div class="transaction-details">
            <h4>${transaction.type.charAt(0).toUpperCase() + transaction.type.slice(1)}</h4>
            <p class="transaction-date">
                ${new Date(transaction.created_at).toLocaleString()}
            </p>
            ${transaction.game_session_id ? 
              `<p class="game-info">Game ID: ${transaction.game_session_id}</p>` : 
              ''}
        </div>
        <div class="transaction-amount ${
            ['deposit', 'winning'].includes(transaction.type) ? 'positive' : 'negative'
        }">
            ${['deposit', 'winning'].includes(transaction.type) ? '+' : '-'}
            ₹${transaction.amount.toFixed(2)}
        </div>
        <div class="transaction-status">
            <span class="status-badge status-${transaction.status}">
                ${transaction.status.charAt(0).toUpperCase() + transaction.status.slice(1)}
            </span>
        </div>
    `;
    
    return div;
}

// Get transaction icon
function getTransactionIcon(type) {
    switch (type) {
        case 'deposit':
            return '💰';
        case 'withdrawal':
            return '💸';
        case 'game_entry':
            return '🎮';
        case 'winning':
            return '🏆';
        default:
            return '💵';
    }
}

// Close modals when clicking outside
window.addEventListener('click', function(e) {
    if (e.target.classList.contains('modal')) {
        e.target.classList.remove('active');
    }
});

// Initialize payment method selection
document.querySelectorAll('.payment-method').forEach(method => {
    method.addEventListener('click', function() {
        document.querySelectorAll('.payment-method').forEach(m => 
            m.classList.remove('selected'));
        this.classList.add('selected');
        this.querySelector('input').checked = true;
    });
});
</script>
