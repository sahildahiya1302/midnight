<?php
$pageTitle = 'Gaming Platform - Play & Win Real Money';
$currentPage = 'home';
ob_start();
?>

<div class="hero-section">
    <div class="hero-content">
        <h1>Play Games, Win Real Money</h1>
        <p>Join thousands of players and compete in exciting games for real cash prizes</p>
        <div class="hero-buttons">
            <?php if (!$auth->isAuthenticated()): ?>
                <a href="/register" class="btn btn-primary btn-large">
                    <i class="icon-play"></i>
                    Start Playing
                </a>
                <a href="/about" class="btn btn-secondary btn-large">
                    <i class="icon-info"></i>
                    Learn More
                </a>
            <?php else: ?>
                <a href="/games/ludo/lobby" class="btn btn-primary btn-large">
                    <i class="icon-play"></i>
                    Play Now
                </a>
                <a href="/user/wallet" class="btn btn-secondary btn-large">
                    <i class="icon-wallet"></i>
                    Add Money
                </a>
            <?php endif; ?>
        </div>
    </div>
    <div class="hero-stats">
        <div class="stat-item">
            <div class="stat-value" id="onlinePlayers">0</div>
            <div class="stat-label">Players Online</div>
        </div>
        <div class="stat-item">
            <div class="stat-value" id="activeGames">0</div>
            <div class="stat-label">Active Games</div>
        </div>
        <div class="stat-item">
            <div class="stat-value">₹<span id="totalPrizes">0</span></div>
            <div class="stat-label">Total Prizes</div>
        </div>
    </div>
</div>

<section class="games-section">
    <h2>Featured Games</h2>
    <div class="games-grid">
        <div class="game-card">
            <div class="game-image">
                <img src="/assets/images/games/ludo-banner.jpg" alt="Ludo">
                <div class="game-overlay">
                    <a href="/games/ludo/lobby" class="btn btn-primary">Play Now</a>
                </div>
            </div>
            <div class="game-info">
                <h3>Ludo</h3>
                <div class="game-stats">
                    <span class="players">
                        <i class="icon-users"></i>
                        <span id="ludoPlayers">0</span> Playing
                    </span>
                    <span class="entry-fee">
                        <i class="icon-coins"></i>
                        From ₹10
                    </span>
                </div>
                <p>Play the classic board game with real players and win cash prizes!</p>
            </div>
        </div>

        <div class="game-card">
            <div class="game-image">
                <img src="/assets/images/games/aviator-banner.jpg" alt="Aviator">
                <div class="game-overlay">
                    <a href="/games/aviator/game" class="btn btn-primary">Play Now</a>
                </div>
            </div>
            <div class="game-info">
                <h3>Aviator</h3>
                <div class="game-stats">
                    <span class="players">
                        <i class="icon-users"></i>
                        <span id="aviatorPlayers">0</span> Playing
                    </span>
                    <span class="entry-fee">
                        <i class="icon-coins"></i>
                        From ₹10
                    </span>
                </div>
                <p>Watch the multiplier rise and cash out before the plane flies away!</p>
            </div>
        </div>
    </div>
</section>

<section class="features-section">
    <h2>Why Choose Us</h2>
    <div class="features-grid">
        <div class="feature-card">
            <i class="icon-secure"></i>
            <h3>Secure Gaming</h3>
            <p>Your money and data are protected with bank-grade security</p>
        </div>
        <div class="feature-card">
            <i class="icon-instant"></i>
            <h3>Instant Withdrawals</h3>
            <p>Get your winnings instantly in your bank account</p>
        </div>
        <div class="feature-card">
            <i class="icon-support"></i>
            <h3>24/7 Support</h3>
            <p>Our support team is always here to help you</p>
        </div>
        <div class="feature-card">
            <i class="icon-fair"></i>
            <h3>Fair Play</h3>
            <p>All games are tested and certified for fairness</p>
        </div>
    </div>
</section>

<section class="winners-section">
    <h2>Recent Winners</h2>
    <div class="winners-grid" id="recentWinners">
        <!-- Winners will be populated via JavaScript -->
    </div>
</section>

<section class="cta-section">
    <div class="cta-content">
        <h2>Ready to Start Playing?</h2>
        <p>Join now and get a welcome bonus on your first deposit!</p>
        <?php if (!$auth->isAuthenticated()): ?>
            <a href="/register" class="btn btn-primary btn-large">Create Account</a>
        <?php else: ?>
            <a href="/user/wallet" class="btn btn-primary btn-large">Add Money</a>
        <?php endif; ?>
    </div>
</section>

<script>
// Update real-time stats
function updateStats() {
    fetch('/api/stats')
        .then(response => response.json())
        .then(data => {
            document.getElementById('onlinePlayers').textContent = data.onlinePlayers;
            document.getElementById('activeGames').textContent = data.activeGames;
            document.getElementById('totalPrizes').textContent = data.totalPrizes;
            document.getElementById('ludoPlayers').textContent = data.ludoPlayers;
            document.getElementById('aviatorPlayers').textContent = data.aviatorPlayers;
        })
        .catch(console.error);
}

// Update recent winners
function updateWinners() {
    fetch('/api/winners')
        .then(response => response.json())
        .then(winners => {
            const container = document.getElementById('recentWinners');
            container.innerHTML = winners.map(winner => `
                <div class="winner-card">
                    <img src="${winner.avatar}" alt="${winner.username}" class="winner-avatar">
                    <div class="winner-info">
                        <h4>${winner.username}</h4>
                        <p>Won ₹${winner.amount}</p>
                        <span class="game-name">${winner.game}</span>
                    </div>
                </div>
            `).join('');
        })
        .catch(console.error);
}

// Initialize
updateStats();
updateWinners();

// Update stats every 30 seconds
setInterval(updateStats, 30000);

// Update winners every 60 seconds
setInterval(updateWinners, 60000);
</script>

<?php
$content = ob_get_clean();
require_once __DIR__ . '/layouts/main.php';
?>
