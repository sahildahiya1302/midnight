<?php
// Prevent direct access
if (!defined('BASE_PATH')) {
    header('Location: /');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Gaming Platform</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/responsive.css">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        }

        .auth-card {
            background: var(--background-primary);
            border-radius: 1rem;
            box-shadow: var(--shadow-md);
            width: 100%;
            max-width: 400px;
            padding: 2rem;
        }

        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .auth-header img {
            height: 60px;
            margin-bottom: 1rem;
        }

        .auth-header h1 {
            font-size: 1.5rem;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .auth-header p {
            color: var(--text-secondary);
        }

        .auth-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-group label {
            font-weight: 500;
            color: var(--text-primary);
        }

        .form-group input {
            padding: 0.75rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: border-color 0.2s;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .remember-forgot {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.875rem;
        }

        .remember-me {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .remember-me input[type="checkbox"] {
            width: 1rem;
            height: 1rem;
        }

        .forgot-password {
            color: var(--primary-color);
            text-decoration: none;
        }

        .login-button {
            background: var(--primary-color);
            color: white;
            padding: 0.875rem;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .login-button:hover {
            background: var(--secondary-color);
        }

        .auth-footer {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-color);
        }

        .auth-footer p {
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }

        .social-login {
            display: flex;
            justify-content: center;
            gap: 1rem;
        }

        .social-button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--background-secondary);
            transition: background-color 0.2s;
        }

        .social-button:hover {
            background: var(--border-color);
        }

        .social-button img {
            width: 24px;
            height: 24px;
        }

        .register-link {
            margin-top: 1rem;
            color: var(--text-secondary);
        }

        .register-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        @media (max-width: 480px) {
            .auth-card {
                padding: 1.5rem;
            }

            .auth-header img {
                height: 48px;
            }

            .auth-header h1 {
                font-size: 1.25rem;
            }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <img src="/assets/images/logo.png" alt="Gaming Platform">
                <h1>Welcome Back!</h1>
                <p>Login to continue playing</p>
            </div>

            <form class="auth-form" action="/api/auth/login" method="POST" data-ajax>
                <?php if (isset($_SESSION['csrf_token'])): ?>
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label for="username">Username or Email</label>
                    <input type="text" id="username" name="username" required 
                           autocomplete="username" autofocus>
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required 
                           autocomplete="current-password">
                </div>

                <div class="remember-forgot">
                    <label class="remember-me">
                        <input type="checkbox" name="remember" value="1">
                        Remember me
                    </label>
                    <a href="/forgot-password" class="forgot-password">Forgot Password?</a>
                </div>

                <button type="submit" class="login-button">Login</button>
            </form>

            <div class="auth-footer">
                <p>Or continue with</p>
                <div class="social-login">
                    <a href="/auth/google" class="social-button">
                        <img src="/assets/images/icons/google.svg" alt="Google">
                    </a>
                    <a href="/auth/facebook" class="social-button">
                        <img src="/assets/images/icons/facebook.svg" alt="Facebook">
                    </a>
                    <a href="/auth/apple" class="social-button">
                        <img src="/assets/images/icons/apple.svg" alt="Apple">
                    </a>
                </div>

                <p class="register-link">
                    Don't have an account? <a href="/register">Register Now</a>
                </p>
            </div>
        </div>
    </div>

    <script src="/assets/js/app.js"></script>
    <script>
        // Form validation
        document.querySelector('.auth-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const form = e.target;
            const formData = new FormData(form);
            
            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.success) {
                    window.location.href = data.redirect || '/';
                } else {
                    utils.showToast(data.error || 'Login failed', 'error');
                }
            } catch (error) {
                utils.showToast('An error occurred', 'error');
            }
        });

        // Password visibility toggle
        const passwordInput = document.getElementById('password');
        const togglePassword = document.createElement('button');
        togglePassword.type = 'button';
        togglePassword.className = 'password-toggle';
        togglePassword.innerHTML = '👁️';
        togglePassword.onclick = () => {
            const type = passwordInput.type === 'password' ? 'text' : 'password';
            passwordInput.type = type;
            togglePassword.innerHTML = type === 'password' ? '👁️' : '👁️‍🗨️';
        };
        passwordInput.parentNode.style.position = 'relative';
        passwordInput.parentNode.appendChild(togglePassword);
    </script>
</body>
</html>
