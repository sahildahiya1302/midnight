<?php
// Prevent direct access
if (!defined('BASE_PATH')) {
    header('Location: /');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - Gaming Platform</title>
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/responsive.css">
    <style>
        .auth-container {
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 1rem;
            background: linear-gradient(135deg, var(--primary-color) 0%, var(--secondary-color) 100%);
        }

        .auth-card {
            background: var(--background-primary);
            border-radius: 1rem;
            box-shadow: var(--shadow-md);
            width: 100%;
            max-width: 400px;
            padding: 2rem;
        }

        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .auth-header img {
            height: 60px;
            margin-bottom: 1rem;
        }

        .auth-header h1 {
            font-size: 1.5rem;
            color: var(--text-primary);
            margin-bottom: 0.5rem;
        }

        .auth-header p {
            color: var(--text-secondary);
        }

        .auth-form {
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 0.5rem;
        }

        .form-group label {
            font-weight: 500;
            color: var(--text-primary);
        }

        .form-group input {
            padding: 0.75rem 1rem;
            border: 1px solid var(--border-color);
            border-radius: 0.5rem;
            font-size: 1rem;
            transition: border-color 0.2s;
        }

        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
        }

        .password-requirements {
            font-size: 0.875rem;
            color: var(--text-secondary);
            margin-top: 0.25rem;
        }

        .password-requirements ul {
            list-style: none;
            padding-left: 0;
            margin-top: 0.5rem;
        }

        .password-requirements li {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            margin-bottom: 0.25rem;
        }

        .password-requirements li::before {
            content: "•";
            color: var(--text-light);
        }

        .password-requirements li.valid::before {
            content: "✓";
            color: var(--success-color);
        }

        .terms-checkbox {
            display: flex;
            align-items: flex-start;
            gap: 0.75rem;
            margin-top: 1rem;
        }

        .terms-checkbox input[type="checkbox"] {
            width: 1.25rem;
            height: 1.25rem;
            margin-top: 0.25rem;
        }

        .terms-checkbox label {
            font-size: 0.875rem;
            color: var(--text-secondary);
        }

        .terms-checkbox a {
            color: var(--primary-color);
            text-decoration: none;
        }

        .register-button {
            background: var(--primary-color);
            color: white;
            padding: 0.875rem;
            border: none;
            border-radius: 0.5rem;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.2s;
        }

        .register-button:hover {
            background: var(--secondary-color);
        }

        .register-button:disabled {
            background: var(--text-light);
            cursor: not-allowed;
        }

        .auth-footer {
            text-align: center;
            margin-top: 1.5rem;
            padding-top: 1.5rem;
            border-top: 1px solid var(--border-color);
        }

        .auth-footer p {
            color: var(--text-secondary);
            margin-bottom: 1rem;
        }

        .social-login {
            display: flex;
            justify-content: center;
            gap: 1rem;
        }

        .social-button {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--background-secondary);
            transition: background-color 0.2s;
        }

        .social-button:hover {
            background: var(--border-color);
        }

        .social-button img {
            width: 24px;
            height: 24px;
        }

        .login-link {
            margin-top: 1rem;
            color: var(--text-secondary);
        }

        .login-link a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
        }

        @media (max-width: 480px) {
            .auth-card {
                padding: 1.5rem;
            }

            .auth-header img {
                height: 48px;
            }

            .auth-header h1 {
                font-size: 1.25rem;
            }
        }
    </style>
</head>
<body>
    <div class="auth-container">
        <div class="auth-card">
            <div class="auth-header">
                <img src="/assets/images/logo.png" alt="Gaming Platform">
                <h1>Create Account</h1>
                <p>Join the gaming community</p>
            </div>

            <form class="auth-form" action="/api/auth/register" method="POST" data-ajax>
                <?php if (isset($_SESSION['csrf_token'])): ?>
                    <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
                <?php endif; ?>

                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" id="username" name="username" required 
                           minlength="3" maxlength="30" pattern="^[a-zA-Z0-9_]+$"
                           title="Username can only contain letters, numbers, and underscores"
                           autocomplete="username" autofocus>
                </div>

                <div class="form-group">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" required 
                           autocomplete="email">
                </div>

                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required 
                           minlength="8" autocomplete="new-password">
                    <div class="password-requirements">
                        Password must contain:
                        <ul>
                            <li data-requirement="length">At least 8 characters</li>
                            <li data-requirement="uppercase">One uppercase letter</li>
                            <li data-requirement="lowercase">One lowercase letter</li>
                            <li data-requirement="number">One number</li>
                            <li data-requirement="special">One special character</li>
                        </ul>
                    </div>
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <input type="password" id="confirm_password" name="confirm_password" 
                           required minlength="8" autocomplete="new-password">
                </div>

                <div class="terms-checkbox">
                    <input type="checkbox" id="terms" name="terms" required>
                    <label for="terms">
                        I agree to the <a href="/terms" target="_blank">Terms & Conditions</a> 
                        and <a href="/privacy" target="_blank">Privacy Policy</a>
                    </label>
                </div>

                <button type="submit" class="register-button" disabled>Create Account</button>
            </form>

            <div class="auth-footer">
                <p>Or register with</p>
                <div class="social-login">
                    <a href="/auth/google" class="social-button">
                        <img src="/assets/images/icons/google.svg" alt="Google">
                    </a>
                    <a href="/auth/facebook" class="social-button">
                        <img src="/assets/images/icons/facebook.svg" alt="Facebook">
                    </a>
                    <a href="/auth/apple" class="social-button">
                        <img src="/assets/images/icons/apple.svg" alt="Apple">
                    </a>
                </div>

                <p class="login-link">
                    Already have an account? <a href="/login">Login</a>
                </p>
            </div>
        </div>
    </div>

    <script src="/assets/js/app.js"></script>
    <script>
        // Password validation
        const passwordInput = document.getElementById('password');
        const confirmPasswordInput = document.getElementById('confirm_password');
        const termsCheckbox = document.getElementById('terms');
        const registerButton = document.querySelector('.register-button');
        const requirements = document.querySelectorAll('.password-requirements li');

        const validatePassword = () => {
            const password = passwordInput.value;
            const validations = {
                length: password.length >= 8,
                uppercase: /[A-Z]/.test(password),
                lowercase: /[a-z]/.test(password),
                number: /[0-9]/.test(password),
                special: /[^A-Za-z0-9]/.test(password)
            };

            requirements.forEach(req => {
                const type = req.dataset.requirement;
                if (validations[type]) {
                    req.classList.add('valid');
                } else {
                    req.classList.remove('valid');
                }
            });

            return Object.values(validations).every(v => v);
        };

        const validateForm = () => {
            const isPasswordValid = validatePassword();
            const doPasswordsMatch = passwordInput.value === confirmPasswordInput.value;
            const areTermsAccepted = termsCheckbox.checked;

            registerButton.disabled = !(isPasswordValid && doPasswordsMatch && areTermsAccepted);
        };

        passwordInput.addEventListener('input', validateForm);
        confirmPasswordInput.addEventListener('input', validateForm);
        termsCheckbox.addEventListener('change', validateForm);

        // Form submission
        document.querySelector('.auth-form').addEventListener('submit', async (e) => {
            e.preventDefault();
            
            const form = e.target;
            const formData = new FormData(form);
            
            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    body: formData,
                    credentials: 'include'
                });
                
                const data = await response.json();
                
                if (data.success) {
                    window.location.href = data.redirect || '/login';
                } else {
                    utils.showToast(data.error || 'Registration failed', 'error');
                }
            } catch (error) {
                utils.showToast('An error occurred', 'error');
            }
        });

        // Username validation
        const usernameInput = document.getElementById('username');
        let usernameTimeout;

        usernameInput.addEventListener('input', () => {
            clearTimeout(usernameTimeout);
            usernameTimeout = setTimeout(async () => {
                const username = usernameInput.value;
                if (username.length >= 3) {
                    try {
                        const response = await fetch(`/api/auth/check-username?username=${username}`);
                        const data = await response.json();
                        
                        if (!data.available) {
                            utils.showToast('Username is already taken', 'error');
                            usernameInput.setCustomValidity('Username is already taken');
                        } else {
                            usernameInput.setCustomValidity('');
                        }
                    } catch (error) {
                        console.error('Error checking username:', error);
                    }
                }
            }, 500);
        });
    </script>
</body>
</html>
