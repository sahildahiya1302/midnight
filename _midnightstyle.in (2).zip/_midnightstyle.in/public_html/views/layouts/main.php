<?php
// Use the global $auth instance from bootstrap.php
global $auth;
$user = $auth->getUser();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Gaming Platform' ?></title>
    
    <!-- Meta Tags -->
    <meta name="description" content="Play exciting games and win real money">
    <meta name="theme-color" content="#2563eb">
    
    <!-- Open Graph Tags -->
    <meta property="og:title" content="<?= isset($pageTitle) ? htmlspecialchars($pageTitle) : 'Gaming Platform' ?>">
    <meta property="og:description" content="Play exciting games and win real money">
    <meta property="og:image" content="/assets/images/og-image.jpg">
    <meta property="og:url" content="https://midnightstyle.in<?= $_SERVER['REQUEST_URI'] ?>">
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/assets/images/favicon.png">
    
    <!-- Manifest -->
    <link rel="manifest" href="/manifest.json">
    
    <!-- CSS -->
    <link rel="stylesheet" href="/assets/css/style.css">
    <link rel="stylesheet" href="/assets/css/responsive.css">
    <?php if (isset($extraCSS)) echo $extraCSS; ?>
    
    <!-- Preconnect to WebSocket -->
    <link rel="preconnect" href="wss://midnightstyle.in">
</head>
<body class="<?= isset($bodyClass) ? htmlspecialchars($bodyClass) : '' ?>">
    <!-- Header -->
    <header class="main-header">
        <div class="header-container">
            <div class="header-left">
                <a href="/" class="logo">
                    <img src="/assets/images/logo.png" alt="Gaming Platform" width="40" height="40">
                </a>
                <nav class="main-nav">
                    <a href="/" class="nav-item <?= $currentPage === 'home' ? 'active' : '' ?>">Home</a>
                    <a href="/games/ludo/lobby" class="nav-item <?= $currentPage === 'ludo' ? 'active' : '' ?>">Ludo</a>
                    <a href="/games/aviator/game" class="nav-item <?= $currentPage === 'aviator' ? 'active' : '' ?>">Aviator</a>
                    <a href="/leaderboard" class="nav-item <?= $currentPage === 'leaderboard' ? 'active' : '' ?>">Leaderboard</a>
                </nav>
            </div>
            
            <div class="header-right">
                <?php if ($user): ?>
                    <div class="wallet-balance">
                        <i class="icon-wallet"></i>
                        <span class="balance">₹<?= number_format($user->getWallet()->getBalance(), 2) ?></span>
                        <a href="/user/wallet" class="add-money" title="Add Money">
                            <i class="icon-plus"></i>
                        </a>
                    </div>
                    
                    <div class="user-menu">
                        <button class="user-toggle" aria-label="User menu">
                            <img src="<?= $user->getData()['avatar'] ?? '/assets/images/default-avatar.png' ?>" 
                                 alt="<?= htmlspecialchars($user->getData()['username']) ?>"
                                 class="user-avatar"
                                 width="32"
                                 height="32">
                            <span class="username"><?= htmlspecialchars($user->getData()['username']) ?></span>
                            <i class="icon-chevron-down"></i>
                        </button>
                        
                        <div class="dropdown-menu">
                            <a href="/user/profile" class="menu-item">
                                <i class="icon-user"></i>
                                <span>Profile</span>
                            </a>
                            <a href="/user/wallet" class="menu-item">
                                <i class="icon-wallet"></i>
                                <span>Wallet</span>
                            </a>
                            <a href="/user/history" class="menu-item">
                                <i class="icon-history"></i>
                                <span>History</span>
                            </a>
                            <?php if ($auth->isAdmin()): ?>
                                <a href="/admin" class="menu-item">
                                    <i class="icon-admin"></i>
                                    <span>Admin Panel</span>
                                </a>
                            <?php endif; ?>
                            <a href="/logout" class="menu-item">
                                <i class="icon-logout"></i>
                                <span>Logout</span>
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="auth-buttons">
                        <a href="/login" class="btn btn-secondary">Login</a>
                        <a href="/register" class="btn btn-primary">Register</a>
                    </div>
                <?php endif; ?>
                
                <button class="menu-toggle" aria-label="Toggle mobile menu">
                    <i class="icon-menu"></i>
                </button>
            </div>
        </div>
    </header>

    <!-- Mobile Menu -->
    <div class="mobile-menu">
        <div class="menu-header">
            <?php if ($user): ?>
                <div class="user-info">
                    <img src="<?= $user->getData()['avatar'] ?? '/assets/images/default-avatar.png' ?>" 
                         alt="<?= htmlspecialchars($user->getData()['username']) ?>"
                         class="user-avatar"
                         width="40"
                         height="40">
                    <div class="user-details">
                        <span class="username"><?= htmlspecialchars($user->getData()['username']) ?></span>
                        <span class="balance">₹<?= number_format($user->getWallet()->getBalance(), 2) ?></span>
                    </div>
                </div>
            <?php else: ?>
                <div class="auth-buttons">
                    <a href="/login" class="btn btn-secondary">Login</a>
                    <a href="/register" class="btn btn-primary">Register</a>
                </div>
            <?php endif; ?>
        </div>
        
        <nav class="menu-nav">
            <a href="/" class="nav-item <?= $currentPage === 'home' ? 'active' : '' ?>">
                <i class="icon-home"></i>
                <span>Home</span>
            </a>
            <a href="/games/ludo/lobby" class="nav-item <?= $currentPage === 'ludo' ? 'active' : '' ?>">
                <i class="icon-ludo"></i>
                <span>Ludo</span>
            </a>
            <a href="/games/aviator/game" class="nav-item <?= $currentPage === 'aviator' ? 'active' : '' ?>">
                <i class="icon-aviator"></i>
                <span>Aviator</span>
            </a>
            <a href="/leaderboard" class="nav-item <?= $currentPage === 'leaderboard' ? 'active' : '' ?>">
                <i class="icon-trophy"></i>
                <span>Leaderboard</span>
            </a>
            <?php if ($user): ?>
                <a href="/user/profile" class="nav-item <?= $currentPage === 'profile' ? 'active' : '' ?>">
                    <i class="icon-user"></i>
                    <span>Profile</span>
                </a>
                <a href="/user/wallet" class="nav-item <?= $currentPage === 'wallet' ? 'active' : '' ?>">
                    <i class="icon-wallet"></i>
                    <span>Wallet</span>
                </a>
                <a href="/user/history" class="nav-item <?= $currentPage === 'history' ? 'active' : '' ?>">
                    <i class="icon-history"></i>
                    <span>History</span>
                </a>
                <?php if ($auth->isAdmin()): ?>
                    <a href="/admin" class="nav-item <?= $currentPage === 'admin' ? 'active' : '' ?>">
                        <i class="icon-admin"></i>
                        <span>Admin Panel</span>
                    </a>
                <?php endif; ?>
                <a href="/logout" class="nav-item">
                    <i class="icon-logout"></i>
                    <span>Logout</span>
                </a>
            <?php endif; ?>
        </nav>
    </div>

    <!-- Main Content -->
    <main class="main-content">
        <?= $content ?? '' ?>
    </main>

    <!-- Footer -->
    <?php require_once __DIR__ . '/footer.php'; ?>

    <!-- Scripts -->
    <script src="/assets/js/app.js"></script>
    <?php if (isset($extraJS)) echo $extraJS; ?>

    <!-- Service Worker Registration -->
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js')
                    .then(registration => {
                        console.log('ServiceWorker registration successful');
                    })
                    .catch(err => {
                        console.log('ServiceWorker registration failed: ', err);
                    });
            });
        }
    </script>
</body>
</html>
