</main>

    <!-- Footer -->
    <footer class="main-footer">
        <div class="footer-container">
            <div class="footer-top">
                <div class="footer-logo">
                    <img src="/assets/images/logo.png" alt="Gaming Platform" width="80" height="80">
                    <p>Play exciting games and win real money</p>
                    <div class="social-links">
                        <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                            <i class="icon-facebook"></i>
                        </a>
                        <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
                            <i class="icon-twitter"></i>
                        </a>
                        <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                            <i class="icon-instagram"></i>
                        </a>
                        <a href="#" target="_blank" rel="noopener noreferrer" aria-label="Telegram">
                            <i class="icon-telegram"></i>
                        </a>
                    </div>
                </div>
                
                <div class="footer-links">
                    <div class="link-group">
                        <h3>Quick Links</h3>
                        <a href="/about">About Us</a>
                        <a href="/contact">Contact</a>
                        <a href="/faq">FAQ</a>
                        <a href="/blog">Blog</a>
                    </div>
                    
                    <div class="link-group">
                        <h3>Legal</h3>
                        <a href="/terms">Terms of Service</a>
                        <a href="/privacy">Privacy Policy</a>
                        <a href="/responsible-gaming">Responsible Gaming</a>
                        <a href="/kyc">KYC Policy</a>
                    </div>
                    
                    <div class="link-group">
                        <h3>Support</h3>
                        <a href="/help">Help Center</a>
                        <a href="/support">Support</a>
                        <a href="/report">Report Issue</a>
                        <a href="/feedback">Feedback</a>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <div class="footer-info">
                    <p>&copy; <?= date('Y') ?> Gaming Platform. All rights reserved.</p>
                    <div class="payment-methods">
                        <img src="/assets/images/payments/upi.png" alt="UPI" width="40" height="24">
                        <img src="/assets/images/payments/paytm.png" alt="Paytm" width="40" height="24">
                        <img src="/assets/images/payments/gpay.png" alt="Google Pay" width="40" height="24">
                        <img src="/assets/images/payments/phonepe.png" alt="PhonePe" width="40" height="24">
                    </div>
                </div>
                
                <div class="footer-disclaimer">
                    <p>This platform involves an element of financial risk and may be addictive. Please play responsibly and at your own risk.</p>
                </div>
            </div>
        </div>
    </footer>

    <!-- Notification Container -->
    <div id="notificationContainer"></div>

    <!-- Scripts -->
    <script src="/assets/js/app.js"></script>
    <?php if (isset($extraJS)) echo $extraJS; ?>

    <!-- Service Worker Registration -->
    <script>
        if ('serviceWorker' in navigator) {
            window.addEventListener('load', () => {
                navigator.serviceWorker.register('/sw.js')
                    .then(registration => {
                        console.log('ServiceWorker registration successful');
                    })
                    .catch(err => {
                        console.log('ServiceWorker registration failed: ', err);
                    });
            });
        }

        // Initialize mobile menu
        document.querySelector('.menu-toggle').addEventListener('click', () => {
            document.body.classList.toggle('menu-open');
        });

        // Initialize user menu dropdown
        const userToggle = document.querySelector('.user-toggle');
        if (userToggle) {
            userToggle.addEventListener('click', (e) => {
                e.stopPropagation();
                userToggle.closest('.user-menu').classList.toggle('active');
            });

            // Close dropdown when clicking outside
            document.addEventListener('click', (e) => {
                if (!e.target.closest('.user-menu')) {
                    document.querySelector('.user-menu')?.classList.remove('active');
                }
            });
        }

        // Handle notifications
        window.showNotification = function(message, type = 'info') {
            const notification = document.createElement('div');
            notification.className = `notification ${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <i class="icon-${type}"></i>
                    <span>${message}</span>
                </div>
                <button class="close-notification" onclick="this.parentElement.remove()">
                    <i class="icon-close"></i>
                </button>
            `;
            
            document.getElementById('notificationContainer').appendChild(notification);
            
            // Auto dismiss after 5 seconds
            setTimeout(() => {
                notification.classList.add('fade-out');
                setTimeout(() => notification.remove(), 300);
            }, 5000);
        }

        // Handle WebSocket connection status
        window.addEventListener('online', () => {
            showNotification('Connection restored', 'success');
        });

        window.addEventListener('offline', () => {
            showNotification('Connection lost. Please check your internet connection.', 'error');
        });
    </script>

    <?php if (isset($pageScripts)) echo $pageScripts; ?>
</body>
</html>
