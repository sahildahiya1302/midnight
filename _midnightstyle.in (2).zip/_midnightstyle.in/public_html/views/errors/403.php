<?php
$pageTitle = '403 - Access Denied';
require_once __DIR__ . '/../layouts/header.php';
?>

<div class="error-page">
    <div class="error-container">
        <div class="error-code">403</div>
        <h1>Access Denied</h1>
        <p>You don't have permission to access this area.</p>
        <div class="error-actions">
            <a href="/" class="btn btn-primary">
                <i class="icon-home"></i> Go Home
            </a>
            <a href="javascript:history.back()" class="btn btn-secondary">
                <i class="icon-back"></i> Go Back
            </a>
        </div>
    </div>
</div>

<style>
.error-page {
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background: var(--background-primary);
    padding: 2rem;
}

.error-container {
    text-align: center;
    max-width: 600px;
}

.error-code {
    font-size: 8rem;
    font-weight: 700;
    color: var(--danger-color);
    line-height: 1;
    margin-bottom: 1rem;
    text-shadow: 2px 2px 4px rgba(239, 68, 68, 0.2);
}

.error-container h1 {
    font-size: 2rem;
    margin-bottom: 1rem;
    color: var(--text-primary);
}

.error-container p {
    color: var(--text-secondary);
    margin-bottom: 2rem;
}

.error-actions {
    display: flex;
    gap: 1rem;
    justify-content: center;
}

.btn {
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    padding: 0.75rem 1.5rem;
    border-radius: 0.5rem;
    font-weight: 500;
    text-decoration: none;
    transition: all 0.2s;
}

.btn-primary {
    background: var(--primary-color);
    color: white;
}

.btn-primary:hover {
    background: var(--primary-color-dark);
}

.btn-secondary {
    background: var(--background-secondary);
    color: var(--text-primary);
}

.btn-secondary:hover {
    background: var(--border-color);
}

@media (max-width: 768px) {
    .error-code {
        font-size: 6rem;
    }

    .error-container h1 {
        font-size: 1.5rem;
    }

    .error-actions {
        flex-direction: column;
    }
}

/* Animation */
.error-code {
    animation: shake 0.5s cubic-bezier(.36,.07,.19,.97) both;
}

@keyframes shake {
    10%, 90% {
        transform: translate3d(-1px, 0, 0);
    }
    20%, 80% {
        transform: translate3d(2px, 0, 0);
    }
    30%, 50%, 70% {
        transform: translate3d(-4px, 0, 0);
    }
    40%, 60% {
        transform: translate3d(4px, 0, 0);
    }
}
</style>

<?php require_once __DIR__ . '/../layouts/footer.php'; ?>
