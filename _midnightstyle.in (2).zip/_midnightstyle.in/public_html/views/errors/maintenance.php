<?php
http_response_code(503);
header('Retry-After: 3600');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Maintenance Mode - Gaming Platform</title>
    <style>
        :root {
            --primary-color: #2563eb;
            --text-primary: #1e293b;
            --text-secondary: #64748b;
            --background: #f8fafc;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
            line-height: 1.6;
            color: var(--text-primary);
            background: var(--background);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .maintenance-container {
            text-align: center;
            max-width: 600px;
            padding: 2rem;
        }

        .maintenance-icon {
            width: 120px;
            height: 120px;
            margin-bottom: 2rem;
            animation: float 3s ease-in-out infinite;
        }

        .maintenance-title {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 1rem;
            color: var(--primary-color);
        }

        .maintenance-message {
            font-size: 1.125rem;
            color: var(--text-secondary);
            margin-bottom: 2rem;
        }

        .maintenance-info {
            background: white;
            border-radius: 0.5rem;
            padding: 1.5rem;
            box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            margin-bottom: 2rem;
        }

        .maintenance-info h2 {
            font-size: 1.25rem;
            margin-bottom: 1rem;
            color: var(--text-primary);
        }

        .maintenance-info p {
            color: var(--text-secondary);
            margin-bottom: 0.5rem;
        }

        .maintenance-status {
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            background: rgba(37, 99, 235, 0.1);
            color: var(--primary-color);
            font-weight: 500;
            margin-top: 1rem;
        }

        .status-dot {
            width: 8px;
            height: 8px;
            border-radius: 50%;
            background: currentColor;
            animation: pulse 2s infinite;
        }

        @keyframes float {
            0%, 100% {
                transform: translateY(0);
            }
            50% {
                transform: translateY(-20px);
            }
        }

        @keyframes pulse {
            0%, 100% {
                opacity: 1;
            }
            50% {
                opacity: 0.5;
            }
        }

        @media (max-width: 640px) {
            .maintenance-title {
                font-size: 2rem;
            }

            .maintenance-message {
                font-size: 1rem;
            }

            .maintenance-icon {
                width: 100px;
                height: 100px;
            }
        }
    </style>
</head>
<body>
    <div class="maintenance-container">
        <svg class="maintenance-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <circle cx="12" cy="12" r="7"></circle>
            <path d="M12 9v2l1 1"></path>
            <path d="M16.13 7.87l-4.25 4.25"></path>
            <path d="M12 1v2"></path>
            <path d="M12 21v2"></path>
            <path d="M4.22 4.22l1.42 1.42"></path>
            <path d="M18.36 18.36l1.42 1.42"></path>
            <path d="M1 12h2"></path>
            <path d="M21 12h2"></path>
            <path d="M4.22 19.78l1.42-1.42"></path>
            <path d="M18.36 5.64l1.42-1.42"></path>
        </svg>

        <h1 class="maintenance-title">Under Maintenance</h1>
        <p class="maintenance-message">
            We're currently performing scheduled maintenance to improve your gaming experience. 
            We'll be back online shortly!
        </p>

        <div class="maintenance-info">
            <h2>Maintenance Details</h2>
            <p>We're upgrading our systems to provide you with:</p>
            <ul style="list-style: none; margin: 1rem 0;">
                <li>✨ Enhanced gaming performance</li>
                <li>🛡️ Improved security measures</li>
                <li>🎮 New gaming features</li>
                <li>🚀 Better user experience</li>
            </ul>
            <p>Expected completion: ~1 hour</p>
        </div>

        <div class="maintenance-status">
            <span class="status-dot"></span>
            <span>Maintenance in Progress</span>
        </div>
    </div>

    <script>
        // Refresh the page every 5 minutes to check if maintenance is complete
        setTimeout(() => {
            window.location.reload();
        }, 300000);
    </script>
</body>
</html>
