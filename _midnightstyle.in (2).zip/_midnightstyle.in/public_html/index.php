<?php

/**
 * MidnightStyle Gaming Platform
 * 
 * This is the main entry point for the application. All web requests
 * are routed through this file.
 */

// Define the application start time
define('APP_START', microtime(true));

// Define base path
define('BASE_PATH', dirname(__DIR__));

/*
|--------------------------------------------------------------------------
| Register The Auto Loader
|--------------------------------------------------------------------------
|
| Load the application bootstrap file which sets up autoloading,
| environment variables, error handling, and creates the application
| instance.
*/

$app = require BASE_PATH . '/private/bootstrap.php';

/*
|--------------------------------------------------------------------------
| Run The Application
|--------------------------------------------------------------------------
|
| Handle the incoming request through the application's routing system
| and send the response back to the client.
*/

try {
    // Create request from globals
    $request = App\Core\Http\Request::createFromGlobals();

    // Handle the request and get response
    $response = $app->handle($request);

    // Send response to client
    $response->send();

    // Terminate the application
    $app->terminate($request, $response);

} catch (\Throwable $e) {
    // Handle any uncaught exceptions
    $errorHandler = $app->get('error.handler');
    $response = $errorHandler->handleException($e);
    $response->send();
}

/*
|--------------------------------------------------------------------------
| Log Performance Metrics
|--------------------------------------------------------------------------
|
| Calculate and log the total execution time and memory usage
| for performance monitoring.
*/

if ($_ENV['APP_DEBUG'] ?? false) {
    $executionTime = (microtime(true) - APP_START) * 1000;
    $memoryUsage = memory_get_peak_usage(true) / 1024 / 1024;
    
    error_log(sprintf(
        'Request: %s %s | Time: %.2fms | Memory: %.2fMB',
        $_SERVER['REQUEST_METHOD'],
        $_SERVER['REQUEST_URI'],
        $executionTime,
        $memoryUsage
    ));
}
