// sw.js

const CACHE_NAME = 'gaming-platform-v1';
const ASSETS_TO_CACHE = [
    '/',
    '/index.php',
    '/assets/css/style.css',
    '/assets/css/responsive.css',
    '/assets/js/app.js',
    '/assets/images/logo.png',
    '/assets/images/favicon.png',
    '/assets/images/default-avatar.png',
    '/assets/images/icons/profile.svg',
    '/assets/images/icons/wallet.svg',
    '/assets/images/icons/history.svg',
    '/assets/images/icons/settings.svg',
    '/assets/images/icons/support.svg',
    '/assets/images/icons/logout.svg',
    '/assets/images/icons/icon-192x192.png',
    '/assets/images/icons/icon-512x512.png',
    '/manifest.json'
];

// Install Service Worker
self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then((cache) => {
                return Promise.all(
                    ASSETS_TO_CACHE.map((url) => {
                        return cache.add(url).catch((error) => {
                            console.error('Failed to cache:', url, error);
                        });
                    })
                );
            })
            .then(() => {
                return self.skipWaiting();
            })
    );
});

// Activate Service Worker
self.addEventListener('activate', (event) => {
    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (cacheName !== CACHE_NAME) {
                        return caches.delete(cacheName);
                    }
                })
            );
        }).then(() => {
            return self.clients.claim();
        })
    );
});

// Fetch Event Handler
self.addEventListener('fetch', (event) => {
    // Skip cross-origin requests
    if (!event.request.url.startsWith(self.location.origin)) {
        return;
    }

    // Handle API requests
    if (event.request.url.includes('/api/')) {
        return handleApiRequest(event);
    }

    // Handle static assets and pages
    event.respondWith(
        caches.match(event.request)
            .then((response) => {
                if (response) {
                    return response;
                }

                return fetch(event.request).then((response) => {
                    // Check if we received a valid response
                    if (!response || response.status !== 200 || response.type !== 'basic') {
                        return response;
                    }

                    // Clone the response as it can only be consumed once
                    const responseToCache = response.clone();

                    caches.open(CACHE_NAME)
                        .then((cache) => {
                            cache.put(event.request, responseToCache);
                        });

                    return response;
                });
            })
    );
});

// Handle API Requests
function handleApiRequest(event) {
    return fetch(event.request)
        .then((response) => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response;
        })
        .catch((error) => {
            // If offline, try to return cached data for GET requests
            if (event.request.method === 'GET') {
                return caches.match(event.request);
            }
            throw error;
        });
}

// Push Notification Handler
self.addEventListener('push', (event) => {
    if (!event.data) {
        return;
    }

    const data = event.data.json();
    const options = {
        body: data.body,
        icon: '/assets/images/icons/icon-192x192.png',
        badge: '/assets/images/icons/badge.png',
        vibrate: [100, 50, 100],
        data: {
            url: data.url
        }
    };

    event.waitUntil(
        self.registration.showNotification(data.title, options)
    );
});

// Notification Click Handler
self.addEventListener('notificationclick', (event) => {
    event.notification.close();

    if (event.notification.data.url) {
        event.waitUntil(
            clients.openWindow(event.notification.data.url)
        );
    }
});

// Background Sync for Offline Actions
self.addEventListener('sync', (event) => {
    if (event.tag === 'sync-game-moves') {
        event.waitUntil(syncGameMoves());
    }
});

// Sync Game Moves when Online
async function syncGameMoves() {
    try {
        const db = await openDB();
        const moves = await db.getAll('offlineMoves');

        for (const move of moves) {
            try {
                await fetch('/api/games/move', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(move)
                });

                await db.delete('offlineMoves', move.id);
            } catch (error) {
                console.error('Error syncing move:', error);
            }
        }
    } catch (error) {
        console.error('Error in syncGameMoves:', error);
    }
}

// IndexedDB Helper
function openDB() {
    return new Promise((resolve, reject) => {
        const request = indexedDB.open('GamingPlatformDB', 1);

        request.onerror = () => reject(request.error);
        request.onsuccess = () => resolve(request.result);

        request.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains('offlineMoves')) {
                db.createObjectStore('offlineMoves', { keyPath: 'id', autoIncrement: true });
            }
        };
    });
}

// Periodic Background Sync
self.addEventListener('periodicsync', (event) => {
    if (event.tag === 'update-game-state') {
        event.waitUntil(updateGameState());
    }
});

// Update Game State
async function updateGameState() {
    try {
        const cache = await caches.open(CACHE_NAME);
        const gameStateResponse = await fetch('/api/games/state');
        if (gameStateResponse.ok) {
            await cache.put('/api/games/state', gameStateResponse);
        }
    } catch (error) {
        console.error('Error updating game state:', error);
    }
}