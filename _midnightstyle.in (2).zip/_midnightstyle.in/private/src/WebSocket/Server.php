<?php

namespace App\WebSocket;

use Ratchet\MessageComponentInterface;
use Ratchet\ConnectionInterface;
use App\Core\Session\SessionManager;
use App\Core\Security\Auth\Authentication;
use Psr\Log\LoggerInterface;

class Server implements MessageComponentInterface
{
    protected $clients;
    protected $sessions;
    protected $auth;
    protected $logger;

    public function __construct(
        SessionManager $sessions,
        Authentication $auth,
        LoggerInterface $logger
    ) {
        $this->clients = new \SplObjectStorage;
        $this->sessions = $sessions;
        $this->auth = $auth;
        $this->logger = $logger;
    }

    public function onOpen(ConnectionInterface $conn)
    {
        $this->clients->attach($conn);
        $this->logger->info("New connection! ({$conn->resourceId})");
    }

    public function onMessage(ConnectionInterface $from, $msg)
    {
        $data = json_decode($msg, true);
        
        if (!$data) {
            $this->logger->warning("Received invalid JSON from client {$from->resourceId}");
            return;
        }

        try {
            // Validate authentication
            if (!isset($data['token'])) {
                throw new \Exception('Authentication token required');
            }

            $user = $this->auth->validateToken($data['token']);
            if (!$user) {
                throw new \Exception('Invalid authentication token');
            }

            // Associate user with connection
            $from->user = $user;

            // Handle message based on type
            switch ($data['type'] ?? '') {
                case 'join_game':
                    $this->handleJoinGame($from, $data);
                    break;
                    
                case 'game_action':
                    $this->handleGameAction($from, $data);
                    break;
                    
                case 'chat':
                    $this->handleChat($from, $data);
                    break;
                    
                default:
                    throw new \Exception('Invalid message type');
            }

        } catch (\Exception $e) {
            $this->logger->error("Error handling message: " . $e->getMessage());
            $from->send(json_encode([
                'type' => 'error',
                'message' => $e->getMessage()
            ]));
        }
    }

    public function onClose(ConnectionInterface $conn)
    {
        $this->clients->detach($conn);
        $this->logger->info("Connection {$conn->resourceId} has disconnected");
        
        // Handle cleanup if user was in a game
        if (isset($conn->user)) {
            $this->handlePlayerDisconnect($conn);
        }
    }

    public function onError(ConnectionInterface $conn, \Exception $e)
    {
        $this->logger->error("An error occurred: {$e->getMessage()}");
        $conn->close();
    }

    protected function handleJoinGame(ConnectionInterface $conn, array $data)
    {
        // Validate game ID
        if (!isset($data['game_id'])) {
            throw new \Exception('Game ID required');
        }

        // Join game room
        $gameId = $data['game_id'];
        $conn->gameId = $gameId;

        // Notify other players
        $this->broadcast([
            'type' => 'player_joined',
            'game_id' => $gameId,
            'player' => [
                'id' => $conn->user->getId(),
                'name' => $conn->user->getName()
            ]
        ], $gameId);
    }

    protected function handleGameAction(ConnectionInterface $conn, array $data)
    {
        // Validate game action
        if (!isset($conn->gameId)) {
            throw new \Exception('Not in a game');
        }

        if (!isset($data['action'])) {
            throw new \Exception('Game action required');
        }

        // Broadcast action to other players in game
        $this->broadcast([
            'type' => 'game_action',
            'game_id' => $conn->gameId,
            'player_id' => $conn->user->getId(),
            'action' => $data['action'],
            'data' => $data['data'] ?? null
        ], $conn->gameId, [$conn]);
    }

    protected function handleChat(ConnectionInterface $conn, array $data)
    {
        // Validate chat message
        if (!isset($data['message'])) {
            throw new \Exception('Chat message required');
        }

        // Broadcast to appropriate room/game
        $target = isset($conn->gameId) ? $conn->gameId : 'lobby';
        $this->broadcast([
            'type' => 'chat',
            'room' => $target,
            'player' => [
                'id' => $conn->user->getId(),
                'name' => $conn->user->getName()
            ],
            'message' => $data['message']
        ], $target);
    }

    protected function handlePlayerDisconnect(ConnectionInterface $conn)
    {
        if (isset($conn->gameId)) {
            $this->broadcast([
                'type' => 'player_left',
                'game_id' => $conn->gameId,
                'player_id' => $conn->user->getId()
            ], $conn->gameId);
        }
    }

    protected function broadcast(array $data, string $room, array $exclude = [])
    {
        $message = json_encode($data);
        
        foreach ($this->clients as $client) {
            if (in_array($client, $exclude)) {
                continue;
            }

            if ($room === 'lobby' || (isset($client->gameId) && $client->gameId === $room)) {
                $client->send($message);
            }
        }
    }
}
