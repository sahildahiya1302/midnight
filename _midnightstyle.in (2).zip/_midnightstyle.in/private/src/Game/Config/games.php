<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Game Settings
    |--------------------------------------------------------------------------
    |
    | Global settings that apply to all games
    |
    */
    'global' => [
        // Default currency settings
        'currency' => [
            'default' => 'USD',
            'supported' => ['USD', 'EUR', 'GBP', 'BTC', 'ETH'],
            'decimals' => [
                'USD' => 2,
                'EUR' => 2,
                'GBP' => 2,
                'BTC' => 8,
                'ETH' => 8
            ]
        ],

        // Rate limiting
        'rate_limits' => [
            'bets' => [
                'max_per_minute' => 60,
                'max_per_hour' => 1000
            ],
            'cashouts' => [
                'max_per_minute' => 60,
                'max_per_hour' => 1000
            ]
        ],

        // Transaction settings
        'transactions' => [
            'timeout' => 30, // seconds
            'retry_attempts' => 3,
            'retry_delay' => 5 // seconds
        ],

        // Leaderboard settings
        'leaderboards' => [
            'update_interval' => 300, // 5 minutes
            'cache_duration' => 3600, // 1 hour
            'max_entries' => 100
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Aviator Game Settings
    |--------------------------------------------------------------------------
    |
    | Settings specific to the Aviator game
    |
    */
    'aviator' => [
        // Game mechanics
        'mechanics' => [
            'min_bet' => 1.00,
            'max_bet' => 1000.00,
            'max_multiplier' => 100.0,
            'house_edge' => 0.01,
            'round_time' => 5,  // seconds
            'wait_time' => 3,   // seconds between rounds
            'max_auto_cashout' => 1000.0
        ],

        // Betting limits per currency
        'betting_limits' => [
            'USD' => ['min' => 1.00, 'max' => 1000.00],
            'EUR' => ['min' => 1.00, 'max' => 850.00],
            'GBP' => ['min' => 1.00, 'max' => 750.00],
            'BTC' => ['min' => 0.00001, 'max' => 0.05],
            'ETH' => ['min' => 0.0001, 'max' => 0.5]
        ],

        // Game state settings
        'state' => [
            'phases' => ['waiting', 'betting', 'flying', 'crashed'],
            'betting_phase_duration' => 5,  // seconds
            'max_players_per_game' => 100,
            'min_players_to_start' => 1
        ],

        // Multiplier settings
        'multiplier' => [
            'growth_rate' => 1.06,
            'update_interval' => 0.05,  // seconds
            'display_precision' => 2
        ],

        // Auto-cashout settings
        'auto_cashout' => [
            'min_multiplier' => 1.01,
            'max_multiplier' => 1000.0,
            'precision' => 2
        ],

        // Fairness settings
        'fairness' => [
            'hash_algorithm' => 'sha256',
            'seed_length' => 32,
            'public_seed' => true,
            'verify_url' => '/verify/aviator'
        ],

        // History settings
        'history' => [
            'max_recent_games' => 50,
            'max_player_history' => 100,
            'cache_duration' => 3600  // 1 hour
        ],

        // Statistics settings
        'statistics' => [
            'update_interval' => 300,  // 5 minutes
            'cache_duration' => 3600,  // 1 hour
            'tracked_metrics' => [
                'total_games',
                'total_bets',
                'total_winnings',
                'highest_multiplier',
                'average_multiplier',
                'win_rate',
                'best_streak'
            ]
        ],

        // WebSocket settings
        'websocket' => [
            'update_rate' => 20,  // updates per second
            'compression' => true,
            'max_connections' => 10000,
            'ping_interval' => 30,  // seconds
            'timeout' => 60        // seconds
        ],

        // Error handling
        'errors' => [
            'max_retries' => 3,
            'retry_delay' => 1000,  // milliseconds
            'log_level' => 'warning'
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Game Providers
    |--------------------------------------------------------------------------
    |
    | Service providers for game functionality
    |
    */
    'providers' => [
        // Core game providers
        App\Game\Providers\GameServiceProvider::class,
        App\Game\Providers\WebSocketServiceProvider::class,
        App\Game\Providers\FairnessServiceProvider::class,

        // Game-specific providers
        App\Game\Aviator\Providers\AviatorServiceProvider::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Game Events
    |--------------------------------------------------------------------------
    |
    | Event handlers for game functionality
    |
    */
    'events' => [
        // Game lifecycle events
        'game.created' => [
            App\Game\Listeners\LogGameCreation::class,
            App\Game\Listeners\NotifyGameCreation::class,
        ],
        'game.started' => [
            App\Game\Listeners\LogGameStart::class,
            App\Game\Listeners\NotifyGameStart::class,
        ],
        'game.ended' => [
            App\Game\Listeners\LogGameEnd::class,
            App\Game\Listeners\NotifyGameEnd::class,
            App\Game\Listeners\ProcessGameRewards::class,
        ],

        // Player action events
        'player.bet' => [
            App\Game\Listeners\LogPlayerBet::class,
            App\Game\Listeners\ValidatePlayerBet::class,
            App\Game\Listeners\ProcessPlayerBet::class,
        ],
        'player.cashout' => [
            App\Game\Listeners\LogPlayerCashout::class,
            App\Game\Listeners\ProcessPlayerCashout::class,
        ],

        // Error events
        'game.error' => [
            App\Game\Listeners\LogGameError::class,
            App\Game\Listeners\NotifyGameError::class,
        ]
    ],

    /*
    |--------------------------------------------------------------------------
    | Game Middleware
    |--------------------------------------------------------------------------
    |
    | Middleware for game routes and WebSocket connections
    |
    */
    'middleware' => [
        'web' => [
            App\Game\Middleware\AuthenticatePlayer::class,
            App\Game\Middleware\ValidateGameAccess::class,
            App\Game\Middleware\RateLimitRequests::class,
        ],
        'websocket' => [
            App\Game\Middleware\AuthenticateWebSocket::class,
            App\Game\Middleware\ValidateWebSocketConnection::class,
        ]
    ]
];
