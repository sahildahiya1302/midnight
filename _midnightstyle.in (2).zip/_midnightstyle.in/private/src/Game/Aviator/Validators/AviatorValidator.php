<?php

namespace App\Game\Aviator\Validators;

use App\Game\Validators\GameValidator;
use App\Game\State\GameState;
use App\Game\Exceptions\GameValidationException;

class AviatorValidator extends GameValidator
{
    /**
     * List of required fields for each action type
     *
     * @var array
     */
    protected $requiredFields = [
        'bet' => ['amount'],
        'cashout' => []
    ];

    /**
     * List of allowed actions
     *
     * @var array
     */
    protected $allowedActions = [
        'bet',
        'cashout'
    ];

    /**
     * Custom validation rules for actions
     *
     * @var array
     */
    protected $rules = [
        'bet' => [
            'validateBetAmount',
            'validateAutoCashout'
        ],
        'cashout' => [
            'validateCashoutPhase'
        ]
    ];

    /**
     * Validate bet amount
     *
     * @param array $data
     * @param GameState $state
     * @return bool
     * @throws GameValidationException
     */
    protected function validateBetAmount(array $data, GameState $state): bool
    {
        $amount = $data['amount'];
        $settings = $state->getSettings();

        if (!is_numeric($amount)) {
            throw new GameValidationException('Bet amount must be numeric');
        }

        $amount = (float)$amount;

        if ($amount < $settings['minBet']) {
            throw new GameValidationException(
                "Bet amount must be at least {$settings['minBet']}"
            );
        }

        if ($amount > $settings['maxBet']) {
            throw new GameValidationException(
                "Bet amount cannot exceed {$settings['maxBet']}"
            );
        }

        return true;
    }

    /**
     * Validate auto-cashout multiplier
     *
     * @param array $data
     * @param GameState $state
     * @return bool
     * @throws GameValidationException
     */
    protected function validateAutoCashout(array $data, GameState $state): bool
    {
        if (!isset($data['autoCashout'])) {
            return true;
        }

        $multiplier = $data['autoCashout'];
        $settings = $state->getSettings();

        if (!is_numeric($multiplier)) {
            throw new GameValidationException('Auto-cashout multiplier must be numeric');
        }

        $multiplier = (float)$multiplier;

        if ($multiplier < 1.0) {
            throw new GameValidationException('Auto-cashout multiplier must be at least 1.0');
        }

        if ($multiplier > $settings['maxMultiplier']) {
            throw new GameValidationException(
                "Auto-cashout multiplier cannot exceed {$settings['maxMultiplier']}"
            );
        }

        return true;
    }

    /**
     * Validate cashout phase
     *
     * @param array $data
     * @param GameState $state
     * @return bool
     * @throws GameValidationException
     */
    protected function validateCashoutPhase(array $data, GameState $state): bool
    {
        $gameState = $state->getState();

        if ($gameState['phase'] !== 'flying') {
            throw new GameValidationException('Cannot cashout - game is not in flying phase');
        }

        return true;
    }

    /**
     * Validate that a move is valid for the current game state
     *
     * @param array $data
     * @param GameState $state
     * @return bool
     * @throws GameValidationException
     */
    protected function validateMove(array $data, GameState $state): bool
    {
        $action = $data['action'] ?? null;
        $playerId = $data['playerId'] ?? null;

        if (!$action || !$playerId) {
            throw new GameValidationException('Invalid move data');
        }

        if (!$state->isValidAction($playerId, $action, $data)) {
            throw new GameValidationException('Invalid action for current game state');
        }

        return true;
    }

    /**
     * Validate player has sufficient balance for bet
     *
     * @param string $playerId
     * @param float $amount
     * @param GameState $state
     * @return bool
     * @throws GameValidationException
     */
    public function validatePlayerBalance(string $playerId, float $amount, GameState $state): bool
    {
        // This would typically check the player's wallet balance
        // Implementation depends on your wallet system
        return true;
    }

    /**
     * Validate player is not in cooldown period
     *
     * @param string $playerId
     * @param GameState $state
     * @return bool
     * @throws GameValidationException
     */
    public function validatePlayerCooldown(string $playerId, GameState $state): bool
    {
        // This would check if player has exceeded rate limits
        // Implementation depends on your rate limiting system
        return true;
    }

    /**
     * Get custom validation error messages
     *
     * @return array
     */
    public function getMessages(): array
    {
        return array_merge(parent::getMessages(), [
            'bet_amount' => 'Invalid bet amount',
            'auto_cashout' => 'Invalid auto-cashout multiplier',
            'phase' => 'Invalid game phase for this action',
            'balance' => 'Insufficient balance',
            'cooldown' => 'Please wait before placing another bet'
        ]);
    }
}
