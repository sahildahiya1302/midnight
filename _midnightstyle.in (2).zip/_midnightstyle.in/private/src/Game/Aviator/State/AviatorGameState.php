<?php

namespace App\Game\Aviator\State;

use App\Game\State\GameState;

class AviatorGameState extends GameState
{
    /**
     * Get the initial state for a new game
     *
     * @return array
     */
    protected function getInitialState(): array
    {
        return [
            'multiplier' => 1.0,
            'crashPoint' => $this->generateCrashPoint(),
            'bets' => [],
            'cashouts' => [],
            'phase' => 'betting', // betting, flying, crashed
            'startTime' => null,
            'endTime' => null,
            'elapsedTime' => 0,
            'lastUpdate' => microtime(true)
        ];
    }

    /**
     * Generate a provably fair crash point
     *
     * @return float
     */
    protected function generateCrashPoint(): float
    {
        // Use cryptographically secure random number
        $hash = hash('sha256', random_bytes(32));
        $seed = hexdec(substr($hash, 0, 8)) / 0xffffffff;

        // Apply house edge and generate crash point
        $houseEdge = $this->settings['houseEdge'] ?? 0.01;
        return 99 / (1 - $seed) * (1 - $houseEdge);
    }

    /**
     * Handle game start logic
     *
     * @return void
     */
    protected function onGameStart(): void
    {
        $this->state['phase'] = 'flying';
        $this->state['startTime'] = time();
        $this->state['lastUpdate'] = microtime(true);
    }

    /**
     * Handle a specific game action
     *
     * @param string $playerId
     * @param string $action
     * @param array $data
     * @return array
     */
    protected function handleAction(string $playerId, string $action, array $data): array
    {
        switch ($action) {
            case 'bet':
                return $this->handleBet($playerId, $data);

            case 'cashout':
                return $this->handleCashout($playerId);

            default:
                throw new \InvalidArgumentException("Invalid action: {$action}");
        }
    }

    /**
     * Handle a bet action
     *
     * @param string $playerId
     * @param array $data
     * @return array
     */
    protected function handleBet(string $playerId, array $data): array
    {
        if ($this->state['phase'] !== 'betting') {
            throw new \RuntimeException('Betting phase is over');
        }

        if (isset($this->state['bets'][$playerId])) {
            throw new \RuntimeException('Player has already placed a bet');
        }

        $amount = $data['amount'] ?? 0;
        $autoCashout = $data['autoCashout'] ?? null;

        // Validate bet amount
        if ($amount < $this->settings['minBet'] || $amount > $this->settings['maxBet']) {
            throw new \RuntimeException('Invalid bet amount');
        }

        // Validate auto-cashout
        if ($autoCashout !== null && ($autoCashout < 1.0 || $autoCashout > $this->settings['maxMultiplier'])) {
            throw new \RuntimeException('Invalid auto-cashout multiplier');
        }

        // Record bet
        $this->state['bets'][$playerId] = [
            'amount' => $amount,
            'autoCashout' => $autoCashout,
            'timestamp' => time()
        ];

        return [
            'success' => true,
            'bet' => $amount,
            'autoCashout' => $autoCashout
        ];
    }

    /**
     * Handle a cashout action
     *
     * @param string $playerId
     * @return array
     */
    protected function handleCashout(string $playerId): array
    {
        if ($this->state['phase'] !== 'flying') {
            throw new \RuntimeException('Game is not in flying phase');
        }

        if (!isset($this->state['bets'][$playerId])) {
            throw new \RuntimeException('Player has not placed a bet');
        }

        if (isset($this->state['cashouts'][$playerId])) {
            throw new \RuntimeException('Player has already cashed out');
        }

        $bet = $this->state['bets'][$playerId]['amount'];
        $multiplier = $this->state['multiplier'];
        $winnings = $bet * $multiplier;

        // Record cashout
        $this->state['cashouts'][$playerId] = [
            'multiplier' => $multiplier,
            'winnings' => $winnings,
            'timestamp' => time()
        ];

        return [
            'success' => true,
            'multiplier' => $multiplier,
            'winnings' => $winnings
        ];
    }

    /**
     * Update game state
     *
     * @param float $deltaTime
     * @return void
     */
    public function update(float $deltaTime): void
    {
        if ($this->state['phase'] !== 'flying') {
            return;
        }

        $now = microtime(true);
        $elapsed = $now - $this->state['lastUpdate'];
        $this->state['lastUpdate'] = $now;
        $this->state['elapsedTime'] += $elapsed;

        // Update multiplier
        $this->state['multiplier'] = $this->calculateMultiplier($this->state['elapsedTime']);

        // Check auto-cashouts
        foreach ($this->state['bets'] as $playerId => $bet) {
            if (!isset($this->state['cashouts'][$playerId]) && 
                isset($bet['autoCashout']) && 
                $this->state['multiplier'] >= $bet['autoCashout']
            ) {
                $this->handleCashout($playerId);
            }
        }

        // Check for crash
        if ($this->state['multiplier'] >= $this->state['crashPoint']) {
            $this->crash();
        }
    }

    /**
     * Calculate current multiplier
     *
     * @param float $elapsed
     * @return float
     */
    protected function calculateMultiplier(float $elapsed): float
    {
        // Exponential growth formula
        $multiplier = 1.0 + (pow(1.06, $elapsed) - 1.0);
        
        // Cap at max multiplier
        return min($multiplier, $this->settings['maxMultiplier']);
    }

    /**
     * Handle game crash
     *
     * @return void
     */
    protected function crash(): void
    {
        $this->state['phase'] = 'crashed';
        $this->state['endTime'] = time();
    }

    /**
     * Check if the game is over
     *
     * @return bool
     */
    public function isGameOver(): bool
    {
        return $this->state['phase'] === 'crashed';
    }

    /**
     * Get the winner(s) of the game
     *
     * @return array
     */
    public function getWinners(): array
    {
        if (!$this->isGameOver()) {
            return [];
        }

        $winners = [];
        foreach ($this->state['cashouts'] as $playerId => $cashout) {
            $winners[$playerId] = [
                'multiplier' => $cashout['multiplier'],
                'winnings' => $cashout['winnings']
            ];
        }

        return $winners;
    }

    /**
     * Get player score (winnings)
     *
     * @param string $playerId
     * @return float
     */
    public function getPlayerScore(string $playerId)
    {
        if (isset($this->state['cashouts'][$playerId])) {
            return $this->state['cashouts'][$playerId]['winnings'];
        }

        return 0;
    }

    /**
     * Get available actions for a player
     *
     * @param string $playerId
     * @return array
     */
    public function getAvailableActions(string $playerId): array
    {
        $actions = [];

        if ($this->state['phase'] === 'betting' && !isset($this->state['bets'][$playerId])) {
            $actions[] = 'bet';
        }

        if ($this->state['phase'] === 'flying' && 
            isset($this->state['bets'][$playerId]) && 
            !isset($this->state['cashouts'][$playerId])
        ) {
            $actions[] = 'cashout';
        }

        return $actions;
    }

    /**
     * Get the public state visible to a player
     *
     * @param string $playerId
     * @return array
     */
    protected function getPublicState(string $playerId): array
    {
        return [
            'phase' => $this->state['phase'],
            'multiplier' => $this->state['multiplier'],
            'bets' => $this->state['bets'],
            'cashouts' => $this->state['cashouts'],
            'elapsedTime' => $this->state['elapsedTime'],
            'settings' => $this->settings
        ];
    }

    /**
     * Validate if an action is allowed
     *
     * @param string $playerId
     * @param string $action
     * @param array $data
     * @return bool
     */
    public function isValidAction(string $playerId, string $action, array $data): bool
    {
        $availableActions = $this->getAvailableActions($playerId);
        return in_array($action, $availableActions);
    }
}
