<?php

namespace App\Game\Aviator\Http\Controllers;

use App\Game\Http\Controllers\GameController;
use App\Core\Http\Request;
use App\Core\Http\JsonResponse;
use App\Game\Aviator\AviatorGame;
use App\Core\Security\Auth\Authentication;
use Psr\Log\LoggerInterface;

class AviatorController extends GameController
{
    /**
     * Create a new aviator controller
     *
     * @param AviatorGame $engine
     * @param Authentication $auth
     * @param LoggerInterface $logger
     */
    public function __construct(
        AviatorGame $engine,
        Authentication $auth,
        LoggerInterface $logger
    ) {
        parent::__construct($engine, $auth, $logger);
    }

    /**
     * Get recent crash history
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getCrashHistory(Request $request): JsonResponse
    {
        try {
            $limit = (int)$request->query('limit', 50);
            
            /** @var AviatorGame $engine */
            $engine = $this->engine;
            $history = $engine->getCrashHistory($limit);

            return new JsonResponse([
                'success' => true,
                'history' => array_map(function($game) {
                    return [
                        'id' => $game['id'],
                        'crashPoint' => $game['crashPoint'],
                        'timestamp' => $game['timestamp'],
                        'totalBets' => $game['totalBets'],
                        'totalPlayers' => $game['totalPlayers'],
                        'totalPayout' => $game['totalPayout']
                    ];
                }, $history)
            ]);
        } catch (\Exception $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Get player betting history
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getPlayerHistory(Request $request): JsonResponse
    {
        try {
            $user = $this->auth->getUser();
            $limit = (int)$request->query('limit', 20);
            $offset = (int)$request->query('offset', 0);
            
            /** @var AviatorGame $engine */
            $engine = $this->engine;
            $history = $engine->getPlayerHistory($user->getId(), $limit, $offset);

            return new JsonResponse([
                'success' => true,
                'history' => array_map(function($bet) {
                    return [
                        'gameId' => $bet['gameId'],
                        'amount' => $bet['amount'],
                        'multiplier' => $bet['multiplier'],
                        'autoCashout' => $bet['autoCashout'],
                        'cashoutMultiplier' => $bet['cashoutMultiplier'],
                        'winnings' => $bet['winnings'],
                        'timestamp' => $bet['timestamp']
                    ];
                }, $history)
            ]);
        } catch (\Exception $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Get current game statistics
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getCurrentGameStats(Request $request): JsonResponse
    {
        try {
            $gameId = $request->route('gameId');
            
            /** @var AviatorGame $engine */
            $engine = $this->engine;
            $engine->loadState($gameId);

            $stats = [
                'totalBets' => $engine->getTotalBets(),
                'totalPlayers' => $engine->getTotalPlayers(),
                'highestBet' => $engine->getHighestBet(),
                'highestMultiplier' => $engine->getHighestMultiplier(),
                'totalPotential' => $engine->getTotalPotential()
            ];

            return new JsonResponse([
                'success' => true,
                'stats' => $stats
            ]);
        } catch (\Exception $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Get player performance statistics
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getPlayerStats(Request $request): JsonResponse
    {
        try {
            $user = $this->auth->getUser();
            
            /** @var AviatorGame $engine */
            $engine = $this->engine;
            $stats = $engine->getPlayerStats($user->getId());

            return new JsonResponse([
                'success' => true,
                'stats' => [
                    'totalGames' => $stats['totalGames'],
                    'totalBets' => $stats['totalBets'],
                    'totalWinnings' => $stats['totalWinnings'],
                    'highestWin' => $stats['highestWin'],
                    'averageMultiplier' => $stats['averageMultiplier'],
                    'winRate' => $stats['winRate'],
                    'profitLoss' => $stats['profitLoss'],
                    'bestStreak' => $stats['bestStreak'],
                    'currentStreak' => $stats['currentStreak']
                ]
            ]);
        } catch (\Exception $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Get game predictions and trends
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getTrends(Request $request): JsonResponse
    {
        try {
            /** @var AviatorGame $engine */
            $engine = $this->engine;
            $trends = $engine->analyzeTrends();

            return new JsonResponse([
                'success' => true,
                'trends' => [
                    'averageCrashPoint' => $trends['averageCrashPoint'],
                    'commonMultipliers' => $trends['commonMultipliers'],
                    'peakTimes' => $trends['peakTimes'],
                    'patterns' => $trends['patterns'],
                    'recommendations' => $trends['recommendations']
                ]
            ]);
        } catch (\Exception $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Get real-time game events
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getEvents(Request $request): JsonResponse
    {
        try {
            $gameId = $request->route('gameId');
            
            /** @var AviatorGame $engine */
            $engine = $this->engine;
            $engine->loadState($gameId);

            $events = $engine->getRecentEvents();

            return new JsonResponse([
                'success' => true,
                'events' => array_map(function($event) {
                    return [
                        'type' => $event['type'],
                        'playerId' => $event['playerId'],
                        'data' => $event['data'],
                        'timestamp' => $event['timestamp']
                    ];
                }, $events)
            ]);
        } catch (\Exception $e) {
            return $this->handleGameException($e);
        }
    }
}
