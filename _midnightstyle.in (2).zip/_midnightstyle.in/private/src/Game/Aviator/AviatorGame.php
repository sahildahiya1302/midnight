<?php

namespace App\Game\Aviator;

use App\Game\Engine;
use App\Game\Validators\GameValidator;
use App\Core\Database\DatabaseManager;
use App\Core\Security\Auth\User;
use Psr\Log\LoggerInterface;

class AviatorGame extends Engine
{
    /**
     * Current multiplier
     *
     * @var float
     */
    protected $multiplier = 1.0;

    /**
     * Game crash point
     *
     * @var float
     */
    protected $crashPoint;

    /**
     * Player bets
     *
     * @var array
     */
    protected $bets = [];

    /**
     * Player cashouts
     *
     * @var array
     */
    protected $cashouts = [];

    /**
     * Get default game settings
     *
     * @return array
     */
    protected function getDefaultSettings(): array
    {
        return [
            'minPlayers' => 1,
            'maxPlayers' => 100,
            'minBet' => 1.00,
            'maxBet' => 1000.00,
            'maxMultiplier' => 100.0,
            'houseEdge' => 0.01,
            'roundTime' => 5,
            'waitTime' => 3
        ];
    }

    /**
     * Initialize a new game
     *
     * @param string $gameId
     * @param User $creator
     * @return void
     */
    public function initialize(string $gameId, User $creator): void
    {
        parent::initialize($gameId, $creator);
        
        // Generate crash point using provably fair algorithm
        $this->crashPoint = $this->generateCrashPoint();
        
        $this->logger->info("Game {$gameId} initialized with crash point {$this->crashPoint}");
    }

    /**
     * Generate a provably fair crash point
     *
     * @return float
     */
    protected function generateCrashPoint(): float
    {
        // Use cryptographically secure random number
        $hash = hash('sha256', random_bytes(32));
        $seed = hexdec(substr($hash, 0, 8)) / 0xffffffff;

        // Apply house edge and generate crash point
        $houseEdge = $this->settings['houseEdge'];
        return 99 / (1 - $seed) * (1 - $houseEdge);
    }

    /**
     * Process a player bet
     *
     * @param string $playerId
     * @param float $amount
     * @param float $autoCashout
     * @return array
     */
    public function placeBet(string $playerId, float $amount, ?float $autoCashout = null): array
    {
        if ($this->status !== 'waiting') {
            throw new \RuntimeException('Cannot place bet after game has started');
        }

        if (isset($this->bets[$playerId])) {
            throw new \RuntimeException('Player has already placed a bet');
        }

        // Validate bet amount
        if ($amount < $this->settings['minBet'] || $amount > $this->settings['maxBet']) {
            throw new \RuntimeException('Invalid bet amount');
        }

        // Store bet
        $this->bets[$playerId] = [
            'amount' => $amount,
            'autoCashout' => $autoCashout,
            'timestamp' => time()
        ];

        $this->logger->info("Player {$playerId} placed bet of {$amount} in game {$this->gameId}");

        return [
            'success' => true,
            'bet' => $amount,
            'autoCashout' => $autoCashout
        ];
    }

    /**
     * Process a player cashout
     *
     * @param string $playerId
     * @return array
     */
    public function cashout(string $playerId): array
    {
        if ($this->status !== 'playing') {
            throw new \RuntimeException('Game is not in progress');
        }

        if (!isset($this->bets[$playerId])) {
            throw new \RuntimeException('Player has not placed a bet');
        }

        if (isset($this->cashouts[$playerId])) {
            throw new \RuntimeException('Player has already cashed out');
        }

        if ($this->multiplier >= $this->crashPoint) {
            throw new \RuntimeException('Game has already crashed');
        }

        // Calculate winnings
        $bet = $this->bets[$playerId]['amount'];
        $winnings = $bet * $this->multiplier;

        // Record cashout
        $this->cashouts[$playerId] = [
            'multiplier' => $this->multiplier,
            'winnings' => $winnings,
            'timestamp' => time()
        ];

        $this->logger->info("Player {$playerId} cashed out at {$this->multiplier}x in game {$this->gameId}");

        return [
            'success' => true,
            'multiplier' => $this->multiplier,
            'winnings' => $winnings
        ];
    }

    /**
     * Update game state
     *
     * @param float $elapsed
     * @return void
     */
    public function update(float $elapsed): void
    {
        if ($this->status !== 'playing') {
            return;
        }

        // Update multiplier
        $this->multiplier = $this->calculateMultiplier($elapsed);

        // Check for auto-cashouts
        foreach ($this->bets as $playerId => $bet) {
            if (!isset($this->cashouts[$playerId]) && 
                isset($bet['autoCashout']) && 
                $this->multiplier >= $bet['autoCashout']
            ) {
                $this->cashout($playerId);
            }
        }

        // Check for crash
        if ($this->multiplier >= $this->crashPoint) {
            $this->crash();
        }
    }

    /**
     * Calculate current multiplier based on elapsed time
     *
     * @param float $elapsed
     * @return float
     */
    protected function calculateMultiplier(float $elapsed): float
    {
        // Exponential growth formula
        $multiplier = 1.0 + (pow(1.06, $elapsed) - 1.0);
        
        // Cap at max multiplier
        return min($multiplier, $this->settings['maxMultiplier']);
    }

    /**
     * Handle game crash
     *
     * @return void
     */
    protected function crash(): void
    {
        $this->status = 'crashed';
        $this->endTime = time();

        $this->logger->info("Game {$this->gameId} crashed at {$this->crashPoint}x");
        
        $this->processRewards();
    }

    /**
     * Process end-game rewards
     *
     * @return void
     */
    protected function processRewards(): void
    {
        foreach ($this->bets as $playerId => $bet) {
            if (isset($this->cashouts[$playerId])) {
                // Player cashed out - credit winnings
                $winnings = $this->cashouts[$playerId]['winnings'];
                $this->creditPlayerWinnings($playerId, $winnings);
            }
            // Players who didn't cash out lose their bets
        }
    }

    /**
     * Credit winnings to player wallet
     *
     * @param string $playerId
     * @param float $amount
     * @return void
     */
    protected function creditPlayerWinnings(string $playerId, float $amount): void
    {
        // Implementation would interact with wallet system
        $this->logger->info("Crediting {$amount} to player {$playerId}");
    }

    /**
     * Get game state for client
     *
     * @return array
     */
    public function getClientState(): array
    {
        return [
            'id' => $this->gameId,
            'status' => $this->status,
            'multiplier' => $this->multiplier,
            'bets' => $this->bets,
            'cashouts' => $this->cashouts,
            'elapsed' => $this->startTime ? time() - $this->startTime : 0,
            'settings' => [
                'minBet' => $this->settings['minBet'],
                'maxBet' => $this->settings['maxBet'],
                'maxMultiplier' => $this->settings['maxMultiplier']
            ]
        ];
    }
}
