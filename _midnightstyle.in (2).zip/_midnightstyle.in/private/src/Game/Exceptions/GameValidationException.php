<?php

namespace App\Game\Exceptions;

class GameValidationException extends GameException
{
    /**
     * Validation errors
     *
     * @var array
     */
    protected $errors = [];

    /**
     * Create a new validation exception
     *
     * @param string $message
     * @param array $errors
     * @param array $context
     * @param int $code
     * @param \Throwable|null $previous
     */
    public function __construct(
        string $message = "Validation failed",
        array $errors = [],
        array $context = [],
        int $code = 422,
        \Throwable $previous = null
    ) {
        parent::__construct($message, $context, $code, $previous);
        $this->errors = $errors;
    }

    /**
     * Get validation errors
     *
     * @return array
     */
    public function getErrors(): array
    {
        return $this->errors;
    }

    /**
     * Convert the exception to an array
     *
     * @return array
     */
    public function toArray(): array
    {
        return array_merge(parent::toArray(), [
            'errors' => $this->getErrors()
        ]);
    }
}
