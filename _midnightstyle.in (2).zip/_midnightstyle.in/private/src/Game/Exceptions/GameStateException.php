<?php

namespace App\Game\Exceptions;

class GameStateException extends GameException
{
    /**
     * Current game state
     *
     * @var string
     */
    protected $state;

    /**
     * Expected game state
     *
     * @var string|array
     */
    protected $expectedState;

    /**
     * Create a new game state exception
     *
     * @param string $message
     * @param string $currentState
     * @param string|array $expectedState
     * @param array $context
     * @param int $code
     * @param \Throwable|null $previous
     */
    public function __construct(
        string $message = "Invalid game state",
        string $currentState = '',
        $expectedState = '',
        array $context = [],
        int $code = 409,
        \Throwable $previous = null
    ) {
        parent::__construct($message, $context, $code, $previous);
        $this->state = $currentState;
        $this->expectedState = $expectedState;
    }

    /**
     * Get the current state
     *
     * @return string
     */
    public function getCurrentState(): string
    {
        return $this->state;
    }

    /**
     * Get the expected state
     *
     * @return string|array
     */
    public function getExpectedState()
    {
        return $this->expectedState;
    }

    /**
     * Create an exception for an invalid state transition
     *
     * @param string $currentState
     * @param string $attemptedState
     * @param array $allowedStates
     * @return static
     */
    public static function invalidTransition(
        string $currentState,
        string $attemptedState,
        array $allowedStates
    ): self {
        $message = sprintf(
            'Cannot transition from "%s" to "%s". Allowed transitions: [%s]',
            $currentState,
            $attemptedState,
            implode(', ', $allowedStates)
        );

        return new static($message, $currentState, $allowedStates, [
            'attempted_state' => $attemptedState
        ]);
    }

    /**
     * Create an exception for an invalid action in current state
     *
     * @param string $action
     * @param string $currentState
     * @param array $allowedStates
     * @return static
     */
    public static function invalidAction(
        string $action,
        string $currentState,
        array $allowedStates
    ): self {
        $message = sprintf(
            'Cannot perform "%s" in state "%s". Action allowed in states: [%s]',
            $action,
            $currentState,
            implode(', ', $allowedStates)
        );

        return new static($message, $currentState, $allowedStates, [
            'action' => $action
        ]);
    }

    /**
     * Create an exception for a missing required state data
     *
     * @param string $field
     * @param string $currentState
     * @return static
     */
    public static function missingData(string $field, string $currentState): self
    {
        $message = sprintf(
            'Missing required state data "%s" in state "%s"',
            $field,
            $currentState
        );

        return new static($message, $currentState, '', [
            'missing_field' => $field
        ]);
    }

    /**
     * Convert the exception to an array
     *
     * @return array
     */
    public function toArray(): array
    {
        return array_merge(parent::toArray(), [
            'current_state' => $this->getCurrentState(),
            'expected_state' => $this->getExpectedState()
        ]);
    }
}
