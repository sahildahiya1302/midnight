<?php

namespace App\Game\Exceptions;

class GameException extends \RuntimeException
{
    /**
     * Additional error context
     *
     * @var array
     */
    protected $context = [];

    /**
     * Create a new game exception
     *
     * @param string $message
     * @param array $context
     * @param int $code
     * @param \Throwable|null $previous
     */
    public function __construct(
        string $message = "",
        array $context = [],
        int $code = 0,
        \Throwable $previous = null
    ) {
        parent::__construct($message, $code, $previous);
        $this->context = $context;
    }

    /**
     * Get the error context
     *
     * @return array
     */
    public function getContext(): array
    {
        return $this->context;
    }

    /**
     * Convert the exception to an array
     *
     * @return array
     */
    public function toArray(): array
    {
        return [
            'error' => true,
            'message' => $this->getMessage(),
            'code' => $this->getCode(),
            'context' => $this->getContext()
        ];
    }
}
