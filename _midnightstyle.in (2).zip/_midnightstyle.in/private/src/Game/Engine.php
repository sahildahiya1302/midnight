<?php

namespace App\Game;

use App\Core\Database\DatabaseManager;
use App\Game\State\GameState;
use App\Game\Validators\GameValidator;
use App\Core\Security\Auth\User;
use Psr\Log\LoggerInterface;

abstract class Engine
{
    protected $db;
    protected $logger;
    protected $state;
    protected $validator;
    protected $gameId;
    protected $players = [];
    protected $currentPlayer;
    protected $status = 'waiting';
    protected $settings;
    protected $lastAction;
    protected $startTime;
    protected $endTime;

    public function __construct(
        DatabaseManager $db,
        LoggerInterface $logger,
        GameValidator $validator,
        array $settings = []
    ) {
        $this->db = $db;
        $this->logger = $logger;
        $this->validator = $validator;
        $this->settings = array_merge($this->getDefaultSettings(), $settings);
        $this->state = new GameState();
    }

    /**
     * Get default game settings
     */
    abstract protected function getDefaultSettings(): array;

    /**
     * Initialize a new game
     */
    public function initialize(string $gameId, User $creator): void
    {
        $this->gameId = $gameId;
        $this->addPlayer($creator);
        $this->state->initialize($this->settings);
        
        $this->logger->info("Game {$gameId} initialized by user {$creator->getId()}");
        
        $this->saveState();
    }

    /**
     * Add a player to the game
     */
    public function addPlayer(User $player): void
    {
        if ($this->status !== 'waiting') {
            throw new \RuntimeException('Cannot join game in progress');
        }

        if (count($this->players) >= $this->settings['maxPlayers']) {
            throw new \RuntimeException('Game is full');
        }

        $this->players[$player->getId()] = [
            'id' => $player->getId(),
            'name' => $player->getName(),
            'ready' => false,
            'connected' => true,
            'joinedAt' => time()
        ];

        $this->logger->info("Player {$player->getId()} joined game {$this->gameId}");
    }

    /**
     * Set player ready status
     */
    public function setPlayerReady(string $playerId, bool $ready = true): void
    {
        if (!isset($this->players[$playerId])) {
            throw new \RuntimeException('Player not in game');
        }

        $this->players[$playerId]['ready'] = $ready;

        // Check if all players are ready to start
        if ($this->areAllPlayersReady()) {
            $this->startGame();
        }
    }

    /**
     * Check if all players are ready
     */
    protected function areAllPlayersReady(): bool
    {
        if (count($this->players) < $this->settings['minPlayers']) {
            return false;
        }

        foreach ($this->players as $player) {
            if (!$player['ready']) {
                return false;
            }
        }

        return true;
    }

    /**
     * Start the game
     */
    protected function startGame(): void
    {
        $this->status = 'playing';
        $this->startTime = time();
        $this->currentPlayer = array_key_first($this->players);
        
        $this->state->start($this->players);
        
        $this->logger->info("Game {$this->gameId} started");
        
        $this->saveState();
    }

    /**
     * Process a game action
     */
    public function processAction(string $playerId, string $action, array $data = []): array
    {
        if ($this->status !== 'playing') {
            throw new \RuntimeException('Game not in progress');
        }

        if (!isset($this->players[$playerId])) {
            throw new \RuntimeException('Player not in game');
        }

        if ($playerId !== $this->currentPlayer) {
            throw new \RuntimeException('Not your turn');
        }

        // Validate the action
        $this->validator->validateAction($action, $data, $this->state);

        // Process the action
        $result = $this->state->processAction($playerId, $action, $data);

        // Update game state
        $this->lastAction = [
            'player' => $playerId,
            'action' => $action,
            'data' => $data,
            'timestamp' => time()
        ];

        // Check for game end
        if ($this->state->isGameOver()) {
            $this->endGame();
        } else {
            $this->nextTurn();
        }

        $this->saveState();

        return $result;
    }

    /**
     * Move to next player's turn
     */
    protected function nextTurn(): void
    {
        $players = array_keys($this->players);
        $currentIndex = array_search($this->currentPlayer, $players);
        $nextIndex = ($currentIndex + 1) % count($players);
        $this->currentPlayer = $players[$nextIndex];
    }

    /**
     * End the game
     */
    protected function endGame(): void
    {
        $this->status = 'completed';
        $this->endTime = time();
        
        $winner = $this->state->getWinner();
        if ($winner) {
            $this->logger->info("Game {$this->gameId} won by player {$winner}");
        }
        
        $this->saveState();
        $this->processRewards();
    }

    /**
     * Process end-game rewards
     */
    protected function processRewards(): void
    {
        // Implementation depends on game type
    }

    /**
     * Handle player disconnect
     */
    public function handleDisconnect(string $playerId): void
    {
        if (!isset($this->players[$playerId])) {
            return;
        }

        $this->players[$playerId]['connected'] = false;
        
        // Check if game should be ended
        if ($this->status === 'playing' && !$this->hasEnoughActivePlayers()) {
            $this->forfeitGame($playerId);
        }
    }

    /**
     * Check if enough active players remain
     */
    protected function hasEnoughActivePlayers(): bool
    {
        $activePlayers = 0;
        foreach ($this->players as $player) {
            if ($player['connected']) {
                $activePlayers++;
            }
        }
        return $activePlayers >= $this->settings['minPlayers'];
    }

    /**
     * Forfeit game due to player disconnect
     */
    protected function forfeitGame(string $disconnectedPlayer): void
    {
        $this->status = 'forfeited';
        $this->endTime = time();
        
        $this->logger->info("Game {$this->gameId} forfeited by player {$disconnectedPlayer}");
        
        $this->saveState();
    }

    /**
     * Save game state to database
     */
    protected function saveState(): void
    {
        $state = [
            'id' => $this->gameId,
            'status' => $this->status,
            'players' => $this->players,
            'currentPlayer' => $this->currentPlayer,
            'state' => $this->state->serialize(),
            'settings' => $this->settings,
            'lastAction' => $this->lastAction,
            'startTime' => $this->startTime,
            'endTime' => $this->endTime
        ];

        $this->db->table('games')->updateOrInsert(
            ['id' => $this->gameId],
            $state
        );
    }

    /**
     * Load game state from database
     */
    public function loadState(string $gameId): void
    {
        $state = $this->db->table('games')
            ->where('id', $gameId)
            ->first();

        if (!$state) {
            throw new \RuntimeException('Game not found');
        }

        $this->gameId = $state->id;
        $this->status = $state->status;
        $this->players = json_decode($state->players, true);
        $this->currentPlayer = $state->current_player;
        $this->settings = json_decode($state->settings, true);
        $this->lastAction = json_decode($state->last_action, true);
        $this->startTime = $state->start_time;
        $this->endTime = $state->end_time;

        $this->state->unserialize(json_decode($state->state, true));
    }

    // Getters
    public function getId(): string { return $this->gameId; }
    public function getStatus(): string { return $this->status; }
    public function getPlayers(): array { return $this->players; }
    public function getCurrentPlayer(): ?string { return $this->currentPlayer; }
    public function getState(): GameState { return $this->state; }
    public function getSettings(): array { return $this->settings; }
    public function getLastAction(): ?array { return $this->lastAction; }
}
