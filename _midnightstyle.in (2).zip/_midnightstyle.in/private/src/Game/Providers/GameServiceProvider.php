<?php

namespace App\Game\Providers;

use App\Core\ServiceProvider;
use App\Game\Engine;
use App\Game\State\GameState;
use App\Game\Validators\GameValidator;
use App\Game\Aviator\AviatorGame;
use App\Game\Aviator\State\AviatorGameState;
use App\Game\Aviator\Validators\AviatorValidator;
use App\Game\Http\Controllers\GameController;
use App\Game\Aviator\Http\Controllers\AviatorController;
use App\Core\Database\DatabaseManager;
use App\Core\Security\Auth\Authentication;
use Psr\Log\LoggerInterface;

class GameServiceProvider extends ServiceProvider
{
    /**
     * Register game services
     *
     * @return void
     */
    public function register(): void
    {
        // Register base game components
        $this->registerBaseComponents();

        // Register game types
        $this->registerGameTypes();

        // Register controllers
        $this->registerControllers();

        // Register routes
        $this->registerRoutes();

        // Register event listeners
        $this->registerEventListeners();
    }

    /**
     * Register base game components
     *
     * @return void
     */
    protected function registerBaseComponents(): void
    {
        // Register game configuration
        $this->app->singleton('config.games', function ($app) {
            return require __DIR__ . '/../Config/games.php';
        });

        // Register game factory
        $this->app->singleton('game.factory', function ($app) {
            return new class($app) {
                protected $app;
                protected $games = [];

                public function __construct($app)
                {
                    $this->app = $app;
                }

                public function create(string $type, string $gameId): Engine
                {
                    if (!isset($this->games[$type])) {
                        throw new \InvalidArgumentException("Unknown game type: {$type}");
                    }

                    $class = $this->games[$type];
                    return $this->app->make($class);
                }

                public function register(string $type, string $class): void
                {
                    $this->games[$type] = $class;
                }
            };
        });

        // Register game manager
        $this->app->singleton('game.manager', function ($app) {
            return new class($app) {
                protected $app;
                protected $activeGames = [];

                public function __construct($app)
                {
                    $this->app = $app;
                }

                public function get(string $gameId): ?Engine
                {
                    return $this->activeGames[$gameId] ?? null;
                }

                public function create(string $type, string $gameId): Engine
                {
                    $game = $this->app->make('game.factory')->create($type, $gameId);
                    $this->activeGames[$gameId] = $game;
                    return $game;
                }

                public function remove(string $gameId): void
                {
                    unset($this->activeGames[$gameId]);
                }
            };
        });
    }

    /**
     * Register game types
     *
     * @return void
     */
    protected function registerGameTypes(): void
    {
        // Register Aviator game components
        $this->app->bind(AviatorGame::class, function ($app) {
            return new AviatorGame(
                $app->make(DatabaseManager::class),
                $app->make(LoggerInterface::class),
                $app->make(AviatorValidator::class),
                $app->make('config.games')['aviator']
            );
        });

        $this->app->bind(AviatorGameState::class, function ($app) {
            return new AviatorGameState();
        });

        $this->app->bind(AviatorValidator::class, function ($app) {
            return new AviatorValidator();
        });

        // Register game type with factory
        $this->app->make('game.factory')->register('aviator', AviatorGame::class);
    }

    /**
     * Register game controllers
     *
     * @return void
     */
    protected function registerControllers(): void
    {
        $this->app->bind(GameController::class, function ($app) {
            return new GameController(
                $app->make('game.manager'),
                $app->make(Authentication::class),
                $app->make(LoggerInterface::class)
            );
        });

        $this->app->bind(AviatorController::class, function ($app) {
            return new AviatorController(
                $app->make(AviatorGame::class),
                $app->make(Authentication::class),
                $app->make(LoggerInterface::class)
            );
        });
    }

    /**
     * Register game routes
     *
     * @return void
     */
    protected function registerRoutes(): void
    {
        $routes = require __DIR__ . '/../Http/routes.php';
        $this->app->make('router')->addRoutes($routes);
    }

    /**
     * Register event listeners
     *
     * @return void
     */
    protected function registerEventListeners(): void
    {
        $events = $this->app->make('config.games')['events'];

        foreach ($events as $event => $listeners) {
            foreach ($listeners as $listener) {
                $this->app->make('events')->listen($event, $listener);
            }
        }
    }

    /**
     * Boot game services
     *
     * @return void
     */
    public function boot(): void
    {
        // Register middleware
        $middleware = $this->app->make('config.games')['middleware'];
        
        foreach ($middleware['web'] as $class) {
            $this->app->make('router')->middleware($class);
        }

        foreach ($middleware['websocket'] as $class) {
            $this->app->make('websocket')->middleware($class);
        }
    }
}
