<?php

namespace App\Game\Providers;

use App\Core\ServiceProvider;
use App\Game\WebSocket\Server;
use App\Game\WebSocket\GameServer;
use App\Game\WebSocket\ConnectionManager;
use App\Game\WebSocket\Handlers\AuthenticationHandler;
use App\Game\WebSocket\Handlers\GameActionHandler;
use App\Game\WebSocket\Handlers\ChatHandler;
use App\Game\WebSocket\Middleware\AuthenticateConnection;
use App\Game\WebSocket\Middleware\RateLimitConnection;
use App\Game\WebSocket\Middleware\ValidateGameAccess;
use App\Core\Security\Auth\Authentication;
use App\Core\Session\SessionManager;
use Psr\Log\LoggerInterface;
use Ratchet\Http\HttpServer;
use Ratchet\WebSocket\WsServer;
use React\EventLoop\Factory as LoopFactory;
use React\Socket\Server as SocketServer;

class WebSocketServiceProvider extends ServiceProvider
{
    /**
     * Register WebSocket services
     *
     * @return void
     */
    public function register(): void
    {
        // Register connection manager
        $this->app->singleton(ConnectionManager::class, function ($app) {
            return new ConnectionManager(
                $app->make(Authentication::class),
                $app->make(LoggerInterface::class)
            );
        });

        // Register message handlers
        $this->registerMessageHandlers();

        // Register WebSocket server
        $this->app->singleton(Server::class, function ($app) {
            return new Server(
                $app->make(SessionManager::class),
                $app->make(Authentication::class),
                $app->make(LoggerInterface::class)
            );
        });

        // Register game server
        $this->app->singleton(GameServer::class, function ($app) {
            return new GameServer(
                $app->make(ConnectionManager::class),
                $app->make('game.manager'),
                $app->make(LoggerInterface::class)
            );
        });

        // Register WebSocket middleware
        $this->registerMiddleware();
    }

    /**
     * Register WebSocket message handlers
     *
     * @return void
     */
    protected function registerMessageHandlers(): void
    {
        $this->app->bind(AuthenticationHandler::class, function ($app) {
            return new AuthenticationHandler(
                $app->make(Authentication::class),
                $app->make(LoggerInterface::class)
            );
        });

        $this->app->bind(GameActionHandler::class, function ($app) {
            return new GameActionHandler(
                $app->make('game.manager'),
                $app->make(LoggerInterface::class)
            );
        });

        $this->app->bind(ChatHandler::class, function ($app) {
            return new ChatHandler(
                $app->make(ConnectionManager::class),
                $app->make(LoggerInterface::class)
            );
        });
    }

    /**
     * Register WebSocket middleware
     *
     * @return void
     */
    protected function registerMiddleware(): void
    {
        $this->app->bind(AuthenticateConnection::class, function ($app) {
            return new AuthenticateConnection(
                $app->make(Authentication::class)
            );
        });

        $this->app->bind(RateLimitConnection::class, function ($app) {
            return new RateLimitConnection(
                $app->make('config.games')['global']['rate_limits']
            );
        });

        $this->app->bind(ValidateGameAccess::class, function ($app) {
            return new ValidateGameAccess(
                $app->make('game.manager')
            );
        });
    }

    /**
     * Boot WebSocket services
     *
     * @return void
     */
    public function boot(): void
    {
        // Create event loop
        $loop = LoopFactory::create();
        $this->app->instance('loop', $loop);

        // Create WebSocket server
        $wsServer = new WsServer($this->app->make(Server::class));
        
        // Apply middleware
        $wsServer->enableKeepAlive($loop);
        
        // Create HTTP server
        $server = new HttpServer($wsServer);

        // Create socket server
        $socket = new SocketServer(
            $this->app->make('config.websocket')['port'],
            $loop
        );

        // Attach server to socket
        $socket->on('connection', [$server, 'handle']);

        // Register periodic tasks
        $this->registerPeriodicTasks($loop);

        // Store server instances
        $this->app->instance('websocket.server', $server);
        $this->app->instance('websocket.socket', $socket);
    }

    /**
     * Register periodic tasks
     *
     * @param \React\EventLoop\LoopInterface $loop
     * @return void
     */
    protected function registerPeriodicTasks($loop): void
    {
        $config = $this->app->make('config.games')['aviator']['websocket'];

        // Update game state
        $loop->addPeriodicTimer(1 / $config['update_rate'], function () {
            $this->app->make(GameServer::class)->updateGames();
        });

        // Clean up inactive connections
        $loop->addPeriodicTimer($config['timeout'], function () {
            $this->app->make(ConnectionManager::class)->cleanupInactive();
        });

        // Send ping to keep connections alive
        $loop->addPeriodicTimer($config['ping_interval'], function () {
            $this->app->make(Server::class)->ping();
        });
    }
}
