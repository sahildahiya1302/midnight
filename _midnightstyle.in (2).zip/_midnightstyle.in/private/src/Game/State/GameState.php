<?php

namespace App\Game\State;

use JsonSerializable;

abstract class GameState implements JsonSerializable
{
    /**
     * The current state data
     *
     * @var array
     */
    protected $state = [];

    /**
     * Game settings
     *
     * @var array
     */
    protected $settings = [];

    /**
     * Player data
     *
     * @var array
     */
    protected $players = [];

    /**
     * Game history
     *
     * @var array
     */
    protected $history = [];

    /**
     * Initialize game state with settings
     *
     * @param array $settings
     * @return void
     */
    public function initialize(array $settings): void
    {
        $this->settings = $settings;
        $this->state = $this->getInitialState();
        $this->history = [];
    }

    /**
     * Get the initial state for the game
     *
     * @return array
     */
    abstract protected function getInitialState(): array;

    /**
     * Start the game with the given players
     *
     * @param array $players
     * @return void
     */
    public function start(array $players): void
    {
        $this->players = $players;
        $this->onGameStart();
        $this->addToHistory('game_start', null, [
            'players' => $players
        ]);
    }

    /**
     * Handle game start logic
     *
     * @return void
     */
    abstract protected function onGameStart(): void;

    /**
     * Process a game action
     *
     * @param string $playerId
     * @param string $action
     * @param array $data
     * @return array
     */
    public function processAction(string $playerId, string $action, array $data): array
    {
        $result = $this->handleAction($playerId, $action, $data);
        
        $this->addToHistory($action, $playerId, $data);
        
        return $result;
    }

    /**
     * Handle a specific game action
     *
     * @param string $playerId
     * @param string $action
     * @param array $data
     * @return array
     */
    abstract protected function handleAction(string $playerId, string $action, array $data): array;

    /**
     * Add an action to the game history
     *
     * @param string $action
     * @param string|null $playerId
     * @param array $data
     * @return void
     */
    protected function addToHistory(string $action, ?string $playerId, array $data): void
    {
        $this->history[] = [
            'action' => $action,
            'player' => $playerId,
            'data' => $data,
            'timestamp' => time(),
            'state' => $this->getStateSnapshot()
        ];
    }

    /**
     * Get a snapshot of the current state
     *
     * @return array
     */
    protected function getStateSnapshot(): array
    {
        return [
            'state' => $this->state,
            'players' => $this->players
        ];
    }

    /**
     * Check if the game is over
     *
     * @return bool
     */
    abstract public function isGameOver(): bool;

    /**
     * Get the winner of the game
     *
     * @return string|null Player ID of winner, or null if no winner
     */
    abstract public function getWinner(): ?string;

    /**
     * Get the current score for a player
     *
     * @param string $playerId
     * @return int|float
     */
    abstract public function getPlayerScore(string $playerId);

    /**
     * Get available actions for a player
     *
     * @param string $playerId
     * @return array
     */
    abstract public function getAvailableActions(string $playerId): array;

    /**
     * Get the current state
     *
     * @return array
     */
    public function getState(): array
    {
        return $this->state;
    }

    /**
     * Get player data
     *
     * @return array
     */
    public function getPlayers(): array
    {
        return $this->players;
    }

    /**
     * Get game history
     *
     * @return array
     */
    public function getHistory(): array
    {
        return $this->history;
    }

    /**
     * Get game settings
     *
     * @return array
     */
    public function getSettings(): array
    {
        return $this->settings;
    }

    /**
     * Serialize the state for storage
     *
     * @return array
     */
    public function jsonSerialize(): array
    {
        return [
            'state' => $this->state,
            'settings' => $this->settings,
            'players' => $this->players,
            'history' => $this->history
        ];
    }

    /**
     * Unserialize state from storage
     *
     * @param array $data
     * @return void
     */
    public function unserialize(array $data): void
    {
        $this->state = $data['state'] ?? [];
        $this->settings = $data['settings'] ?? [];
        $this->players = $data['players'] ?? [];
        $this->history = $data['history'] ?? [];
    }

    /**
     * Get a public view of the game state for a specific player
     *
     * @param string $playerId
     * @return array
     */
    public function getPlayerView(string $playerId): array
    {
        return [
            'state' => $this->getPublicState($playerId),
            'players' => $this->getPublicPlayers($playerId),
            'availableActions' => $this->getAvailableActions($playerId),
            'score' => $this->getPlayerScore($playerId),
            'settings' => $this->settings
        ];
    }

    /**
     * Get the public state visible to a player
     *
     * @param string $playerId
     * @return array
     */
    abstract protected function getPublicState(string $playerId): array;

    /**
     * Get the public player data visible to a player
     *
     * @param string $playerId
     * @return array
     */
    protected function getPublicPlayers(string $playerId): array
    {
        $publicPlayers = [];
        foreach ($this->players as $pid => $player) {
            $publicPlayers[$pid] = [
                'id' => $player['id'],
                'name' => $player['name'],
                'score' => $this->getPlayerScore($pid),
                'isCurrentPlayer' => ($pid === $playerId)
            ];
        }
        return $publicPlayers;
    }

    /**
     * Validate if an action is allowed
     *
     * @param string $playerId
     * @param string $action
     * @param array $data
     * @return bool
     */
    abstract public function isValidAction(string $playerId, string $action, array $data): bool;
}
