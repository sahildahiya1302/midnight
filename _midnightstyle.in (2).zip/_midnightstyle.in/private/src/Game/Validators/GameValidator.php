<?php

namespace App\Game\Validators;

use App\Game\State\GameState;
use App\Game\Exceptions\GameValidationException;

abstract class GameValidator
{
    /**
     * List of required fields for each action type
     *
     * @var array
     */
    protected $requiredFields = [];

    /**
     * List of allowed actions
     *
     * @var array
     */
    protected $allowedActions = [];

    /**
     * Custom validation rules for actions
     *
     * @var array
     */
    protected $rules = [];

    /**
     * Validate a game action
     *
     * @param string $action
     * @param array $data
     * @param GameState $state
     * @throws GameValidationException
     * @return bool
     */
    public function validateAction(string $action, array $data, GameState $state): bool
    {
        // Check if action is allowed
        if (!in_array($action, $this->allowedActions)) {
            throw new GameValidationException("Invalid action: {$action}");
        }

        // Check required fields
        if (isset($this->requiredFields[$action])) {
            foreach ($this->requiredFields[$action] as $field) {
                if (!isset($data[$field])) {
                    throw new GameValidationException("Missing required field: {$field}");
                }
            }
        }

        // Run custom validation rules
        if (isset($this->rules[$action])) {
            foreach ($this->rules[$action] as $rule) {
                if (!$this->$rule($data, $state)) {
                    throw new GameValidationException("Validation failed: {$rule}");
                }
            }
        }

        // Run action-specific validation
        $method = 'validate' . ucfirst($action);
        if (method_exists($this, $method)) {
            if (!$this->$method($data, $state)) {
                throw new GameValidationException("Action validation failed: {$action}");
            }
        }

        return true;
    }

    /**
     * Validate data types for fields
     *
     * @param array $data
     * @param array $types
     * @throws GameValidationException
     * @return bool
     */
    protected function validateTypes(array $data, array $types): bool
    {
        foreach ($types as $field => $type) {
            if (!isset($data[$field])) {
                continue;
            }

            switch ($type) {
                case 'int':
                    if (!is_int($data[$field])) {
                        throw new GameValidationException("{$field} must be an integer");
                    }
                    break;

                case 'float':
                    if (!is_float($data[$field]) && !is_int($data[$field])) {
                        throw new GameValidationException("{$field} must be a number");
                    }
                    break;

                case 'string':
                    if (!is_string($data[$field])) {
                        throw new GameValidationException("{$field} must be a string");
                    }
                    break;

                case 'array':
                    if (!is_array($data[$field])) {
                        throw new GameValidationException("{$field} must be an array");
                    }
                    break;

                case 'bool':
                    if (!is_bool($data[$field])) {
                        throw new GameValidationException("{$field} must be a boolean");
                    }
                    break;
            }
        }

        return true;
    }

    /**
     * Validate numeric range
     *
     * @param mixed $value
     * @param float $min
     * @param float $max
     * @param string $field
     * @throws GameValidationException
     * @return bool
     */
    protected function validateRange($value, float $min, float $max, string $field): bool
    {
        if (!is_numeric($value) || $value < $min || $value > $max) {
            throw new GameValidationException("{$field} must be between {$min} and {$max}");
        }

        return true;
    }

    /**
     * Validate array length
     *
     * @param array $array
     * @param int $min
     * @param int $max
     * @param string $field
     * @throws GameValidationException
     * @return bool
     */
    protected function validateArrayLength(array $array, int $min, int $max, string $field): bool
    {
        $length = count($array);
        if ($length < $min || $length > $max) {
            throw new GameValidationException("{$field} must have between {$min} and {$max} items");
        }

        return true;
    }

    /**
     * Validate enum value
     *
     * @param mixed $value
     * @param array $allowed
     * @param string $field
     * @throws GameValidationException
     * @return bool
     */
    protected function validateEnum($value, array $allowed, string $field): bool
    {
        if (!in_array($value, $allowed)) {
            $allowedStr = implode(', ', $allowed);
            throw new GameValidationException("{$field} must be one of: {$allowedStr}");
        }

        return true;
    }

    /**
     * Validate coordinates
     *
     * @param array $coords
     * @param int $maxX
     * @param int $maxY
     * @param string $field
     * @throws GameValidationException
     * @return bool
     */
    protected function validateCoordinates(array $coords, int $maxX, int $maxY, string $field): bool
    {
        if (!isset($coords['x']) || !isset($coords['y'])) {
            throw new GameValidationException("{$field} must have x and y coordinates");
        }

        $this->validateRange($coords['x'], 0, $maxX, "{$field}.x");
        $this->validateRange($coords['y'], 0, $maxY, "{$field}.y");

        return true;
    }

    /**
     * Validate that a move is valid for the current game state
     *
     * @param array $data
     * @param GameState $state
     * @throws GameValidationException
     * @return bool
     */
    abstract protected function validateMove(array $data, GameState $state): bool;

    /**
     * Get validation error messages
     *
     * @return array
     */
    public function getMessages(): array
    {
        return [
            'required' => 'The :field field is required.',
            'integer' => 'The :field must be an integer.',
            'numeric' => 'The :field must be a number.',
            'string' => 'The :field must be a string.',
            'array' => 'The :field must be an array.',
            'boolean' => 'The :field must be a boolean.',
            'range' => 'The :field must be between :min and :max.',
            'length' => 'The :field must have between :min and :max items.',
            'enum' => 'The :field must be one of: :allowed.',
            'coordinates' => 'The :field must have valid x and y coordinates.',
        ];
    }
}
