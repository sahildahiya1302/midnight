<?php

namespace App\Game\Http\Controllers;

use App\Core\Controller\Controller;
use App\Core\Http\Request;
use App\Core\Http\JsonResponse;
use App\Game\Engine;
use App\Game\Exceptions\GameException;
use App\Core\Security\Auth\Authentication;
use Psr\Log\LoggerInterface;

class GameController extends Controller
{
    /**
     * Game engine instance
     *
     * @var Engine
     */
    protected $engine;

    /**
     * Authentication service
     *
     * @var Authentication
     */
    protected $auth;

    /**
     * Logger instance
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * Create a new game controller
     *
     * @param Engine $engine
     * @param Authentication $auth
     * @param LoggerInterface $logger
     */
    public function __construct(
        Engine $engine,
        Authentication $auth,
        LoggerInterface $logger
    ) {
        $this->engine = $engine;
        $this->auth = $auth;
        $this->logger = $logger;
    }

    /**
     * Get current game state
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getState(Request $request): JsonResponse
    {
        try {
            $gameId = $request->route('gameId');
            $this->engine->loadState($gameId);

            return new JsonResponse([
                'success' => true,
                'state' => $this->engine->getClientState()
            ]);
        } catch (GameException $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Place a bet
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function placeBet(Request $request): JsonResponse
    {
        try {
            $user = $this->auth->getUser();
            $gameId = $request->route('gameId');
            
            $this->engine->loadState($gameId);

            $amount = (float)$request->input('amount');
            $autoCashout = $request->input('autoCashout') ? (float)$request->input('autoCashout') : null;

            $result = $this->engine->placeBet($user->getId(), $amount, $autoCashout);

            $this->logger->info('Bet placed', [
                'user_id' => $user->getId(),
                'game_id' => $gameId,
                'amount' => $amount,
                'auto_cashout' => $autoCashout
            ]);

            return new JsonResponse([
                'success' => true,
                'bet' => $result
            ]);
        } catch (GameException $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Cash out from current game
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function cashout(Request $request): JsonResponse
    {
        try {
            $user = $this->auth->getUser();
            $gameId = $request->route('gameId');
            
            $this->engine->loadState($gameId);

            $result = $this->engine->cashout($user->getId());

            $this->logger->info('Cashout successful', [
                'user_id' => $user->getId(),
                'game_id' => $gameId,
                'multiplier' => $result['multiplier'],
                'winnings' => $result['winnings']
            ]);

            return new JsonResponse([
                'success' => true,
                'cashout' => $result
            ]);
        } catch (GameException $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Get game history
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getHistory(Request $request): JsonResponse
    {
        try {
            $limit = (int)$request->query('limit', 10);
            $offset = (int)$request->query('offset', 0);

            $history = $this->engine->getHistory($limit, $offset);

            return new JsonResponse([
                'success' => true,
                'history' => $history
            ]);
        } catch (GameException $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Get user game statistics
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getStats(Request $request): JsonResponse
    {
        try {
            $user = $this->auth->getUser();
            
            $stats = $this->engine->getUserStats($user->getId());

            return new JsonResponse([
                'success' => true,
                'stats' => $stats
            ]);
        } catch (GameException $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Get game leaderboard
     *
     * @param Request $request
     * @return JsonResponse
     */
    public function getLeaderboard(Request $request): JsonResponse
    {
        try {
            $type = $request->query('type', 'daily'); // daily, weekly, monthly, all-time
            $limit = (int)$request->query('limit', 10);

            $leaderboard = $this->engine->getLeaderboard($type, $limit);

            return new JsonResponse([
                'success' => true,
                'leaderboard' => $leaderboard
            ]);
        } catch (GameException $e) {
            return $this->handleGameException($e);
        }
    }

    /**
     * Handle game exceptions
     *
     * @param GameException $e
     * @return JsonResponse
     */
    protected function handleGameException(GameException $e): JsonResponse
    {
        $this->logger->error($e->getMessage(), [
            'exception' => get_class($e),
            'context' => $e->getContext()
        ]);

        return new JsonResponse(
            $e->toArray(),
            $e->getCode() ?: 400
        );
    }
}
