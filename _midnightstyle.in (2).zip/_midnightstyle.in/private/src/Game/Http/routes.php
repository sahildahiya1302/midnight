<?php

use App\Game\Http\Controllers\GameController;
use App\Game\Aviator\Http\Controllers\AviatorController;

/**
 * Game API Routes
 * All routes are prefixed with /api/games
 */

return [
    // Generic game routes
    'GET /api/games/history' => [GameController::class, 'getHistory'],
    'GET /api/games/stats' => [GameController::class, 'getStats'],
    'GET /api/games/leaderboard' => [GameController::class, 'getLeaderboard'],

    // Aviator game routes
    'GET /api/games/aviator/state/{gameId}' => [AviatorController::class, 'getState'],
    'POST /api/games/aviator/{gameId}/bet' => [AviatorController::class, 'placeBet'],
    'POST /api/games/aviator/{gameId}/cashout' => [AviatorController::class, 'cashout'],
    'GET /api/games/aviator/history/crash' => [AviatorController::class, 'getCrashHistory'],
    'GET /api/games/aviator/history/player' => [AviatorController::class, 'getPlayerHistory'],
    'GET /api/games/aviator/{gameId}/stats' => [AviatorController::class, 'getCurrentGameStats'],
    'GET /api/games/aviator/stats/player' => [AviatorController::class, 'getPlayerStats'],
    'GET /api/games/aviator/trends' => [AviatorController::class, 'getTrends'],
    'GET /api/games/aviator/{gameId}/events' => [AviatorController::class, 'getEvents'],

    // WebSocket routes
    'GET /api/games/aviator/{gameId}/ws' => [
        'controller' => AviatorController::class,
        'action' => 'websocket',
        'middleware' => ['auth', 'websocket']
    ],

    // Route groups with middleware
    'middleware' => [
        'auth' => [
            // Routes that require authentication
            'POST /api/games/aviator/{gameId}/bet',
            'POST /api/games/aviator/{gameId}/cashout',
            'GET /api/games/aviator/history/player',
            'GET /api/games/aviator/stats/player',
        ],
        'throttle:60,1' => [
            // Rate limited routes
            'POST /api/games/aviator/{gameId}/bet',
            'POST /api/games/aviator/{gameId}/cashout',
        ],
        'cache' => [
            // Cached routes
            'GET /api/games/aviator/history/crash',
            'GET /api/games/aviator/trends',
            'GET /api/games/leaderboard',
        ]
    ],

    // Route parameters validation
    'parameters' => [
        'gameId' => '[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}',
        'limit' => '[0-9]+',
        'offset' => '[0-9]+',
    ],

    // Route documentation
    'documentation' => [
        'GET /api/games/aviator/state/{gameId}' => [
            'summary' => 'Get current game state',
            'parameters' => [
                'gameId' => 'UUID of the game'
            ],
            'responses' => [
                200 => 'Current game state',
                404 => 'Game not found'
            ]
        ],
        'POST /api/games/aviator/{gameId}/bet' => [
            'summary' => 'Place a bet in the game',
            'parameters' => [
                'gameId' => 'UUID of the game',
                'amount' => 'Bet amount (float)',
                'autoCashout' => 'Auto cashout multiplier (float, optional)'
            ],
            'responses' => [
                200 => 'Bet placed successfully',
                400 => 'Invalid bet parameters',
                403 => 'Insufficient funds',
                409 => 'Game state does not allow betting'
            ]
        ],
        'POST /api/games/aviator/{gameId}/cashout' => [
            'summary' => 'Cash out from current game',
            'parameters' => [
                'gameId' => 'UUID of the game'
            ],
            'responses' => [
                200 => 'Cashout successful',
                400 => 'Invalid cashout request',
                409 => 'Game state does not allow cashout'
            ]
        ],
        'GET /api/games/aviator/history/crash' => [
            'summary' => 'Get crash history',
            'parameters' => [
                'limit' => 'Number of records to return (default: 50)'
            ],
            'responses' => [
                200 => 'Crash history',
            ]
        ],
        'GET /api/games/aviator/history/player' => [
            'summary' => 'Get player betting history',
            'parameters' => [
                'limit' => 'Number of records to return (default: 20)',
                'offset' => 'Number of records to skip (default: 0)'
            ],
            'responses' => [
                200 => 'Player history',
                401 => 'Unauthorized'
            ]
        ],
        'GET /api/games/aviator/{gameId}/stats' => [
            'summary' => 'Get current game statistics',
            'parameters' => [
                'gameId' => 'UUID of the game'
            ],
            'responses' => [
                200 => 'Game statistics',
                404 => 'Game not found'
            ]
        ],
        'GET /api/games/aviator/stats/player' => [
            'summary' => 'Get player performance statistics',
            'responses' => [
                200 => 'Player statistics',
                401 => 'Unauthorized'
            ]
        ],
        'GET /api/games/aviator/trends' => [
            'summary' => 'Get game predictions and trends',
            'responses' => [
                200 => 'Game trends and predictions'
            ]
        ],
        'GET /api/games/aviator/{gameId}/events' => [
            'summary' => 'Get real-time game events',
            'parameters' => [
                'gameId' => 'UUID of the game'
            ],
            'responses' => [
                200 => 'Game events',
                404 => 'Game not found'
            ]
        ]
    ]
];
