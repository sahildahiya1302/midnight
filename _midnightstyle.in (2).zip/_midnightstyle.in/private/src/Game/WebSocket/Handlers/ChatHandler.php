<?php

namespace App\Game\WebSocket\Handlers;

use App\Game\WebSocket\Connection;
use App\Game\WebSocket\ConnectionManager;
use Psr\Log\LoggerInterface;

class ChatHandler extends MessageHandler
{
    /**
     * Connection manager instance
     *
     * @var ConnectionManager
     */
    protected $connections;

    /**
     * Supported message types
     *
     * @var array
     */
    protected $supportedTypes = [
        'chat_message',
        'join_room',
        'leave_room',
        'typing'
    ];

    /**
     * Message rate limits
     *
     * @var array
     */
    protected $rateLimits = [
        'messages_per_minute' => 30,
        'messages_per_hour' => 300
    ];

    /**
     * Message filters
     *
     * @var array
     */
    protected $filters = [
        'max_length' => 500,
        'blocked_words' => [],
        'spam_patterns' => []
    ];

    /**
     * Create a new chat handler
     *
     * @param ConnectionManager $connections
     * @param LoggerInterface $logger
     */
    public function __construct(ConnectionManager $connections, LoggerInterface $logger)
    {
        parent::__construct($logger);
        $this->connections = $connections;
        $this->loadFilters();
    }

    /**
     * Check if handler can process message type
     *
     * @param string $type
     * @return bool
     */
    protected function canHandle(string $type): bool
    {
        return in_array($type, $this->supportedTypes);
    }

    /**
     * Validate message data
     *
     * @param array $message
     * @return void
     * @throws \DomainException
     */
    protected function validateMessageData(array $message): void
    {
        switch ($message['type']) {
            case 'chat_message':
                if (!isset($message['content']) || trim($message['content']) === '') {
                    throw new \DomainException('Message content is required');
                }
                if (!isset($message['room'])) {
                    throw new \DomainException('Chat room is required');
                }
                break;

            case 'join_room':
            case 'leave_room':
                if (!isset($message['room'])) {
                    throw new \DomainException('Room identifier is required');
                }
                break;
        }
    }

    /**
     * Process the message
     *
     * @param Connection $connection
     * @param array $message
     * @return array|null
     */
    protected function processMessage(Connection $connection, array $message): ?array
    {
        if (!$connection->isAuthenticated()) {
            return $this->error('Authentication required', 401);
        }

        try {
            switch ($message['type']) {
                case 'chat_message':
                    return $this->handleChatMessage($connection, $message);

                case 'join_room':
                    return $this->handleJoinRoom($connection, $message['room']);

                case 'leave_room':
                    return $this->handleLeaveRoom($connection, $message['room']);

                case 'typing':
                    return $this->handleTyping($connection, $message['room']);

                default:
                    return null;
            }
        } catch (\Exception $e) {
            return $this->error($e->getMessage());
        }
    }

    /**
     * Handle chat message
     *
     * @param Connection $connection
     * @param array $message
     * @return array
     */
    protected function handleChatMessage(Connection $connection, array $message): array
    {
        // Check rate limits
        if (!$this->checkRateLimit($connection)) {
            return $this->error('Rate limit exceeded', 429);
        }

        // Filter message content
        $content = $this->filterMessage($message['content']);
        if ($content === false) {
            return $this->error('Message contains inappropriate content');
        }

        $user = $connection->getUser();
        $room = $message['room'];

        // Create message data
        $chatMessage = [
            'type' => 'chat_message',
            'room' => $room,
            'user' => [
                'id' => $user->getId(),
                'name' => $user->getName(),
                'avatar' => $user->getAvatar()
            ],
            'content' => $content,
            'timestamp' => time()
        ];

        // Broadcast to room
        $this->broadcastToRoom($room, $chatMessage);

        // Log message
        $this->logger->info('Chat message sent', [
            'user_id' => $user->getId(),
            'room' => $room,
            'content' => $content
        ]);

        return $this->success('message_sent', $chatMessage);
    }

    /**
     * Handle room join
     *
     * @param Connection $connection
     * @param string $room
     * @return array
     */
    protected function handleJoinRoom(Connection $connection, string $room): array
    {
        $user = $connection->getUser();
        
        // Add connection to room
        $connection->joinRoom($room);

        // Broadcast join notification
        $joinMessage = [
            'type' => 'user_joined',
            'room' => $room,
            'user' => [
                'id' => $user->getId(),
                'name' => $user->getName()
            ]
        ];

        $this->broadcastToRoom($room, $joinMessage, [$connection->getId()]);

        return $this->success('joined_room', [
            'room' => $room,
            'users' => $this->getRoomUsers($room)
        ]);
    }

    /**
     * Handle room leave
     *
     * @param Connection $connection
     * @param string $room
     * @return array
     */
    protected function handleLeaveRoom(Connection $connection, string $room): array
    {
        $user = $connection->getUser();
        
        // Remove connection from room
        $connection->leaveRoom($room);

        // Broadcast leave notification
        $leaveMessage = [
            'type' => 'user_left',
            'room' => $room,
            'user' => [
                'id' => $user->getId(),
                'name' => $user->getName()
            ]
        ];

        $this->broadcastToRoom($room, $leaveMessage);

        return $this->success('left_room', ['room' => $room]);
    }

    /**
     * Handle typing indicator
     *
     * @param Connection $connection
     * @param string $room
     * @return array
     */
    protected function handleTyping(Connection $connection, string $room): array
    {
        $user = $connection->getUser();

        // Broadcast typing indicator
        $typingMessage = [
            'type' => 'user_typing',
            'room' => $room,
            'user' => [
                'id' => $user->getId(),
                'name' => $user->getName()
            ]
        ];

        $this->broadcastToRoom($room, $typingMessage, [$connection->getId()]);

        return $this->success('typing_broadcast');
    }

    /**
     * Check message rate limits
     *
     * @param Connection $connection
     * @return bool
     */
    protected function checkRateLimit(Connection $connection): bool
    {
        // Implementation would check against rate limit storage
        return true;
    }

    /**
     * Filter message content
     *
     * @param string $content
     * @return string|false Filtered content or false if blocked
     */
    protected function filterMessage(string $content)
    {
        $content = trim($content);

        // Check length
        if (strlen($content) > $this->filters['max_length']) {
            return false;
        }

        // Filter blocked words
        foreach ($this->filters['blocked_words'] as $word) {
            if (stripos($content, $word) !== false) {
                return false;
            }
        }

        // Check spam patterns
        foreach ($this->filters['spam_patterns'] as $pattern) {
            if (preg_match($pattern, $content)) {
                return false;
            }
        }

        return $content;
    }

    /**
     * Load chat filters
     *
     * @return void
     */
    protected function loadFilters(): void
    {
        // Implementation would load filters from configuration
    }

    /**
     * Get users in a room
     *
     * @param string $room
     * @return array
     */
    protected function getRoomUsers(string $room): array
    {
        return $this->connections->getRoomUsers($room);
    }

    /**
     * Broadcast message to room
     *
     * @param string $room
     * @param array $message
     * @param array $exclude
     * @return void
     */
    protected function broadcastToRoom(string $room, array $message, array $exclude = []): void
    {
        $connections = $this->connections->getRoomConnections($room);
        $this->broadcast($connections, $message, $exclude);
    }
}
