<?php

namespace App\Game\WebSocket\Handlers;

use App\Game\WebSocket\Connection;
use App\Game\Engine;
use App\Game\Exceptions\GameException;
use Psr\Log\LoggerInterface;

class GameActionHandler extends MessageHandler
{
    /**
     * Game manager instance
     *
     * @var mixed
     */
    protected $gameManager;

    /**
     * Supported message types
     *
     * @var array
     */
    protected $supportedTypes = [
        'join_game',
        'leave_game',
        'place_bet',
        'cashout',
        'ready',
        'game_action'
    ];

    /**
     * Required fields for each action type
     *
     * @var array
     */
    protected $requiredFields = [
        'join_game' => ['game_id'],
        'leave_game' => ['game_id'],
        'place_bet' => ['game_id', 'amount'],
        'cashout' => ['game_id'],
        'ready' => ['game_id'],
        'game_action' => ['game_id', 'action', 'data']
    ];

    /**
     * Create a new game action handler
     *
     * @param mixed $gameManager
     * @param LoggerInterface $logger
     */
    public function __construct($gameManager, LoggerInterface $logger)
    {
        parent::__construct($logger);
        $this->gameManager = $gameManager;
    }

    /**
     * Check if handler can process message type
     *
     * @param string $type
     * @return bool
     */
    protected function canHandle(string $type): bool
    {
        return in_array($type, $this->supportedTypes);
    }

    /**
     * Validate message data
     *
     * @param array $message
     * @return void
     * @throws \DomainException
     */
    protected function validateMessageData(array $message): void
    {
        $type = $message['type'];

        // Check required fields
        if (isset($this->requiredFields[$type])) {
            foreach ($this->requiredFields[$type] as $field) {
                if (!isset($message[$field])) {
                    throw new \DomainException("Missing required field: {$field}");
                }
            }
        }

        // Validate specific fields
        switch ($type) {
            case 'place_bet':
                if (!is_numeric($message['amount']) || $message['amount'] <= 0) {
                    throw new \DomainException('Invalid bet amount');
                }
                break;

            case 'game_action':
                if (!is_array($message['data'])) {
                    throw new \DomainException('Action data must be an array');
                }
                break;
        }
    }

    /**
     * Process the message
     *
     * @param Connection $connection
     * @param array $message
     * @return array|null
     */
    protected function processMessage(Connection $connection, array $message): ?array
    {
        if (!$connection->isAuthenticated()) {
            return $this->error('Authentication required', 401);
        }

        try {
            $game = $this->getGame($message['game_id']);

            switch ($message['type']) {
                case 'join_game':
                    return $this->handleJoinGame($connection, $game);

                case 'leave_game':
                    return $this->handleLeaveGame($connection, $game);

                case 'place_bet':
                    return $this->handlePlaceBet($connection, $game, $message);

                case 'cashout':
                    return $this->handleCashout($connection, $game);

                case 'ready':
                    return $this->handleReady($connection, $game);

                case 'game_action':
                    return $this->handleGameAction($connection, $game, $message);

                default:
                    return null;
            }
        } catch (GameException $e) {
            return $this->error($e->getMessage(), $e->getCode());
        } catch (\Exception $e) {
            $this->logger->error('Game action error: ' . $e->getMessage(), [
                'connection_id' => $connection->getId(),
                'user_id' => $connection->getUserId(),
                'message' => $message
            ]);
            return $this->error('Internal game error', 500);
        }
    }

    /**
     * Get game instance
     *
     * @param string $gameId
     * @return Engine
     * @throws GameException
     */
    protected function getGame(string $gameId): Engine
    {
        $game = $this->gameManager->get($gameId);
        if (!$game) {
            throw new GameException('Game not found', [], 404);
        }
        return $game;
    }

    /**
     * Handle join game request
     *
     * @param Connection $connection
     * @param Engine $game
     * @return array
     */
    protected function handleJoinGame(Connection $connection, Engine $game): array
    {
        $userId = $connection->getUserId();
        
        // Add player to game
        $game->addPlayer($userId);
        
        // Associate game with connection
        $connection->setGameId($game->getId());

        // Broadcast join event to other players
        $this->broadcastGameEvent($game, 'player_joined', [
            'player_id' => $userId,
            'player_name' => $connection->getUser()->getName()
        ], [$connection->getId()]);

        return $this->success('joined_game', [
            'game_id' => $game->getId(),
            'state' => $game->getClientState()
        ]);
    }

    /**
     * Handle leave game request
     *
     * @param Connection $connection
     * @param Engine $game
     * @return array
     */
    protected function handleLeaveGame(Connection $connection, Engine $game): array
    {
        $userId = $connection->getUserId();
        
        // Remove player from game
        $game->removePlayer($userId);
        
        // Clear game association
        $connection->setGameId(null);

        // Broadcast leave event
        $this->broadcastGameEvent($game, 'player_left', [
            'player_id' => $userId
        ]);

        return $this->success('left_game');
    }

    /**
     * Handle place bet request
     *
     * @param Connection $connection
     * @param Engine $game
     * @param array $message
     * @return array
     */
    protected function handlePlaceBet(Connection $connection, Engine $game, array $message): array
    {
        $userId = $connection->getUserId();
        $amount = (float)$message['amount'];
        $autoCashout = $message['auto_cashout'] ?? null;

        $result = $game->placeBet($userId, $amount, $autoCashout);

        // Broadcast bet event
        $this->broadcastGameEvent($game, 'bet_placed', [
            'player_id' => $userId,
            'amount' => $amount,
            'auto_cashout' => $autoCashout
        ]);

        return $this->success('bet_placed', $result);
    }

    /**
     * Handle cashout request
     *
     * @param Connection $connection
     * @param Engine $game
     * @return array
     */
    protected function handleCashout(Connection $connection, Engine $game): array
    {
        $userId = $connection->getUserId();
        
        $result = $game->cashout($userId);

        // Broadcast cashout event
        $this->broadcastGameEvent($game, 'player_cashout', [
            'player_id' => $userId,
            'multiplier' => $result['multiplier'],
            'winnings' => $result['winnings']
        ]);

        return $this->success('cashout_success', $result);
    }

    /**
     * Handle ready status request
     *
     * @param Connection $connection
     * @param Engine $game
     * @return array
     */
    protected function handleReady(Connection $connection, Engine $game): array
    {
        $userId = $connection->getUserId();
        
        $game->setPlayerReady($userId);

        // Broadcast ready event
        $this->broadcastGameEvent($game, 'player_ready', [
            'player_id' => $userId
        ]);

        return $this->success('ready_confirmed');
    }

    /**
     * Handle game action request
     *
     * @param Connection $connection
     * @param Engine $game
     * @param array $message
     * @return array
     */
    protected function handleGameAction(Connection $connection, Engine $game, array $message): array
    {
        $userId = $connection->getUserId();
        
        $result = $game->processAction($userId, $message['action'], $message['data']);

        // Broadcast action event
        $this->broadcastGameEvent($game, 'game_action', [
            'player_id' => $userId,
            'action' => $message['action'],
            'data' => $message['data'],
            'result' => $result
        ]);

        return $this->success('action_processed', $result);
    }

    /**
     * Broadcast event to all players in a game
     *
     * @param Engine $game
     * @param string $type
     * @param array $data
     * @param array $exclude Connection IDs to exclude
     * @return void
     */
    protected function broadcastGameEvent(Engine $game, string $type, array $data, array $exclude = []): void
    {
        $message = $this->success($type, $data);
        $this->broadcast($game->getConnections(), $message, $exclude);
    }
}
