<?php

namespace App\Game\WebSocket\Handlers;

use App\Game\WebSocket\Connection;
use App\Core\Security\Auth\Authentication;
use Psr\Log\LoggerInterface;

class AuthenticationHandler extends MessageHandler
{
    /**
     * Authentication service
     *
     * @var Authentication
     */
    protected $auth;

    /**
     * Supported message types
     *
     * @var array
     */
    protected $supportedTypes = [
        'auth',
        'refresh_token'
    ];

    /**
     * Create a new authentication handler
     *
     * @param Authentication $auth
     * @param LoggerInterface $logger
     */
    public function __construct(Authentication $auth, LoggerInterface $logger)
    {
        parent::__construct($logger);
        $this->auth = $auth;
    }

    /**
     * Check if handler can process message type
     *
     * @param string $type
     * @return bool
     */
    protected function canHandle(string $type): bool
    {
        return in_array($type, $this->supportedTypes);
    }

    /**
     * Validate message data
     *
     * @param array $message
     * @return void
     * @throws \DomainException
     */
    protected function validateMessageData(array $message): void
    {
        switch ($message['type']) {
            case 'auth':
                if (!isset($message['token'])) {
                    throw new \DomainException('Authentication token is required');
                }
                break;

            case 'refresh_token':
                if (!isset($message['refresh_token'])) {
                    throw new \DomainException('Refresh token is required');
                }
                break;
        }
    }

    /**
     * Process the message
     *
     * @param Connection $connection
     * @param array $message
     * @return array|null
     */
    protected function processMessage(Connection $connection, array $message): ?array
    {
        switch ($message['type']) {
            case 'auth':
                return $this->handleAuthentication($connection, $message['token']);

            case 'refresh_token':
                return $this->handleTokenRefresh($connection, $message['refresh_token']);

            default:
                return null;
        }
    }

    /**
     * Handle authentication request
     *
     * @param Connection $connection
     * @param string $token
     * @return array
     */
    protected function handleAuthentication(Connection $connection, string $token): array
    {
        try {
            // Validate token
            $user = $this->auth->validateToken($token);
            if (!$user) {
                return $this->error('Invalid authentication token', 401);
            }

            // Associate user with connection
            $connection->setUser($user);
            $connection->setAuthenticated(true);

            // Log successful authentication
            $this->logger->info('WebSocket authentication successful', [
                'connection_id' => $connection->getId(),
                'user_id' => $user->getId()
            ]);

            // Return success response with user data
            return $this->success('auth_success', [
                'user' => [
                    'id' => $user->getId(),
                    'name' => $user->getName(),
                    'avatar' => $user->getAvatar()
                ],
                'permissions' => $user->getPermissions()
            ]);

        } catch (\Exception $e) {
            $this->logger->error('Authentication error: ' . $e->getMessage(), [
                'connection_id' => $connection->getId(),
                'token' => $token
            ]);

            return $this->error('Authentication failed', 401);
        }
    }

    /**
     * Handle token refresh request
     *
     * @param Connection $connection
     * @param string $refreshToken
     * @return array
     */
    protected function handleTokenRefresh(Connection $connection, string $refreshToken): array
    {
        try {
            // Validate refresh token and generate new tokens
            $tokens = $this->auth->refreshToken($refreshToken);
            if (!$tokens) {
                return $this->error('Invalid refresh token', 401);
            }

            // Log token refresh
            $this->logger->info('Token refresh successful', [
                'connection_id' => $connection->getId(),
                'user_id' => $connection->getUserId()
            ]);

            // Return new tokens
            return $this->success('token_refreshed', [
                'access_token' => $tokens['access_token'],
                'refresh_token' => $tokens['refresh_token'],
                'expires_in' => $tokens['expires_in']
            ]);

        } catch (\Exception $e) {
            $this->logger->error('Token refresh error: ' . $e->getMessage(), [
                'connection_id' => $connection->getId(),
                'refresh_token' => $refreshToken
            ]);

            return $this->error('Token refresh failed', 401);
        }
    }

    /**
     * Handle connection close
     *
     * @param Connection $connection
     * @return void
     */
    public function handleClose(Connection $connection): void
    {
        if ($connection->isAuthenticated()) {
            $this->logger->info('Authenticated connection closed', [
                'connection_id' => $connection->getId(),
                'user_id' => $connection->getUserId()
            ]);
        }
    }

    /**
     * Handle authentication timeout
     *
     * @param Connection $connection
     * @return array
     */
    public function handleTimeout(Connection $connection): array
    {
        $this->logger->warning('Authentication timeout', [
            'connection_id' => $connection->getId()
        ]);

        return $this->error('Authentication timeout', 401);
    }
}
