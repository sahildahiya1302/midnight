<?php

namespace App\Game\WebSocket\Handlers;

use App\Game\WebSocket\Connection;
use Psr\Log\LoggerInterface;

abstract class MessageHandler
{
    /**
     * Logger instance
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * Create a new message handler
     *
     * @param LoggerInterface $logger
     */
    public function __construct(LoggerInterface $logger)
    {
        $this->logger = $logger;
    }

    /**
     * Handle a message
     *
     * @param Connection $connection
     * @param array $message
     * @return array|null Response message or null if no response needed
     * @throws \Exception
     */
    public function handle(Connection $connection, array $message): ?array
    {
        try {
            $this->validateMessage($message);
            return $this->processMessage($connection, $message);
        } catch (\Exception $e) {
            $this->logger->error('Message handling error: ' . $e->getMessage(), [
                'connection_id' => $connection->getId(),
                'message' => $message,
                'error' => $e
            ]);

            return [
                'type' => 'error',
                'code' => $e instanceof \DomainException ? 400 : 500,
                'message' => $e->getMessage()
            ];
        }
    }

    /**
     * Validate message structure
     *
     * @param array $message
     * @return void
     * @throws \DomainException
     */
    protected function validateMessage(array $message): void
    {
        if (!isset($message['type'])) {
            throw new \DomainException('Message type is required');
        }

        if (!$this->canHandle($message['type'])) {
            throw new \DomainException("Cannot handle message type: {$message['type']}");
        }

        $this->validateMessageData($message);
    }

    /**
     * Check if handler can process message type
     *
     * @param string $type
     * @return bool
     */
    abstract protected function canHandle(string $type): bool;

    /**
     * Validate message data
     *
     * @param array $message
     * @return void
     * @throws \DomainException
     */
    abstract protected function validateMessageData(array $message): void;

    /**
     * Process the message
     *
     * @param Connection $connection
     * @param array $message
     * @return array|null Response message or null if no response needed
     */
    abstract protected function processMessage(Connection $connection, array $message): ?array;

    /**
     * Broadcast message to multiple connections
     *
     * @param array $connections
     * @param array $message
     * @param array $exclude Connection IDs to exclude
     * @return void
     */
    protected function broadcast(array $connections, array $message, array $exclude = []): void
    {
        foreach ($connections as $connection) {
            if (!in_array($connection->getId(), $exclude)) {
                $connection->send($message);
            }
        }
    }

    /**
     * Log message processing
     *
     * @param Connection $connection
     * @param array $message
     * @param string $level
     * @return void
     */
    protected function logMessage(Connection $connection, array $message, string $level = 'info'): void
    {
        $this->logger->$level('WebSocket message', [
            'connection_id' => $connection->getId(),
            'user_id' => $connection->getUserId(),
            'message' => $message
        ]);
    }

    /**
     * Format success response
     *
     * @param string $type
     * @param array $data
     * @return array
     */
    protected function success(string $type, array $data = []): array
    {
        return array_merge([
            'type' => $type,
            'success' => true
        ], $data);
    }

    /**
     * Format error response
     *
     * @param string $message
     * @param int $code
     * @param array $data
     * @return array
     */
    protected function error(string $message, int $code = 400, array $data = []): array
    {
        return array_merge([
            'type' => 'error',
            'success' => false,
            'message' => $message,
            'code' => $code
        ], $data);
    }
}
