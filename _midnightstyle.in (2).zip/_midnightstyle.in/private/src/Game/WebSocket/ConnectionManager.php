<?php

namespace App\Game\WebSocket;

use App\Core\Security\Auth\Authentication;
use Psr\Log\LoggerInterface;
use Ratchet\ConnectionInterface;
use SplObjectStorage;

class ConnectionManager
{
    /**
     * Active connections
     *
     * @var SplObjectStorage
     */
    protected $connections;

    /**
     * Room connections
     *
     * @var array
     */
    protected $rooms = [];

    /**
     * User connections
     *
     * @var array
     */
    protected $userConnections = [];

    /**
     * Authentication service
     *
     * @var Authentication
     */
    protected $auth;

    /**
     * Logger instance
     *
     * @var LoggerInterface
     */
    protected $logger;

    /**
     * Create a new connection manager
     *
     * @param Authentication $auth
     * @param LoggerInterface $logger
     */
    public function __construct(Authentication $auth, LoggerInterface $logger)
    {
        $this->connections = new SplObjectStorage;
        $this->auth = $auth;
        $this->logger = $logger;
    }

    /**
     * Add a new connection
     *
     * @param ConnectionInterface $conn
     * @return Connection
     */
    public function addConnection(ConnectionInterface $conn): Connection
    {
        $connection = new Connection($conn);
        $this->connections->attach($connection);

        $this->logger->info('New connection established', [
            'connection_id' => $connection->getId()
        ]);

        return $connection;
    }

    /**
     * Remove a connection
     *
     * @param Connection $connection
     * @return void
     */
    public function removeConnection(Connection $connection): void
    {
        // Remove from rooms
        foreach ($connection->getRooms() as $room) {
            $this->leaveRoom($connection, $room);
        }

        // Remove from user connections
        if ($connection->isAuthenticated()) {
            $userId = $connection->getUserId();
            unset($this->userConnections[$userId][$connection->getId()]);
            if (empty($this->userConnections[$userId])) {
                unset($this->userConnections[$userId]);
            }
        }

        // Remove from connections storage
        $this->connections->detach($connection);

        $this->logger->info('Connection closed', [
            'connection_id' => $connection->getId(),
            'user_id' => $connection->getUserId()
        ]);
    }

    /**
     * Get connection by ID
     *
     * @param string $id
     * @return Connection|null
     */
    public function getConnection(string $id): ?Connection
    {
        foreach ($this->connections as $connection) {
            if ($connection->getId() === $id) {
                return $connection;
            }
        }
        return null;
    }

    /**
     * Get all connections
     *
     * @return SplObjectStorage
     */
    public function getConnections(): SplObjectStorage
    {
        return $this->connections;
    }

    /**
     * Join a room
     *
     * @param Connection $connection
     * @param string $room
     * @return void
     */
    public function joinRoom(Connection $connection, string $room): void
    {
        $connection->joinRoom($room);
        $this->rooms[$room][$connection->getId()] = $connection;

        $this->logger->info('Connection joined room', [
            'connection_id' => $connection->getId(),
            'user_id' => $connection->getUserId(),
            'room' => $room
        ]);
    }

    /**
     * Leave a room
     *
     * @param Connection $connection
     * @param string $room
     * @return void
     */
    public function leaveRoom(Connection $connection, string $room): void
    {
        $connection->leaveRoom($room);
        unset($this->rooms[$room][$connection->getId()]);

        if (empty($this->rooms[$room])) {
            unset($this->rooms[$room]);
        }

        $this->logger->info('Connection left room', [
            'connection_id' => $connection->getId(),
            'user_id' => $connection->getUserId(),
            'room' => $room
        ]);
    }

    /**
     * Get connections in a room
     *
     * @param string $room
     * @return array
     */
    public function getRoomConnections(string $room): array
    {
        return $this->rooms[$room] ?? [];
    }

    /**
     * Get users in a room
     *
     * @param string $room
     * @return array
     */
    public function getRoomUsers(string $room): array
    {
        $users = [];
        foreach ($this->getRoomConnections($room) as $connection) {
            if ($connection->isAuthenticated()) {
                $user = $connection->getUser();
                $users[$user->getId()] = [
                    'id' => $user->getId(),
                    'name' => $user->getName(),
                    'avatar' => $user->getAvatar()
                ];
            }
        }
        return array_values($users);
    }

    /**
     * Associate user with connection
     *
     * @param Connection $connection
     * @param string $userId
     * @return void
     */
    public function associateUser(Connection $connection, string $userId): void
    {
        $this->userConnections[$userId][$connection->getId()] = $connection;

        $this->logger->info('User associated with connection', [
            'connection_id' => $connection->getId(),
            'user_id' => $userId
        ]);
    }

    /**
     * Get user connections
     *
     * @param string $userId
     * @return array
     */
    public function getUserConnections(string $userId): array
    {
        return $this->userConnections[$userId] ?? [];
    }

    /**
     * Broadcast message to all connections
     *
     * @param array $message
     * @param array $exclude Connection IDs to exclude
     * @return void
     */
    public function broadcast(array $message, array $exclude = []): void
    {
        foreach ($this->connections as $connection) {
            if (!in_array($connection->getId(), $exclude)) {
                $connection->send($message);
            }
        }
    }

    /**
     * Broadcast message to a room
     *
     * @param string $room
     * @param array $message
     * @param array $exclude Connection IDs to exclude
     * @return void
     */
    public function broadcastToRoom(string $room, array $message, array $exclude = []): void
    {
        foreach ($this->getRoomConnections($room) as $connection) {
            if (!in_array($connection->getId(), $exclude)) {
                $connection->send($message);
            }
        }
    }

    /**
     * Broadcast message to a user's connections
     *
     * @param string $userId
     * @param array $message
     * @param array $exclude Connection IDs to exclude
     * @return void
     */
    public function broadcastToUser(string $userId, array $message, array $exclude = []): void
    {
        foreach ($this->getUserConnections($userId) as $connection) {
            if (!in_array($connection->getId(), $exclude)) {
                $connection->send($message);
            }
        }
    }

    /**
     * Clean up inactive connections
     *
     * @param int $timeout Timeout in seconds
     * @return void
     */
    public function cleanupInactive(int $timeout = 60): void
    {
        $now = time();
        foreach ($this->connections as $connection) {
            if ($now - $connection->getLastActivityTime() > $timeout) {
                $this->logger->info('Removing inactive connection', [
                    'connection_id' => $connection->getId(),
                    'user_id' => $connection->getUserId(),
                    'last_activity' => $connection->getLastActivityTime()
                ]);
                $connection->close();
                $this->removeConnection($connection);
            }
        }
    }
}
