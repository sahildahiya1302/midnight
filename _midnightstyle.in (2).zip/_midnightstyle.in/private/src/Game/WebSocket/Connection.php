<?php

namespace App\Game\WebSocket;

use App\Core\Security\Auth\User;
use Ratchet\ConnectionInterface;
use JsonException;

class Connection
{
    /**
     * Unique connection ID
     *
     * @var string
     */
    protected $id;

    /**
     * WebSocket connection interface
     *
     * @var ConnectionInterface
     */
    protected $connection;

    /**
     * Associated user
     *
     * @var User|null
     */
    protected $user = null;

    /**
     * Authentication status
     *
     * @var bool
     */
    protected $authenticated = false;

    /**
     * Current game ID
     *
     * @var string|null
     */
    protected $gameId = null;

    /**
     * Joined rooms
     *
     * @var array
     */
    protected $rooms = [];

    /**
     * Last activity timestamp
     *
     * @var int
     */
    protected $lastActivity;

    /**
     * Connection attributes
     *
     * @var array
     */
    protected $attributes = [];

    /**
     * Create a new connection
     *
     * @param ConnectionInterface $connection
     */
    public function __construct(ConnectionInterface $connection)
    {
        $this->id = uniqid('conn_', true);
        $this->connection = $connection;
        $this->lastActivity = time();
    }

    /**
     * Get connection ID
     *
     * @return string
     */
    public function getId(): string
    {
        return $this->id;
    }

    /**
     * Get underlying connection
     *
     * @return ConnectionInterface
     */
    public function getConnection(): ConnectionInterface
    {
        return $this->connection;
    }

    /**
     * Set associated user
     *
     * @param User $user
     * @return void
     */
    public function setUser(User $user): void
    {
        $this->user = $user;
    }

    /**
     * Get associated user
     *
     * @return User|null
     */
    public function getUser(): ?User
    {
        return $this->user;
    }

    /**
     * Get user ID
     *
     * @return string|null
     */
    public function getUserId(): ?string
    {
        return $this->user ? $this->user->getId() : null;
    }

    /**
     * Set authentication status
     *
     * @param bool $status
     * @return void
     */
    public function setAuthenticated(bool $status): void
    {
        $this->authenticated = $status;
    }

    /**
     * Check if connection is authenticated
     *
     * @return bool
     */
    public function isAuthenticated(): bool
    {
        return $this->authenticated;
    }

    /**
     * Set current game ID
     *
     * @param string|null $gameId
     * @return void
     */
    public function setGameId(?string $gameId): void
    {
        $this->gameId = $gameId;
    }

    /**
     * Get current game ID
     *
     * @return string|null
     */
    public function getGameId(): ?string
    {
        return $this->gameId;
    }

    /**
     * Join a room
     *
     * @param string $room
     * @return void
     */
    public function joinRoom(string $room): void
    {
        $this->rooms[$room] = true;
    }

    /**
     * Leave a room
     *
     * @param string $room
     * @return void
     */
    public function leaveRoom(string $room): void
    {
        unset($this->rooms[$room]);
    }

    /**
     * Check if in room
     *
     * @param string $room
     * @return bool
     */
    public function isInRoom(string $room): bool
    {
        return isset($this->rooms[$room]);
    }

    /**
     * Get joined rooms
     *
     * @return array
     */
    public function getRooms(): array
    {
        return array_keys($this->rooms);
    }

    /**
     * Update last activity time
     *
     * @return void
     */
    public function updateActivity(): void
    {
        $this->lastActivity = time();
    }

    /**
     * Get last activity time
     *
     * @return int
     */
    public function getLastActivityTime(): int
    {
        return $this->lastActivity;
    }

    /**
     * Set connection attribute
     *
     * @param string $key
     * @param mixed $value
     * @return void
     */
    public function setAttribute(string $key, $value): void
    {
        $this->attributes[$key] = $value;
    }

    /**
     * Get connection attribute
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function getAttribute(string $key, $default = null)
    {
        return $this->attributes[$key] ?? $default;
    }

    /**
     * Remove connection attribute
     *
     * @param string $key
     * @return void
     */
    public function removeAttribute(string $key): void
    {
        unset($this->attributes[$key]);
    }

    /**
     * Send message to connection
     *
     * @param array $message
     * @return void
     * @throws JsonException
     */
    public function send(array $message): void
    {
        $json = json_encode($message, JSON_THROW_ON_ERROR);
        $this->connection->send($json);
        $this->updateActivity();
    }

    /**
     * Close connection
     *
     * @return void
     */
    public function close(): void
    {
        $this->connection->close();
    }

    /**
     * Check if connection is alive
     *
     * @return bool
     */
    public function isAlive(): bool
    {
        return $this->connection->isWritable();
    }

    /**
     * Get connection info for logging
     *
     * @return array
     */
    public function getInfo(): array
    {
        return [
            'id' => $this->id,
            'user_id' => $this->getUserId(),
            'authenticated' => $this->authenticated,
            'game_id' => $this->gameId,
            'rooms' => array_keys($this->rooms),
            'last_activity' => $this->lastActivity
        ];
    }

    /**
     * Convert connection to string
     *
     * @return string
     */
    public function __toString(): string
    {
        return "Connection {$this->id}" . ($this->user ? " (User: {$this->user->getId()})" : '');
    }
}
