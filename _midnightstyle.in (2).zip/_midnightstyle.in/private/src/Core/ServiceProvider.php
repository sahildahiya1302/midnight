<?php

namespace App\Core;

abstract class ServiceProvider
{
    protected Container $container;
    protected bool $isBooted = false;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Register services in the container
     */
    abstract public function register(): void;

    /**
     * Bootstrap any application services
     */
    public function boot(): void
    {
        // Optional boot method for service providers
    }

    /**
     * Boot the service provider if it hasn't been booted
     */
    final public function bootIfNotBooted(): void
    {
        if (!$this->isBooted) {
            $this->boot();
            $this->isBooted = true;
        }
    }

    /**
     * Get the container instance
     */
    public function getContainer(): Container
    {
        return $this->container;
    }

    /**
     * Check if the provider has been booted
     */
    public function isBooted(): bool
    {
        return $this->isBooted;
    }

    /**
     * Register a binding in the container
     */
    protected function bind(string $abstract, mixed $concrete = null, bool $shared = false): void
    {
        $this->container->bind($abstract, $concrete, $shared);
    }

    /**
     * Register a shared binding in the container
     */
    protected function singleton(string $abstract, mixed $concrete = null): void
    {
        $this->container->singleton($abstract, $concrete);
    }

    /**
     * Register an instance in the container
     */
    protected function instance(string $abstract, mixed $instance): void
    {
        $this->container->instance($abstract, $instance);
    }

    /**
     * Register an alias in the container
     */
    protected function alias(string $abstract, string $alias): void
    {
        $this->container->alias($abstract, $alias);
    }

    /**
     * Get a service from the container
     */
    protected function get(string $id)
    {
        return $this->container->get($id);
    }

    /**
     * Check if a service exists in the container
     */
    protected function has(string $id): bool
    {
        return $this->container->has($id);
    }

    /**
     * Call a method on the container
     */
    protected function call(callable|array $callback, array $parameters = []): mixed
    {
        return $this->container->call($callback, $parameters);
    }

    /**
     * Get a configuration value
     */
    protected function config(string $key, mixed $default = null): mixed
    {
        return $this->container->get('config')->get($key, $default);
    }

    /**
     * Get the application environment
     */
    protected function environment(): string
    {
        return $this->container->get('config')->get('app.env', 'production');
    }

    /**
     * Check if the application is in debug mode
     */
    protected function isDebug(): bool
    {
        return $this->container->get('config')->get('app.debug', false);
    }

    /**
     * Get the application base path
     */
    protected function basePath(string $path = ''): string
    {
        return $this->container->get('config')->get('app.base_path') . ($path ? DIRECTORY_SEPARATOR . $path : '');
    }

    /**
     * Get the storage path
     */
    protected function storagePath(string $path = ''): string
    {
        return $this->container->get('config')->get('app.storage_path') . ($path ? DIRECTORY_SEPARATOR . $path : '');
    }

    /**
     * Get the public path
     */
    protected function publicPath(string $path = ''): string
    {
        return $this->container->get('config')->get('app.public_path') . ($path ? DIRECTORY_SEPARATOR . $path : '');
    }

    /**
     * Get the resource path
     */
    protected function resourcePath(string $path = ''): string
    {
        return $this->container->get('config')->get('app.resource_path') . ($path ? DIRECTORY_SEPARATOR . $path : '');
    }

    /**
     * Get the configuration path
     */
    protected function configPath(string $path = ''): string
    {
        return $this->container->get('config')->get('app.config_path') . ($path ? DIRECTORY_SEPARATOR . $path : '');
    }

    /**
     * Get the database path
     */
    protected function databasePath(string $path = ''): string
    {
        return $this->container->get('config')->get('app.database_path') . ($path ? DIRECTORY_SEPARATOR . $path : '');
    }

    /**
     * Get the bootstrap path
     */
    protected function bootstrapPath(string $path = ''): string
    {
        return $this->container->get('config')->get('app.bootstrap_path') . ($path ? DIRECTORY_SEPARATOR . $path : '');
    }
}
