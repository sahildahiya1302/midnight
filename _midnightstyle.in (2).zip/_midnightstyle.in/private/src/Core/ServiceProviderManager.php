<?php

namespace App\Core;

class ServiceProviderManager
{
    private Container $container;
    private array $providers = [];
    private array $deferredProviders = [];
    private array $loadedProviders = [];
    private array $bootedProviders = [];

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Register a service provider
     */
    public function register(string|ServiceProvider $provider): ServiceProvider
    {
        $provider = $this->resolveProvider($provider);
        $providerClass = get_class($provider);

        if (isset($this->loadedProviders[$providerClass])) {
            return $provider;
        }

        if ($provider->isDeferred()) {
            $this->deferredProviders[$providerClass] = $provider;
            
            foreach ($provider->provides() as $service) {
                $this->deferredProviders[$service] = $providerClass;
            }
            
            return $provider;
        }

        $provider->register();
        $this->loadedProviders[$providerClass] = true;
        $this->providers[] = $provider;

        return $provider;
    }

    /**
     * Boot all registered service providers
     */
    public function boot(): void
    {
        foreach ($this->providers as $provider) {
            $this->bootProvider($provider);
        }
    }

    /**
     * Boot a specific service provider
     */
    public function bootProvider(ServiceProvider $provider): void
    {
        $providerClass = get_class($provider);

        if (isset($this->bootedProviders[$providerClass])) {
            return;
        }

        $provider->boot();
        $this->bootedProviders[$providerClass] = true;
    }

    /**
     * Load a deferred provider
     */
    public function loadDeferred(string $service): void
    {
        if (!isset($this->deferredProviders[$service])) {
            return;
        }

        $providerClass = $this->deferredProviders[$service];

        if (!isset($this->loadedProviders[$providerClass])) {
            $this->registerDeferredProvider($providerClass, $service);
        }
    }

    /**
     * Register a deferred provider
     */
    protected function registerDeferredProvider(string $provider, string $service): void
    {
        $provider = $this->resolveProvider($provider);
        $provider->register();

        $this->loadedProviders[get_class($provider)] = true;
        $this->providers[] = $provider;

        $this->bootProvider($provider);

        unset($this->deferredProviders[$service]);
    }

    /**
     * Resolve a provider instance
     */
    protected function resolveProvider(string|ServiceProvider $provider): ServiceProvider
    {
        if ($provider instanceof ServiceProvider) {
            return $provider;
        }

        return new $provider($this->container);
    }

    /**
     * Get all registered providers
     */
    public function getProviders(): array
    {
        return $this->providers;
    }

    /**
     * Get all deferred providers
     */
    public function getDeferredProviders(): array
    {
        return $this->deferredProviders;
    }

    /**
     * Get all loaded providers
     */
    public function getLoadedProviders(): array
    {
        return $this->loadedProviders;
    }

    /**
     * Get all booted providers
     */
    public function getBootedProviders(): array
    {
        return $this->bootedProviders;
    }

    /**
     * Check if a provider is registered
     */
    public function hasProvider(string $provider): bool
    {
        return isset($this->loadedProviders[$provider]);
    }

    /**
     * Check if a provider is deferred
     */
    public function isDeferred(string $provider): bool
    {
        return isset($this->deferredProviders[$provider]);
    }

    /**
     * Check if a provider is booted
     */
    public function isBooted(string $provider): bool
    {
        return isset($this->bootedProviders[$provider]);
    }

    /**
     * Register multiple providers
     */
    public function registerMany(array $providers): void
    {
        foreach ($providers as $provider) {
            $this->register($provider);
        }
    }

    /**
     * Get the container instance
     */
    public function getContainer(): Container
    {
        return $this->container;
    }

    /**
     * Clear all registered providers
     */
    public function clear(): void
    {
        $this->providers = [];
        $this->deferredProviders = [];
        $this->loadedProviders = [];
        $this->bootedProviders = [];
    }

    /**
     * Get a list of all registered service names
     */
    public function getServices(): array
    {
        $services = [];

        foreach ($this->providers as $provider) {
            if (method_exists($provider, 'provides')) {
                $services = array_merge($services, $provider->provides());
            }
        }

        return array_unique($services);
    }

    /**
     * Get the provider that provides a specific service
     */
    public function getProviderForService(string $service): ?string
    {
        return $this->deferredProviders[$service] ?? null;
    }
}
