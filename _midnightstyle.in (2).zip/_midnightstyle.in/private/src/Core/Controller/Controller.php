<?php

namespace App\Core\Controller;

use App\Core\Container;
use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Http\JsonResponse;
use App\Core\Http\RedirectResponse;
use App\Core\Http\ViewResponse;
use App\Core\Security\Auth\AuthenticationInterface;
use App\Core\Security\CSRF\CSRFProtection;
use App\Core\Session\SessionManager;
use App\Core\View\ViewEngine;

abstract class Controller
{
    protected Container $container;
    protected Request $request;
    protected AuthenticationInterface $auth;
    protected SessionManager $session;
    protected CSRFProtection $csrf;
    protected ViewEngine $view;

    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->auth = $container->get(AuthenticationInterface::class);
        $this->session = $container->get(SessionManager::class);
        $this->csrf = $container->get(CSRFProtection::class);
        $this->view = $container->get(ViewEngine::class);
    }

    /**
     * Set the current request
     */
    public function setRequest(Request $request): void
    {
        $this->request = $request;
    }

    /**
     * Create a view response
     */
    protected function view(
        string $view,
        array $data = [],
        int $status = 200,
        array $headers = []
    ): ViewResponse {
        return new ViewResponse($view, $data, $status, $headers, $this->view);
    }

    /**
     * Create a JSON response
     */
    protected function json(
        mixed $data = null,
        int $status = 200,
        array $headers = []
    ): JsonResponse {
        return new JsonResponse($data, $status, $headers);
    }

    /**
     * Create a redirect response
     */
    protected function redirect(
        string $url,
        int $status = 302,
        array $headers = []
    ): RedirectResponse {
        return new RedirectResponse($url, $status, $headers);
    }

    /**
     * Redirect back to the previous page
     */
    protected function back(
        int $status = 302,
        array $headers = []
    ): RedirectResponse {
        return RedirectResponse::back($status, $headers);
    }

    /**
     * Create a success response
     */
    protected function success(
        mixed $data = null,
        string $message = 'Success',
        int $status = 200
    ): JsonResponse {
        return JsonResponse::success($data, $message, $status);
    }

    /**
     * Create an error response
     */
    protected function error(
        string $message = 'Error',
        mixed $errors = null,
        int $status = 400
    ): JsonResponse {
        return JsonResponse::error($message, $errors, $status);
    }

    /**
     * Create a validation error response
     */
    protected function validationError(
        array $errors,
        string $message = 'Validation failed'
    ): JsonResponse {
        return JsonResponse::validationError($errors, $message);
    }

    /**
     * Get the authenticated user
     */
    protected function user()
    {
        return $this->auth->user();
    }

    /**
     * Check if user is authenticated
     */
    protected function isAuthenticated(): bool
    {
        return $this->auth->check();
    }

    /**
     * Get a request input value
     */
    protected function input(string $key, mixed $default = null): mixed
    {
        return $this->request->request($key, $default);
    }

    /**
     * Get all request input values
     */
    protected function all(): array
    {
        return $this->request->getRequestParams();
    }

    /**
     * Get a query parameter
     */
    protected function query(string $key, mixed $default = null): mixed
    {
        return $this->request->query($key, $default);
    }

    /**
     * Get all query parameters
     */
    protected function queryParams(): array
    {
        return $this->request->getQueryParams();
    }

    /**
     * Get a file from the request
     */
    protected function file(string $key): ?array
    {
        return $this->request->file($key);
    }

    /**
     * Get all files from the request
     */
    protected function files(): array
    {
        return $this->request->getFiles();
    }

    /**
     * Get a header value
     */
    protected function header(string $key, mixed $default = null): mixed
    {
        return $this->request->header($key, $default);
    }

    /**
     * Get all headers
     */
    protected function headers(): array
    {
        return $this->request->headers();
    }

    /**
     * Get a session value
     */
    protected function session(string $key, mixed $default = null): mixed
    {
        return $this->session->get($key, $default);
    }

    /**
     * Flash data to the session
     */
    protected function flash(string $key, mixed $value): void
    {
        $this->session->flash($key, $value);
    }

    /**
     * Get the CSRF token
     */
    protected function csrf(): string
    {
        return $this->csrf->getToken();
    }

    /**
     * Get a service from the container
     */
    protected function service(string $id)
    {
        return $this->container->get($id);
    }

    /**
     * Get the container instance
     */
    protected function getContainer(): Container
    {
        return $this->container;
    }

    /**
     * Get the current request
     */
    protected function getRequest(): Request
    {
        return $this->request;
    }

    /**
     * Get the authentication service
     */
    protected function getAuth(): AuthenticationInterface
    {
        return $this->auth;
    }

    /**
     * Get the session manager
     */
    protected function getSession(): SessionManager
    {
        return $this->session;
    }

    /**
     * Get the CSRF protection service
     */
    protected function getCsrf(): CSRFProtection
    {
        return $this->csrf;
    }

    /**
     * Get the view engine
     */
    protected function getView(): ViewEngine
    {
        return $this->view;
    }
}
