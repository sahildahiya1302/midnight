<?php

namespace App\Core\Http;

class RedirectResponse extends Response
{
    protected string $targetUrl;
    protected array $flashData = [];

    public function __construct(
        string $url,
        int $statusCode = 302,
        array $headers = []
    ) {
        $this->targetUrl = $url;

        $headers = array_merge([
            'Location' => $url
        ], $headers);

        parent::__construct('', $statusCode, $headers);
    }

    /**
     * Set the target URL
     */
    public function setTargetUrl(string $url): self
    {
        $this->targetUrl = $url;
        $this->setHeader('Location', $url);
        return $this;
    }

    /**
     * Get the target URL
     */
    public function getTargetUrl(): string
    {
        return $this->targetUrl;
    }

    /**
     * Add flash data to the session
     */
    public function with(string $key, mixed $value): self
    {
        $this->flashData[$key] = $value;
        return $this;
    }

    /**
     * Add multiple flash data to the session
     */
    public function withMany(array $data): self
    {
        $this->flashData = array_merge($this->flashData, $data);
        return $this;
    }

    /**
     * Flash success message
     */
    public function withSuccess(string $message): self
    {
        return $this->with('success', $message);
    }

    /**
     * Flash error message
     */
    public function withError(string $message): self
    {
        return $this->with('error', $message);
    }

    /**
     * Flash warning message
     */
    public function withWarning(string $message): self
    {
        return $this->with('warning', $message);
    }

    /**
     * Flash info message
     */
    public function withInfo(string $message): self
    {
        return $this->with('info', $message);
    }

    /**
     * Flash input data
     */
    public function withInput(array $input = null): self
    {
        $input = $input ?? $_POST;
        return $this->with('_old_input', $input);
    }

    /**
     * Flash validation errors
     */
    public function withErrors(array $errors, string $key = 'default'): self
    {
        return $this->with('errors', [$key => $errors]);
    }

    /**
     * Send the response
     */
    public function send(): void
    {
        $this->flashData();
        parent::send();
    }

    /**
     * Store flash data in session
     */
    protected function flashData(): void
    {
        if (empty($this->flashData)) {
            return;
        }

        if (!isset($_SESSION)) {
            session_start();
        }

        foreach ($this->flashData as $key => $value) {
            $_SESSION['_flash'][$key] = $value;
        }
    }

    /**
     * Create a redirect response to the previous URL
     */
    public static function back(
        int $statusCode = 302,
        array $headers = []
    ): self {
        $previousUrl = $_SERVER['HTTP_REFERER'] ?? '/';
        return new self($previousUrl, $statusCode, $headers);
    }

    /**
     * Create a redirect response to a named route
     */
    public static function route(
        string $name,
        array $parameters = [],
        int $statusCode = 302,
        array $headers = []
    ): self {
        // TODO: Implement route generation
        $url = '/' . $name;
        return new self($url, $statusCode, $headers);
    }

    /**
     * Create a redirect response to the home page
     */
    public static function home(
        int $statusCode = 302,
        array $headers = []
    ): self {
        return new self('/', $statusCode, $headers);
    }

    /**
     * Create a redirect response intended for a specific URL
     */
    public static function intended(
        string $default = '/',
        int $statusCode = 302,
        array $headers = []
    ): self {
        $url = $_SESSION['_intended_url'] ?? $default;
        unset($_SESSION['_intended_url']);
        return new self($url, $statusCode, $headers);
    }

    /**
     * Store the current URL as the intended URL
     */
    public static function setIntendedUrl(string $url): void
    {
        if (!isset($_SESSION)) {
            session_start();
        }
        $_SESSION['_intended_url'] = $url;
    }
}
