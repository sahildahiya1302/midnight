<?php

namespace App\Core\Http;

class JsonResponse extends Response
{
    protected mixed $data;

    public function __construct(
        mixed $data,
        int $statusCode = 200,
        array $headers = []
    ) {
        $this->data = $data;

        $headers = array_merge([
            'Content-Type' => 'application/json; charset=UTF-8'
        ], $headers);

        parent::__construct('', $statusCode, $headers);
    }

    /**
     * Set the response data
     */
    public function setData(mixed $data): self
    {
        $this->data = $data;
        return $this;
    }

    /**
     * Get the response data
     */
    public function getData(): mixed
    {
        return $this->data;
    }

    /**
     * Send response content
     */
    protected function sendContent(): void
    {
        echo json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    }

    /**
     * Create a success response
     */
    public static function success(
        mixed $data = null,
        string $message = 'Success',
        int $statusCode = 200
    ): self {
        return new self([
            'success' => true,
            'message' => $message,
            'data' => $data
        ], $statusCode);
    }

    /**
     * Create an error response
     */
    public static function error(
        string $message = 'Error',
        mixed $errors = null,
        int $statusCode = 400
    ): self {
        return new self([
            'success' => false,
            'message' => $message,
            'errors' => $errors
        ], $statusCode);
    }

    /**
     * Create a validation error response
     */
    public static function validationError(
        array $errors,
        string $message = 'Validation failed'
    ): self {
        return self::error($message, $errors, 422);
    }

    /**
     * Create an unauthorized error response
     */
    public static function unauthorized(
        string $message = 'Unauthorized'
    ): self {
        return self::error($message, null, 401);
    }

    /**
     * Create a forbidden error response
     */
    public static function forbidden(
        string $message = 'Forbidden'
    ): self {
        return self::error($message, null, 403);
    }

    /**
     * Create a not found error response
     */
    public static function notFound(
        string $message = 'Not found'
    ): self {
        return self::error($message, null, 404);
    }

    /**
     * Create a server error response
     */
    public static function serverError(
        string $message = 'Internal server error'
    ): self {
        return self::error($message, null, 500);
    }

    /**
     * Create a paginated response
     */
    public static function paginated(
        array $items,
        int $total,
        int $page,
        int $perPage,
        array $meta = []
    ): self {
        return new self([
            'success' => true,
            'data' => $items,
            'meta' => array_merge([
                'total' => $total,
                'per_page' => $perPage,
                'current_page' => $page,
                'last_page' => ceil($total / $perPage),
                'from' => ($page - 1) * $perPage + 1,
                'to' => min($page * $perPage, $total)
            ], $meta)
        ]);
    }
}
