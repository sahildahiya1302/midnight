<?php

namespace App\Core\Http;

use Exception;

class FileResponse extends Response
{
    protected string $file;
    protected ?string $name;
    protected bool $deleteFileAfterSend = false;

    public function __construct(
        string $file,
        ?string $name = null,
        int $statusCode = 200,
        array $headers = []
    ) {
        $this->file = $file;
        $this->name = $name;

        if (!file_exists($file)) {
            throw new Exception("File not found: $file");
        }

        $headers = array_merge([
            'Content-Type' => $this->getMimeType($file),
            'Content-Length' => filesize($file),
            'Content-Disposition' => $this->getDisposition($name ?: basename($file))
        ], $headers);

        parent::__construct('', $statusCode, $headers);
    }

    /**
     * Set file to be deleted after sending
     */
    public function deleteFileAfterSend(bool $delete = true): self
    {
        $this->deleteFileAfterSend = $delete;
        return $this;
    }

    /**
     * Set the content disposition
     */
    public function setDisposition(string $disposition): self
    {
        $this->setHeader(
            'Content-Disposition',
            $this->getDisposition($this->name ?: basename($this->file), $disposition)
        );
        return $this;
    }

    /**
     * Set as attachment (force download)
     */
    public function asAttachment(): self
    {
        return $this->setDisposition('attachment');
    }

    /**
     * Set as inline (display in browser)
     */
    public function asInline(): self
    {
        return $this->setDisposition('inline');
    }

    /**
     * Send response content
     */
    protected function sendContent(): void
    {
        $handle = fopen($this->file, 'rb');
        if ($handle === false) {
            throw new Exception("Could not open file: {$this->file}");
        }

        // Send file in chunks to handle large files
        while (!feof($handle)) {
            echo fread($handle, 8192);
            flush();
        }

        fclose($handle);

        if ($this->deleteFileAfterSend) {
            @unlink($this->file);
        }
    }

    /**
     * Get the content disposition header value
     */
    protected function getDisposition(string $filename, string $disposition = 'attachment'): string
    {
        $encodedFilename = rawurlencode($filename);
        
        return sprintf(
            '%s; filename="%s"; filename*=UTF-8\'\'%s',
            $disposition,
            $filename,
            $encodedFilename
        );
    }

    /**
     * Get the MIME type of the file
     */
    protected function getMimeType(string $file): string
    {
        $mimeTypes = [
            'txt' => 'text/plain',
            'htm' => 'text/html',
            'html' => 'text/html',
            'php' => 'text/html',
            'css' => 'text/css',
            'js' => 'application/javascript',
            'json' => 'application/json',
            'xml' => 'application/xml',
            'swf' => 'application/x-shockwave-flash',
            'flv' => 'video/x-flv',

            // images
            'png' => 'image/png',
            'jpe' => 'image/jpeg',
            'jpeg' => 'image/jpeg',
            'jpg' => 'image/jpeg',
            'gif' => 'image/gif',
            'bmp' => 'image/bmp',
            'ico' => 'image/vnd.microsoft.icon',
            'tiff' => 'image/tiff',
            'tif' => 'image/tiff',
            'svg' => 'image/svg+xml',
            'svgz' => 'image/svg+xml',
            'webp' => 'image/webp',

            // archives
            'zip' => 'application/zip',
            'rar' => 'application/x-rar-compressed',
            'exe' => 'application/x-msdownload',
            'msi' => 'application/x-msdownload',
            'cab' => 'application/vnd.ms-cab-compressed',

            // audio/video
            'mp3' => 'audio/mpeg',
            'qt' => 'video/quicktime',
            'mov' => 'video/quicktime',
            'mp4' => 'video/mp4',
            'webm' => 'video/webm',
            'ogv' => 'video/ogg',

            // adobe
            'pdf' => 'application/pdf',
            'psd' => 'image/vnd.adobe.photoshop',
            'ai' => 'application/postscript',
            'eps' => 'application/postscript',
            'ps' => 'application/postscript',

            // ms office
            'doc' => 'application/msword',
            'rtf' => 'application/rtf',
            'xls' => 'application/vnd.ms-excel',
            'ppt' => 'application/vnd.ms-powerpoint',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',

            // open office
            'odt' => 'application/vnd.oasis.opendocument.text',
            'ods' => 'application/vnd.oasis.opendocument.spreadsheet',
        ];

        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));

        if (isset($mimeTypes[$extension])) {
            return $mimeTypes[$extension];
        }

        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            $mimeType = finfo_file($finfo, $file);
            finfo_close($finfo);
            return $mimeType;
        }

        return 'application/octet-stream';
    }

    /**
     * Create a file response from binary content
     */
    public static function fromContent(
        string $content,
        string $filename,
        array $headers = []
    ): self {
        $tempFile = tempnam(sys_get_temp_dir(), 'file');
        file_put_contents($tempFile, $content);

        $response = new self($tempFile, $filename, 200, $headers);
        return $response->deleteFileAfterSend();
    }
}
