<?php

namespace App\Core\Http;

use App\Core\View\ViewEngine;
use Exception;

class ViewResponse extends Response
{
    protected string $view;
    protected array $data;
    protected ?ViewEngine $engine;
    protected string $layout;

    public function __construct(
        string $view,
        array $data = [],
        int $statusCode = 200,
        array $headers = [],
        ?ViewEngine $engine = null,
        string $layout = 'layouts/main'
    ) {
        $this->view = $view;
        $this->data = $data;
        $this->engine = $engine ?? new ViewEngine();
        $this->layout = $layout;

        parent::__construct('', $statusCode, $headers);
    }

    /**
     * Set the view template
     */
    public function setView(string $view): self
    {
        $this->view = $view;
        return $this;
    }

    /**
     * Get the view template
     */
    public function getView(): string
    {
        return $this->view;
    }

    /**
     * Set the view data
     */
    public function setData(array $data): self
    {
        $this->data = $data;
        return $this;
    }

    /**
     * Add data to the view
     */
    public function with(string $key, mixed $value): self
    {
        $this->data[$key] = $value;
        return $this;
    }

    /**
     * Add multiple data to the view
     */
    public function withMany(array $data): self
    {
        $this->data = array_merge($this->data, $data);
        return $this;
    }

    /**
     * Get the view data
     */
    public function getData(): array
    {
        return $this->data;
    }

    /**
     * Set the layout template
     */
    public function setLayout(string $layout): self
    {
        $this->layout = $layout;
        return $this;
    }

    /**
     * Get the layout template
     */
    public function getLayout(): string
    {
        return $this->layout;
    }

    /**
     * Disable the layout
     */
    public function withoutLayout(): self
    {
        $this->layout = '';
        return $this;
    }

    /**
     * Send response content
     */
    protected function sendContent(): void
    {
        try {
            // Add default data
            $this->data = array_merge([
                'errors' => $_SESSION['_flash']['errors'] ?? [],
                'old' => $_SESSION['_flash']['_old_input'] ?? [],
                'success' => $_SESSION['_flash']['success'] ?? null,
                'error' => $_SESSION['_flash']['error'] ?? null,
                'warning' => $_SESSION['_flash']['warning'] ?? null,
                'info' => $_SESSION['_flash']['info'] ?? null
            ], $this->data);

            // Render the view
            $content = $this->engine->render($this->view, $this->data);

            // Render with layout if specified
            if ($this->layout) {
                $content = $this->engine->render($this->layout, array_merge(
                    $this->data,
                    ['content' => $content]
                ));
            }

            echo $content;

        } catch (Exception $e) {
            // Log error and show error page in production
            error_log("View error: " . $e->getMessage());
            
            if (defined('APP_DEBUG') && APP_DEBUG) {
                throw $e;
            }

            echo $this->engine->render('errors/500', [
                'message' => 'An error occurred while rendering the view.'
            ]);
        }
    }

    /**
     * Create a view response with a JSON fallback
     */
    public static function withJsonFallback(
        string $view,
        array $data = [],
        int $statusCode = 200,
        array $headers = []
    ): Response {
        if (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) === 'xmlhttprequest') {
            return new JsonResponse($data, $statusCode, $headers);
        }

        return new self($view, $data, $statusCode, $headers);
    }

    /**
     * Share data with all views
     */
    public function share(array $data): void
    {
        $this->engine->share($data);
    }

    /**
     * Add a view composer
     */
    public function composer(string $view, callable $callback): void
    {
        $this->engine->composer($view, $callback);
    }

    /**
     * Add a view creator
     */
    public function creator(string $view, callable $callback): void
    {
        $this->engine->creator($view, $callback);
    }

    /**
     * Add a custom directive
     */
    public function directive(string $name, callable $handler): void
    {
        $this->engine->directive($name, $handler);
    }

    /**
     * Add a path to the view finder
     */
    public function addPath(string $path): void
    {
        $this->engine->addPath($path);
    }

    /**
     * Set paths for the view finder
     */
    public function setPaths(array $paths): void
    {
        $this->engine->setPaths($paths);
    }

    /**
     * Get the view engine instance
     */
    public function getEngine(): ViewEngine
    {
        return $this->engine;
    }
}
