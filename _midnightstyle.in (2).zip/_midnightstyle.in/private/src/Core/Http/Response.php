<?php

namespace App\Core\Http;

class Response
{
    protected string $content;
    protected int $statusCode;
    protected array $headers;

    public function __construct(
        string $content = '',
        int $statusCode = 200,
        array $headers = []
    ) {
        $this->content = $content;
        $this->statusCode = $statusCode;
        $this->headers = array_merge([
            'Content-Type' => 'text/html; charset=UTF-8'
        ], $headers);
    }

    /**
     * Set the response content
     */
    public function setContent(string $content): self
    {
        $this->content = $content;
        return $this;
    }

    /**
     * Get the response content
     */
    public function getContent(): string
    {
        return $this->content;
    }

    /**
     * Set the response status code
     */
    public function setStatusCode(int $statusCode): self
    {
        $this->statusCode = $statusCode;
        return $this;
    }

    /**
     * Get the response status code
     */
    public function getStatusCode(): int
    {
        return $this->statusCode;
    }

    /**
     * Set a response header
     */
    public function setHeader(string $name, string $value): self
    {
        $this->headers[$name] = $value;
        return $this;
    }

    /**
     * Set multiple response headers
     */
    public function setHeaders(array $headers): self
    {
        $this->headers = array_merge($this->headers, $headers);
        return $this;
    }

    /**
     * Get all response headers
     */
    public function getHeaders(): array
    {
        return $this->headers;
    }

    /**
     * Send the response
     */
    public function send(): void
    {
        $this->sendHeaders();
        $this->sendContent();
    }

    /**
     * Send response headers
     */
    protected function sendHeaders(): void
    {
        if (headers_sent()) {
            return;
        }

        // Send status code
        http_response_code($this->statusCode);

        // Send headers
        foreach ($this->headers as $name => $value) {
            header("$name: $value");
        }
    }

    /**
     * Send response content
     */
    protected function sendContent(): void
    {
        echo $this->content;
    }

    /**
     * Create a JSON response
     */
    public static function json(
        mixed $data,
        int $statusCode = 200,
        array $headers = []
    ): JsonResponse {
        return new JsonResponse($data, $statusCode, $headers);
    }

    /**
     * Create a redirect response
     */
    public static function redirect(
        string $url,
        int $statusCode = 302,
        array $headers = []
    ): RedirectResponse {
        return new RedirectResponse($url, $statusCode, $headers);
    }

    /**
     * Create a file download response
     */
    public static function download(
        string $file,
        string $name = null,
        array $headers = []
    ): FileResponse {
        return new FileResponse($file, $name, 200, $headers);
    }

    /**
     * Create a view response
     */
    public static function view(
        string $view,
        array $data = [],
        int $statusCode = 200,
        array $headers = []
    ): ViewResponse {
        return new ViewResponse($view, $data, $statusCode, $headers);
    }
}
