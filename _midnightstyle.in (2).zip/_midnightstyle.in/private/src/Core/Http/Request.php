<?php

namespace App\Core\Http;

use App\Core\Session\SessionManager;

class Request
{
    /**
     * The request query parameters ($_GET).
     *
     * @var array
     */
    protected $query;

    /**
     * The request post parameters ($_POST).
     *
     * @var array
     */
    protected $request;

    /**
     * The request attributes (parameters from route matching).
     *
     * @var array
     */
    protected $attributes = [];

    /**
     * The request cookies.
     *
     * @var array
     */
    protected $cookies;

    /**
     * The request files ($_FILES).
     *
     * @var array
     */
    protected $files;

    /**
     * The request server information ($_SERVER).
     *
     * @var array
     */
    protected $server;

    /**
     * The request headers.
     *
     * @var array
     */
    protected $headers;

    /**
     * The raw content of the request body.
     *
     * @var string|null
     */
    protected $content;

    /**
     * The decoded JSON payload.
     *
     * @var array|null
     */
    protected $json;

    /**
     * Create a new request from globals.
     *
     * @return static
     */
    public static function createFromGlobals(): self
    {
        return new static(
            $_GET,
            $_POST,
            [],
            $_COOKIE,
            $_FILES,
            $_SERVER
        );
    }

    /**
     * Constructor.
     *
     * @param array $query
     * @param array $request
     * @param array $attributes
     * @param array $cookies
     * @param array $files
     * @param array $server
     * @param string|null $content
     */
    public function __construct(
        array $query = [],
        array $request = [],
        array $attributes = [],
        array $cookies = [],
        array $files = [],
        array $server = [],
        string $content = null
    ) {
        $this->query = $query;
        $this->request = $request;
        $this->attributes = $attributes;
        $this->cookies = $cookies;
        $this->files = $files;
        $this->server = $server;
        $this->content = $content;

        $this->headers = $this->getHeadersFromServer();
    }

    /**
     * Get the request method.
     *
     * @return string
     */
    public function getMethod(): string
    {
        return strtoupper($this->server['REQUEST_METHOD'] ?? 'GET');
    }

    /**
     * Get the request URI.
     *
     * @return string
     */
    public function getUri(): string
    {
        return $this->server['REQUEST_URI'] ?? '/';
    }

    /**
     * Get the request path info.
     *
     * @return string
     */
    public function getPathInfo(): string
    {
        $path = parse_url($this->getUri(), PHP_URL_PATH) ?? '/';
        return '/' . trim($path, '/');
    }

    /**
     * Get a query string parameter.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function query(string $key, $default = null)
    {
        return $this->query[$key] ?? $default;
    }

    /**
     * Get all query parameters.
     *
     * @return array
     */
    public function getQueryParams(): array
    {
        return $this->query;
    }

    /**
     * Get a request parameter ($_POST).
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function post(string $key, $default = null)
    {
        return $this->request[$key] ?? $default;
    }

    /**
     * Get all request parameters.
     *
     * @return array
     */
    public function getPostParams(): array
    {
        return $this->request;
    }

    /**
     * Get an input parameter (query or post).
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function input(string $key, $default = null)
    {
        return $this->post($key) ?? $this->query($key) ?? $default;
    }

    /**
     * Get all input parameters.
     *
     * @return array
     */
    public function all(): array
    {
        return array_merge($this->query, $this->request);
    }

    /**
     * Get a route parameter.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function route(string $key, $default = null)
    {
        return $this->attributes[$key] ?? $default;
    }

    /**
     * Set route parameters.
     *
     * @param array $parameters
     * @return void
     */
    public function setRouteParams(array $parameters): void
    {
        $this->attributes = array_merge($this->attributes, $parameters);
    }

    /**
     * Get a cookie value.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function cookie(string $key, $default = null)
    {
        return $this->cookies[$key] ?? $default;
    }

    /**
     * Get a header value.
     *
     * @param string $key
     * @param mixed $default
     * @return mixed
     */
    public function header(string $key, $default = null)
    {
        $key = strtolower($key);
        return $this->headers[$key] ?? $default;
    }

    /**
     * Get all headers.
     *
     * @return array
     */
    public function headers(): array
    {
        return $this->headers;
    }

    /**
     * Get the request body content.
     *
     * @return string
     */
    public function getContent(): string
    {
        if (null === $this->content) {
            $this->content = file_get_contents('php://input');
        }

        return $this->content;
    }

    /**
     * Get the request body as JSON.
     *
     * @param bool $assoc
     * @return mixed
     */
    public function json(bool $assoc = true)
    {
        if (null === $this->json) {
            $this->json = json_decode($this->getContent(), $assoc);
        }

        return $this->json;
    }

    /**
     * Get the client IP address.
     *
     * @return string|null
     */
    public function getClientIp(): ?string
    {
        $keys = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];

        foreach ($keys as $key) {
            if (array_key_exists($key, $this->server)) {
                foreach (explode(',', $this->server[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP)) {
                        return $ip;
                    }
                }
            }
        }

        return null;
    }

    /**
     * Get the user agent string.
     *
     * @return string|null
     */
    public function getUserAgent(): ?string
    {
        return $this->server['HTTP_USER_AGENT'] ?? null;
    }

    /**
     * Determine if the request is secure.
     *
     * @return bool
     */
    public function isSecure(): bool
    {
        if (isset($this->server['HTTPS'])) {
            return $this->server['HTTPS'] !== 'off';
        }
        return false;
    }

    /**
     * Determine if the request is an AJAX request.
     *
     * @return bool
     */
    public function isXhr(): bool
    {
        return 'XMLHttpRequest' === ($this->server['HTTP_X_REQUESTED_WITH'] ?? null);
    }

    /**
     * Get the request host.
     *
     * @return string
     */
    public function getHost(): string
    {
        return $this->server['HTTP_HOST'] ?? '';
    }

    /**
     * Get the request scheme.
     *
     * @return string
     */
    public function getScheme(): string
    {
        return $this->isSecure() ? 'https' : 'http';
    }

    /**
     * Get headers from server variables.
     *
     * @return array
     */
    protected function getHeadersFromServer(): array
    {
        $headers = [];
        foreach ($this->server as $key => $value) {
            if (strpos($key, 'HTTP_') === 0) {
                $name = strtolower(str_replace('_', '-', substr($key, 5)));
                $headers[$name] = $value;
            } elseif (in_array($key, ['CONTENT_TYPE', 'CONTENT_LENGTH', 'CONTENT_MD5'])) {
                $name = strtolower(str_replace('_', '-', $key));
                $headers[$name] = $value;
            }
        }
        return $headers;
    }

    /**
     * Get a file from the request.
     *
     * @param string $key
     * @return array|null
     */
    public function file(string $key): ?array
    {
        return $this->files[$key] ?? null;
    }

    /**
     * Get all files from the request.
     *
     * @return array
     */
    public function files(): array
    {
        return $this->files;
    }

    /**
     * Get the session instance.
     *
     * @return SessionManager
     */
    public function session(): SessionManager
    {
        return app(SessionManager::class);
    }

    /**
     * Get the bearer token from the request headers.
     *
     * @return string|null
     */
    public function bearerToken(): ?string
    {
        $header = $this->header('Authorization', '');
        if (strpos($header, 'Bearer ') === 0) {
            return substr($header, 7);
        }
        return null;
    }
}
