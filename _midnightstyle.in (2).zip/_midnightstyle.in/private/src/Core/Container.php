<?php

namespace App\Core;

use Closure;
use ReflectionClass;
use ReflectionParameter;
use App\Core\Exceptions\ContainerException;
use App\Core\Exceptions\NotFoundException;
use Psr\Container\ContainerInterface;

class Container implements ContainerInterface
{
    /**
     * The container's bindings.
     *
     * @var array
     */
    protected $bindings = [];

    /**
     * The container's shared instances.
     *
     * @var array
     */
    protected $instances = [];

    /**
     * The container's deferred services.
     *
     * @var array
     */
    protected $deferred = [];

    /**
     * The registered type aliases.
     *
     * @var array
     */
    protected $aliases = [];

    /**
     * The registered tags.
     *
     * @var array
     */
    protected $tags = [];

    /**
     * Bind a type into the container.
     *
     * @param string $abstract
     * @param mixed $concrete
     * @param bool $shared
     * @return void
     */
    public function bind(string $abstract, $concrete = null, bool $shared = false): void
    {
        // If no concrete type is given, we'll assume the abstract is the concrete
        $concrete = $concrete ?? $abstract;

        // If the concrete is a closure, we can just store it directly
        if ($concrete instanceof Closure) {
            $this->bindings[$abstract] = compact('concrete', 'shared');
            return;
        }

        // If the concrete is not a closure, we'll make it one
        $this->bindings[$abstract] = [
            'concrete' => $this->getClosure($abstract, $concrete),
            'shared' => $shared,
        ];
    }

    /**
     * Register a shared binding in the container.
     *
     * @param string $abstract
     * @param mixed $concrete
     * @return void
     */
    public function singleton(string $abstract, $concrete = null): void
    {
        $this->bind($abstract, $concrete, true);
    }

    /**
     * Register a deferred service provider.
     *
     * @param string $service
     * @param Closure $callback
     * @return void
     */
    public function defer(string $service, Closure $callback): void
    {
        $this->deferred[$service] = $callback;
    }

    /**
     * Register an existing instance as shared in the container.
     *
     * @param string $abstract
     * @param mixed $instance
     * @return mixed
     */
    public function instance(string $abstract, $instance)
    {
        $this->instances[$abstract] = $instance;

        return $instance;
    }

    /**
     * Resolve the given type from the container.
     *
     * @param string $abstract
     * @param array $parameters
     * @return mixed
     *
     * @throws ContainerException
     */
    public function make(string $abstract, array $parameters = [])
    {
        return $this->resolve($abstract, $parameters);
    }

    /**
     * Get a closure to resolve the type.
     *
     * @param string $abstract
     * @param string $concrete
     * @return Closure
     */
    protected function getClosure(string $abstract, string $concrete): Closure
    {
        return function ($container, $parameters = []) use ($abstract, $concrete) {
            if ($abstract === $concrete) {
                return $container->build($concrete);
            }

            return $container->make($concrete, $parameters);
        };
    }

    /**
     * Resolve the given type from the container.
     *
     * @param string $abstract
     * @param array $parameters
     * @return mixed
     *
     * @throws ContainerException
     */
    protected function resolve(string $abstract, array $parameters = [])
    {
        // If we have a deferred service, resolve it now
        if (isset($this->deferred[$abstract])) {
            return $this->deferred[$abstract]();
        }

        // If an instance exists, return it
        if (isset($this->instances[$abstract])) {
            return $this->instances[$abstract];
        }

        // Get the concrete implementation
        $concrete = $this->getConcreteClass($abstract);

        // If we have a binding, resolve it
        if (isset($this->bindings[$abstract])) {
            $object = $this->bindings[$abstract]['concrete']($this, $parameters);

            if ($this->bindings[$abstract]['shared']) {
                $this->instances[$abstract] = $object;
            }

            return $object;
        }

        // If no binding found, try to build it
        $object = $this->build($concrete, $parameters);

        return $object;
    }

    /**
     * Get the concrete type for a given abstract.
     *
     * @param string $abstract
     * @return string
     */
    protected function getConcreteClass(string $abstract): string
    {
        if (isset($this->aliases[$abstract])) {
            return $this->aliases[$abstract];
        }

        return $abstract;
    }

    /**
     * Instantiate a concrete instance of the given type.
     *
     * @param string $concrete
     * @param array $parameters
     * @return mixed
     *
     * @throws ContainerException
     */
    protected function build(string $concrete, array $parameters = [])
    {
        try {
            $reflector = new ReflectionClass($concrete);

            if (!$reflector->isInstantiable()) {
                throw new ContainerException("Class {$concrete} is not instantiable");
            }

            $constructor = $reflector->getConstructor();

            if (is_null($constructor)) {
                return new $concrete;
            }

            $dependencies = $this->resolveDependencies($constructor->getParameters(), $parameters);

            return $reflector->newInstanceArgs($dependencies);

        } catch (\ReflectionException $e) {
            throw new ContainerException("Error resolving class {$concrete}: " . $e->getMessage());
        }
    }

    /**
     * Resolve all of the dependencies from the ReflectionParameters.
     *
     * @param array $parameters
     * @param array $primitives
     * @return array
     */
    protected function resolveDependencies(array $parameters, array $primitives = []): array
    {
        $dependencies = [];

        foreach ($parameters as $parameter) {
            // If the parameter is a primitive and we have a value, use it
            if (array_key_exists($parameter->getName(), $primitives)) {
                $dependencies[] = $primitives[$parameter->getName()];
                continue;
            }

            // If the parameter has a type hint, resolve it from the container
            $dependency = $this->resolveParameterDependency($parameter);
            
            if (!is_null($dependency)) {
                $dependencies[] = $dependency;
                continue;
            }

            // If the parameter is optional, use the default value
            if ($parameter->isOptional()) {
                $dependencies[] = $parameter->getDefaultValue();
                continue;
            }

            throw new ContainerException("Unable to resolve dependency: {$parameter->getName()}");
        }

        return $dependencies;
    }

    /**
     * Resolve a parameter's type hint from the container.
     *
     * @param ReflectionParameter $parameter
     * @return mixed|null
     */
    protected function resolveParameterDependency(ReflectionParameter $parameter)
    {
        $type = $parameter->getType();

        if (!$type || $type->isBuiltin()) {
            return null;
        }

        try {
            return $this->make($type->getName());
        } catch (ContainerException $e) {
            return null;
        }
    }

    /**
     * Add a tag to the container.
     *
     * @param string $tag
     * @param array $services
     * @return void
     */
    public function tag(string $tag, array $services): void
    {
        foreach ($services as $service) {
            $this->tags[$tag][] = $service;
        }
    }

    /**
     * Get all services with a given tag.
     *
     * @param string $tag
     * @return array
     */
    public function tagged(string $tag): array
    {
        if (!isset($this->tags[$tag])) {
            return [];
        }

        return array_map(function ($service) {
            return $this->make($service);
        }, $this->tags[$tag]);
    }

    /**
     * Determine if the given abstract type has been bound.
     *
     * @param string $abstract
     * @return bool
     */
    public function has(string $abstract): bool
    {
        return isset($this->bindings[$abstract]) ||
               isset($this->instances[$abstract]) ||
               isset($this->deferred[$abstract]);
    }

    /**
     * Get a service from the container.
     *
     * @param string $id
     * @return mixed
     *
     * @throws NotFoundException
     */
    public function get(string $id)
    {
        try {
            return $this->make($id);
        } catch (ContainerException $e) {
            throw new NotFoundException($e->getMessage(), $e->getCode(), $e);
        }
    }
}
