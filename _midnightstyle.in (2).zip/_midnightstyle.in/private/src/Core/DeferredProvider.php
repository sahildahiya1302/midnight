<?php

namespace App\Core;

abstract class DeferredProvider extends ServiceProvider implements DeferredServiceProvider
{
    /**
     * Indicates if loading of the provider is deferred
     */
    protected bool $defer = true;

    /**
     * Get the services provided by the provider
     *
     * @return array<string>
     */
    abstract public function provides(): array;

    /**
     * Determine if the provider is deferred
     */
    public function isDeferred(): bool
    {
        return $this->defer;
    }

    /**
     * Set whether the provider is deferred
     */
    public function setDeferred(bool $defer): void
    {
        $this->defer = $defer;
    }

    /**
     * Register a deferred provider and service
     */
    protected function registerDeferredProvider(
        string $provider,
        ?string $service = null,
        bool $shared = true
    ): void {
        if ($service) {
            $this->container->bind($service, function ($container) use ($provider) {
                $provider = $this->resolveProvider($provider);
                $provider->register();
                return $container->get($service);
            }, $shared);
        }
    }

    /**
     * Resolve a service provider instance
     */
    protected function resolveProvider(string $provider): ServiceProvider
    {
        return new $provider($this->container);
    }

    /**
     * Register a deferred binding in the container
     */
    protected function deferBinding(string $abstract, callable $concrete, bool $shared = true): void
    {
        $this->container->bind($abstract, function ($container) use ($concrete) {
            $this->register();
            return $concrete($container);
        }, $shared);
    }

    /**
     * Register a deferred singleton binding in the container
     */
    protected function deferSingleton(string $abstract, callable $concrete): void
    {
        $this->deferBinding($abstract, $concrete, true);
    }

    /**
     * Register multiple deferred bindings at once
     */
    protected function deferBindings(array $bindings, bool $shared = true): void
    {
        foreach ($bindings as $abstract => $concrete) {
            if (is_callable($concrete)) {
                $this->deferBinding($abstract, $concrete, $shared);
            } else {
                $this->deferBinding($abstract, function () use ($concrete) {
                    return $concrete;
                }, $shared);
            }
        }
    }

    /**
     * Register multiple deferred singleton bindings at once
     */
    protected function deferSingletons(array $bindings): void
    {
        foreach ($bindings as $abstract => $concrete) {
            if (is_callable($concrete)) {
                $this->deferSingleton($abstract, $concrete);
            } else {
                $this->deferSingleton($abstract, function () use ($concrete) {
                    return $concrete;
                });
            }
        }
    }

    /**
     * Register a deferred instance in the container
     */
    protected function deferInstance(string $abstract, mixed $instance): void
    {
        $this->container->bind($abstract, function () use ($instance) {
            $this->register();
            return $instance;
        }, true);
    }

    /**
     * Register a deferred alias in the container
     */
    protected function deferAlias(string $abstract, string $alias): void
    {
        $this->container->bind($alias, function ($container) use ($abstract) {
            $this->register();
            return $container->get($abstract);
        }, true);
    }

    /**
     * Register multiple deferred aliases at once
     */
    protected function deferAliases(array $aliases): void
    {
        foreach ($aliases as $abstract => $alias) {
            $this->deferAlias($abstract, $alias);
        }
    }

    /**
     * Register a deferred factory in the container
     */
    protected function deferFactory(string $abstract, callable $factory, bool $shared = false): void
    {
        $this->container->bind($abstract, function ($container) use ($factory) {
            $this->register();
            return $factory($container);
        }, $shared);
    }

    /**
     * Register a deferred callback to be run when a service is resolved
     */
    protected function deferCallback(string $abstract, callable $callback): void
    {
        $this->container->resolving($abstract, function ($service, $container) use ($callback) {
            $this->register();
            return $callback($service, $container);
        });
    }

    /**
     * Register a deferred service with a callback that configures it
     */
    protected function deferConfigure(string $abstract, callable $configure): void
    {
        $this->container->resolving($abstract, function ($service, $container) use ($configure) {
            $this->register();
            $configure($service, $container);
        });
    }

    /**
     * Register a deferred service that extends an existing service
     */
    protected function deferExtend(string $abstract, callable $extension): void
    {
        $this->container->extend($abstract, function ($service, $container) use ($extension) {
            $this->register();
            return $extension($service, $container);
        });
    }
}
