<?php

namespace App\Core;

interface DeferredServiceProvider
{
    /**
     * Get the services provided by the provider
     *
     * @return array<string>
     */
    public function provides(): array;

    /**
     * Determine if the provider is deferred
     */
    public function isDeferred(): bool;
}
