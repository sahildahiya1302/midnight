<?php

namespace App\Core\Security\Auth;

use App\Core\Config\ConfigurationInterface;
use App\Core\Security\Auth\UserInterface;
use Exception;
use Firebase\JWT\JWT;
use Firebase\JWT\Key;

class TokenManager
{
    private ConfigurationInterface $config;
    private string $algorithm;
    private string $secret;
    private int $accessTokenLifetime;
    private int $refreshTokenLifetime;

    public function __construct(ConfigurationInterface $config)
    {
        $this->config = $config;
        $this->algorithm = $config->get('security.jwt.algorithm', 'HS256');
        $this->secret = $config->get('security.jwt.secret');
        $this->accessTokenLifetime = $config->get('security.jwt.access_token_lifetime', 3600);
        $this->refreshTokenLifetime = $config->get('security.jwt.refresh_token_lifetime', 604800);

        if (empty($this->secret)) {
            throw new Exception('JWT secret key not configured');
        }
    }

    /**
     * Create a new access token
     */
    public function createToken(UserInterface $user, array $abilities = ['*']): string
    {
        $payload = [
            'sub' => $user->getId(),
            'name' => $user->getUsername(),
            'email' => $user->getEmail(),
            'roles' => $user->toArray()['roles'] ?? [],
            'abilities' => $abilities,
            'iat' => time(),
            'exp' => time() + $this->accessTokenLifetime,
            'iss' => $this->config->get('app.url'),
            'jti' => bin2hex(random_bytes(16))
        ];

        return JWT::encode($payload, $this->secret, $this->algorithm);
    }

    /**
     * Create a new refresh token
     */
    public function createRefreshToken(UserInterface $user): string
    {
        $payload = [
            'sub' => $user->getId(),
            'type' => 'refresh',
            'iat' => time(),
            'exp' => time() + $this->refreshTokenLifetime,
            'iss' => $this->config->get('app.url'),
            'jti' => bin2hex(random_bytes(16))
        ];

        return JWT::encode($payload, $this->secret, $this->algorithm);
    }

    /**
     * Validate a token
     */
    public function validateToken(string $token): bool
    {
        try {
            $this->parseToken($token);
            return true;
        } catch (Exception $e) {
            return false;
        }
    }

    /**
     * Parse and validate a token
     */
    public function parseToken(string $token): ?array
    {
        try {
            $decoded = JWT::decode($token, new Key($this->secret, $this->algorithm));
            return (array)$decoded;
        } catch (Exception $e) {
            error_log("Token validation failed: " . $e->getMessage());
            return null;
        }
    }

    /**
     * Get user ID from token
     */
    public function getUserIdFromToken(string $token): ?int
    {
        $payload = $this->parseToken($token);
        return $payload ? (int)$payload['sub'] : null;
    }

    /**
     * Check if token has expired
     */
    public function hasTokenExpired(string $token): bool
    {
        $payload = $this->parseToken($token);
        return !$payload || $payload['exp'] < time();
    }

    /**
     * Check if token has specific ability
     */
    public function tokenCan(string $token, string $ability): bool
    {
        $payload = $this->parseToken($token);
        
        if (!$payload) {
            return false;
        }

        return in_array('*', $payload['abilities']) || 
               in_array($ability, $payload['abilities']);
    }

    /**
     * Refresh an access token using a refresh token
     */
    public function refreshToken(string $refreshToken): ?string
    {
        $payload = $this->parseToken($refreshToken);
        
        if (!$payload || 
            $payload['type'] !== 'refresh' || 
            $payload['exp'] < time()) {
            return null;
        }

        // Create new access token with same subject
        $newPayload = [
            'sub' => $payload['sub'],
            'iat' => time(),
            'exp' => time() + $this->accessTokenLifetime,
            'iss' => $this->config->get('app.url'),
            'jti' => bin2hex(random_bytes(16))
        ];

        return JWT::encode($newPayload, $this->secret, $this->algorithm);
    }

    /**
     * Blacklist a token
     */
    public function blacklistToken(string $token): void
    {
        $payload = $this->parseToken($token);
        if (!$payload) {
            return;
        }

        // Store token in blacklist with expiry
        $this->storeBlacklistedToken(
            $payload['jti'],
            $payload['exp']
        );
    }

    /**
     * Check if a token is blacklisted
     */
    public function isTokenBlacklisted(string $token): bool
    {
        $payload = $this->parseToken($token);
        if (!$payload) {
            return true;
        }

        return $this->isBlacklistedJti($payload['jti']);
    }

    /**
     * Store a blacklisted token
     */
    private function storeBlacklistedToken(string $jti, int $expiry): void
    {
        try {
            // Store in database or cache
            // Implementation depends on your storage system
        } catch (Exception $e) {
            error_log("Failed to blacklist token: " . $e->getMessage());
        }
    }

    /**
     * Check if a JTI is blacklisted
     */
    private function isBlacklistedJti(string $jti): bool
    {
        try {
            // Check database or cache
            // Implementation depends on your storage system
            return false;
        } catch (Exception $e) {
            error_log("Failed to check blacklisted token: " . $e->getMessage());
            return true;
        }
    }

    /**
     * Clean up expired blacklisted tokens
     */
    public function cleanupBlacklist(): void
    {
        try {
            // Remove expired tokens from blacklist
            // Implementation depends on your storage system
        } catch (Exception $e) {
            error_log("Failed to cleanup blacklist: " . $e->getMessage());
        }
    }
}
