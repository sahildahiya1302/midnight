<?php

namespace App\Core\Security\Auth;

interface UserInterface
{
    /**
     * Get the user's ID
     */
    public function getId(): int;

    /**
     * Get the user's username
     */
    public function getUsername(): string;

    /**
     * Get the user's email
     */
    public function getEmail(): string;

    /**
     * Get the user's password hash
     */
    public function getPasswordHash(): string;

    /**
     * Get the user's status
     */
    public function getStatus(): string;

    /**
     * Check if the user has a specific role
     */
    public function hasRole(string $role): bool;

    /**
     * Check if the user has a specific permission
     */
    public function hasPermission(string $permission): bool;

    /**
     * Get all user data as array
     */
    public function toArray(): array;

    /**
     * Get the user's wallet
     */
    public function getWallet(): ?WalletInterface;

    /**
     * Check if the user is active
     */
    public function isActive(): bool;

    /**
     * Check if the user is an admin
     */
    public function isAdmin(): bool;

    /**
     * Check if the user's email is verified
     */
    public function isEmailVerified(): bool;

    /**
     * Check if the user's phone is verified
     */
    public function isPhoneVerified(): bool;

    /**
     * Check if the user's KYC is verified
     */
    public function isKYCVerified(): bool;
}
