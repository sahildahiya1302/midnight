<?php

namespace App\Core\Security\Auth;

use App\Core\Database\DatabaseManager;
use App\Core\Security\Auth\WalletInterface;
use Exception;

class User implements UserInterface
{
    private array $data;
    private ?WalletInterface $wallet = null;
    private ?DatabaseManager $db = null;
    private array $roles = [];
    private array $permissions = [];

    public function __construct(array $data, ?DatabaseManager $db = null)
    {
        $this->data = $data;
        $this->db = $db;
        
        if (isset($data['roles'])) {
            $this->roles = is_array($data['roles']) ? $data['roles'] : json_decode($data['roles'], true) ?? [];
        }
        
        if (isset($data['permissions'])) {
            $this->permissions = is_array($data['permissions']) ? $data['permissions'] : json_decode($data['permissions'], true) ?? [];
        }
    }

    public function getId(): int
    {
        return (int)$this->data['id'];
    }

    public function getUsername(): string
    {
        return $this->data['username'];
    }

    public function getEmail(): string
    {
        return $this->data['email'];
    }

    public function getPasswordHash(): string
    {
        return $this->data['password_hash'];
    }

    public function getStatus(): string
    {
        return $this->data['status'];
    }

    public function hasRole(string $role): bool
    {
        if ($this->isAdmin()) {
            return true;
        }
        
        return in_array($role, $this->roles);
    }

    public function hasPermission(string $permission): bool
    {
        if ($this->isAdmin()) {
            return true;
        }
        
        return in_array($permission, $this->permissions);
    }

    public function toArray(): array
    {
        return array_merge($this->data, [
            'roles' => $this->roles,
            'permissions' => $this->permissions,
            'is_admin' => $this->isAdmin(),
            'is_active' => $this->isActive(),
            'is_email_verified' => $this->isEmailVerified(),
            'is_phone_verified' => $this->isPhoneVerified(),
            'is_kyc_verified' => $this->isKYCVerified()
        ]);
    }

    public function getWallet(): ?WalletInterface
    {
        if ($this->wallet === null && $this->db !== null) {
            try {
                $walletData = $this->db->connection()->fetchOne(
                    "SELECT * FROM wallets WHERE user_id = ?",
                    [$this->getId()]
                );

                if ($walletData) {
                    $this->wallet = new Wallet($walletData, $this->db);
                }
            } catch (Exception $e) {
                error_log("Failed to load wallet: " . $e->getMessage());
            }
        }

        return $this->wallet;
    }

    public function isActive(): bool
    {
        return $this->data['status'] === 'active';
    }

    public function isAdmin(): bool
    {
        return in_array('admin', $this->roles) || $this->data['role'] === 'admin';
    }

    public function isEmailVerified(): bool
    {
        return !empty($this->data['email_verified_at']);
    }

    public function isPhoneVerified(): bool
    {
        return !empty($this->data['phone_verified_at']);
    }

    public function isKYCVerified(): bool
    {
        return $this->data['kyc_status'] === 'verified';
    }

    public function update(array $data): bool
    {
        if (!$this->db) {
            throw new Exception('Database connection not available');
        }

        try {
            $this->db->connection()->beginTransaction();

            // Update user data
            $this->db->connection()->update(
                'users',
                array_merge($data, ['updated_at' => date('Y-m-d H:i:s')]),
                'id = ?',
                [$this->getId()]
            );

            // Update local data
            $this->data = array_merge($this->data, $data);

            $this->db->connection()->commit();
            return true;

        } catch (Exception $e) {
            $this->db->connection()->rollBack();
            error_log("Failed to update user: " . $e->getMessage());
            return false;
        }
    }

    public function updatePassword(string $password): bool
    {
        return $this->update([
            'password_hash' => password_hash($password, PASSWORD_DEFAULT)
        ]);
    }

    public function updateEmail(string $email): bool
    {
        return $this->update([
            'email' => $email,
            'email_verified_at' => null
        ]);
    }

    public function verifyEmail(): bool
    {
        return $this->update([
            'email_verified_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function updatePhone(string $phone): bool
    {
        return $this->update([
            'phone' => $phone,
            'phone_verified_at' => null
        ]);
    }

    public function verifyPhone(): bool
    {
        return $this->update([
            'phone_verified_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function updateKYC(array $kycData): bool
    {
        return $this->update([
            'kyc_data' => json_encode($kycData),
            'kyc_status' => 'pending'
        ]);
    }

    public function verifyKYC(): bool
    {
        return $this->update([
            'kyc_status' => 'verified',
            'kyc_verified_at' => date('Y-m-d H:i:s')
        ]);
    }

    public function suspend(string $reason = ''): bool
    {
        return $this->update([
            'status' => 'suspended',
            'suspension_reason' => $reason
        ]);
    }

    public function activate(): bool
    {
        return $this->update([
            'status' => 'active',
            'suspension_reason' => null
        ]);
    }

    public function delete(): bool
    {
        if (!$this->db) {
            throw new Exception('Database connection not available');
        }

        try {
            $this->db->connection()->beginTransaction();

            // Soft delete user
            $this->db->connection()->update(
                'users',
                [
                    'status' => 'deleted',
                    'deleted_at' => date('Y-m-d H:i:s')
                ],
                'id = ?',
                [$this->getId()]
            );

            $this->db->connection()->commit();
            return true;

        } catch (Exception $e) {
            $this->db->connection()->rollBack();
            error_log("Failed to delete user: " . $e->getMessage());
            return false;
        }
    }

    public function getData(string $key = null, mixed $default = null): mixed
    {
        if ($key === null) {
            return $this->data;
        }

        return $this->data[$key] ?? $default;
    }
}
