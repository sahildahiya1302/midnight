<?php

namespace App\Core\Security\Auth;

interface WalletInterface
{
    /**
     * Get the wallet ID
     */
    public function getId(): int;

    /**
     * Get the user ID associated with this wallet
     */
    public function getUserId(): int;

    /**
     * Get the current balance
     */
    public function getBalance(): float;

    /**
     * Get the bonus balance
     */
    public function getBonusBalance(): float;

    /**
     * Add funds to the wallet
     */
    public function addFunds(float $amount, string $type = 'deposit', ?string $reference = null): array;

    /**
     * Deduct funds from the wallet
     */
    public function deductFunds(float $amount, string $type = 'withdrawal', ?string $reference = null): array;

    /**
     * Lock funds for a game or transaction
     */
    public function lockFunds(float $amount, string $reference): array;

    /**
     * Unlock previously locked funds
     */
    public function unlockFunds(float $amount, string $reference): array;

    /**
     * Get transaction history
     */
    public function getTransactions(int $limit = 10, int $offset = 0): array;

    /**
     * Get the total deposits
     */
    public function getTotalDeposits(): float;

    /**
     * Get the total withdrawals
     */
    public function getTotalWithdrawals(): float;

    /**
     * Check if the wallet has sufficient funds
     */
    public function hasSufficientFunds(float $amount): bool;

    /**
     * Get the wallet data as array
     */
    public function toArray(): array;
}
