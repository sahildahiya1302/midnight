<?php

namespace App\Core\Security\Auth;

interface AuthenticationInterface
{
    /**
     * Attempt to authenticate a user
     */
    public function attempt(array $credentials): bool;

    /**
     * Login a user by ID
     */
    public function loginById(int $id): bool;

    /**
     * Login a user instance
     */
    public function login(UserInterface $user): bool;

    /**
     * Logout the current user
     */
    public function logout(): void;

    /**
     * Check if user is authenticated
     */
    public function check(): bool;

    /**
     * Get the currently authenticated user
     */
    public function user(): ?UserInterface;

    /**
     * Get the user ID
     */
    public function id(): ?int;

    /**
     * Validate a user's credentials
     */
    public function validate(array $credentials): bool;

    /**
     * Create an access token for a user
     */
    public function createToken(UserInterface $user, array $abilities = ['*']): string;

    /**
     * Validate an access token
     */
    public function validateToken(string $token): bool;

    /**
     * Get user by token
     */
    public function getUserByToken(string $token): ?UserInterface;

    /**
     * Check if user has a specific role
     */
    public function hasRole(string $role): bool;

    /**
     * Check if user has a specific permission
     */
    public function hasPermission(string $permission): bool;
}
