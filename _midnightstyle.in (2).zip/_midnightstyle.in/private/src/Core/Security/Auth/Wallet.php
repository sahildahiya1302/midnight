<?php

namespace App\Core\Security\Auth;

use App\Core\Database\DatabaseManager;
use Exception;
use PDOException;

class Wallet implements WalletInterface
{
    private array $data;
    private DatabaseManager $db;
    private array $lockedFunds = [];

    public function __construct(array $data, DatabaseManager $db)
    {
        $this->data = $data;
        $this->db = $db;
        $this->loadLockedFunds();
    }

    public function getId(): int
    {
        return (int)$this->data['id'];
    }

    public function getUserId(): int
    {
        return (int)$this->data['user_id'];
    }

    public function getBalance(): float
    {
        return (float)$this->data['balance'];
    }

    public function getBonusBalance(): float
    {
        return (float)($this->data['bonus_balance'] ?? 0);
    }

    public function addFunds(float $amount, string $type = 'deposit', ?string $reference = null): array
    {
        if ($amount <= 0) {
            return [
                'success' => false,
                'error' => 'Invalid amount'
            ];
        }

        try {
            $this->db->connection()->beginTransaction();

            // Update wallet balance
            $this->db->connection()->update(
                'wallets',
                [
                    'balance' => $this->getBalance() + $amount,
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'id = ?',
                [$this->getId()]
            );

            // Record transaction
            $transactionId = $this->db->connection()->insert('transactions', [
                'user_id' => $this->getUserId(),
                'wallet_id' => $this->getId(),
                'type' => $type,
                'amount' => $amount,
                'balance_before' => $this->getBalance(),
                'balance_after' => $this->getBalance() + $amount,
                'reference' => $reference,
                'status' => 'completed',
                'created_at' => date('Y-m-d H:i:s')
            ]);

            $this->db->connection()->commit();

            // Update local data
            $this->data['balance'] += $amount;

            return [
                'success' => true,
                'transaction_id' => $transactionId,
                'new_balance' => $this->getBalance()
            ];

        } catch (Exception $e) {
            $this->db->connection()->rollBack();
            error_log("Failed to add funds: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'Transaction failed'
            ];
        }
    }

    public function deductFunds(float $amount, string $type = 'withdrawal', ?string $reference = null): array
    {
        if (!$this->hasSufficientFunds($amount)) {
            return [
                'success' => false,
                'error' => 'Insufficient funds'
            ];
        }

        try {
            $this->db->connection()->beginTransaction();

            // Update wallet balance
            $result = $this->db->connection()->update(
                'wallets',
                [
                    'balance' => $this->getBalance() - $amount,
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'id = ? AND balance >= ?',
                [$this->getId(), $amount]
            );

            if (!$result) {
                throw new Exception('Insufficient funds');
            }

            // Record transaction
            $transactionId = $this->db->connection()->insert('transactions', [
                'user_id' => $this->getUserId(),
                'wallet_id' => $this->getId(),
                'type' => $type,
                'amount' => $amount,
                'balance_before' => $this->getBalance(),
                'balance_after' => $this->getBalance() - $amount,
                'reference' => $reference,
                'status' => 'completed',
                'created_at' => date('Y-m-d H:i:s')
            ]);

            $this->db->connection()->commit();

            // Update local data
            $this->data['balance'] -= $amount;

            return [
                'success' => true,
                'transaction_id' => $transactionId,
                'new_balance' => $this->getBalance()
            ];

        } catch (Exception $e) {
            $this->db->connection()->rollBack();
            error_log("Failed to deduct funds: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'Transaction failed'
            ];
        }
    }

    public function lockFunds(float $amount, string $reference): array
    {
        if (!$this->hasSufficientFunds($amount)) {
            return [
                'success' => false,
                'error' => 'Insufficient funds'
            ];
        }

        try {
            $this->db->connection()->beginTransaction();

            // Create lock record
            $lockId = $this->db->connection()->insert('wallet_locks', [
                'wallet_id' => $this->getId(),
                'amount' => $amount,
                'reference' => $reference,
                'created_at' => date('Y-m-d H:i:s')
            ]);

            // Update wallet balance
            $this->db->connection()->update(
                'wallets',
                [
                    'locked_balance' => $this->getLockedBalance() + $amount,
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'id = ?',
                [$this->getId()]
            );

            $this->db->connection()->commit();

            // Update local data
            $this->lockedFunds[$reference] = $amount;
            $this->data['locked_balance'] = ($this->data['locked_balance'] ?? 0) + $amount;

            return [
                'success' => true,
                'lock_id' => $lockId
            ];

        } catch (Exception $e) {
            $this->db->connection()->rollBack();
            error_log("Failed to lock funds: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'Lock failed'
            ];
        }
    }

    public function unlockFunds(float $amount, string $reference): array
    {
        if (!isset($this->lockedFunds[$reference])) {
            return [
                'success' => false,
                'error' => 'Lock not found'
            ];
        }

        try {
            $this->db->connection()->beginTransaction();

            // Release lock
            $this->db->connection()->update(
                'wallet_locks',
                [
                    'released_at' => date('Y-m-d H:i:s')
                ],
                'wallet_id = ? AND reference = ? AND released_at IS NULL',
                [$this->getId(), $reference]
            );

            // Update wallet balance
            $this->db->connection()->update(
                'wallets',
                [
                    'locked_balance' => $this->getLockedBalance() - $amount,
                    'updated_at' => date('Y-m-d H:i:s')
                ],
                'id = ?',
                [$this->getId()]
            );

            $this->db->connection()->commit();

            // Update local data
            unset($this->lockedFunds[$reference]);
            $this->data['locked_balance'] = ($this->data['locked_balance'] ?? 0) - $amount;

            return [
                'success' => true
            ];

        } catch (Exception $e) {
            $this->db->connection()->rollBack();
            error_log("Failed to unlock funds: " . $e->getMessage());
            
            return [
                'success' => false,
                'error' => 'Unlock failed'
            ];
        }
    }

    public function getTransactions(int $limit = 10, int $offset = 0): array
    {
        try {
            return $this->db->connection()->fetchAll(
                "SELECT * FROM transactions 
                WHERE wallet_id = ? 
                ORDER BY created_at DESC 
                LIMIT ? OFFSET ?",
                [$this->getId(), $limit, $offset]
            );
        } catch (PDOException $e) {
            error_log("Failed to get transactions: " . $e->getMessage());
            return [];
        }
    }

    public function getTotalDeposits(): float
    {
        try {
            return (float)$this->db->connection()->fetchColumn(
                "SELECT COALESCE(SUM(amount), 0) 
                FROM transactions 
                WHERE wallet_id = ? AND type = 'deposit' AND status = 'completed'",
                [$this->getId()]
            );
        } catch (PDOException $e) {
            error_log("Failed to get total deposits: " . $e->getMessage());
            return 0.0;
        }
    }

    public function getTotalWithdrawals(): float
    {
        try {
            return (float)$this->db->connection()->fetchColumn(
                "SELECT COALESCE(SUM(amount), 0) 
                FROM transactions 
                WHERE wallet_id = ? AND type = 'withdrawal' AND status = 'completed'",
                [$this->getId()]
            );
        } catch (PDOException $e) {
            error_log("Failed to get total withdrawals: " . $e->getMessage());
            return 0.0;
        }
    }

    public function hasSufficientFunds(float $amount): bool
    {
        return ($this->getBalance() - $this->getLockedBalance()) >= $amount;
    }

    public function toArray(): array
    {
        return array_merge($this->data, [
            'locked_funds' => $this->lockedFunds,
            'available_balance' => $this->getBalance() - $this->getLockedBalance()
        ]);
    }

    private function getLockedBalance(): float
    {
        return (float)($this->data['locked_balance'] ?? 0);
    }

    private function loadLockedFunds(): void
    {
        try {
            $locks = $this->db->connection()->fetchAll(
                "SELECT * FROM wallet_locks 
                WHERE wallet_id = ? AND released_at IS NULL",
                [$this->getId()]
            );

            foreach ($locks as $lock) {
                $this->lockedFunds[$lock['reference']] = (float)$lock['amount'];
            }
        } catch (PDOException $e) {
            error_log("Failed to load locked funds: " . $e->getMessage());
        }
    }
}
