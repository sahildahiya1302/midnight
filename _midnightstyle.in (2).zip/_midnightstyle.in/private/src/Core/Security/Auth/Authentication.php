<?php

namespace App\Core\Security\Auth;

use App\Core\Config\ConfigurationInterface;
use App\Core\Session\SessionManager;
use App\Core\Database\DatabaseManager;
use App\Core\Security\Auth\UserInterface;
use App\Core\Security\Auth\TokenManager;
use Exception;
use PDOException;

class Authentication implements AuthenticationInterface
{
    private ?UserInterface $user = null;
    private DatabaseManager $db;
    private SessionManager $session;
    private TokenManager $tokenManager;
    private ConfigurationInterface $config;

    public function __construct(
        ConfigurationInterface $config,
        SessionManager $session,
        TokenManager $tokenManager,
        DatabaseManager $db
    ) {
        $this->config = $config;
        $this->session = $session;
        $this->tokenManager = $tokenManager;
        $this->db = $db;
        
        $this->initializeFromSession();
    }

    private function initializeFromSession(): void
    {
        if ($userId = $this->session->get('auth_user_id')) {
            try {
                $this->loginById($userId);
            } catch (Exception $e) {
                $this->session->remove('auth_user_id');
            }
        }
    }

    public function attempt(array $credentials): bool
    {
        try {
            $user = $this->retrieveByCredentials($credentials);
            
            if (!$user || !$this->validateCredentials($user, $credentials)) {
                $this->logFailedAttempt($credentials);
                return false;
            }

            $this->login($user);
            return true;

        } catch (Exception $e) {
            error_log("Authentication attempt failed: " . $e->getMessage());
            return false;
        }
    }

    public function loginById(int $id): bool
    {
        try {
            $user = $this->retrieveById($id);
            
            if (!$user) {
                return false;
            }

            $this->login($user);
            return true;

        } catch (Exception $e) {
            error_log("Login by ID failed: " . $e->getMessage());
            return false;
        }
    }

    public function login(UserInterface $user): bool
    {
        $this->user = $user;
        $this->session->set('auth_user_id', $user->getId());
        $this->session->regenerate();

        // Update last login timestamp
        try {
            $this->db->connection()->update(
                'users',
                ['last_login_at' => date('Y-m-d H:i:s')],
                'id = ?',
                [$user->getId()]
            );
        } catch (PDOException $e) {
            error_log("Failed to update last login: " . $e->getMessage());
        }

        return true;
    }

    public function logout(): void
    {
        $this->user = null;
        $this->session->remove('auth_user_id');
        $this->session->regenerate();
    }

    public function check(): bool
    {
        return $this->user !== null;
    }

    public function user(): ?UserInterface
    {
        return $this->user;
    }

    public function id(): ?int
    {
        return $this->user ? $this->user->getId() : null;
    }

    public function validate(array $credentials): bool
    {
        $user = $this->retrieveByCredentials($credentials);
        return $user && $this->validateCredentials($user, $credentials);
    }

    public function createToken(UserInterface $user, array $abilities = ['*']): string
    {
        return $this->tokenManager->createToken($user, $abilities);
    }

    public function validateToken(string $token): bool
    {
        return $this->tokenManager->validateToken($token);
    }

    public function getUserByToken(string $token): ?UserInterface
    {
        $payload = $this->tokenManager->parseToken($token);
        if (!$payload) {
            return null;
        }

        return $this->retrieveById($payload['sub']);
    }

    public function hasRole(string $role): bool
    {
        return $this->user && $this->user->hasRole($role);
    }

    public function hasPermission(string $permission): bool
    {
        return $this->user && $this->user->hasPermission($permission);
    }

    private function retrieveByCredentials(array $credentials): ?UserInterface
    {
        if (empty($credentials)) {
            return null;
        }

        try {
            $query = "SELECT * FROM users WHERE ";
            $params = [];

            // Build query based on credentials
            $conditions = [];
            foreach ($credentials as $key => $value) {
                if ($key === 'password') {
                    continue;
                }
                $conditions[] = "$key = ?";
                $params[] = $value;
            }

            $query .= implode(' AND ', $conditions);
            $query .= " AND status = 'active' LIMIT 1";

            $user = $this->db->connection()->fetchOne($query, $params);
            
            if (!$user) {
                return null;
            }

            return $this->createUserInstance($user);

        } catch (PDOException $e) {
            error_log("Database error during credential check: " . $e->getMessage());
            return null;
        }
    }

    private function retrieveById(int $id): ?UserInterface
    {
        try {
            $user = $this->db->connection()->fetchOne(
                "SELECT * FROM users WHERE id = ? AND status = 'active'",
                [$id]
            );

            if (!$user) {
                return null;
            }

            return $this->createUserInstance($user);

        } catch (PDOException $e) {
            error_log("Database error during user retrieval: " . $e->getMessage());
            return null;
        }
    }

    private function validateCredentials(UserInterface $user, array $credentials): bool
    {
        if (!isset($credentials['password'])) {
            return false;
        }

        return password_verify(
            $credentials['password'],
            $user->getPasswordHash()
        );
    }

    private function logFailedAttempt(array $credentials): void
    {
        try {
            $this->db->connection()->insert('login_attempts', [
                'username' => $credentials['username'] ?? $credentials['email'] ?? '',
                'ip_address' => $_SERVER['REMOTE_ADDR'] ?? '',
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
                'success' => 0,
                'attempted_at' => date('Y-m-d H:i:s')
            ]);
        } catch (PDOException $e) {
            error_log("Failed to log login attempt: " . $e->getMessage());
        }
    }

    private function createUserInstance(array $userData): UserInterface
    {
        $userClass = $this->config->get('auth.user_class', User::class);
        return new $userClass($userData);
    }
}
