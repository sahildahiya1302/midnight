<?php

namespace App\Core\Security;

use App\Core\Config\ConfigurationInterface;
use App\Core\Session\SessionManager;
use App\Core\Security\Auth\AuthenticationInterface;
use App\Core\Security\Auth\TokenManager;
use App\Core\Security\CSRF\CSRFProtection;
use App\Core\Security\RateLimit\RateLimiter;
use Exception;

class SecurityManager
{
    private ConfigurationInterface $config;
    private SessionManager $session;
    private ?AuthenticationInterface $auth = null;
    private ?TokenManager $tokenManager = null;
    private ?CSRFProtection $csrf = null;
    private ?RateLimiter $rateLimiter = null;

    public function __construct(
        ConfigurationInterface $config,
        SessionManager $session
    ) {
        $this->config = $config;
        $this->session = $session;
    }

    /**
     * Get the authentication service
     */
    public function auth(): AuthenticationInterface
    {
        if ($this->auth === null) {
            $authClass = $this->config->get('security.auth.provider');
            if (!$authClass || !class_exists($authClass)) {
                throw new Exception('Authentication provider not configured');
            }
            
            $this->auth = new $authClass(
                $this->config,
                $this->session,
                $this->getTokenManager()
            );
        }
        
        return $this->auth;
    }

    /**
     * Get the token manager
     */
    public function getTokenManager(): TokenManager
    {
        if ($this->tokenManager === null) {
            $this->tokenManager = new TokenManager($this->config);
        }
        
        return $this->tokenManager;
    }

    /**
     * Get the CSRF protection service
     */
    public function csrf(): CSRFProtection
    {
        if ($this->csrf === null) {
            $this->csrf = new CSRFProtection($this->session);
        }
        
        return $this->csrf;
    }

    /**
     * Get the rate limiter
     */
    public function rateLimiter(): RateLimiter
    {
        if ($this->rateLimiter === null) {
            $this->rateLimiter = new RateLimiter($this->config);
        }
        
        return $this->rateLimiter;
    }

    /**
     * Generate a secure random string
     */
    public function generateRandomString(int $length = 32): string
    {
        return bin2hex(random_bytes($length / 2));
    }

    /**
     * Hash a password
     */
    public function hashPassword(string $password): string
    {
        $algo = $this->config->get('security.password.algo', PASSWORD_DEFAULT);
        $options = $this->config->get('security.password.options', []);
        
        return password_hash($password, $algo, $options);
    }

    /**
     * Verify a password
     */
    public function verifyPassword(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    /**
     * Encrypt data
     */
    public function encrypt(string $data): string
    {
        $key = $this->config->get('security.encryption.key');
        if (!$key) {
            throw new Exception('Encryption key not configured');
        }

        $iv = random_bytes(16);
        $encrypted = openssl_encrypt(
            $data,
            'AES-256-CBC',
            base64_decode($key),
            0,
            $iv
        );

        if ($encrypted === false) {
            throw new Exception('Encryption failed');
        }

        return base64_encode($iv . $encrypted);
    }

    /**
     * Decrypt data
     */
    public function decrypt(string $data): string
    {
        $key = $this->config->get('security.encryption.key');
        if (!$key) {
            throw new Exception('Encryption key not configured');
        }

        $data = base64_decode($data);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);

        $decrypted = openssl_decrypt(
            $encrypted,
            'AES-256-CBC',
            base64_decode($key),
            0,
            $iv
        );

        if ($decrypted === false) {
            throw new Exception('Decryption failed');
        }

        return $decrypted;
    }

    /**
     * Generate a secure hash
     */
    public function hash(string $data): string
    {
        $algo = $this->config->get('security.hash.algo', 'sha256');
        $salt = $this->config->get('security.hash.salt', '');
        
        return hash_hmac($algo, $data, $salt);
    }

    /**
     * Verify a hash
     */
    public function verifyHash(string $data, string $hash): bool
    {
        return hash_equals($this->hash($data), $hash);
    }

    /**
     * Check if the current request is secure (HTTPS)
     */
    public function isSecureRequest(): bool
    {
        return isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    }

    /**
     * Get the client IP address
     */
    public function getClientIp(): string
    {
        $headers = [
            'HTTP_CLIENT_IP',
            'HTTP_X_FORWARDED_FOR',
            'HTTP_X_FORWARDED',
            'HTTP_X_CLUSTER_CLIENT_IP',
            'HTTP_FORWARDED_FOR',
            'HTTP_FORWARDED',
            'REMOTE_ADDR'
        ];

        foreach ($headers as $header) {
            if (isset($_SERVER[$header])) {
                $ips = explode(',', $_SERVER[$header]);
                $ip = trim($ips[0]);
                
                if (filter_var($ip, FILTER_VALIDATE_IP)) {
                    return $ip;
                }
            }
        }

        return '0.0.0.0';
    }

    /**
     * Check if an IP is allowed
     */
    public function isIpAllowed(string $ip): bool
    {
        $allowedIps = $this->config->get('security.allowed_ips', []);
        if (empty($allowedIps)) {
            return true;
        }

        return in_array($ip, $allowedIps);
    }

    /**
     * Check if an IP is banned
     */
    public function isIpBanned(string $ip): bool
    {
        $bannedIps = $this->config->get('security.banned_ips', []);
        return in_array($ip, $bannedIps);
    }

    /**
     * Set security headers
     */
    public function setSecurityHeaders(): void
    {
        $headers = [
            'X-Frame-Options' => 'DENY',
            'X-XSS-Protection' => '1; mode=block',
            'X-Content-Type-Options' => 'nosniff',
            'Referrer-Policy' => 'strict-origin-when-cross-origin',
            'Content-Security-Policy' => $this->config->get('security.csp'),
            'Permissions-Policy' => $this->config->get('security.permissions_policy'),
        ];

        if ($this->isSecureRequest()) {
            $headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
        }

        foreach ($headers as $header => $value) {
            if ($value) {
                header("$header: $value");
            }
        }
    }
}
