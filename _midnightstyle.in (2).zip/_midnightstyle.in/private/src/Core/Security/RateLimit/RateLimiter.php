<?php

namespace App\Core\Security\RateLimit;

use App\Core\Config\ConfigurationInterface;
use App\Core\Database\DatabaseManager;
use Exception;

class RateLimiter
{
    private ConfigurationInterface $config;
    private DatabaseManager $db;
    private array $limits = [];
    private string $identifier;

    public function __construct(
        ConfigurationInterface $config,
        DatabaseManager $db
    ) {
        $this->config = $config;
        $this->db = $db;
        $this->identifier = $this->getClientIdentifier();
        $this->loadLimits();
    }

    /**
     * Attempt an action
     */
    public function attempt(string $action, int $maxAttempts = null, int $decayMinutes = null): bool
    {
        $key = $this->getKey($action);
        $maxAttempts = $maxAttempts ?? $this->getLimitForAction($action)['attempts'];
        $decayMinutes = $decayMinutes ?? $this->getLimitForAction($action)['decay'];

        try {
            $this->db->connection()->beginTransaction();

            // Clean up old attempts
            $this->clearOldAttempts($key, $decayMinutes);

            // Get current attempts
            $attempts = $this->getCurrentAttempts($key);

            if ($attempts >= $maxAttempts) {
                $this->db->connection()->commit();
                return false;
            }

            // Record new attempt
            $this->recordAttempt($key);

            $this->db->connection()->commit();
            return true;

        } catch (Exception $e) {
            $this->db->connection()->rollBack();
            error_log("Rate limit error: " . $e->getMessage());
            return false;
        }
    }

    /**
     * Get remaining attempts
     */
    public function remaining(string $action): int
    {
        $key = $this->getKey($action);
        $limit = $this->getLimitForAction($action);
        
        $this->clearOldAttempts($key, $limit['decay']);
        $attempts = $this->getCurrentAttempts($key);
        
        return max(0, $limit['attempts'] - $attempts);
    }

    /**
     * Check if action is too many attempts
     */
    public function tooManyAttempts(string $action): bool
    {
        return !$this->attempt($action);
    }

    /**
     * Get retry after timestamp
     */
    public function retryAfter(string $action): int
    {
        $key = $this->getKey($action);
        $limit = $this->getLimitForAction($action);

        try {
            $lastAttempt = $this->db->connection()->fetchOne(
                "SELECT attempted_at 
                FROM rate_limits 
                WHERE action_key = ? 
                ORDER BY attempted_at DESC 
                LIMIT 1",
                [$key]
            );

            if (!$lastAttempt) {
                return 0;
            }

            $timestamp = strtotime($lastAttempt['attempted_at']);
            $retryAfter = $timestamp + ($limit['decay'] * 60);

            return max(0, $retryAfter - time());

        } catch (Exception $e) {
            error_log("Rate limit error: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Clear attempts for action
     */
    public function clear(string $action): void
    {
        $key = $this->getKey($action);

        try {
            $this->db->connection()->execute(
                "DELETE FROM rate_limits WHERE action_key = ?",
                [$key]
            );
        } catch (Exception $e) {
            error_log("Failed to clear rate limit: " . $e->getMessage());
        }
    }

    /**
     * Get the rate limit key
     */
    private function getKey(string $action): string
    {
        return sprintf(
            '%s:%s:%s',
            $action,
            $this->identifier,
            date('Y-m-d')
        );
    }

    /**
     * Get client identifier
     */
    private function getClientIdentifier(): string
    {
        return md5(
            $_SERVER['REMOTE_ADDR'] . '|' . 
            ($_SERVER['HTTP_USER_AGENT'] ?? '')
        );
    }

    /**
     * Load rate limits from configuration
     */
    private function loadLimits(): void
    {
        $this->limits = $this->config->get('security.rate_limits', [
            'login' => ['attempts' => 5, 'decay' => 1],
            'register' => ['attempts' => 3, 'decay' => 60],
            'password_reset' => ['attempts' => 3, 'decay' => 60],
            'api' => ['attempts' => 60, 'decay' => 1]
        ]);
    }

    /**
     * Get limit configuration for action
     */
    private function getLimitForAction(string $action): array
    {
        return $this->limits[$action] ?? ['attempts' => 60, 'decay' => 1];
    }

    /**
     * Clear old attempts
     */
    private function clearOldAttempts(string $key, int $decayMinutes): void
    {
        try {
            $this->db->connection()->execute(
                "DELETE FROM rate_limits 
                WHERE action_key = ? 
                AND attempted_at < DATE_SUB(NOW(), INTERVAL ? MINUTE)",
                [$key, $decayMinutes]
            );
        } catch (Exception $e) {
            error_log("Failed to clear old attempts: " . $e->getMessage());
        }
    }

    /**
     * Get current attempts count
     */
    private function getCurrentAttempts(string $key): int
    {
        try {
            return (int)$this->db->connection()->fetchColumn(
                "SELECT COUNT(*) FROM rate_limits WHERE action_key = ?",
                [$key]
            );
        } catch (Exception $e) {
            error_log("Failed to get attempts: " . $e->getMessage());
            return 0;
        }
    }

    /**
     * Record an attempt
     */
    private function recordAttempt(string $key): void
    {
        try {
            $this->db->connection()->insert('rate_limits', [
                'action_key' => $key,
                'identifier' => $this->identifier,
                'ip_address' => $_SERVER['REMOTE_ADDR'],
                'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? null,
                'attempted_at' => date('Y-m-d H:i:s')
            ]);
        } catch (Exception $e) {
            error_log("Failed to record attempt: " . $e->getMessage());
        }
    }

    /**
     * Add or update a rate limit
     */
    public function setLimit(string $action, int $attempts, int $decay): void
    {
        $this->limits[$action] = [
            'attempts' => $attempts,
            'decay' => $decay
        ];
    }

    /**
     * Remove a rate limit
     */
    public function removeLimit(string $action): void
    {
        unset($this->limits[$action]);
    }

    /**
     * Get all rate limits
     */
    public function getLimits(): array
    {
        return $this->limits;
    }

    /**
     * Clean up old rate limits
     */
    public function cleanup(): void
    {
        try {
            $this->db->connection()->execute(
                "DELETE FROM rate_limits 
                WHERE attempted_at < DATE_SUB(NOW(), INTERVAL 24 HOUR)"
            );
        } catch (Exception $e) {
            error_log("Failed to cleanup rate limits: " . $e->getMessage());
        }
    }
}
