<?php

namespace App\Core\Security\CSRF;

use App\Core\Session\SessionManager;
use Exception;

class CSRFProtection
{
    private SessionManager $session;
    private string $tokenKey = '_csrf_token';
    private string $headerName = 'X-CSRF-TOKEN';
    private array $excludedPaths = [];
    private array $excludedMethods = ['GET', 'HEAD', 'OPTIONS'];

    public function __construct(
        SessionManager $session,
        array $config = []
    ) {
        $this->session = $session;
        $this->tokenKey = $config['token_key'] ?? '_csrf_token';
        $this->headerName = $config['header_name'] ?? 'X-CSRF-TOKEN';
        $this->excludedPaths = $config['excluded_paths'] ?? [];
        $this->excludedMethods = $config['excluded_methods'] ?? ['GET', 'HEAD', 'OPTIONS'];
    }

    /**
     * Generate a new CSRF token
     */
    public function generateToken(): string
    {
        $token = bin2hex(random_bytes(32));
        $this->session->set($this->tokenKey, $token);
        return $token;
    }

    /**
     * Get the current CSRF token
     */
    public function getToken(): string
    {
        if (!$this->session->has($this->tokenKey)) {
            return $this->generateToken();
        }
        return $this->session->get($this->tokenKey);
    }

    /**
     * Validate the CSRF token
     */
    public function validateToken(?string $token = null): bool
    {
        if ($token === null) {
            $token = $this->getTokenFromRequest();
        }

        if (!$this->session->has($this->tokenKey)) {
            return false;
        }

        return hash_equals($this->session->get($this->tokenKey), $token);
    }

    /**
     * Check if the request should be validated
     */
    public function shouldValidateRequest(string $method, string $path): bool
    {
        // Skip validation for excluded methods
        if (in_array(strtoupper($method), $this->excludedMethods)) {
            return false;
        }

        // Skip validation for excluded paths
        foreach ($this->excludedPaths as $excludedPath) {
            if ($this->pathMatches($path, $excludedPath)) {
                return false;
            }
        }

        return true;
    }

    /**
     * Validate the request
     */
    public function validateRequest(): void
    {
        $method = $_SERVER['REQUEST_METHOD'];
        $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

        if (!$this->shouldValidateRequest($method, $path)) {
            return;
        }

        if (!$this->validateToken()) {
            throw new Exception('CSRF token validation failed');
        }
    }

    /**
     * Get token from request
     */
    private function getTokenFromRequest(): ?string
    {
        // Check POST data
        if (isset($_POST['_token'])) {
            return $_POST['_token'];
        }

        // Check headers
        $headers = getallheaders();
        if (isset($headers[$this->headerName])) {
            return $headers[$this->headerName];
        }

        // Check custom header
        $headerKey = 'HTTP_' . str_replace('-', '_', strtoupper($this->headerName));
        if (isset($_SERVER[$headerKey])) {
            return $_SERVER[$headerKey];
        }

        return null;
    }

    /**
     * Check if path matches pattern
     */
    private function pathMatches(string $path, string $pattern): bool
    {
        $pattern = str_replace('*', '.*', preg_quote($pattern, '/'));
        return (bool)preg_match('/^' . $pattern . '$/', $path);
    }

    /**
     * Generate HTML meta tag with CSRF token
     */
    public function generateMetaTag(): string
    {
        return sprintf(
            '<meta name="csrf-token" content="%s">',
            htmlspecialchars($this->getToken(), ENT_QUOTES, 'UTF-8')
        );
    }

    /**
     * Generate HTML hidden input with CSRF token
     */
    public function generateHiddenInput(): string
    {
        return sprintf(
            '<input type="hidden" name="_token" value="%s">',
            htmlspecialchars($this->getToken(), ENT_QUOTES, 'UTF-8')
        );
    }

    /**
     * Refresh the CSRF token
     */
    public function refreshToken(): string
    {
        return $this->generateToken();
    }

    /**
     * Remove the CSRF token
     */
    public function removeToken(): void
    {
        $this->session->remove($this->tokenKey);
    }

    /**
     * Get the CSRF header name
     */
    public function getHeaderName(): string
    {
        return $this->headerName;
    }

    /**
     * Add excluded path
     */
    public function addExcludedPath(string $path): void
    {
        $this->excludedPaths[] = $path;
    }

    /**
     * Add excluded method
     */
    public function addExcludedMethod(string $method): void
    {
        $this->excludedMethods[] = strtoupper($method);
    }

    /**
     * Set excluded paths
     */
    public function setExcludedPaths(array $paths): void
    {
        $this->excludedPaths = $paths;
    }

    /**
     * Set excluded methods
     */
    public function setExcludedMethods(array $methods): void
    {
        $this->excludedMethods = array_map('strtoupper', $methods);
    }

    /**
     * Get excluded paths
     */
    public function getExcludedPaths(): array
    {
        return $this->excludedPaths;
    }

    /**
     * Get excluded methods
     */
    public function getExcludedMethods(): array
    {
        return $this->excludedMethods;
    }
}
