<?php

namespace App\Core\Session;

use App\Core\Config\ConfigurationInterface;
use SessionHandlerInterface;
use Exception;

class SessionManager
{
    private ConfigurationInterface $config;
    private bool $started = false;
    private array $options;

    public function __construct(ConfigurationInterface $config)
    {
        $this->config = $config;
        $this->options = $this->getSessionOptions();
    }

    /**
     * Start the session
     */
    public function start(): bool
    {
        if ($this->started) {
            return true;
        }

        // Set session handler if configured
        $handler = $this->config->get('session.handler');
        if ($handler && class_exists($handler)) {
            $handlerInstance = new $handler($this->config);
            if (!$handlerInstance instanceof SessionHandlerInterface) {
                throw new Exception("Session handler must implement SessionHandlerInterface");
            }
            session_set_save_handler($handlerInstance, true);
        }

        // Set session options
        session_name($this->options['name']);
        session_set_cookie_params($this->options['cookie']);

        // Start session
        if (session_start()) {
            $this->started = true;
            
            // Regenerate session ID periodically
            if (!isset($_SESSION['_last_regenerate']) ||
                time() - $_SESSION['_last_regenerate'] > $this->options['regenerate_interval']) {
                $this->regenerate();
            }
            
            // Check for session expiry
            if (isset($_SESSION['_last_activity']) && 
                time() - $_SESSION['_last_activity'] > $this->options['lifetime']) {
                $this->destroy();
                return $this->start();
            }
            
            // Update last activity time
            $_SESSION['_last_activity'] = time();
            
            return true;
        }
        
        return false;
    }

    /**
     * Get session options from configuration
     */
    private function getSessionOptions(): array
    {
        return [
            'name' => $this->config->get('session.name', 'PHPSESSID'),
            'lifetime' => $this->config->get('session.lifetime', 7200),
            'regenerate_interval' => $this->config->get('session.regenerate_interval', 300),
            'cookie' => [
                'lifetime' => $this->config->get('session.cookie.lifetime', 0),
                'path' => $this->config->get('session.cookie.path', '/'),
                'domain' => $this->config->get('session.cookie.domain', null),
                'secure' => $this->config->get('session.cookie.secure', true),
                'httponly' => $this->config->get('session.cookie.httponly', true),
                'samesite' => $this->config->get('session.cookie.samesite', 'Lax')
            ]
        ];
    }

    /**
     * Get a value from session
     */
    public function get(string $key, mixed $default = null): mixed
    {
        $this->ensureStarted();
        return $_SESSION[$key] ?? $default;
    }

    /**
     * Set a value in session
     */
    public function set(string $key, mixed $value): void
    {
        $this->ensureStarted();
        $_SESSION[$key] = $value;
    }

    /**
     * Check if a key exists in session
     */
    public function has(string $key): bool
    {
        $this->ensureStarted();
        return isset($_SESSION[$key]);
    }

    /**
     * Remove a value from session
     */
    public function remove(string $key): void
    {
        $this->ensureStarted();
        unset($_SESSION[$key]);
    }

    /**
     * Get all session data
     */
    public function all(): array
    {
        $this->ensureStarted();
        return $_SESSION;
    }

    /**
     * Clear all session data
     */
    public function clear(): void
    {
        $this->ensureStarted();
        $_SESSION = [];
    }

    /**
     * Destroy the session
     */
    public function destroy(): bool
    {
        if ($this->started) {
            $this->clear();
            
            // Delete the session cookie
            if (isset($_COOKIE[session_name()])) {
                $params = session_get_cookie_params();
                setcookie(
                    session_name(),
                    '',
                    time() - 42000,
                    $params['path'],
                    $params['domain'],
                    $params['secure'],
                    $params['httponly']
                );
            }
            
            $this->started = false;
            return session_destroy();
        }
        
        return false;
    }

    /**
     * Regenerate the session ID
     */
    public function regenerate(bool $deleteOldSession = true): bool
    {
        if ($this->started) {
            $success = session_regenerate_id($deleteOldSession);
            if ($success) {
                $_SESSION['_last_regenerate'] = time();
            }
            return $success;
        }
        return false;
    }

    /**
     * Flash a value for the next request
     */
    public function flash(string $key, mixed $value): void
    {
        $this->ensureStarted();
        $_SESSION['_flash'][$key] = $value;
    }

    /**
     * Get and remove a flashed value
     */
    public function getFlash(string $key, mixed $default = null): mixed
    {
        $this->ensureStarted();
        $value = $_SESSION['_flash'][$key] ?? $default;
        unset($_SESSION['_flash'][$key]);
        return $value;
    }

    /**
     * Get all flash data
     */
    public function getAllFlash(): array
    {
        $this->ensureStarted();
        $flash = $_SESSION['_flash'] ?? [];
        $_SESSION['_flash'] = [];
        return $flash;
    }

    /**
     * Check if session has started
     */
    public function isStarted(): bool
    {
        return $this->started;
    }

    /**
     * Ensure session has started
     */
    private function ensureStarted(): void
    {
        if (!$this->started) {
            throw new Exception('Session not started');
        }
    }

    /**
     * Get the session ID
     */
    public function getId(): string
    {
        return session_id();
    }

    /**
     * Set the session ID
     */
    public function setId(string $id): void
    {
        if (!$this->started) {
            session_id($id);
        }
    }

    /**
     * Get the session name
     */
    public function getName(): string
    {
        return session_name();
    }

    /**
     * Set the session name
     */
    public function setName(string $name): void
    {
        if (!$this->started) {
            session_name($name);
        }
    }
}
