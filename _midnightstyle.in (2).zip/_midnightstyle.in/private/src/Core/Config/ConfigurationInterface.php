<?php

namespace App\Core\Config;

interface ConfigurationInterface
{
    /**
     * Get a configuration value using dot notation
     */
    public function get(string $key, mixed $default = null): mixed;

    /**
     * Set a configuration value using dot notation
     */
    public function set(string $key, mixed $value): void;

    /**
     * Check if a configuration value exists
     */
    public function has(string $key): bool;

    /**
     * Get all configuration values
     */
    public function all(): array;

    /**
     * Load configuration from a file
     */
    public function load(string $path): void;

    /**
     * Get the environment setting
     */
    public function getEnvironment(): string;

    /**
     * Check if running in development environment
     */
    public function isDevelopment(): bool;

    /**
     * Check if running in production environment
     */
    public function isProduction(): bool;

    /**
     * Check if debug mode is enabled
     */
    public function isDebugEnabled(): bool;
}
