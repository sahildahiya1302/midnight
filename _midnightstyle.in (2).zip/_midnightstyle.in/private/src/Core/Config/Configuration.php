<?php

namespace App\Core\Config;

use Dotenv\Dotenv;
use Exception;

class Configuration implements ConfigurationInterface
{
    private array $config = [];
    private string $configPath;

    public function __construct(string $configPath)
    {
        $this->configPath = $configPath;
        $this->loadEnvironment();
        $this->loadConfigurations();
    }

    private function loadEnvironment(): void
    {
        // Load .env file from project root
        $dotenv = Dotenv::createImmutable(dirname($this->configPath, 2));
        $dotenv->load();

        // Required environment variables
        $dotenv->required([
            'APP_ENV',
            'APP_DEBUG',
            'APP_URL',
            'DB_HOST',
            'DB_NAME',
            'DB_USER',
            'DB_PASS'
        ]);

        // Add environment variables to config
        $this->config['env'] = $_ENV;
    }

    private function loadConfigurations(): void
    {
        // Load all PHP configuration files
        foreach (glob($this->configPath . '/*.php') as $file) {
            $name = basename($file, '.php');
            $config = require $file;
            
            if (!is_array($config)) {
                throw new Exception("Configuration file must return an array: $file");
            }
            
            $this->config[$name] = $config;
        }
    }

    public function get(string $key, mixed $default = null): mixed
    {
        $keys = explode('.', $key);
        $config = $this->config;

        foreach ($keys as $segment) {
            if (!isset($config[$segment])) {
                return $default;
            }
            $config = $config[$segment];
        }

        return $config;
    }

    public function set(string $key, mixed $value): void
    {
        $keys = explode('.', $key);
        $config = &$this->config;

        foreach ($keys as $i => $segment) {
            if ($i === count($keys) - 1) {
                $config[$segment] = $value;
                break;
            }

            if (!isset($config[$segment]) || !is_array($config[$segment])) {
                $config[$segment] = [];
            }

            $config = &$config[$segment];
        }
    }

    public function has(string $key): bool
    {
        return $this->get($key) !== null;
    }

    public function all(): array
    {
        return $this->config;
    }

    public function load(string $path): void
    {
        if (!file_exists($path)) {
            throw new Exception("Configuration file not found: $path");
        }

        $config = require $path;
        
        if (!is_array($config)) {
            throw new Exception("Configuration file must return an array: $path");
        }

        $name = basename($path, '.php');
        $this->config[$name] = $config;
    }

    public function getEnvironment(): string
    {
        return $_ENV['APP_ENV'] ?? 'production';
    }

    public function isDevelopment(): bool
    {
        return $this->getEnvironment() === 'development';
    }

    public function isProduction(): bool
    {
        return $this->getEnvironment() === 'production';
    }

    public function isDebugEnabled(): bool
    {
        return filter_var($_ENV['APP_DEBUG'] ?? false, FILTER_VALIDATE_BOOLEAN);
    }

    /**
     * Get the configuration directory path
     */
    public function getConfigPath(): string
    {
        return $this->configPath;
    }

    /**
     * Merge configuration arrays
     */
    private function mergeConfig(array $original, array $merge): array
    {
        foreach ($merge as $key => $value) {
            if (is_array($value) && isset($original[$key]) && is_array($original[$key])) {
                $original[$key] = $this->mergeConfig($original[$key], $value);
            } else {
                $original[$key] = $value;
            }
        }

        return $original;
    }

    /**
     * Create a backup of the current configuration
     */
    public function backup(): array
    {
        return $this->config;
    }

    /**
     * Restore configuration from a backup
     */
    public function restore(array $backup): void
    {
        $this->config = $backup;
    }

    /**
     * Clear all configuration values
     */
    public function clear(): void
    {
        $this->config = [];
    }

    /**
     * Get configuration for a specific environment
     */
    public function getForEnvironment(string $environment): array
    {
        $envConfig = [];
        
        foreach ($this->config as $key => $value) {
            if (isset($value[$environment])) {
                $envConfig[$key] = $value[$environment];
            } else {
                $envConfig[$key] = $value;
            }
        }

        return $envConfig;
    }
}
