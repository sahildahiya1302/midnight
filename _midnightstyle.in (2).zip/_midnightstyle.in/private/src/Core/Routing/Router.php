<?php

namespace App\Core\Routing;

use App\Core\Container;
use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Http\JsonResponse;
use App\Core\Middleware\MiddlewareStack;
use App\Core\Exceptions\RouteNotFoundException;
use App\Core\Exceptions\MethodNotAllowedException;

class Router
{
    /**
     * The container instance.
     *
     * @var Container
     */
    protected $container;

    /**
     * The route collection instance.
     *
     * @var RouteCollection
     */
    protected $routes;

    /**
     * The middleware stack instance.
     *
     * @var MiddlewareStack
     */
    protected $middleware;

    /**
     * The current group stack.
     *
     * @var array
     */
    protected $groupStack = [];

    /**
     * Create a new Router instance.
     *
     * @param Container $container
     */
    public function __construct(Container $container)
    {
        $this->container = $container;
        $this->routes = new RouteCollection();
        $this->middleware = new MiddlewareStack($container);
    }

    /**
     * Register a GET route.
     *
     * @param string $uri
     * @param mixed $action
     * @return Route
     */
    public function get(string $uri, $action): Route
    {
        return $this->addRoute(['GET', 'HEAD'], $uri, $action);
    }

    /**
     * Register a POST route.
     *
     * @param string $uri
     * @param mixed $action
     * @return Route
     */
    public function post(string $uri, $action): Route
    {
        return $this->addRoute(['POST'], $uri, $action);
    }

    /**
     * Register a PUT route.
     *
     * @param string $uri
     * @param mixed $action
     * @return Route
     */
    public function put(string $uri, $action): Route
    {
        return $this->addRoute(['PUT'], $uri, $action);
    }

    /**
     * Register a DELETE route.
     *
     * @param string $uri
     * @param mixed $action
     * @return Route
     */
    public function delete(string $uri, $action): Route
    {
        return $this->addRoute(['DELETE'], $uri, $action);
    }

    /**
     * Register a route for multiple HTTP methods.
     *
     * @param array $methods
     * @param string $uri
     * @param mixed $action
     * @return Route
     */
    public function match(array $methods, string $uri, $action): Route
    {
        return $this->addRoute($methods, $uri, $action);
    }

    /**
     * Create a route group with shared attributes.
     *
     * @param array $attributes
     * @param callable $callback
     * @return void
     */
    public function group(array $attributes, callable $callback): void
    {
        $this->groupStack[] = $attributes;

        $callback($this);

        array_pop($this->groupStack);
    }

    /**
     * Add a route to the collection.
     *
     * @param array $methods
     * @param string $uri
     * @param mixed $action
     * @return Route
     */
    protected function addRoute(array $methods, string $uri, $action): Route
    {
        // Merge group attributes
        $attributes = $this->mergeGroupAttributes([
            'prefix' => '',
            'namespace' => '',
            'middleware' => [],
        ]);

        // Create the route
        $route = new Route(
            $methods,
            $this->prefix($attributes['prefix'], $uri),
            $this->parseAction($action, $attributes['namespace'])
        );

        // Add middleware
        if (!empty($attributes['middleware'])) {
            $route->middleware($attributes['middleware']);
        }

        // Add route to collection
        $this->routes->add($route);

        return $route;
    }

    /**
     * Merge the current group stack with the given attributes.
     *
     * @param array $defaults
     * @return array
     */
    protected function mergeGroupAttributes(array $defaults): array
    {
        $attributes = $defaults;

        foreach ($this->groupStack as $group) {
            // Merge prefixes
            if (isset($group['prefix'])) {
                $attributes['prefix'] = trim($attributes['prefix'] . '/' . trim($group['prefix'], '/'), '/');
            }

            // Merge namespaces
            if (isset($group['namespace'])) {
                $attributes['namespace'] = trim($attributes['namespace'] . '\\' . trim($group['namespace'], '\\'), '\\');
            }

            // Merge middleware
            if (isset($group['middleware'])) {
                $attributes['middleware'] = array_merge(
                    $attributes['middleware'],
                    (array)$group['middleware']
                );
            }
        }

        return $attributes;
    }

    /**
     * Add a prefix to the route URI.
     *
     * @param string $prefix
     * @param string $uri
     * @return string
     */
    protected function prefix(string $prefix, string $uri): string
    {
        $uri = trim($uri, '/');
        
        if ($prefix) {
            $uri = trim($prefix, '/') . '/' . $uri;
        }

        return '/' . trim($uri, '/');
    }

    /**
     * Parse the route action.
     *
     * @param mixed $action
     * @param string $namespace
     * @return array
     */
    protected function parseAction($action, string $namespace): array
    {
        if (is_string($action)) {
            $action = ['uses' => $action];
        } elseif (is_callable($action)) {
            $action = ['uses' => $action];
        }

        if (!empty($namespace) && is_string($action['uses'])) {
            $action['uses'] = trim($namespace, '\\') . '\\' . $action['uses'];
        }

        return $action;
    }

    /**
     * Dispatch the request to a route and return the response.
     *
     * @param Request $request
     * @return Response
     *
     * @throws RouteNotFoundException
     * @throws MethodNotAllowedException
     */
    public function dispatch(Request $request): Response
    {
        // Find matching route
        $route = $this->findRoute($request);

        // Add route parameters to request
        $request->setRouteParams($route->getParameters());

        try {
            // Run middleware stack
            return $this->middleware
                ->withRoute($route)
                ->then(function ($request) use ($route) {
                    return $this->runRoute($route, $request);
                })
                ->handle($request);

        } catch (\Throwable $e) {
            // Convert exceptions to responses
            return $this->convertExceptionToResponse($e);
        }
    }

    /**
     * Find the route matching the request.
     *
     * @param Request $request
     * @return Route
     *
     * @throws RouteNotFoundException
     * @throws MethodNotAllowedException
     */
    protected function findRoute(Request $request): Route
    {
        // Get matching routes
        $routes = $this->routes->match($request->getMethod(), $request->getPathInfo());

        if (empty($routes)) {
            // Check if route exists for other methods
            $methods = $this->routes->getMethodsForUri($request->getPathInfo());
            
            if (!empty($methods)) {
                throw new MethodNotAllowedException(
                    'Method not allowed',
                    405,
                    null,
                    $methods
                );
            }

            throw new RouteNotFoundException(
                'No route found for ' . $request->getMethod() . ' ' . $request->getPathInfo()
            );
        }

        return reset($routes);
    }

    /**
     * Run the route action and return the response.
     *
     * @param Route $route
     * @param Request $request
     * @return Response
     */
    protected function runRoute(Route $route, Request $request): Response
    {
        $action = $route->getAction();

        if (is_callable($action['uses'])) {
            $response = $action['uses']($request, ...array_values($route->getParameters()));
        } else {
            [$controller, $method] = explode('@', $action['uses']);
            $instance = $this->container->make($controller);
            $response = $instance->$method($request, ...array_values($route->getParameters()));
        }

        // Convert response if needed
        if (!$response instanceof Response) {
            $response = $this->convertToResponse($response);
        }

        return $response;
    }

    /**
     * Convert the given value to a Response instance.
     *
     * @param mixed $response
     * @return Response
     */
    protected function convertToResponse($response): Response
    {
        if (is_array($response) || is_object($response)) {
            return new JsonResponse($response);
        }

        return new Response($response);
    }

    /**
     * Convert an exception to a Response instance.
     *
     * @param \Throwable $e
     * @return Response
     */
    protected function convertExceptionToResponse(\Throwable $e): Response
    {
        return $this->container->get('error.handler')->handle($e);
    }

    /**
     * Get the route collection instance.
     *
     * @return RouteCollection
     */
    public function getRoutes(): RouteCollection
    {
        return $this->routes;
    }

    /**
     * Load routes from a configuration array.
     *
     * @param array $routes
     * @return void
     */
    public function loadRoutes(array $routes): void
    {
        foreach ($routes as $route) {
            if (isset($route['group'])) {
                $this->group($route['group'], function ($router) use ($route) {
                    foreach ($route['routes'] as $r) {
                        $router->match(
                            (array)$r['method'],
                            $r['uri'],
                            $r['action']
                        );
                    }
                });
            } else {
                $this->match(
                    (array)$route['method'],
                    $route['uri'],
                    $route['action']
                );
            }
        }
    }
}
