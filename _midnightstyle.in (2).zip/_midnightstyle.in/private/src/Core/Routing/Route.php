<?php

namespace App\Core\Routing;

class Route
{
    /**
     * The HTTP methods the route responds to.
     *
     * @var array
     */
    protected $methods;

    /**
     * The route URI pattern.
     *
     * @var string
     */
    protected $uri;

    /**
     * The route action array.
     *
     * @var array
     */
    protected $action;

    /**
     * The regular expression requirements.
     *
     * @var array
     */
    protected $wheres = [];

    /**
     * The route parameters.
     *
     * @var array
     */
    protected $parameters = [];

    /**
     * The middleware assigned to the route.
     *
     * @var array
     */
    protected $middleware = [];

    /**
     * The default values for the route.
     *
     * @var array
     */
    protected $defaults = [];

    /**
     * Create a new Route instance.
     *
     * @param array $methods
     * @param string $uri
     * @param array $action
     */
    public function __construct(array $methods, string $uri, array $action)
    {
        $this->methods = $methods;
        $this->uri = $uri;
        $this->action = $action;
    }

    /**
     * Set a regular expression requirement on the route.
     *
     * @param string $name
     * @param string $expression
     * @return $this
     */
    public function where(string $name, string $expression): self
    {
        $this->wheres[$name] = $expression;

        return $this;
    }

    /**
     * Set multiple regular expression requirements on the route.
     *
     * @param array $wheres
     * @return $this
     */
    public function whereArray(array $wheres): self
    {
        foreach ($wheres as $name => $expression) {
            $this->where($name, $expression);
        }

        return $this;
    }

    /**
     * Set a default value for the route.
     *
     * @param string $name
     * @param mixed $value
     * @return $this
     */
    public function defaults(string $name, $value): self
    {
        $this->defaults[$name] = $value;

        return $this;
    }

    /**
     * Add middleware to the route.
     *
     * @param array|string $middleware
     * @return $this
     */
    public function middleware($middleware): self
    {
        $this->middleware = array_merge(
            $this->middleware,
            (array)$middleware
        );

        return $this;
    }

    /**
     * Get the route's compiled pattern.
     *
     * @return string
     */
    public function getCompiledPattern(): string
    {
        $pattern = preg_replace_callback('/\{(\w+)\??}/', function ($matches) {
            $name = $matches[1];
            $pattern = $this->wheres[$name] ?? '[^/]+';
            return '(?P<' . $name . '>' . $pattern . ')' . (isset($matches[0][2]) ? '?' : '');
        }, $this->uri);

        return '#^' . $pattern . '$#';
    }

    /**
     * Determine if the route matches the given path and method.
     *
     * @param string $method
     * @param string $path
     * @return bool
     */
    public function matches(string $method, string $path): bool
    {
        if (!in_array($method, $this->methods)) {
            return false;
        }

        $pattern = $this->getCompiledPattern();
        
        if (!preg_match($pattern, $path, $matches)) {
            return false;
        }

        // Store the route parameters
        foreach ($matches as $key => $value) {
            if (is_string($key)) {
                $this->parameters[$key] = $value;
            }
        }

        // Apply default values
        foreach ($this->defaults as $key => $value) {
            if (!isset($this->parameters[$key])) {
                $this->parameters[$key] = $value;
            }
        }

        return true;
    }

    /**
     * Get the URI pattern for the route.
     *
     * @return string
     */
    public function getUri(): string
    {
        return $this->uri;
    }

    /**
     * Get the HTTP methods the route responds to.
     *
     * @return array
     */
    public function getMethods(): array
    {
        return $this->methods;
    }

    /**
     * Get the route action array.
     *
     * @return array
     */
    public function getAction(): array
    {
        return $this->action;
    }

    /**
     * Get the route parameters.
     *
     * @return array
     */
    public function getParameters(): array
    {
        return $this->parameters;
    }

    /**
     * Get the middleware assigned to the route.
     *
     * @return array
     */
    public function getMiddleware(): array
    {
        return $this->middleware;
    }

    /**
     * Get a parameter value.
     *
     * @param string $name
     * @param mixed $default
     * @return mixed
     */
    public function getParameter(string $name, $default = null)
    {
        return $this->parameters[$name] ?? $default;
    }

    /**
     * Set a parameter value.
     *
     * @param string $name
     * @param mixed $value
     * @return $this
     */
    public function setParameter(string $name, $value): self
    {
        $this->parameters[$name] = $value;

        return $this;
    }

    /**
     * Get the route name.
     *
     * @return string|null
     */
    public function getName(): ?string
    {
        return $this->action['as'] ?? null;
    }

    /**
     * Set the route name.
     *
     * @param string $name
     * @return $this
     */
    public function name(string $name): self
    {
        $this->action['as'] = $name;

        return $this;
    }

    /**
     * Generate a URL for the route.
     *
     * @param array $parameters
     * @return string
     */
    public function generateUrl(array $parameters = []): string
    {
        $path = $this->uri;

        // Replace named parameters
        foreach ($parameters as $key => $value) {
            $path = str_replace("{{$key}}", $value, $path);
        }

        // Replace any remaining optional parameters
        $path = preg_replace('/\{(\w+)\?}/', '', $path);

        // Replace any remaining required parameters with defaults
        foreach ($this->defaults as $key => $value) {
            $path = str_replace("{{$key}}", $value, $path);
        }

        return $path;
    }

    /**
     * Determine if the route is a fallback route.
     *
     * @return bool
     */
    public function isFallback(): bool
    {
        return isset($this->action['fallback']) && $this->action['fallback'];
    }

    /**
     * Mark the route as a fallback route.
     *
     * @return $this
     */
    public function fallback(): self
    {
        $this->action['fallback'] = true;

        return $this;
    }
}
