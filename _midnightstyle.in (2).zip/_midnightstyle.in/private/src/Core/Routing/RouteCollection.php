<?php

namespace App\Core\Routing;

class RouteCollection
{
    /**
     * All registered routes.
     *
     * @var Route[]
     */
    protected $routes = [];

    /**
     * Routes lookup by method.
     *
     * @var array
     */
    protected $methodRoutes = [];

    /**
     * Named routes lookup.
     *
     * @var array
     */
    protected $nameList = [];

    /**
     * Add a Route instance to the collection.
     *
     * @param Route $route
     * @return void
     */
    public function add(Route $route): void
    {
        $this->addToLookups($route);
        $this->routes[] = $route;
    }

    /**
     * Add the route to the lookup arrays.
     *
     * @param Route $route
     * @return void
     */
    protected function addToLookups(Route $route): void
    {
        // Add to method lookup
        foreach ($route->getMethods() as $method) {
            $this->methodRoutes[$method][] = $route;
        }

        // Add to name lookup if named
        $name = $route->getName();
        if ($name) {
            $this->nameList[$name] = $route;
        }
    }

    /**
     * Find routes matching the given HTTP method and path.
     *
     * @param string $method
     * @param string $path
     * @return Route[]
     */
    public function match(string $method, string $path): array
    {
        $routes = [];

        // Check method-specific routes
        if (isset($this->methodRoutes[$method])) {
            foreach ($this->methodRoutes[$method] as $route) {
                if ($route->matches($method, $path)) {
                    $routes[] = $route;
                }
            }
        }

        // If no routes found and this is a HEAD request, try GET routes
        if (empty($routes) && $method === 'HEAD' && isset($this->methodRoutes['GET'])) {
            foreach ($this->methodRoutes['GET'] as $route) {
                if ($route->matches('GET', $path)) {
                    $routes[] = $route;
                }
            }
        }

        // Check for fallback routes if no matches found
        if (empty($routes)) {
            foreach ($this->routes as $route) {
                if ($route->isFallback() && in_array($method, $route->getMethods())) {
                    $routes[] = $route;
                    break;
                }
            }
        }

        return $routes;
    }

    /**
     * Get all registered routes.
     *
     * @return Route[]
     */
    public function getRoutes(): array
    {
        return $this->routes;
    }

    /**
     * Get a route by name.
     *
     * @param string $name
     * @return Route|null
     */
    public function getByName(string $name): ?Route
    {
        return $this->nameList[$name] ?? null;
    }

    /**
     * Get all routes registered for a given HTTP method.
     *
     * @param string $method
     * @return Route[]
     */
    public function getByMethod(string $method): array
    {
        return $this->methodRoutes[$method] ?? [];
    }

    /**
     * Get all methods that match a given URI.
     *
     * @param string $uri
     * @return array
     */
    public function getMethodsForUri(string $uri): array
    {
        $methods = [];

        foreach ($this->methodRoutes as $method => $routes) {
            foreach ($routes as $route) {
                if ($route->matches($method, $uri)) {
                    $methods[] = $method;
                    break;
                }
            }
        }

        return $methods;
    }

    /**
     * Get all named routes.
     *
     * @return array
     */
    public function getNameList(): array
    {
        return $this->nameList;
    }

    /**
     * Check if a named route exists.
     *
     * @param string $name
     * @return bool
     */
    public function hasNamedRoute(string $name): bool
    {
        return isset($this->nameList[$name]);
    }

    /**
     * Generate a URL for a named route.
     *
     * @param string $name
     * @param array $parameters
     * @return string
     * @throws \InvalidArgumentException
     */
    public function generateUrl(string $name, array $parameters = []): string
    {
        if (!isset($this->nameList[$name])) {
            throw new \InvalidArgumentException("Route [{$name}] not found.");
        }

        return $this->nameList[$name]->generateUrl($parameters);
    }

    /**
     * Get the number of registered routes.
     *
     * @return int
     */
    public function count(): int
    {
        return count($this->routes);
    }

    /**
     * Clear all registered routes.
     *
     * @return void
     */
    public function clear(): void
    {
        $this->routes = [];
        $this->methodRoutes = [];
        $this->nameList = [];
    }

    /**
     * Get routes where the URI matches a pattern.
     *
     * @param string $pattern
     * @return Route[]
     */
    public function getRoutesByPattern(string $pattern): array
    {
        $matches = [];

        foreach ($this->routes as $route) {
            if (preg_match($pattern, $route->getUri())) {
                $matches[] = $route;
            }
        }

        return $matches;
    }

    /**
     * Get routes that use specific middleware.
     *
     * @param string $middleware
     * @return Route[]
     */
    public function getRoutesByMiddleware(string $middleware): array
    {
        $matches = [];

        foreach ($this->routes as $route) {
            if (in_array($middleware, $route->getMiddleware())) {
                $matches[] = $route;
            }
        }

        return $matches;
    }

    /**
     * Get a list of all registered URIs.
     *
     * @return array
     */
    public function getUris(): array
    {
        return array_unique(array_map(function ($route) {
            return $route->getUri();
        }, $this->routes));
    }

    /**
     * Get a list of all registered middleware.
     *
     * @return array
     */
    public function getMiddleware(): array
    {
        $middleware = [];

        foreach ($this->routes as $route) {
            $middleware = array_merge($middleware, $route->getMiddleware());
        }

        return array_unique($middleware);
    }
}
