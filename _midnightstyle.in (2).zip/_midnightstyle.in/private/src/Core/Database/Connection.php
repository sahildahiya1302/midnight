<?php

namespace App\Core\Database;

use PDO;
use PDOStatement;
use PDOException;
use Exception;

class Connection
{
    private PDO $pdo;
    private array $config;
    private bool $inTransaction = false;
    private array $queryLog = [];
    private bool $loggingEnabled = false;

    public function __construct(PDO $pdo, array $config)
    {
        $this->pdo = $pdo;
        $this->config = $config;
        $this->loggingEnabled = $config['logging'] ?? false;
    }

    /**
     * Begin a transaction
     */
    public function beginTransaction(): bool
    {
        if (!$this->inTransaction) {
            $this->inTransaction = $this->pdo->beginTransaction();
            return $this->inTransaction;
        }
        return false;
    }

    /**
     * Commit a transaction
     */
    public function commit(): bool
    {
        if ($this->inTransaction) {
            $this->inTransaction = false;
            return $this->pdo->commit();
        }
        return false;
    }

    /**
     * Rollback a transaction
     */
    public function rollBack(): bool
    {
        if ($this->inTransaction) {
            $this->inTransaction = false;
            return $this->pdo->rollBack();
        }
        return false;
    }

    /**
     * Execute a query and return the statement
     */
    public function query(string $query, array $params = []): PDOStatement
    {
        $start = microtime(true);

        try {
            $stmt = $this->pdo->prepare($query);
            $stmt->execute($params);

            if ($this->loggingEnabled) {
                $this->logQuery($query, $params, microtime(true) - $start);
            }

            return $stmt;
        } catch (PDOException $e) {
            throw new PDOException(
                "Query failed: " . $e->getMessage() . "\nQuery: $query",
                (int)$e->getCode(),
                $e
            );
        }
    }

    /**
     * Execute a query and return the number of affected rows
     */
    public function execute(string $query, array $params = []): int
    {
        return $this->query($query, $params)->rowCount();
    }

    /**
     * Fetch a single row
     */
    public function fetchOne(string $query, array $params = []): ?array
    {
        $stmt = $this->query($query, $params);
        $result = $stmt->fetch();
        return $result !== false ? $result : null;
    }

    /**
     * Fetch all rows
     */
    public function fetchAll(string $query, array $params = []): array
    {
        return $this->query($query, $params)->fetchAll();
    }

    /**
     * Fetch a single column
     */
    public function fetchColumn(string $query, array $params = [], int $column = 0)
    {
        $stmt = $this->query($query, $params);
        $result = $stmt->fetchColumn($column);
        return $result !== false ? $result : null;
    }

    /**
     * Insert a row and return the last insert ID
     */
    public function insert(string $table, array $data): int
    {
        $columns = implode(', ', array_keys($data));
        $values = implode(', ', array_fill(0, count($data), '?'));
        
        $query = "INSERT INTO $table ($columns) VALUES ($values)";
        $this->query($query, array_values($data));
        
        return (int)$this->pdo->lastInsertId();
    }

    /**
     * Update rows and return the number of affected rows
     */
    public function update(string $table, array $data, string $where, array $params = []): int
    {
        $set = implode(', ', array_map(fn($col) => "$col = ?", array_keys($data)));
        $query = "UPDATE $table SET $set WHERE $where";
        
        return $this->execute($query, [...array_values($data), ...$params]);
    }

    /**
     * Delete rows and return the number of affected rows
     */
    public function delete(string $table, string $where, array $params = []): int
    {
        $query = "DELETE FROM $table WHERE $where";
        return $this->execute($query, $params);
    }

    /**
     * Get the underlying PDO instance
     */
    public function getPdo(): PDO
    {
        return $this->pdo;
    }

    /**
     * Quote a string
     */
    public function quote(string $value): string
    {
        return $this->pdo->quote($value);
    }

    /**
     * Enable or disable query logging
     */
    public function enableQueryLog(bool $enable = true): void
    {
        $this->loggingEnabled = $enable;
    }

    /**
     * Get the query log
     */
    public function getQueryLog(): array
    {
        return $this->queryLog;
    }

    /**
     * Clear the query log
     */
    public function clearQueryLog(): void
    {
        $this->queryLog = [];
    }

    /**
     * Log a query
     */
    private function logQuery(string $query, array $params, float $time): void
    {
        $this->queryLog[] = [
            'query' => $query,
            'params' => $params,
            'time' => $time,
            'memory' => memory_get_usage(true),
            'timestamp' => microtime(true)
        ];
    }

    /**
     * Create a backup of the database
     */
    public function backup(string $backupPath): bool
    {
        if ($this->inTransaction) {
            throw new Exception('Cannot backup database during transaction');
        }

        if ($this->config['driver'] !== 'sqlite') {
            throw new Exception('Backup only supported for SQLite databases');
        }

        try {
            $this->pdo->exec('BEGIN IMMEDIATE');
            copy($this->config['database'], $backupPath);
            $this->pdo->exec('COMMIT');
            return true;
        } catch (Exception $e) {
            $this->pdo->exec('ROLLBACK');
            throw $e;
        }
    }

    /**
     * Restore database from backup
     */
    public function restore(string $backupPath): bool
    {
        if ($this->inTransaction) {
            throw new Exception('Cannot restore database during transaction');
        }

        if ($this->config['driver'] !== 'sqlite') {
            throw new Exception('Restore only supported for SQLite databases');
        }

        if (!file_exists($backupPath)) {
            throw new Exception('Backup file not found');
        }

        try {
            // Close current connection
            $this->pdo = null;
            
            // Copy backup file
            copy($backupPath, $this->config['database']);
            
            // Reconnect
            $this->pdo = new PDO(
                "sqlite:" . $this->config['database'],
                null,
                null,
                $this->config['options'] ?? []
            );
            
            return true;
        } catch (Exception $e) {
            throw $e;
        }
    }

    /**
     * Run VACUUM to optimize the database
     */
    public function vacuum(): bool
    {
        if ($this->inTransaction) {
            throw new Exception('Cannot vacuum database during transaction');
        }

        if ($this->config['driver'] !== 'sqlite') {
            throw new Exception('Vacuum only supported for SQLite databases');
        }

        try {
            $this->pdo->exec('VACUUM');
            return true;
        } catch (PDOException $e) {
            throw new PDOException(
                "Vacuum failed: " . $e->getMessage(),
                (int)$e->getCode(),
                $e
            );
        }
    }
}
