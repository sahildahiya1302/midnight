<?php

namespace App\Core\Database;

use App\Core\Config\ConfigurationInterface;
use PDO;
use PDOException;

class DatabaseManager
{
    private array $connections = [];
    private ?string $default = null;
    private ConfigurationInterface $config;

    public function __construct(ConfigurationInterface $config)
    {
        $this->config = $config;
        $this->default = $config->get('database.default', 'default');
    }

    /**
     * Get a database connection
     */
    public function connection(?string $name = null): Connection
    {
        $name = $name ?: $this->default;

        if (!isset($this->connections[$name])) {
            $this->connections[$name] = $this->makeConnection($name);
        }

        return $this->connections[$name];
    }

    /**
     * Create a new connection
     */
    private function makeConnection(string $name): Connection
    {
        $config = $this->config->get("database.connections.{$name}");

        if (!$config) {
            throw new PDOException("Database connection [$name] not configured.");
        }

        return new Connection(
            $this->createPDO($config),
            $config
        );
    }

    /**
     * Create a new PDO instance
     */
    private function createPDO(array $config): PDO
    {
        try {
            $dsn = $this->createDsn($config);
            $options = $config['options'] ?? [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];

            $pdo = new PDO(
                $dsn,
                $config['username'] ?? null,
                $config['password'] ?? null,
                $options
            );

            if (isset($config['init_commands'])) {
                foreach ($config['init_commands'] as $command) {
                    $pdo->exec($command);
                }
            }

            return $pdo;
        } catch (PDOException $e) {
            throw new PDOException(
                "Failed to connect to database: " . $e->getMessage(),
                (int)$e->getCode(),
                $e
            );
        }
    }

    /**
     * Create the DSN string
     */
    private function createDsn(array $config): string
    {
        $driver = $config['driver'] ?? 'sqlite';

        return match($driver) {
            'sqlite' => $this->createSqliteDsn($config),
            'mysql' => $this->createMysqlDsn($config),
            default => throw new PDOException("Unsupported database driver: $driver")
        };
    }

    /**
     * Create SQLite DSN
     */
    private function createSqliteDsn(array $config): string
    {
        $path = $config['database'];

        if ($path === ':memory:') {
            return 'sqlite::memory:';
        }

        $realPath = realpath($path);
        if ($realPath === false) {
            // Create directory if it doesn't exist
            $dir = dirname($path);
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
            $realPath = $path;
        }

        return "sqlite:$realPath";
    }

    /**
     * Create MySQL DSN
     */
    private function createMysqlDsn(array $config): string
    {
        $host = $config['host'] ?? 'localhost';
        $port = $config['port'] ?? 3306;
        $database = $config['database'];
        $charset = $config['charset'] ?? 'utf8mb4';

        return "mysql:host=$host;port=$port;dbname=$database;charset=$charset";
    }

    /**
     * Disconnect from the given database
     */
    public function disconnect(?string $name = null): void
    {
        $name = $name ?: $this->default;
        unset($this->connections[$name]);
    }

    /**
     * Reconnect to the given database
     */
    public function reconnect(?string $name = null): Connection
    {
        $name = $name ?: $this->default;
        $this->disconnect($name);
        return $this->connection($name);
    }

    /**
     * Get all database connections
     */
    public function getConnections(): array
    {
        return $this->connections;
    }

    /**
     * Set the default connection name
     */
    public function setDefault(string $name): void
    {
        $this->default = $name;
    }

    /**
     * Get the default connection name
     */
    public function getDefault(): string
    {
        return $this->default;
    }
}
