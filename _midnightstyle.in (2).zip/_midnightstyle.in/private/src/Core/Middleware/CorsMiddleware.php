<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Config\ConfigurationInterface;

class CorsMiddleware implements MiddlewareInterface
{
    private ConfigurationInterface $config;
    private array $settings;

    public function __construct(ConfigurationInterface $config)
    {
        $this->config = $config;
        $this->settings = $this->getDefaultSettings();
    }

    public function handle(Request $request, callable $next): Response
    {
        // Handle preflight requests
        if ($request->getMethod() === 'OPTIONS') {
            return $this->handlePreflight($request);
        }

        // Handle actual request
        $response = $next($request);
        return $this->addCorsHeaders($request, $response);
    }

    /**
     * Handle preflight request
     */
    private function handlePreflight(Request $request): Response
    {
        $response = new Response('', 204);

        // Add CORS headers
        return $this->addCorsHeaders($request, $response);
    }

    /**
     * Add CORS headers to response
     */
    private function addCorsHeaders(Request $request, Response $response): Response
    {
        // Origin header
        $origin = $request->header('Origin');
        if ($origin && $this->isAllowedOrigin($origin)) {
            $response->setHeader('Access-Control-Allow-Origin', $origin);
        }

        // Vary header
        $response->setHeader('Vary', 'Origin');

        // Allow credentials
        if ($this->settings['supports_credentials']) {
            $response->setHeader('Access-Control-Allow-Credentials', 'true');
        }

        // Expose headers
        if (!empty($this->settings['exposed_headers'])) {
            $response->setHeader('Access-Control-Expose-Headers', 
                implode(', ', $this->settings['exposed_headers'])
            );
        }

        // Handle preflight request
        if ($request->getMethod() === 'OPTIONS') {
            // Allow methods
            if (!empty($this->settings['allowed_methods'])) {
                $response->setHeader('Access-Control-Allow-Methods',
                    implode(', ', $this->settings['allowed_methods'])
                );
            }

            // Allow headers
            $requestHeaders = $request->header('Access-Control-Request-Headers');
            if ($requestHeaders) {
                $response->setHeader('Access-Control-Allow-Headers', $requestHeaders);
            } elseif (!empty($this->settings['allowed_headers'])) {
                $response->setHeader('Access-Control-Allow-Headers',
                    implode(', ', $this->settings['allowed_headers'])
                );
            }

            // Max age
            if ($this->settings['max_age'] !== null) {
                $response->setHeader('Access-Control-Max-Age', 
                    (string)$this->settings['max_age']
                );
            }
        }

        return $response;
    }

    /**
     * Check if origin is allowed
     */
    private function isAllowedOrigin(string $origin): bool
    {
        if (in_array('*', $this->settings['allowed_origins'])) {
            return true;
        }

        return in_array($origin, $this->settings['allowed_origins']);
    }

    /**
     * Get default CORS settings
     */
    private function getDefaultSettings(): array
    {
        return array_merge([
            'allowed_origins' => ['*'],
            'allowed_methods' => ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
            'allowed_headers' => [
                'Content-Type',
                'X-Requested-With',
                'Authorization',
                'Accept',
                'Origin'
            ],
            'exposed_headers' => [],
            'max_age' => 86400,
            'supports_credentials' => false
        ], $this->config->get('cors', []));
    }

    /**
     * Set allowed origins
     */
    public function setAllowedOrigins(array $origins): self
    {
        $this->settings['allowed_origins'] = $origins;
        return $this;
    }

    /**
     * Set allowed methods
     */
    public function setAllowedMethods(array $methods): self
    {
        $this->settings['allowed_methods'] = array_map('strtoupper', $methods);
        return $this;
    }

    /**
     * Set allowed headers
     */
    public function setAllowedHeaders(array $headers): self
    {
        $this->settings['allowed_headers'] = $headers;
        return $this;
    }

    /**
     * Set exposed headers
     */
    public function setExposedHeaders(array $headers): self
    {
        $this->settings['exposed_headers'] = $headers;
        return $this;
    }

    /**
     * Set max age
     */
    public function setMaxAge(?int $maxAge): self
    {
        $this->settings['max_age'] = $maxAge;
        return $this;
    }

    /**
     * Set supports credentials
     */
    public function setSupportsCredentials(bool $supports): self
    {
        $this->settings['supports_credentials'] = $supports;
        return $this;
    }

    /**
     * Get current settings
     */
    public function getSettings(): array
    {
        return $this->settings;
    }

    /**
     * Add an allowed origin
     */
    public function addAllowedOrigin(string $origin): self
    {
        if (!in_array($origin, $this->settings['allowed_origins'])) {
            $this->settings['allowed_origins'][] = $origin;
        }
        return $this;
    }

    /**
     * Add an allowed method
     */
    public function addAllowedMethod(string $method): self
    {
        $method = strtoupper($method);
        if (!in_array($method, $this->settings['allowed_methods'])) {
            $this->settings['allowed_methods'][] = $method;
        }
        return $this;
    }

    /**
     * Add an allowed header
     */
    public function addAllowedHeader(string $header): self
    {
        if (!in_array($header, $this->settings['allowed_headers'])) {
            $this->settings['allowed_headers'][] = $header;
        }
        return $this;
    }

    /**
     * Add an exposed header
     */
    public function addExposedHeader(string $header): self
    {
        if (!in_array($header, $this->settings['exposed_headers'])) {
            $this->settings['exposed_headers'][] = $header;
        }
        return $this;
    }
}
