<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Http\JsonResponse;
use App\Core\Http\RedirectResponse;
use App\Core\Security\Auth\AuthenticationInterface;

class GuestMiddleware implements MiddlewareInterface
{
    private AuthenticationInterface $auth;

    public function __construct(AuthenticationInterface $auth)
    {
        $this->auth = $auth;
    }

    public function handle(Request $request, callable $next): Response
    {
        if ($this->auth->check()) {
            if ($request->isAjax()) {
                return JsonResponse::error('You are already logged in', null, 400);
            }

            // Redirect to dashboard or home page
            $redirectTo = $_ENV['AUTH_HOME'] ?? '/dashboard';
            return new RedirectResponse($redirectTo, 302, [
                'X-Error-Message' => 'You are already logged in'
            ]);
        }

        return $next($request);
    }
}
