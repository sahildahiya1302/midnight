<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Container;

class MiddlewareStack
{
    private Container $container;
    private array $middleware = [];
    private array $middlewareGroups = [];
    private array $middlewareAliases = [];

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Add middleware to the stack
     */
    public function add(string|array|callable $middleware): self
    {
        if (is_array($middleware)) {
            foreach ($middleware as $m) {
                $this->add($m);
            }
            return $this;
        }

        $this->middleware[] = $middleware;
        return $this;
    }

    /**
     * Add middleware group
     */
    public function addGroup(string $name, array $middleware): self
    {
        $this->middlewareGroups[$name] = $middleware;
        return $this;
    }

    /**
     * Add middleware alias
     */
    public function addAlias(string $alias, string $middleware): self
    {
        $this->middlewareAliases[$alias] = $middleware;
        return $this;
    }

    /**
     * Process the middleware stack
     */
    public function process(Request $request, callable $handler): Response
    {
        $pipeline = array_reduce(
            array_reverse($this->resolveMiddleware()),
            $this->carry(),
            $handler
        );

        return $pipeline($request);
    }

    /**
     * Create middleware pipeline
     */
    private function carry(): callable
    {
        return function ($stack, $middleware) {
            return function (Request $request) use ($stack, $middleware) {
                $next = function (Request $request) use ($stack) {
                    return $stack($request);
                };

                if (is_string($middleware)) {
                    $middleware = $this->resolveMiddlewareClass($middleware);
                }

                return $middleware->handle($request, $next);
            };
        };
    }

    /**
     * Resolve middleware class from container
     */
    private function resolveMiddlewareClass(string $middleware): MiddlewareInterface
    {
        // Check for alias
        if (isset($this->middlewareAliases[$middleware])) {
            $middleware = $this->middlewareAliases[$middleware];
        }

        if (!class_exists($middleware)) {
            throw new \RuntimeException("Middleware class not found: $middleware");
        }

        $instance = $this->container->make($middleware);

        if (!$instance instanceof MiddlewareInterface) {
            throw new \RuntimeException(
                "Middleware must implement MiddlewareInterface: $middleware"
            );
        }

        return $instance;
    }

    /**
     * Resolve middleware stack
     */
    private function resolveMiddleware(): array
    {
        $resolved = [];

        foreach ($this->middleware as $middleware) {
            if (is_string($middleware) && isset($this->middlewareGroups[$middleware])) {
                // Resolve middleware group
                foreach ($this->middlewareGroups[$middleware] as $groupMiddleware) {
                    $resolved[] = $groupMiddleware;
                }
            } else {
                $resolved[] = $middleware;
            }
        }

        return array_unique($resolved);
    }

    /**
     * Get all registered middleware
     */
    public function getMiddleware(): array
    {
        return $this->middleware;
    }

    /**
     * Get all middleware groups
     */
    public function getMiddlewareGroups(): array
    {
        return $this->middlewareGroups;
    }

    /**
     * Get all middleware aliases
     */
    public function getMiddlewareAliases(): array
    {
        return $this->middlewareAliases;
    }

    /**
     * Clear all middleware
     */
    public function clear(): self
    {
        $this->middleware = [];
        return $this;
    }

    /**
     * Clear middleware groups
     */
    public function clearGroups(): self
    {
        $this->middlewareGroups = [];
        return $this;
    }

    /**
     * Clear middleware aliases
     */
    public function clearAliases(): self
    {
        $this->middlewareAliases = [];
        return $this;
    }

    /**
     * Check if middleware exists
     */
    public function has(string $middleware): bool
    {
        return in_array($middleware, $this->middleware);
    }

    /**
     * Check if middleware group exists
     */
    public function hasGroup(string $name): bool
    {
        return isset($this->middlewareGroups[$name]);
    }

    /**
     * Check if middleware alias exists
     */
    public function hasAlias(string $alias): bool
    {
        return isset($this->middlewareAliases[$alias]);
    }

    /**
     * Remove middleware
     */
    public function remove(string $middleware): self
    {
        $this->middleware = array_filter(
            $this->middleware,
            fn($m) => $m !== $middleware
        );
        return $this;
    }

    /**
     * Remove middleware group
     */
    public function removeGroup(string $name): self
    {
        unset($this->middlewareGroups[$name]);
        return $this;
    }

    /**
     * Remove middleware alias
     */
    public function removeAlias(string $alias): self
    {
        unset($this->middlewareAliases[$alias]);
        return $this;
    }
}
