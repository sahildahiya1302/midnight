<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Http\JsonResponse;
use App\Core\Http\RedirectResponse;
use App\Core\Security\Auth\AuthenticationInterface;

class AuthMiddleware implements MiddlewareInterface
{
    private AuthenticationInterface $auth;

    public function __construct(AuthenticationInterface $auth)
    {
        $this->auth = $auth;
    }

    public function handle(Request $request, callable $next): Response
    {
        if (!$this->auth->check()) {
            if ($request->isAjax()) {
                return JsonResponse::unauthorized('Please login to continue');
            }

            // Store intended URL for post-login redirect
            RedirectResponse::setIntendedUrl($request->getUri());
            
            return new RedirectResponse('/login', 302, [
                'X-Error-Message' => 'Please login to continue'
            ]);
        }

        // Check if user is active
        $user = $this->auth->user();
        if (!$user->isActive()) {
            $this->auth->logout();

            if ($request->isAjax()) {
                return JsonResponse::forbidden('Your account has been suspended');
            }

            return new RedirectResponse('/login', 302, [
                'X-Error-Message' => 'Your account has been suspended'
            ]);
        }

        // Check if user's session has expired
        if ($this->hasSessionExpired()) {
            $this->auth->logout();

            if ($request->isAjax()) {
                return JsonResponse::unauthorized('Session expired, please login again');
            }

            return new RedirectResponse('/login', 302, [
                'X-Error-Message' => 'Session expired, please login again'
            ]);
        }

        // Update last activity timestamp
        $this->updateLastActivity();

        return $next($request);
    }

    /**
     * Check if the session has expired
     */
    private function hasSessionExpired(): bool
    {
        if (!isset($_SESSION['_last_activity'])) {
            return true;
        }

        $timeout = $_ENV['SESSION_LIFETIME'] ?? 7200; // 2 hours default
        return (time() - $_SESSION['_last_activity']) > $timeout;
    }

    /**
     * Update last activity timestamp
     */
    private function updateLastActivity(): void
    {
        $_SESSION['_last_activity'] = time();
    }
}
