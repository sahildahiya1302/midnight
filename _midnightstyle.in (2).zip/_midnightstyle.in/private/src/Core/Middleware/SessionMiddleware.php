<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Session\SessionManager;

class SessionMiddleware implements MiddlewareInterface
{
    private SessionManager $session;
    private array $config;

    public function __construct(SessionManager $session, array $config = [])
    {
        $this->session = $session;
        $this->config = array_merge([
            'lifetime' => 7200,             // Session lifetime in seconds (2 hours)
            'path' => '/',                  // Cookie path
            'domain' => null,               // Cookie domain
            'secure' => true,               // Only transmit cookie over HTTPS
            'httponly' => true,             // Prevent JavaScript access to session cookie
            'samesite' => 'Lax',           // Cookie SameSite attribute
            'gc_probability' => 1,          // Garbage collection probability (1%)
            'gc_divisor' => 100,           // Garbage collection divisor
            'regenerate_interval' => 300,   // Session ID regeneration interval (5 minutes)
            'rotate_interval' => 3600       // Session data rotation interval (1 hour)
        ], $config);
    }

    public function handle(Request $request, callable $next): Response
    {
        // Configure session
        $this->configureSession();

        // Start session
        $this->session->start();

        try {
            // Handle the request
            $response = $next($request);

            // Process flash data
            $this->processFlashData();

            // Perform session maintenance
            $this->performMaintenance();

            return $response;

        } catch (\Throwable $e) {
            // Ensure session data is saved even if an error occurs
            if ($this->session->isStarted()) {
                session_write_close();
            }
            throw $e;
        }
    }

    /**
     * Configure session settings
     */
    private function configureSession(): void
    {
        // Set session cookie parameters
        session_set_cookie_params([
            'lifetime' => $this->config['lifetime'],
            'path' => $this->config['path'],
            'domain' => $this->config['domain'],
            'secure' => $this->config['secure'],
            'httponly' => $this->config['httponly'],
            'samesite' => $this->config['samesite']
        ]);

        // Set garbage collection probability
        ini_set('session.gc_probability', $this->config['gc_probability']);
        ini_set('session.gc_divisor', $this->config['gc_divisor']);
        ini_set('session.gc_maxlifetime', $this->config['lifetime']);

        // Set session name if configured
        if (isset($this->config['name'])) {
            session_name($this->config['name']);
        }
    }

    /**
     * Process flash data
     */
    private function processFlashData(): void
    {
        // Move current flash data to old flash data
        if (isset($_SESSION['_flash'])) {
            $_SESSION['_old_flash'] = $_SESSION['_flash'];
            unset($_SESSION['_flash']);
        }

        // Clear old flash data
        if (isset($_SESSION['_old_flash'])) {
            unset($_SESSION['_old_flash']);
        }
    }

    /**
     * Perform session maintenance
     */
    private function performMaintenance(): void
    {
        $time = time();

        // Regenerate session ID periodically
        if (!isset($_SESSION['_last_regenerate']) ||
            $time - $_SESSION['_last_regenerate'] > $this->config['regenerate_interval']) {
            $this->session->regenerate();
            $_SESSION['_last_regenerate'] = $time;
        }

        // Rotate session data periodically
        if (!isset($_SESSION['_last_rotate']) ||
            $time - $_SESSION['_last_rotate'] > $this->config['rotate_interval']) {
            $this->rotateSessionData();
            $_SESSION['_last_rotate'] = $time;
        }
    }

    /**
     * Rotate session data
     */
    private function rotateSessionData(): void
    {
        $sessionData = $_SESSION;

        // Start new session
        session_destroy();
        $this->session->start();

        // Restore session data
        $_SESSION = $sessionData;
    }

    /**
     * Get session configuration
     */
    public function getConfig(): array
    {
        return $this->config;
    }

    /**
     * Set session configuration
     */
    public function setConfig(array $config): void
    {
        $this->config = array_merge($this->config, $config);
    }

    /**
     * Get session manager instance
     */
    public function getSessionManager(): SessionManager
    {
        return $this->session;
    }
}
