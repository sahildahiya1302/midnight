<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Http\JsonResponse;
use App\Core\Security\CSRF\CSRFProtection;
use Exception;

class CSRFMiddleware implements MiddlewareInterface
{
    private CSRFProtection $csrf;
    private array $excludedPaths;
    private array $excludedMethods;

    public function __construct(
        CSRFProtection $csrf,
        array $excludedPaths = [],
        array $excludedMethods = ['GET', 'HEAD', 'OPTIONS']
    ) {
        $this->csrf = $csrf;
        $this->excludedPaths = $excludedPaths;
        $this->excludedMethods = array_map('strtoupper', $excludedMethods);
    }

    public function handle(Request $request, callable $next): Response
    {
        // Skip CSRF check for excluded methods
        if (in_array($request->getMethod(), $this->excludedMethods)) {
            return $next($request);
        }

        // Skip CSRF check for excluded paths
        $path = $request->getPath();
        foreach ($this->excludedPaths as $excludedPath) {
            if ($this->pathMatches($path, $excludedPath)) {
                return $next($request);
            }
        }

        try {
            // Validate CSRF token
            if (!$this->csrf->validateToken()) {
                if ($request->isAjax()) {
                    return JsonResponse::error('CSRF token mismatch', null, 419);
                }

                throw new Exception('CSRF token mismatch');
            }

            // Generate new token for next request
            $response = $next($request);
            $this->csrf->refreshToken();

            return $response;

        } catch (Exception $e) {
            if ($request->isAjax()) {
                return JsonResponse::error($e->getMessage(), null, 419);
            }

            // Redirect back with error
            return new RedirectResponse(
                $request->server('HTTP_REFERER', '/'),
                302,
                ['X-Error-Message' => $e->getMessage()]
            );
        }
    }

    /**
     * Check if path matches pattern
     */
    private function pathMatches(string $path, string $pattern): bool
    {
        $pattern = str_replace('*', '.*', preg_quote($pattern, '/'));
        return (bool)preg_match('/^' . $pattern . '$/', $path);
    }

    /**
     * Add excluded path
     */
    public function addExcludedPath(string $path): void
    {
        $this->excludedPaths[] = $path;
    }

    /**
     * Add excluded method
     */
    public function addExcludedMethod(string $method): void
    {
        $this->excludedMethods[] = strtoupper($method);
    }

    /**
     * Set excluded paths
     */
    public function setExcludedPaths(array $paths): void
    {
        $this->excludedPaths = $paths;
    }

    /**
     * Set excluded methods
     */
    public function setExcludedMethods(array $methods): void
    {
        $this->excludedMethods = array_map('strtoupper', $methods);
    }

    /**
     * Get excluded paths
     */
    public function getExcludedPaths(): array
    {
        return $this->excludedPaths;
    }

    /**
     * Get excluded methods
     */
    public function getExcludedMethods(): array
    {
        return $this->excludedMethods;
    }
}
