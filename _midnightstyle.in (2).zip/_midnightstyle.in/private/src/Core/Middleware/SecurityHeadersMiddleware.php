<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Config\ConfigurationInterface;

class SecurityHeadersMiddleware implements MiddlewareInterface
{
    private ConfigurationInterface $config;
    private array $headers;

    public function __construct(ConfigurationInterface $config)
    {
        $this->config = $config;
        $this->headers = $this->getDefaultHeaders();
    }

    public function handle(Request $request, callable $next): Response
    {
        $response = $next($request);

        // Add security headers
        foreach ($this->headers as $header => $value) {
            if ($value !== null) {
                $response->setHeader($header, $value);
            }
        }

        return $response;
    }

    /**
     * Get default security headers
     */
    private function getDefaultHeaders(): array
    {
        return [
            // Prevent browsers from MIME-sniffing the response
            'X-Content-Type-Options' => 'nosniff',

            // Enable browser's XSS filtering
            'X-XSS-Protection' => '1; mode=block',

            // Control how much information the browser includes with navigational requests
            'Referrer-Policy' => 'strict-origin-when-cross-origin',

            // Prevent page from being displayed in an iframe (clickjacking protection)
            'X-Frame-Options' => 'DENY',

            // Enable strict transport security (force HTTPS)
            'Strict-Transport-Security' => 'max-age=31536000; includeSubDomains',

            // Control which features and APIs can be used in the browser
            'Permissions-Policy' => $this->getPermissionsPolicy(),

            // Content Security Policy
            'Content-Security-Policy' => $this->getContentSecurityPolicy(),

            // Disable powered by header
            'X-Powered-By' => null,

            // Cache control
            'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0',
            'Pragma' => 'no-cache',
            'Expires' => '0',
        ];
    }

    /**
     * Get Content Security Policy
     */
    private function getContentSecurityPolicy(): string
    {
        $policies = [
            // Default fallback
            "default-src 'self'",

            // Scripts
            "script-src 'self' 'unsafe-inline' 'unsafe-eval'",

            // Styles
            "style-src 'self' 'unsafe-inline'",

            // Images
            "img-src 'self' data: https:",

            // Fonts
            "font-src 'self' data: https:",

            // Connect (XHR, WebSocket)
            "connect-src 'self'",

            // Media
            "media-src 'self'",

            // Object/Embed
            "object-src 'none'",

            // Forms
            "form-action 'self'",

            // Frames
            "frame-ancestors 'none'",

            // Base URI
            "base-uri 'self'",

            // Manifest
            "manifest-src 'self'",

            // Worker
            "worker-src 'self'",

            // Upgrade insecure requests
            "upgrade-insecure-requests"
        ];

        // Get custom policies from config
        $customPolicies = $this->config->get('security.csp', []);
        
        return implode('; ', array_merge($policies, $customPolicies));
    }

    /**
     * Get Permissions Policy
     */
    private function getPermissionsPolicy(): string
    {
        $policies = [
            'accelerometer' => '()',
            'ambient-light-sensor' => '()',
            'autoplay' => '()',
            'battery' => '()',
            'camera' => '()',
            'display-capture' => '()',
            'document-domain' => '()',
            'encrypted-media' => '()',
            'execution-while-not-rendered' => '()',
            'execution-while-out-of-viewport' => '()',
            'fullscreen' => '(self)',
            'geolocation' => '()',
            'gyroscope' => '()',
            'layout-animations' => '(self)',
            'legacy-image-formats' => '(self)',
            'magnetometer' => '()',
            'microphone' => '()',
            'midi' => '()',
            'navigation-override' => '()',
            'payment' => '()',
            'picture-in-picture' => '()',
            'publickey-credentials-get' => '()',
            'screen-wake-lock' => '()',
            'sync-xhr' => '(self)',
            'usb' => '()',
            'web-share' => '()',
            'xr-spatial-tracking' => '()'
        ];

        // Get custom policies from config
        $customPolicies = $this->config->get('security.permissions_policy', []);
        $policies = array_merge($policies, $customPolicies);

        // Build policy string
        $policyStrings = [];
        foreach ($policies as $feature => $allowlist) {
            $policyStrings[] = "$feature=$allowlist";
        }

        return implode(', ', $policyStrings);
    }

    /**
     * Set a custom header
     */
    public function setHeader(string $name, ?string $value): self
    {
        $this->headers[$name] = $value;
        return $this;
    }

    /**
     * Set multiple headers
     */
    public function setHeaders(array $headers): self
    {
        $this->headers = array_merge($this->headers, $headers);
        return $this;
    }

    /**
     * Remove a header
     */
    public function removeHeader(string $name): self
    {
        unset($this->headers[$name]);
        return $this;
    }

    /**
     * Get all headers
     */
    public function getHeaders(): array
    {
        return $this->headers;
    }
}
