<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Http\JsonResponse;
use App\Core\View\ViewEngine;
use App\Core\Config\ConfigurationInterface;
use Throwable;
use Exception;
use Error;
use PDOException;

class ErrorHandlerMiddleware implements MiddlewareInterface
{
    private ConfigurationInterface $config;
    private ViewEngine $view;
    private bool $debug;
    private string $errorLogPath;

    public function __construct(
        ConfigurationInterface $config,
        ViewEngine $view
    ) {
        $this->config = $config;
        $this->view = $view;
        $this->debug = $config->get('app.debug', false);
        $this->errorLogPath = $config->get('app.error_log', 'logs/error.log');
    }

    public function handle(Request $request, callable $next): Response
    {
        try {
            // Set error handling
            $this->registerErrorHandlers();

            // Handle the request
            return $next($request);

        } catch (Throwable $e) {
            return $this->handleException($e, $request);
        }
    }

    /**
     * Register error and exception handlers
     */
    private function registerErrorHandlers(): void
    {
        set_error_handler([$this, 'handleError']);
        set_exception_handler([$this, 'handleException']);
        register_shutdown_function([$this, 'handleShutdown']);
    }

    /**
     * Handle PHP errors
     */
    public function handleError(
        int $level,
        string $message,
        string $file = '',
        int $line = 0
    ): bool {
        if (error_reporting() & $level) {
            throw new ErrorException($message, 0, $level, $file, $line);
        }

        return false;
    }

    /**
     * Handle exceptions
     */
    public function handleException(Throwable $e, ?Request $request = null): Response
    {
        // Log the error
        $this->logException($e);

        // Determine if request expects JSON
        $wantsJson = $request && ($request->isAjax() || 
            strpos($request->header('Accept', ''), 'application/json') !== false);

        // Get status code
        $status = $this->getStatusCode($e);

        if ($wantsJson) {
            return $this->createJsonResponse($e, $status);
        }

        return $this->createHtmlResponse($e, $status);
    }

    /**
     * Handle fatal errors
     */
    public function handleShutdown(): void
    {
        $error = error_get_last();
        
        if ($error !== null && in_array($error['type'], [E_ERROR, E_CORE_ERROR, E_COMPILE_ERROR, E_PARSE])) {
            $e = new ErrorException(
                $error['message'], 
                0, 
                $error['type'], 
                $error['file'], 
                $error['line']
            );
            
            $this->handleException($e);
        }
    }

    /**
     * Create JSON error response
     */
    private function createJsonResponse(Throwable $e, int $status): JsonResponse
    {
        $data = [
            'success' => false,
            'message' => $this->getErrorMessage($e),
        ];

        if ($this->debug) {
            $data['debug'] = [
                'exception' => get_class($e),
                'file' => $e->getFile(),
                'line' => $e->getLine(),
                'trace' => $e->getTrace()
            ];
        }

        return new JsonResponse($data, $status);
    }

    /**
     * Create HTML error response
     */
    private function createHtmlResponse(Throwable $e, int $status): Response
    {
        $view = $this->getErrorView($status);
        
        try {
            $content = $this->view->render($view, [
                'exception' => $e,
                'message' => $this->getErrorMessage($e),
                'debug' => $this->debug,
                'status' => $status
            ]);
        } catch (Throwable $e) {
            // Fallback to basic error page if view rendering fails
            $content = $this->getFallbackErrorContent($e, $status);
        }

        return new Response($content, $status);
    }

    /**
     * Get appropriate error view
     */
    private function getErrorView(int $status): string
    {
        $views = [
            '403' => 'errors/403',
            '404' => 'errors/404',
            '419' => 'errors/419', // CSRF token mismatch
            '429' => 'errors/429', // Too many requests
            '500' => 'errors/500',
            '503' => 'errors/503'
        ];

        return $views[$status] ?? 'errors/500';
    }

    /**
     * Get fallback error content
     */
    private function getFallbackErrorContent(Throwable $e, int $status): string
    {
        $message = $this->getErrorMessage($e);
        
        return "<!DOCTYPE html>
                <html>
                <head>
                    <title>Error $status</title>
                </head>
                <body>
                    <h1>Error $status</h1>
                    <p>$message</p>
                </body>
                </html>";
    }

    /**
     * Get appropriate status code for exception
     */
    private function getStatusCode(Throwable $e): int
    {
        if (method_exists($e, 'getStatusCode')) {
            return $e->getStatusCode();
        }

        return match (true) {
            $e instanceof PDOException => 500,
            $e instanceof \InvalidArgumentException => 400,
            $e instanceof \RuntimeException => 500,
            default => 500
        };
    }

    /**
     * Get user-friendly error message
     */
    private function getErrorMessage(Throwable $e): string
    {
        if ($this->debug) {
            return $e->getMessage();
        }

        return match ($this->getStatusCode($e)) {
            403 => 'Forbidden',
            404 => 'Not Found',
            419 => 'Page Expired',
            429 => 'Too Many Requests',
            503 => 'Service Unavailable',
            default => 'An error occurred while processing your request.'
        };
    }

    /**
     * Log exception
     */
    private function logException(Throwable $e): void
    {
        $message = sprintf(
            "[%s] %s: %s in %s:%d\nStack trace:\n%s\n",
            date('Y-m-d H:i:s'),
            get_class($e),
            $e->getMessage(),
            $e->getFile(),
            $e->getLine(),
            $e->getTraceAsString()
        );

        error_log($message, 3, $this->errorLogPath);
    }
}
