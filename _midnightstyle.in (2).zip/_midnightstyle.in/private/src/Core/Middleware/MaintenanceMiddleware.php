<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Http\JsonResponse;
use App\Core\View\ViewEngine;
use App\Core\Config\ConfigurationInterface;

class MaintenanceMiddleware implements MiddlewareInterface
{
    private ConfigurationInterface $config;
    private ViewEngine $view;
    private array $allowedIPs;
    private array $bypassTokens;
    private string $maintenanceFile;

    public function __construct(
        ConfigurationInterface $config,
        ViewEngine $view
    ) {
        $this->config = $config;
        $this->view = $view;
        $this->allowedIPs = $config->get('maintenance.allowed_ips', []);
        $this->bypassTokens = $config->get('maintenance.bypass_tokens', []);
        $this->maintenanceFile = $config->get('maintenance.file', 'storage/framework/down');
    }

    public function handle(Request $request, callable $next): Response
    {
        if ($this->isDownForMaintenance()) {
            if ($this->shouldBypassMaintenance($request)) {
                return $next($request);
            }

            return $this->getMaintenanceResponse($request);
        }

        return $next($request);
    }

    /**
     * Check if application is down for maintenance
     */
    private function isDownForMaintenance(): bool
    {
        return file_exists($this->maintenanceFile);
    }

    /**
     * Check if the request should bypass maintenance mode
     */
    private function shouldBypassMaintenance(Request $request): bool
    {
        // Check IP address
        $clientIP = $request->getClientIp();
        if (in_array($clientIP, $this->allowedIPs)) {
            return true;
        }

        // Check bypass token in URL
        $token = $request->query('bypass_maintenance');
        if ($token && in_array($token, $this->bypassTokens)) {
            return true;
        }

        // Check bypass token in cookie
        $token = $request->cookie('bypass_maintenance');
        if ($token && in_array($token, $this->bypassTokens)) {
            return true;
        }

        return false;
    }

    /**
     * Get maintenance mode response
     */
    private function getMaintenanceResponse(Request $request): Response
    {
        $data = $this->getMaintenanceData();

        if ($request->isAjax()) {
            return new JsonResponse([
                'status' => 'maintenance',
                'message' => $data['message'] ?? 'System is under maintenance',
                'retry_after' => $data['retry_after'] ?? null
            ], 503);
        }

        try {
            $content = $this->view->render('errors/maintenance', $data);
        } catch (\Throwable $e) {
            $content = $this->getFallbackMaintenanceContent($data);
        }

        $headers = [];
        if (isset($data['retry_after'])) {
            $headers['Retry-After'] = (string)$data['retry_after'];
        }

        return new Response($content, 503, $headers);
    }

    /**
     * Get maintenance mode data
     */
    private function getMaintenanceData(): array
    {
        if (!file_exists($this->maintenanceFile)) {
            return [];
        }

        $data = json_decode(file_get_contents($this->maintenanceFile), true);
        return is_array($data) ? $data : [];
    }

    /**
     * Get fallback maintenance content
     */
    private function getFallbackMaintenanceContent(array $data): string
    {
        $message = $data['message'] ?? 'System is under maintenance';
        $retryAfter = isset($data['retry_after']) 
            ? date('Y-m-d H:i:s', time() + $data['retry_after'])
            : 'shortly';

        return "<!DOCTYPE html>
                <html>
                <head>
                    <title>Maintenance Mode</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            text-align: center;
                            padding: 50px;
                            background: #f5f5f5;
                        }
                        .container {
                            background: white;
                            padding: 30px;
                            border-radius: 5px;
                            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
                            max-width: 600px;
                            margin: 0 auto;
                        }
                        h1 { color: #333; }
                        p { color: #666; }
                    </style>
                </head>
                <body>
                    <div class='container'>
                        <h1>System Maintenance</h1>
                        <p>{$message}</p>
                        <p>Please check back {$retryAfter}.</p>
                    </div>
                </body>
                </html>";
    }

    /**
     * Put application in maintenance mode
     */
    public function enable(array $data = []): bool
    {
        $data = array_merge([
            'time' => time(),
            'message' => 'System is under maintenance',
            'retry_after' => 3600 // 1 hour
        ], $data);

        return (bool)file_put_contents($this->maintenanceFile, json_encode($data));
    }

    /**
     * Disable maintenance mode
     */
    public function disable(): bool
    {
        if (file_exists($this->maintenanceFile)) {
            return unlink($this->maintenanceFile);
        }

        return true;
    }

    /**
     * Add allowed IP address
     */
    public function addAllowedIP(string $ip): self
    {
        if (!in_array($ip, $this->allowedIPs)) {
            $this->allowedIPs[] = $ip;
        }
        return $this;
    }

    /**
     * Add bypass token
     */
    public function addBypassToken(string $token): self
    {
        if (!in_array($token, $this->bypassTokens)) {
            $this->bypassTokens[] = $token;
        }
        return $this;
    }

    /**
     * Get allowed IPs
     */
    public function getAllowedIPs(): array
    {
        return $this->allowedIPs;
    }

    /**
     * Get bypass tokens
     */
    public function getBypassTokens(): array
    {
        return $this->bypassTokens;
    }

    /**
     * Get maintenance file path
     */
    public function getMaintenanceFile(): string
    {
        return $this->maintenanceFile;
    }
}
