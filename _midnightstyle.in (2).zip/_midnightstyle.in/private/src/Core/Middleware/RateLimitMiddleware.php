<?php

namespace App\Core\Middleware;

use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Http\JsonResponse;
use App\Core\Security\RateLimit\RateLimiter;
use Exception;

class RateLimitMiddleware implements MiddlewareInterface
{
    private RateLimiter $limiter;
    private string $action;
    private int $maxAttempts;
    private int $decayMinutes;

    public function __construct(
        RateLimiter $limiter,
        string $action = 'default',
        int $maxAttempts = 60,
        int $decayMinutes = 1
    ) {
        $this->limiter = $limiter;
        $this->action = $action;
        $this->maxAttempts = $maxAttempts;
        $this->decayMinutes = $decayMinutes;
    }

    public function handle(Request $request, callable $next): Response
    {
        try {
            if ($this->limiter->tooManyAttempts($this->action)) {
                return $this->buildTooManyAttemptsResponse($request);
            }

            $response = $next($request);

            // Add rate limit headers to response
            $response->setHeader('X-RateLimit-Limit', (string)$this->maxAttempts);
            $response->setHeader('X-RateLimit-Remaining', (string)$this->limiter->remaining($this->action));

            return $response;

        } catch (Exception $e) {
            // Log the error
            error_log("Rate limit error: " . $e->getMessage());

            if ($request->isAjax()) {
                return JsonResponse::error('Rate limit error occurred', null, 500);
            }

            throw $e;
        }
    }

    /**
     * Build the response for when too many attempts have been made
     */
    protected function buildTooManyAttemptsResponse(Request $request): Response
    {
        $retryAfter = $this->limiter->retryAfter($this->action);
        $message = sprintf(
            'Too many attempts. Please try again in %d seconds.',
            $retryAfter
        );

        $headers = [
            'Retry-After' => (string)$retryAfter,
            'X-RateLimit-Limit' => (string)$this->maxAttempts,
            'X-RateLimit-Remaining' => '0',
            'X-RateLimit-Reset' => (string)(time() + $retryAfter)
        ];

        if ($request->isAjax()) {
            return new JsonResponse([
                'success' => false,
                'message' => $message,
                'retry_after' => $retryAfter
            ], 429, $headers);
        }

        return new Response($message, 429, $headers);
    }

    /**
     * Set the action name
     */
    public function setAction(string $action): self
    {
        $this->action = $action;
        return $this;
    }

    /**
     * Set the maximum attempts
     */
    public function setMaxAttempts(int $maxAttempts): self
    {
        $this->maxAttempts = $maxAttempts;
        return $this;
    }

    /**
     * Set the decay minutes
     */
    public function setDecayMinutes(int $decayMinutes): self
    {
        $this->decayMinutes = $decayMinutes;
        return $this;
    }

    /**
     * Get the action name
     */
    public function getAction(): string
    {
        return $this->action;
    }

    /**
     * Get the maximum attempts
     */
    public function getMaxAttempts(): int
    {
        return $this->maxAttempts;
    }

    /**
     * Get the decay minutes
     */
    public function getDecayMinutes(): int
    {
        return $this->decayMinutes;
    }

    /**
     * Get the rate limiter instance
     */
    public function getRateLimiter(): RateLimiter
    {
        return $this->limiter;
    }
}
