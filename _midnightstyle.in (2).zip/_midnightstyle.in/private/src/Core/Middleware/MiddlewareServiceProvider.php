<?php

namespace App\Core\Middleware;

use App\Core\Container;
use App\Core\ServiceProvider;

class MiddlewareServiceProvider extends ServiceProvider
{
    /**
     * Default middleware stack
     */
    protected array $middleware = [
        ErrorHandlerMiddleware::class,
        MaintenanceMiddleware::class,
        SecurityHeadersMiddleware::class,
        SessionMiddleware::class,
        CorsMiddleware::class
    ];

    /**
     * Route middleware groups
     */
    protected array $middlewareGroups = [
        'web' => [
            SessionMiddleware::class,
            CSRFMiddleware::class,
            SecurityHeadersMiddleware::class
        ],
        'api' => [
            CorsMiddleware::class,
            'throttle:60,1'
        ]
    ];

    /**
     * Route middleware aliases
     */
    protected array $middlewareAliases = [
        'auth' => AuthMiddleware::class,
        'guest' => GuestMiddleware::class,
        'csrf' => CSRFMiddleware::class,
        'cors' => CorsMiddleware::class,
        'throttle' => RateLimitMiddleware::class,
        'maintenance' => MaintenanceMiddleware::class
    ];

    /**
     * Register middleware services
     */
    public function register(): void
    {
        // Register MiddlewareStack
        $this->container->singleton(MiddlewareStack::class, function (Container $container) {
            $stack = new MiddlewareStack($container);

            // Register global middleware
            $stack->add($this->middleware);

            // Register middleware groups
            foreach ($this->middlewareGroups as $name => $middleware) {
                $stack->addGroup($name, $middleware);
            }

            // Register middleware aliases
            foreach ($this->middlewareAliases as $alias => $middleware) {
                $stack->addAlias($alias, $middleware);
            }

            return $stack;
        });

        // Register individual middleware
        $this->registerErrorHandler();
        $this->registerMaintenance();
        $this->registerSecurityHeaders();
        $this->registerSession();
        $this->registerCors();
        $this->registerCsrf();
        $this->registerAuth();
        $this->registerRateLimit();
    }

    /**
     * Register error handler middleware
     */
    protected function registerErrorHandler(): void
    {
        $this->container->singleton(ErrorHandlerMiddleware::class, function (Container $container) {
            return new ErrorHandlerMiddleware(
                $container->get('config'),
                $container->get('view')
            );
        });
    }

    /**
     * Register maintenance middleware
     */
    protected function registerMaintenance(): void
    {
        $this->container->singleton(MaintenanceMiddleware::class, function (Container $container) {
            return new MaintenanceMiddleware(
                $container->get('config'),
                $container->get('view')
            );
        });
    }

    /**
     * Register security headers middleware
     */
    protected function registerSecurityHeaders(): void
    {
        $this->container->singleton(SecurityHeadersMiddleware::class, function (Container $container) {
            return new SecurityHeadersMiddleware(
                $container->get('config')
            );
        });
    }

    /**
     * Register session middleware
     */
    protected function registerSession(): void
    {
        $this->container->singleton(SessionMiddleware::class, function (Container $container) {
            return new SessionMiddleware(
                $container->get('session'),
                $container->get('config')->get('session', [])
            );
        });
    }

    /**
     * Register CORS middleware
     */
    protected function registerCors(): void
    {
        $this->container->singleton(CorsMiddleware::class, function (Container $container) {
            return new CorsMiddleware(
                $container->get('config')
            );
        });
    }

    /**
     * Register CSRF middleware
     */
    protected function registerCsrf(): void
    {
        $this->container->singleton(CSRFMiddleware::class, function (Container $container) {
            return new CSRFMiddleware(
                $container->get('csrf'),
                $container->get('config')->get('csrf.excluded_paths', []),
                $container->get('config')->get('csrf.excluded_methods', ['GET', 'HEAD', 'OPTIONS'])
            );
        });
    }

    /**
     * Register authentication middleware
     */
    protected function registerAuth(): void
    {
        $this->container->singleton(AuthMiddleware::class, function (Container $container) {
            return new AuthMiddleware(
                $container->get('auth')
            );
        });

        $this->container->singleton(GuestMiddleware::class, function (Container $container) {
            return new GuestMiddleware(
                $container->get('auth')
            );
        });
    }

    /**
     * Register rate limit middleware
     */
    protected function registerRateLimit(): void
    {
        $this->container->singleton(RateLimitMiddleware::class, function (Container $container) {
            return new RateLimitMiddleware(
                $container->get('rate_limiter')
            );
        });
    }

    /**
     * Get middleware stack
     */
    public function getMiddlewareStack(): MiddlewareStack
    {
        return $this->container->get(MiddlewareStack::class);
    }

    /**
     * Add global middleware
     */
    public function addMiddleware(string $middleware): void
    {
        $this->middleware[] = $middleware;
        $this->getMiddlewareStack()->add($middleware);
    }

    /**
     * Add middleware group
     */
    public function addMiddlewareGroup(string $name, array $middleware): void
    {
        $this->middlewareGroups[$name] = $middleware;
        $this->getMiddlewareStack()->addGroup($name, $middleware);
    }

    /**
     * Add middleware alias
     */
    public function addMiddlewareAlias(string $alias, string $middleware): void
    {
        $this->middlewareAliases[$alias] = $middleware;
        $this->getMiddlewareStack()->addAlias($alias, $middleware);
    }
}
