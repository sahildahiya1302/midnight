<?php

namespace App\Core;

use App\Core\Config\ConfigurationInterface;
use App\Core\Container;
use App\Core\ServiceProvider;
use App\Core\Http\Request;
use App\Core\Http\Response;
use App\Core\Routing\Router;
use App\Core\Session\SessionManager;
use App\Core\Security\SecurityManager;
use App\Core\Database\DatabaseManager;

class Application
{
    /**
     * The application container instance.
     *
     * @var Container
     */
    protected $container;

    /**
     * The base path of the application.
     *
     * @var string
     */
    protected $basePath;

    /**
     * The application environment.
     *
     * @var string
     */
    protected $environment;

    /**
     * Indicates if the application has been bootstrapped.
     *
     * @var bool
     */
    protected $bootstrapped = false;

    /**
     * Create a new application instance.
     *
     * @param string $basePath
     * @param string $environment
     */
    public function __construct(string $basePath, string $environment = 'production')
    {
        $this->basePath = $basePath;
        $this->environment = $environment;
        $this->container = new Container();

        $this->registerBaseBindings();
    }

    /**
     * Register the basic bindings into the container.
     *
     * @return void
     */
    protected function registerBaseBindings(): void
    {
        // Bind the application instance
        $this->container->singleton('app', $this);
        $this->container->singleton(self::class, $this);

        // Bind the container
        $this->container->singleton('container', $this->container);
        $this->container->singleton(Container::class, $this->container);

        // Bind the base path
        $this->container->singleton('path', $this->basePath);
        $this->container->singleton('path.private', $this->basePath . '/private');
        $this->container->singleton('path.public', $this->basePath . '/public_html');
        $this->container->singleton('path.config', $this->basePath . '/private/config');
        $this->container->singleton('path.storage', $this->basePath . '/private/storage');
        $this->container->singleton('path.logs', $this->basePath . '/private/logs');
    }

    /**
     * Boot the application.
     *
     * @return void
     */
    public function boot(): void
    {
        if ($this->bootstrapped) {
            return;
        }

        // Load configuration
        $this->loadConfiguration();

        // Initialize core services
        $this->initializeServices();

        $this->bootstrapped = true;
    }

    /**
     * Load all configuration files.
     *
     * @return void
     */
    protected function loadConfiguration(): void
    {
        $config = $this->container->make(ConfigurationInterface::class);

        // Load all configuration files
        foreach (glob($this->container->get('path.config') . '/*.php') as $file) {
            $name = basename($file, '.php');
            $config->set($name, require $file);
        }
    }

    /**
     * Initialize core services.
     *
     * @return void
     */
    protected function initializeServices(): void
    {
        // Initialize database
        $this->container->make(DatabaseManager::class)->initialize();

        // Initialize session
        $this->container->make(SessionManager::class)->initialize();

        // Initialize security
        $this->container->make(SecurityManager::class)->initialize();
    }

    /**
     * Register core service providers.
     *
     * @param array $providers
     * @return void
     */
    public function registerCoreProviders(array $providers): void
    {
        foreach ($providers as $provider) {
            $this->registerProvider(new $provider($this));
        }
    }

    /**
     * Register application service providers.
     *
     * @param array $providers
     * @return void
     */
    public function registerProviders(array $providers): void
    {
        // Register regular providers
        foreach ($providers as $provider) {
            if (!isset($providers['deferred'][$provider])) {
                $this->registerProvider(new $provider($this));
            }
        }

        // Register deferred providers
        if (isset($providers['deferred'])) {
            foreach ($providers['deferred'] as $service => $provider) {
                $this->registerDeferredProvider(new $provider($this), $service);
            }
        }
    }

    /**
     * Register a service provider.
     *
     * @param ServiceProvider $provider
     * @return void
     */
    protected function registerProvider(ServiceProvider $provider): void
    {
        $provider->register();

        if (method_exists($provider, 'boot')) {
            $provider->boot();
        }
    }

    /**
     * Register a deferred service provider.
     *
     * @param ServiceProvider $provider
     * @param string $service
     * @return void
     */
    protected function registerDeferredProvider(ServiceProvider $provider, string $service): void
    {
        $this->container->defer($service, function () use ($provider) {
            $provider->register();
            return $this->container->get($service);
        });
    }

    /**
     * Handle an incoming HTTP request.
     *
     * @param Request $request
     * @return Response
     */
    public function handle(Request $request): Response
    {
        try {
            // Add request to container
            $this->container->singleton('request', $request);
            $this->container->singleton(Request::class, $request);

            // Route the request
            return $this->container->get(Router::class)->dispatch($request);

        } catch (\Throwable $e) {
            return $this->handleException($request, $e);
        }
    }

    /**
     * Handle an uncaught exception.
     *
     * @param Request $request
     * @param \Throwable $e
     * @return Response
     */
    protected function handleException(Request $request, \Throwable $e): Response
    {
        return $this->container->get('error.handler')->handle($request, $e);
    }

    /**
     * Terminate the application.
     *
     * @param Request $request
     * @param Response $response
     * @return void
     */
    public function terminate(Request $request, Response $response): void
    {
        // Perform any cleanup tasks
        foreach ($this->container->tagged('terminable') as $service) {
            if (method_exists($service, 'terminate')) {
                $service->terminate($request, $response);
            }
        }
    }

    /**
     * Get a service from the container.
     *
     * @param string $service
     * @return mixed
     */
    public function get(string $service)
    {
        return $this->container->get($service);
    }

    /**
     * Get the application environment.
     *
     * @return string
     */
    public function environment(): string
    {
        return $this->environment;
    }

    /**
     * Determine if the application is in debug mode.
     *
     * @return bool
     */
    public function debug(): bool
    {
        return (bool)($_ENV['APP_DEBUG'] ?? false);
    }

    /**
     * Get the application base path.
     *
     * @return string
     */
    public function basePath(): string
    {
        return $this->basePath;
    }

    /**
     * Get the IoC container instance.
     *
     * @return Container
     */
    public function container(): Container
    {
        return $this->container;
    }
}
