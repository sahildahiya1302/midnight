<?php

namespace App\Core\View;

use Exception;

class ViewEngine
{
    protected array $paths = [];
    protected array $cache = [];
    protected array $shared = [];
    protected array $composers = [];
    protected array $creators = [];
    protected array $directives = [];
    protected string $fileExtension = '.php';

    public function __construct(array $paths = [])
    {
        $this->paths = $paths;
        $this->registerDefaultDirectives();
    }

    /**
     * Add a path to search for views
     */
    public function addPath(string $path): void
    {
        $this->paths[] = $path;
    }

    /**
     * Set the paths to search for views
     */
    public function setPaths(array $paths): void
    {
        $this->paths = $paths;
    }

    /**
     * Share data with all views
     */
    public function share(array $data): void
    {
        $this->shared = array_merge($this->shared, $data);
    }

    /**
     * Add a view composer
     */
    public function composer(string $view, callable $callback): void
    {
        $this->composers[$view][] = $callback;
    }

    /**
     * Add a view creator
     */
    public function creator(string $view, callable $callback): void
    {
        $this->creators[$view][] = $callback;
    }

    /**
     * Add a custom directive
     */
    public function directive(string $name, callable $handler): void
    {
        $this->directives[$name] = $handler;
    }

    /**
     * Render a view
     */
    public function render(string $view, array $data = []): string
    {
        // Merge shared data
        $data = array_merge($this->shared, $data);

        // Find the view file
        $file = $this->findView($view);
        if (!$file) {
            throw new Exception("View not found: $view");
        }

        // Run view creators
        $this->runCreators($view, $data);

        // Run view composers
        $this->runComposers($view, $data);

        // Extract data to make it available in the view
        extract($data);

        // Start output buffering
        ob_start();

        try {
            // Include the view file
            include $file;
            $content = ob_get_clean();

            // Process custom directives
            return $this->processDirectives($content);
        } catch (Exception $e) {
            ob_end_clean();
            throw $e;
        }
    }

    /**
     * Find a view file
     */
    protected function findView(string $view): ?string
    {
        // Check cache first
        if (isset($this->cache[$view])) {
            return $this->cache[$view];
        }

        // Replace dots with directory separators
        $view = str_replace('.', '/', $view);

        // Search in all paths
        foreach ($this->paths as $path) {
            $file = $path . '/' . $view . $this->fileExtension;
            if (file_exists($file)) {
                $this->cache[$view] = $file;
                return $file;
            }
        }

        return null;
    }

    /**
     * Run view creators
     */
    protected function runCreators(string $view, array &$data): void
    {
        if (isset($this->creators[$view])) {
            foreach ($this->creators[$view] as $creator) {
                $data = array_merge($data, $creator($data));
            }
        }
    }

    /**
     * Run view composers
     */
    protected function runComposers(string $view, array &$data): void
    {
        if (isset($this->composers[$view])) {
            foreach ($this->composers[$view] as $composer) {
                $data = array_merge($data, $composer($data));
            }
        }
    }

    /**
     * Process custom directives
     */
    protected function processDirectives(string $content): string
    {
        foreach ($this->directives as $name => $handler) {
            $pattern = "/@{$name}\s*\((.*?)\)/";
            $content = preg_replace_callback($pattern, function($matches) use ($handler) {
                $args = $this->parseDirectiveArguments($matches[1]);
                return $handler(...$args);
            }, $content);
        }

        return $content;
    }

    /**
     * Parse directive arguments
     */
    protected function parseDirectiveArguments(string $argumentString): array
    {
        $arguments = [];
        
        if (empty($argumentString)) {
            return $arguments;
        }

        // Match strings, numbers, variables
        preg_match_all('/([\'"])(.*?)\1|\$[a-zA-Z_\x7f-\xff][a-zA-Z0-9_\x7f-\xff]*|\d+/', 
            $argumentString, 
            $matches
        );

        foreach ($matches[0] as $match) {
            if ($match[0] === '"' || $match[0] === "'") {
                // String argument
                $arguments[] = substr($match, 1, -1);
            } elseif ($match[0] === '$') {
                // Variable argument
                $arguments[] = ${substr($match, 1)};
            } else {
                // Number argument
                $arguments[] = is_numeric($match) ? (strpos($match, '.') !== false ? (float)$match : (int)$match) : $match;
            }
        }

        return $arguments;
    }

    /**
     * Register default directives
     */
    protected function registerDefaultDirectives(): void
    {
        // @if directive
        $this->directive('if', function($condition) {
            return "<?php if ($condition): ?>";
        });

        // @else directive
        $this->directive('else', function() {
            return "<?php else: ?>";
        });

        // @elseif directive
        $this->directive('elseif', function($condition) {
            return "<?php elseif ($condition): ?>";
        });

        // @endif directive
        $this->directive('endif', function() {
            return "<?php endif; ?>";
        });

        // @foreach directive
        $this->directive('foreach', function($expression) {
            return "<?php foreach ($expression): ?>";
        });

        // @endforeach directive
        $this->directive('endforeach', function() {
            return "<?php endforeach; ?>";
        });

        // @for directive
        $this->directive('for', function($expression) {
            return "<?php for ($expression): ?>";
        });

        // @endfor directive
        $this->directive('endfor', function() {
            return "<?php endfor; ?>";
        });

        // @while directive
        $this->directive('while', function($expression) {
            return "<?php while ($expression): ?>";
        });

        // @endwhile directive
        $this->directive('endwhile', function() {
            return "<?php endwhile; ?>";
        });

        // @include directive
        $this->directive('include', function($view, $data = '[]') {
            return "<?php echo \$this->render($view, $data); ?>";
        });

        // @csrf directive
        $this->directive('csrf', function() {
            return '<input type="hidden" name="_token" value="<?php echo $_SESSION["_token"] ?? ""; ?>">';
        });
    }

    /**
     * Clear the view cache
     */
    public function clearCache(): void
    {
        $this->cache = [];
    }

    /**
     * Get registered paths
     */
    public function getPaths(): array
    {
        return $this->paths;
    }

    /**
     * Get shared data
     */
    public function getShared(): array
    {
        return $this->shared;
    }

    /**
     * Get registered composers
     */
    public function getComposers(): array
    {
        return $this->composers;
    }

    /**
     * Get registered creators
     */
    public function getCreators(): array
    {
        return $this->creators;
    }

    /**
     * Get registered directives
     */
    public function getDirectives(): array
    {
        return $this->directives;
    }
}
