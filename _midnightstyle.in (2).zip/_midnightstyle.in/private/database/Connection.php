<?php
namespace Database;

use PDO;
use PDOException;

class Connection {
    private $pdo;
    private $config;
    private static $instance = null;
    
    public function __construct(array $config) {
        $this->config = $config;
        $this->connect();
    }
    
    private function connect(): void {
        try {
            $dsn = "sqlite:" . $this->config['database'];
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::ATTR_STRINGIFY_FETCHES => false
            ];
            
            $this->pdo = new PDO($dsn, null, null, $options);
            
            // Enable foreign key constraints
            $this->pdo->exec('PRAGMA foreign_keys = ON');
            
            // Set busy timeout to prevent "database is locked" errors
            $this->pdo->exec('PRAGMA busy_timeout = 5000');
            
            // Enable WAL mode for better concurrency
            $this->pdo->exec('PRAGMA journal_mode = WAL');
            
        } catch (PDOException $e) {
            throw new DatabaseException(
                "Failed to connect to database: " . $e->getMessage(),
                $e->getCode(),
                $e
            );
        }
    }
    
    public function getPdo(): PDO {
        return $this->pdo;
    }
    
    public function beginTransaction(): bool {
        return $this->pdo->beginTransaction();
    }
    
    public function commit(): bool {
        return $this->pdo->commit();
    }
    
    public function rollBack(): bool {
        return $this->pdo->rollBack();
    }
    
    public function prepare(string $query): \PDOStatement {
        return $this->pdo->prepare($query);
    }
    
    public function execute(string $query, array $params = []): bool {
        try {
            $stmt = $this->prepare($query);
            return $stmt->execute($params);
        } catch (PDOException $e) {
            throw new DatabaseException(
                "Failed to execute query: " . $e->getMessage(),
                $e->getCode(),
                $e
            );
        }
    }
    
    public function query(string $query): \PDOStatement {
        try {
            return $this->pdo->query($query);
        } catch (PDOException $e) {
            throw new DatabaseException(
                "Failed to execute query: " . $e->getMessage(),
                $e->getCode(),
                $e
            );
        }
    }
    
    public function lastInsertId(): string {
        return $this->pdo->lastInsertId();
    }
    
    public function fetchAll(string $query, array $params = []): array {
        try {
            $stmt = $this->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchAll();
        } catch (PDOException $e) {
            throw new DatabaseException(
                "Failed to fetch results: " . $e->getMessage(),
                $e->getCode(),
                $e
            );
        }
    }
    
    public function fetchOne(string $query, array $params = []): ?array {
        try {
            $stmt = $this->prepare($query);
            $stmt->execute($params);
            $result = $stmt->fetch();
            return $result !== false ? $result : null;
        } catch (PDOException $e) {
            throw new DatabaseException(
                "Failed to fetch result: " . $e->getMessage(),
                $e->getCode(),
                $e
            );
        }
    }
    
    public function fetchColumn(string $query, array $params = [], int $column = 0) {
        try {
            $stmt = $this->prepare($query);
            $stmt->execute($params);
            return $stmt->fetchColumn($column);
        } catch (PDOException $e) {
            throw new DatabaseException(
                "Failed to fetch column: " . $e->getMessage(),
                $e->getCode(),
                $e
            );
        }
    }
    
    public function insert(string $table, array $data): int {
        $fields = array_keys($data);
        $placeholders = array_fill(0, count($fields), '?');
        
        $query = sprintf(
            "INSERT INTO %s (%s) VALUES (%s)",
            $table,
            implode(', ', $fields),
            implode(', ', $placeholders)
        );
        
        $this->execute($query, array_values($data));
        return (int) $this->lastInsertId();
    }
    
    public function update(string $table, array $data, string $where, array $params = []): int {
        $set = array_map(function($field) {
            return "$field = ?";
        }, array_keys($data));
        
        $query = sprintf(
            "UPDATE %s SET %s WHERE %s",
            $table,
            implode(', ', $set),
            $where
        );
        
        $stmt = $this->prepare($query);
        $stmt->execute(array_merge(array_values($data), $params));
        return $stmt->rowCount();
    }
    
    public function delete(string $table, string $where, array $params = []): int {
        $query = sprintf("DELETE FROM %s WHERE %s", $table, $where);
        $stmt = $this->prepare($query);
        $stmt->execute($params);
        return $stmt->rowCount();
    }
    
    public function tableExists(string $table): bool {
        $result = $this->fetchOne(
            "SELECT name FROM sqlite_master WHERE type='table' AND name = ?",
            [$table]
        );
        return !empty($result);
    }
    
    public function vacuum(): void {
        $this->pdo->exec('VACUUM');
    }
    
    public function optimize(): void {
        $this->pdo->exec('PRAGMA optimize');
    }
}

class DatabaseException extends \Exception {
    public function __construct(string $message, int $code = 0, \Throwable $previous = null) {
        parent::__construct($message, $code, $previous);
    }
}
