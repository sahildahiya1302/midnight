<?php

/*
|--------------------------------------------------------------------------
| Register The Auto Loader
|--------------------------------------------------------------------------
|
| Composer provides a convenient, automatically generated class loader for
| our application. We just need to utilize it! We'll simply require it
| into the script here so that we don't have to worry about manual
| loading any of our classes later on.
*/

require __DIR__ . '/../vendor/autoload.php';

/*
|--------------------------------------------------------------------------
| Load Environment Variables
|--------------------------------------------------------------------------
|
| Load environment variables from .env file. These can be used throughout
| the application via the $_ENV superglobal.
*/

$dotenv = Dotenv\Dotenv::createImmutable(__DIR__);
$dotenv->load();

/*
|--------------------------------------------------------------------------
| Set Error Reporting
|--------------------------------------------------------------------------
|
| Set error reporting based on environment. In production, we'll disable
| error display but log all errors. In development, we'll show all errors.
*/

$debug = $_ENV['APP_DEBUG'] ?? false;
error_reporting(E_ALL);
ini_set('display_errors', $debug ? '1' : '0');
ini_set('log_errors', '1');
ini_set('error_log', __DIR__ . '/logs/error.log');

/*
|--------------------------------------------------------------------------
| Set Default Timezone
|--------------------------------------------------------------------------
|
| Set the default timezone for the application. This will be used for all
| date/time functions unless overridden.
*/

date_default_timezone_set($_ENV['APP_TIMEZONE'] ?? 'UTC');

/*
|--------------------------------------------------------------------------
| Create The Application
|--------------------------------------------------------------------------
|
| The first thing we will do is create a new application instance which
| serves as the "glue" for all the components of the framework.
*/

$app = new App\Core\Application(
    dirname(__DIR__),
    $_ENV['APP_ENV'] ?? 'production'
);

/*
|--------------------------------------------------------------------------
| Register Core Service Providers
|--------------------------------------------------------------------------
|
| Register the core service providers that handle essential framework
| functionality like configuration, database, session management, etc.
*/

$app->registerCoreProviders([
    App\Core\Config\ConfigServiceProvider::class,
    App\Core\Database\DatabaseServiceProvider::class,
    App\Core\Session\SessionServiceProvider::class,
    App\Core\Security\SecurityServiceProvider::class,
    App\Core\Routing\RouterServiceProvider::class,
    App\Core\View\ViewServiceProvider::class,
]);

/*
|--------------------------------------------------------------------------
| Register Application Service Providers
|--------------------------------------------------------------------------
|
| Register the application service providers defined in the configuration.
| These providers add additional functionality to the application.
*/

$providers = require __DIR__ . '/config/providers.php';
$app->registerProviders($providers);

/*
|--------------------------------------------------------------------------
| Set Up Error Handling
|--------------------------------------------------------------------------
|
| Configure error and exception handling for the application. This ensures
| that all errors are properly logged and handled appropriately.
*/

$errorHandler = new App\Core\ErrorHandler($app);
$errorHandler->register();

/*
|--------------------------------------------------------------------------
| Initialize Security Components
|--------------------------------------------------------------------------
|
| Set up security-related components including CSRF protection, rate
| limiting, and other security measures.
*/

$app->get('security')->initialize();

/*
|--------------------------------------------------------------------------
| Set Up Session Handling
|--------------------------------------------------------------------------
|
| Configure and start the session handling for the application. This is
| important for maintaining user state and authentication.
*/

$app->get('session')->start();

/*
|--------------------------------------------------------------------------
| Load Application Routes
|--------------------------------------------------------------------------
|
| Load all application routes from the routes configuration file. This
| sets up all the URL endpoints that the application will respond to.
*/

$app->get('router')->loadRoutes(
    require __DIR__ . '/config/routes.php'
);

/*
|--------------------------------------------------------------------------
| Set Up WebSocket Server (if applicable)
|--------------------------------------------------------------------------
|
| If this bootstrap file is being used to start the WebSocket server,
| initialize the necessary WebSocket components.
*/

if (defined('WEBSOCKET_SERVER') && WEBSOCKET_SERVER === true) {
    $app->get('websocket')->initialize();
}

/*
|--------------------------------------------------------------------------
| Return The Application
|--------------------------------------------------------------------------
|
| Return the application instance. This instance can be used to access
| various services and components throughout the application.
*/

return $app;
