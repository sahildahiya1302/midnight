<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Service Providers
    |--------------------------------------------------------------------------
    |
    | The service providers listed here will be automatically loaded on the
    | request to your application. Feel free to add your own services to
    | this array to grant expanded functionality to your applications.
    */

    // Framework Service Providers
    App\Core\Config\ConfigServiceProvider::class,
    App\Core\Database\DatabaseServiceProvider::class,
    App\Core\Session\SessionServiceProvider::class,
    App\Core\Security\SecurityServiceProvider::class,
    App\Core\Middleware\MiddlewareServiceProvider::class,
    App\Core\Routing\RouterServiceProvider::class,
    App\Core\View\ViewServiceProvider::class,

    // Application Service Providers
    App\Providers\AppServiceProvider::class,
    App\Providers\AuthServiceProvider::class,
    App\Providers\EventServiceProvider::class,
    App\Providers\RouteServiceProvider::class,
    App\Providers\WebSocketServiceProvider::class,

    // Game Service Providers
    App\Game\Providers\GameServiceProvider::class,
    App\Game\Providers\AviatorServiceProvider::class,
    App\Game\Providers\LudoServiceProvider::class,

    // Third-Party Service Providers
    App\Providers\RedisServiceProvider::class,
    App\Providers\MailServiceProvider::class,
    App\Providers\LogServiceProvider::class,
    App\Providers\CacheServiceProvider::class,

    /*
    |--------------------------------------------------------------------------
    | Deferred Service Providers
    |--------------------------------------------------------------------------
    |
    | The service providers listed here will not be automatically loaded on the
    | request to your application. They will only be loaded as needed by the
    | application, improving performance by lazy loading services.
    */

    'deferred' => [
        // Authentication Services
        'auth.jwt' => App\Security\Providers\JWTServiceProvider::class,
        'auth.oauth' => App\Security\Providers\OAuthServiceProvider::class,

        // Payment Services
        'payment.stripe' => App\Payment\Providers\StripeServiceProvider::class,
        'payment.paypal' => App\Payment\Providers\PayPalServiceProvider::class,

        // Storage Services
        'storage.s3' => App\Storage\Providers\S3ServiceProvider::class,
        'storage.ftp' => App\Storage\Providers\FTPServiceProvider::class,

        // Queue Services
        'queue.redis' => App\Queue\Providers\RedisQueueProvider::class,
        'queue.database' => App\Queue\Providers\DatabaseQueueProvider::class,

        // Cache Services
        'cache.redis' => App\Cache\Providers\RedisCacheProvider::class,
        'cache.memcached' => App\Cache\Providers\MemcachedProvider::class,

        // Search Services
        'search.elastic' => App\Search\Providers\ElasticSearchProvider::class,
        'search.algolia' => App\Search\Providers\AlgoliaProvider::class,

        // Notification Services
        'notifications.sms' => App\Notifications\Providers\SMSProvider::class,
        'notifications.push' => App\Notifications\Providers\PushProvider::class,

        // Analytics Services
        'analytics.google' => App\Analytics\Providers\GoogleAnalyticsProvider::class,
        'analytics.custom' => App\Analytics\Providers\CustomAnalyticsProvider::class,

        // Game Services
        'game.matchmaking' => App\Game\Providers\MatchmakingProvider::class,
        'game.leaderboard' => App\Game\Providers\LeaderboardProvider::class,
        'game.tournament' => App\Game\Providers\TournamentProvider::class,

        // API Services
        'api.throttle' => App\API\Providers\ThrottleServiceProvider::class,
        'api.documentation' => App\API\Providers\DocumentationProvider::class,

        // Monitoring Services
        'monitor.performance' => App\Monitoring\Providers\PerformanceProvider::class,
        'monitor.error' => App\Monitoring\Providers\ErrorTrackingProvider::class,
    ],
];
