<?php
// Environment settings
define('APP_ENV', 'production');
define('APP_DEBUG', false);
define('APP_URL', 'https://midnightstyle.in');
define('APP_TIMEZONE', 'Asia/Kolkata');

// Security settings - Generated secure random keys
define('APP_KEY', 'base64:' . base64_encode(random_bytes(32)));
define('ENCRYPTION_KEY', 'base64:' . base64_encode(random_bytes(32)));
define('JWT_SECRET', 'base64:' . base64_encode(random_bytes(32)));

// Database settings (from database.php)
define('DB_HOST', 'localhost');
define('DB_NAME', 'u185229455_Gamingzone');
define('DB_USER', 'u185229455_u185229455');
define('DB_PASS', 'Sahil@hostinger#ssh2025');

// Redis settings
define('REDIS_HOST', 'localhost');
define('REDIS_PORT', 6379);
define('REDIS_DB', 0);
define('REDIS_AUTH', false);
define('REDIS_PASS', null);

// WebSocket settings
define('WS_HOST', 'midnightstyle.in');
define('WS_PORT', 8080);
define('WS_SECURE', true);

// Payment gateway settings (to be updated by user)
define('PAYMENT_MODE', 'test');
define('RAZORPAY_KEY_ID', '');
define('RAZORPAY_KEY_SECRET', '');
define('CASHFREE_APP_ID', '');
define('CASHFREE_SECRET_KEY', '');

// Admin settings
define('ADMIN_IPS', [
    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
    '127.0.0.1'
]);

// Game settings
define('MIN_BET_AMOUNT', 10);
define('MAX_BET_AMOUNT', 10000);
define('HOUSE_EDGE', 0.05);
define('MAX_MULTIPLIER', 100.0);

// Session settings
define('SESSION_LIFETIME', 7200);
define('SESSION_SECURE', true);
define('SESSION_HTTP_ONLY', true);
define('SESSION_SAME_SITE', 'Lax');

// Cache settings
define('CACHE_DRIVER', 'file'); // Changed from redis to file for initial setup
define('CACHE_PREFIX', 'gaming_');
define('CACHE_TTL', 3600);

// Mail settings (to be updated by user)
define('MAIL_DRIVER', 'smtp');
define('MAIL_HOST', 'smtp.hostinger.com');
define('MAIL_PORT', 587);
define('MAIL_USERNAME', '');
define('MAIL_PASSWORD', '');
define('MAIL_ENCRYPTION', 'tls');
define('MAIL_FROM_ADDRESS', 'noreply@midnightstyle.in');
define('MAIL_FROM_NAME', 'Gaming Platform');

// SMS settings (to be updated by user)
define('SMS_PROVIDER', 'twilio');
define('TWILIO_SID', '');
define('TWILIO_TOKEN', '');
define('TWILIO_FROM', '');

// KYC settings
define('KYC_REQUIRED', true);
define('MIN_WITHDRAWAL_AMOUNT', 100);
define('MAX_WITHDRAWAL_AMOUNT', 100000);
define('DAILY_WITHDRAWAL_LIMIT', 200000);

// Rate limiting
define('RATE_LIMIT_ENABLED', true);
define('RATE_LIMIT_ATTEMPTS', 60);
define('RATE_LIMIT_DECAY_MINUTES', 1);

// Monitoring
define('MONITOR_ERRORS', true);
define('MONITOR_QUERIES', true);
define('MONITOR_REQUESTS', true);
define('MONITOR_GAMES', true);

// Backup settings
define('BACKUP_ENABLED', true);
define('BACKUP_PATH', __DIR__ . '/../storage/backups');
define('BACKUP_CLEANUP_AFTER', 7);

// Maintenance mode
define('MAINTENANCE_MODE', false);
define('MAINTENANCE_IPS', [
    $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1',
    '127.0.0.1'
]);

// Feature flags
define('FEATURE_LUDO', true);
define('FEATURE_AVIATOR', true);
define('FEATURE_CHAT', true);
define('FEATURE_TOURNAMENTS', false);
define('FEATURE_REFERRALS', true);
define('FEATURE_ACHIEVEMENTS', true);

// Error reporting
if (APP_ENV === 'production') {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_STRICT);
    ini_set('display_errors', 0);
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
}

date_default_timezone_set(APP_TIMEZONE);

return [
    'app' => [
        'env' => APP_ENV,
        'debug' => APP_DEBUG,
        'url' => APP_URL,
        'timezone' => APP_TIMEZONE
    ],
    'security' => [
        'app_key' => APP_KEY,
        'encryption_key' => ENCRYPTION_KEY,
        'jwt_secret' => JWT_SECRET
    ],
    'database' => [
        'host' => DB_HOST,
        'name' => DB_NAME,
        'user' => DB_USER,
        'pass' => DB_PASS
    ],
    'redis' => [
        'host' => REDIS_HOST,
        'port' => REDIS_PORT,
        'db' => REDIS_DB,
        'auth' => REDIS_AUTH,
        'pass' => REDIS_PASS
    ],
    'websocket' => [
        'host' => WS_HOST,
        'port' => WS_PORT,
        'secure' => WS_SECURE
    ]
];
