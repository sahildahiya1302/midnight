<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Default Log Channel
    |--------------------------------------------------------------------------
    |
    | This option defines the default log channel that gets used when writing
    | messages to the logs. The name specified in this option should match
    | one of the channels defined in the "channels" configuration array.
    */
    'default' => $_ENV['LOG_CHANNEL'] ?? 'stack',

    /*
    |--------------------------------------------------------------------------
    | Deprecations Log Channel
    |--------------------------------------------------------------------------
    |
    | This option controls the log channel that should be used to log warnings
    | regarding deprecated PHP and library features. This allows you to get
    | your application ready for upcoming major versions of dependencies.
    */
    'deprecations' => [
        'channel' => $_ENV['LOG_DEPRECATIONS_CHANNEL'] ?? 'null',
        'trace' => false,
    ],

    /*
    |--------------------------------------------------------------------------
    | Log Channels
    |--------------------------------------------------------------------------
    |
    | Here you may configure the log channels for your application. Out of
    | the box, the framework uses the Monolog PHP logging library. This gives
    | you a variety of powerful log handlers / formatters to utilize.
    |
    | Available Drivers: "single", "daily", "slack", "syslog",
    |                    "errorlog", "custom", "stack"
    |
    */
    'channels' => [
        'stack' => [
            'driver' => 'stack',
            'channels' => ['daily', 'slack'],
            'ignore_exceptions' => false,
        ],

        'single' => [
            'driver' => 'single',
            'path' => BASE_PATH . '/private/logs/app.log',
            'level' => $_ENV['LOG_LEVEL'] ?? 'debug',
            'permission' => 0664,
        ],

        'daily' => [
            'driver' => 'daily',
            'path' => BASE_PATH . '/private/logs/app.log',
            'level' => $_ENV['LOG_LEVEL'] ?? 'debug',
            'days' => 14,
            'permission' => 0664,
        ],

        'slack' => [
            'driver' => 'slack',
            'url' => $_ENV['LOG_SLACK_WEBHOOK_URL'],
            'username' => 'MidnightStyle Log',
            'emoji' => ':boom:',
            'level' => $_ENV['LOG_SLACK_LEVEL'] ?? 'critical',
        ],

        'syslog' => [
            'driver' => 'syslog',
            'facility' => LOG_USER,
            'level' => $_ENV['LOG_LEVEL'] ?? 'debug',
        ],

        'errorlog' => [
            'driver' => 'errorlog',
            'level' => $_ENV['LOG_LEVEL'] ?? 'debug',
        ],

        'null' => [
            'driver' => 'null',
        ],

        'emergency' => [
            'path' => BASE_PATH . '/private/logs/emergency.log',
            'permission' => 0664,
        ],

        'game' => [
            'driver' => 'daily',
            'path' => BASE_PATH . '/private/logs/game.log',
            'level' => 'debug',
            'days' => 7,
            'permission' => 0664,
        ],

        'websocket' => [
            'driver' => 'daily',
            'path' => BASE_PATH . '/private/logs/websocket.log',
            'level' => 'debug',
            'days' => 7,
            'permission' => 0664,
        ],

        'security' => [
            'driver' => 'daily',
            'path' => BASE_PATH . '/private/logs/security.log',
            'level' => 'info',
            'days' => 30,
            'permission' => 0664,
        ],

        'transaction' => [
            'driver' => 'daily',
            'path' => BASE_PATH . '/private/logs/transactions.log',
            'level' => 'info',
            'days' => 90,
            'permission' => 0664,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Log Level Hierarchy
    |--------------------------------------------------------------------------
    |
    | This array defines the log level hierarchy. Messages at or above the
    | specified level will be logged. This helps control the verbosity
    | of your application's logs.
    */
    'levels' => [
        'emergency' => 600,
        'alert'     => 550,
        'critical'  => 500,
        'error'     => 400,
        'warning'   => 300,
        'notice'    => 250,
        'info'      => 200,
        'debug'     => 100,
    ],

    /*
    |--------------------------------------------------------------------------
    | Log Message Format
    |--------------------------------------------------------------------------
    |
    | Configure the format of log messages. You can use placeholders like
    | {datetime}, {level}, {message}, {context}, etc.
    */
    'format' => [
        'line' => "[{datetime}] {level}: {message} {context} {extra}\n",
        'datetime' => 'Y-m-d H:i:s',
    ],

    /*
    |--------------------------------------------------------------------------
    | Log Rotation
    |--------------------------------------------------------------------------
    |
    | Configure log rotation settings including maximum file size and
    | number of files to keep.
    */
    'rotation' => [
        'max_files' => 30,
        'max_size' => 10485760, // 10MB
        'compress' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | Log Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure log monitoring settings. This can help alert you when
    | important events occur in your application.
    */
    'monitoring' => [
        'enabled' => false,
        'driver' => 'slack',
        'levels' => ['emergency', 'alert', 'critical'],
    ],
];
