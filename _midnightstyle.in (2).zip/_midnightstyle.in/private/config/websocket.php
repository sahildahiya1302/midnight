<?php

return [
    /*
    |--------------------------------------------------------------------------
    | WebSocket Server Configuration
    |--------------------------------------------------------------------------
    |
    | Configure the WebSocket server settings including host, port,
    | and other server-specific options.
    */
    'server' => [
        'host' => $_ENV['WS_HOST'] ?? '0.0.0.0',
        'port' => (int)($_ENV['WS_PORT'] ?? 8080),
        'max_connections' => (int)($_ENV['WS_MAX_CONNECTIONS'] ?? 1000),
        'worker_count' => (int)($_ENV['WS_WORKERS'] ?? 4),
        'ssl' => [
            'enabled' => (bool)($_ENV['WS_SSL_ENABLED'] ?? false),
            'cert_file' => $_ENV['WS_SSL_CERT'] ?? null,
            'key_file' => $_ENV['WS_SSL_KEY'] ?? null,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Authentication
    |--------------------------------------------------------------------------
    |
    | Configure authentication settings for WebSocket connections.
    | This determines how clients are authenticated when connecting.
    */
    'auth' => [
        'enabled' => true,
        'driver' => 'token', // token, session, jwt
        'timeout' => 60, // authentication timeout in seconds
        'header' => 'Authorization',
    ],

    /*
    |--------------------------------------------------------------------------
    | Game Server Settings
    |--------------------------------------------------------------------------
    |
    | Configure game-specific WebSocket settings including rooms,
    | matchmaking, and game state management.
    */
    'game' => [
        // Room configuration
        'rooms' => [
            'max_players' => 4,
            'min_players' => 2,
            'timeout' => 300, // room timeout in seconds
            'cleanup_interval' => 60, // cleanup interval in seconds
        ],

        // Matchmaking configuration
        'matchmaking' => [
            'enabled' => true,
            'timeout' => 60, // matchmaking timeout in seconds
            'rating_range' => 200, // acceptable rating difference
            'max_queue_size' => 100,
        ],

        // Game state configuration
        'state' => [
            'save_interval' => 30, // state save interval in seconds
            'history_length' => 50, // number of moves to keep in history
            'max_turn_time' => 60, // maximum time per turn in seconds
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Client Settings
    |--------------------------------------------------------------------------
    |
    | Configure client-side settings including connection timeouts,
    | heartbeat intervals, and reconnection attempts.
    */
    'client' => [
        'connection_timeout' => 10, // seconds
        'heartbeat_interval' => 25, // seconds
        'max_reconnect_attempts' => 5,
        'reconnect_interval' => 3, // seconds
        'ping_interval' => 25, // seconds
    ],

    /*
    |--------------------------------------------------------------------------
    | Message Handlers
    |--------------------------------------------------------------------------
    |
    | Register message handlers for different types of WebSocket messages.
    | These handlers will process incoming messages based on their type.
    */
    'handlers' => [
        'chat' => App\WebSocket\Handlers\ChatHandler::class,
        'game' => App\WebSocket\Handlers\GameHandler::class,
        'system' => App\WebSocket\Handlers\SystemHandler::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Broadcasting
    |--------------------------------------------------------------------------
    |
    | Configure broadcasting settings for WebSocket messages including
    | channels and authentication for pub/sub functionality.
    */
    'broadcasting' => [
        'driver' => 'redis', // redis, local
        'redis' => [
            'host' => $_ENV['REDIS_HOST'] ?? '127.0.0.1',
            'port' => (int)($_ENV['REDIS_PORT'] ?? 6379),
            'password' => $_ENV['REDIS_PASSWORD'] ?? null,
            'database' => (int)($_ENV['REDIS_DB'] ?? 0),
        ],
        'channels' => [
            'prefix' => 'ws:',
            'max_subscribers' => 10000,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Logging
    |--------------------------------------------------------------------------
    |
    | Configure WebSocket server logging settings including log level,
    | file location, and what types of events to log.
    */
    'logging' => [
        'enabled' => true,
        'level' => $_ENV['WS_LOG_LEVEL'] ?? 'info',
        'file' => BASE_PATH . '/private/logs/websocket.log',
        'events' => [
            'connection' => true,
            'message' => true,
            'error' => true,
            'game' => true,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Rate Limiting
    |--------------------------------------------------------------------------
    |
    | Configure rate limiting for WebSocket connections and messages
    | to prevent abuse and ensure fair usage.
    */
    'rate_limit' => [
        'enabled' => true,
        'max_messages' => 60, // messages per minute
        'max_connections' => 10, // connections per minute per IP
        'whitelist' => [
            // IPs that bypass rate limiting
            '127.0.0.1',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure monitoring settings for the WebSocket server including
    | metrics collection and health checks.
    */
    'monitoring' => [
        'enabled' => true,
        'metrics' => [
            'connections' => true,
            'messages' => true,
            'memory' => true,
            'games' => true,
        ],
        'health_check' => [
            'interval' => 60, // seconds
            'timeout' => 5, // seconds
        ],
    ],
];
