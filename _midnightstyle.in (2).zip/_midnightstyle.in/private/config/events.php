<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Event Listeners
    |--------------------------------------------------------------------------
    |
    | Here you may register event listeners and their corresponding handlers.
    | Events provide a simple observer pattern implementation, allowing you
    | to subscribe and listen for various events that occur in your app.
    */
    'listeners' => [
        // Authentication Events
        'App\Events\Auth\UserRegistered' => [
            'App\Listeners\Auth\SendWelcomeEmail',
            'App\Listeners\Auth\CreateWallet',
            'App\Listeners\Auth\AssignDefaultRole',
        ],
        'App\Events\Auth\UserLoggedIn' => [
            'App\Listeners\Auth\UpdateLastLoginTimestamp',
            'App\Listeners\Auth\LogLoginActivity',
        ],
        'App\Events\Auth\PasswordReset' => [
            'App\Listeners\Auth\SendPasswordResetNotification',
            'App\Listeners\Auth\LogPasswordReset',
        ],

        // Game Events
        'App\Events\Game\GameStarted' => [
            'App\Listeners\Game\InitializeGameState',
            'App\Listeners\Game\NotifyPlayers',
            'App\Listeners\Game\LogGameStart',
        ],
        'App\Events\Game\GameEnded' => [
            'App\Listeners\Game\ProcessGameResults',
            'App\Listeners\Game\UpdatePlayerStats',
            'App\Listeners\Game\DistributePrizes',
            'App\Listeners\Game\LogGameEnd',
        ],
        'App\Events\Game\BetPlaced' => [
            'App\Listeners\Game\ValidateBet',
            'App\Listeners\Game\ProcessBet',
            'App\Listeners\Game\UpdateWallet',
            'App\Listeners\Game\LogBet',
        ],

        // Transaction Events
        'App\Events\Transaction\DepositCreated' => [
            'App\Listeners\Transaction\ProcessDeposit',
            'App\Listeners\Transaction\UpdateWalletBalance',
            'App\Listeners\Transaction\SendDepositConfirmation',
            'App\Listeners\Transaction\LogDeposit',
        ],
        'App\Events\Transaction\WithdrawalRequested' => [
            'App\Listeners\Transaction\ValidateWithdrawal',
            'App\Listeners\Transaction\ProcessWithdrawal',
            'App\Listeners\Transaction\UpdateWalletBalance',
            'App\Listeners\Transaction\SendWithdrawalConfirmation',
            'App\Listeners\Transaction\LogWithdrawal',
        ],

        // WebSocket Events
        'App\Events\WebSocket\ClientConnected' => [
            'App\Listeners\WebSocket\AuthenticateClient',
            'App\Listeners\WebSocket\InitializeClientState',
            'App\Listeners\WebSocket\LogConnection',
        ],
        'App\Events\WebSocket\ClientDisconnected' => [
            'App\Listeners\WebSocket\CleanupClientState',
            'App\Listeners\WebSocket\LogDisconnection',
        ],
        'App\Events\WebSocket\MessageReceived' => [
            'App\Listeners\WebSocket\ProcessMessage',
            'App\Listeners\WebSocket\LogMessage',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Event Subscribers
    |--------------------------------------------------------------------------
    |
    | Event subscribers are classes that can subscribe to multiple events.
    | These classes can handle related events within a single subscriber.
    */
    'subscribers' => [
        'App\Subscribers\GameSubscriber',
        'App\Subscribers\AuthSubscriber',
        'App\Subscribers\TransactionSubscriber',
        'App\Subscribers\WebSocketSubscriber',
        'App\Subscribers\SecuritySubscriber',
    ],

    /*
    |--------------------------------------------------------------------------
    | Event Broadcasting
    |--------------------------------------------------------------------------
    |
    | Configure event broadcasting settings including channels and
    | authentication for real-time events.
    */
    'broadcasting' => [
        'default' => $_ENV['BROADCAST_DRIVER'] ?? 'redis',
        
        'connections' => [
            'redis' => [
                'driver' => 'redis',
                'connection' => 'default',
            ],
            'log' => [
                'driver' => 'log',
            ],
            'null' => [
                'driver' => 'null',
            ],
        ],

        'channels' => [
            'game' => [
                'driver' => 'redis',
                'prefix' => 'game_',
            ],
            'user' => [
                'driver' => 'redis',
                'prefix' => 'user_',
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Event Storage
    |--------------------------------------------------------------------------
    |
    | Configure event storage settings for persisting and retrieving
    | event data.
    */
    'storage' => [
        'enabled' => true,
        'driver' => 'database', // database, redis
        'table' => 'events',
        'retention' => [
            'days' => 30,
            'max_events' => 1000000,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Event Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure event monitoring settings including logging and metrics
    | collection.
    */
    'monitoring' => [
        'enabled' => true,
        'log_events' => true,
        'metrics' => [
            'enabled' => true,
            'driver' => 'prometheus',
        ],
        'alerts' => [
            'enabled' => true,
            'channels' => ['slack', 'email'],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Event Queue
    |--------------------------------------------------------------------------
    |
    | Configure event queue settings for processing events asynchronously.
    */
    'queue' => [
        'enabled' => true,
        'connection' => 'redis',
        'queue' => 'events',
        'retry_after' => 90,
        'timeout' => 60,
    ],
];
