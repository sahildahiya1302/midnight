<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as payment processors, email services, and other external APIs that
    | your application might need to interact with.
    */

    // Payment Services
    'stripe' => [
        'enabled' => (bool)($_ENV['STRIPE_ENABLED'] ?? false),
        'key' => $_ENV['STRIPE_KEY'],
        'secret' => $_ENV['STRIPE_SECRET'],
        'webhook' => [
            'secret' => $_ENV['STRIPE_WEBHOOK_SECRET'],
            'tolerance' => 300,
        ],
        'currency' => $_ENV['STRIPE_CURRENCY'] ?? 'usd',
    ],

    'paypal' => [
        'enabled' => (bool)($_ENV['PAYPAL_ENABLED'] ?? false),
        'mode' => $_ENV['PAYPAL_MODE'] ?? 'sandbox', // sandbox or live
        'client_id' => $_ENV['PAYPAL_CLIENT_ID'],
        'secret' => $_ENV['PAYPAL_SECRET'],
        'currency' => $_ENV['PAYPAL_CURRENCY'] ?? 'USD',
        'webhook' => [
            'id' => $_ENV['PAYPAL_WEBHOOK_ID'],
        ],
    ],

    // Email Services
    'mailgun' => [
        'domain' => $_ENV['MAILGUN_DOMAIN'],
        'secret' => $_ENV['MAILGUN_SECRET'],
        'endpoint' => $_ENV['MAILGUN_ENDPOINT'] ?? 'api.mailgun.net',
    ],

    'postmark' => [
        'token' => $_ENV['POSTMARK_TOKEN'],
    ],

    'ses' => [
        'key' => $_ENV['AWS_ACCESS_KEY_ID'],
        'secret' => $_ENV['AWS_SECRET_ACCESS_KEY'],
        'region' => $_ENV['AWS_DEFAULT_REGION'] ?? 'us-east-1',
    ],

    // SMS Services
    'twilio' => [
        'enabled' => (bool)($_ENV['TWILIO_ENABLED'] ?? false),
        'sid' => $_ENV['TWILIO_SID'],
        'token' => $_ENV['TWILIO_TOKEN'],
        'from' => $_ENV['TWILIO_FROM'],
        'verify' => [
            'sid' => $_ENV['TWILIO_VERIFY_SID'],
        ],
    ],

    // Cloud Storage
    'aws' => [
        'key' => $_ENV['AWS_ACCESS_KEY_ID'],
        'secret' => $_ENV['AWS_SECRET_ACCESS_KEY'],
        'region' => $_ENV['AWS_DEFAULT_REGION'] ?? 'us-east-1',
        'bucket' => $_ENV['AWS_BUCKET'],
        'url' => $_ENV['AWS_URL'],
        'endpoint' => $_ENV['AWS_ENDPOINT'],
    ],

    // Social Authentication
    'google' => [
        'enabled' => (bool)($_ENV['GOOGLE_ENABLED'] ?? false),
        'client_id' => $_ENV['GOOGLE_CLIENT_ID'],
        'client_secret' => $_ENV['GOOGLE_CLIENT_SECRET'],
        'redirect' => $_ENV['GOOGLE_REDIRECT_URI'],
    ],

    'facebook' => [
        'enabled' => (bool)($_ENV['FACEBOOK_ENABLED'] ?? false),
        'client_id' => $_ENV['FACEBOOK_CLIENT_ID'],
        'client_secret' => $_ENV['FACEBOOK_CLIENT_SECRET'],
        'redirect' => $_ENV['FACEBOOK_REDIRECT_URI'],
    ],

    // Analytics Services
    'google_analytics' => [
        'enabled' => (bool)($_ENV['GA_ENABLED'] ?? false),
        'id' => $_ENV['GA_TRACKING_ID'],
    ],

    'mixpanel' => [
        'enabled' => (bool)($_ENV['MIXPANEL_ENABLED'] ?? false),
        'token' => $_ENV['MIXPANEL_TOKEN'],
    ],

    // Error Tracking
    'sentry' => [
        'enabled' => (bool)($_ENV['SENTRY_ENABLED'] ?? false),
        'dsn' => $_ENV['SENTRY_DSN'],
        'traces_sample_rate' => (float)($_ENV['SENTRY_TRACES_SAMPLE_RATE'] ?? 0.1),
    ],

    // Push Notifications
    'firebase' => [
        'enabled' => (bool)($_ENV['FIREBASE_ENABLED'] ?? false),
        'project_id' => $_ENV['FIREBASE_PROJECT_ID'],
        'credentials' => $_ENV['FIREBASE_CREDENTIALS'],
        'database_url' => $_ENV['FIREBASE_DATABASE_URL'],
    ],

    // CDN Services
    'cloudflare' => [
        'enabled' => (bool)($_ENV['CLOUDFLARE_ENABLED'] ?? false),
        'token' => $_ENV['CLOUDFLARE_TOKEN'],
        'zone_id' => $_ENV['CLOUDFLARE_ZONE_ID'],
    ],

    // Cache Services
    'redis' => [
        'client' => 'predis',
        'default' => [
            'host' => $_ENV['REDIS_HOST'] ?? '127.0.0.1',
            'password' => $_ENV['REDIS_PASSWORD'] ?? null,
            'port' => $_ENV['REDIS_PORT'] ?? 6379,
            'database' => $_ENV['REDIS_DB'] ?? 0,
        ],
    ],

    'memcached' => [
        'persistent_id' => $_ENV['MEMCACHED_PERSISTENT_ID'] ?? null,
        'sasl' => [
            $_ENV['MEMCACHED_USERNAME'] ?? null,
            $_ENV['MEMCACHED_PASSWORD'] ?? null,
        ],
        'options' => [],
        'servers' => [
            [
                'host' => $_ENV['MEMCACHED_HOST'] ?? '127.0.0.1',
                'port' => $_ENV['MEMCACHED_PORT'] ?? 11211,
                'weight' => 100,
            ],
        ],
    ],

    // Search Services
    'elasticsearch' => [
        'enabled' => (bool)($_ENV['ELASTICSEARCH_ENABLED'] ?? false),
        'hosts' => [
            $_ENV['ELASTICSEARCH_HOST'] ?? 'localhost:9200',
        ],
    ],

    'algolia' => [
        'enabled' => (bool)($_ENV['ALGOLIA_ENABLED'] ?? false),
        'app_id' => $_ENV['ALGOLIA_APP_ID'],
        'secret' => $_ENV['ALGOLIA_SECRET'],
    ],
];
