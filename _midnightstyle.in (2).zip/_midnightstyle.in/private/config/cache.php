<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Default Cache Store
    |--------------------------------------------------------------------------
    |
    | This option controls the default cache connection that gets used while
    | using this caching library. This connection is used when another is
    | not explicitly specified when executing a given caching function.
    |
    | Supported: "file", "redis", "memcached", "array", "null"
    */
    'default' => $_ENV['CACHE_DRIVER'] ?? 'file',

    /*
    |--------------------------------------------------------------------------
    | Cache Stores
    |--------------------------------------------------------------------------
    |
    | Here you may define all of the cache "stores" for your application as
    | well as their drivers. You may even define multiple stores for the
    | same cache driver to group types of items stored in your caches.
    */
    'stores' => [
        'file' => [
            'driver' => 'file',
            'path' => BASE_PATH . '/private/storage/cache',
            'permission' => 0777,
            'lock_path' => BASE_PATH . '/private/storage/cache/locks',
        ],

        'redis' => [
            'driver' => 'redis',
            'connection' => 'cache',
            'prefix' => $_ENV['CACHE_PREFIX'] ?? 'midnightstyle_cache:',
            'lock_connection' => 'default',
            'lock_timeout' => 60,
        ],

        'memcached' => [
            'driver' => 'memcached',
            'persistent_id' => $_ENV['MEMCACHED_PERSISTENT_ID'] ?? null,
            'sasl' => [
                $_ENV['MEMCACHED_USERNAME'] ?? null,
                $_ENV['MEMCACHED_PASSWORD'] ?? null,
            ],
            'options' => [
                // Memcached::OPT_CONNECT_TIMEOUT => 2000,
            ],
            'servers' => [
                [
                    'host' => $_ENV['MEMCACHED_HOST'] ?? '127.0.0.1',
                    'port' => $_ENV['MEMCACHED_PORT'] ?? 11211,
                    'weight' => 100,
                ],
            ],
        ],

        'array' => [
            'driver' => 'array',
            'serialize' => false,
        ],

        'null' => [
            'driver' => 'null',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Key Prefix
    |--------------------------------------------------------------------------
    |
    | When utilizing a RAM based store such as APC or Memcached, there might
    | be other applications utilizing the same cache. So, we'll specify a
    | value to get prefixed to all our keys so we can avoid collisions.
    */
    'prefix' => $_ENV['CACHE_PREFIX'] ?? 'midnightstyle_cache:',

    /*
    |--------------------------------------------------------------------------
    | Cache TTL (Time To Live)
    |--------------------------------------------------------------------------
    |
    | Default cache TTL in seconds. This value will be used when a specific
    | TTL is not provided when storing items in the cache.
    */
    'ttl' => (int)($_ENV['CACHE_TTL'] ?? 3600),

    /*
    |--------------------------------------------------------------------------
    | Cache Tags
    |--------------------------------------------------------------------------
    |
    | Configure cache tag settings including prefix and delimiter.
    | Tags allow you to tag related items and flush all tagged items.
    */
    'tags' => [
        'prefix' => 'tag:',
        'delimiter' => '|',
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Locks
    |--------------------------------------------------------------------------
    |
    | Configure cache lock settings including timeout and wait time.
    | Locks prevent multiple processes from running the same operation.
    */
    'locks' => [
        'timeout' => 60, // seconds
        'wait_timeout' => 5, // seconds
        'wait_interval' => 250, // milliseconds
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Events
    |--------------------------------------------------------------------------
    |
    | Enable/disable cache events. When enabled, events will be fired when
    | items are read from or written to the cache.
    */
    'events' => [
        'enabled' => false,
        'log_events' => false,
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Serialization
    |--------------------------------------------------------------------------
    |
    | Configure serialization settings for cache values. This is used when
    | storing complex objects in the cache.
    */
    'serializer' => [
        'enabled' => true,
        'format' => 'php', // php, json, igbinary
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Compression
    |--------------------------------------------------------------------------
    |
    | Configure compression settings for cache values. This can help reduce
    | the size of cached data but adds CPU overhead.
    */
    'compression' => [
        'enabled' => false,
        'level' => -1, // -1 (default) to 9 (maximum)
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure cache monitoring settings. This helps track cache usage
    | and performance metrics.
    */
    'monitoring' => [
        'enabled' => false,
        'driver' => 'log', // log, statsd, prometheus
        'sample_rate' => 0.1, // 10% of operations
    ],
];
