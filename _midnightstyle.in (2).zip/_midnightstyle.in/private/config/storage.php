<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Default Filesystem Disk
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default filesystem disk that should be used
    | by the framework. The "local" disk, as well as a variety of cloud
    | based disks are available to your application for file storage.
    */
    'default' => $_ENV['FILESYSTEM_DISK'] ?? 'local',

    /*
    |--------------------------------------------------------------------------
    | Filesystem Disks
    |--------------------------------------------------------------------------
    |
    | Here you may configure as many filesystem "disks" as you wish, and you
    | may even configure multiple disks of the same driver. Defaults have
    | been set up for each driver as an example of the required values.
    |
    | Supported Drivers: "local", "ftp", "sftp", "s3"
    */
    'disks' => [
        'local' => [
            'driver' => 'local',
            'root' => BASE_PATH . '/private/storage',
            'permissions' => [
                'file' => [
                    'public' => 0644,
                    'private' => 0600,
                ],
                'dir' => [
                    'public' => 0755,
                    'private' => 0700,
                ],
            ],
            'throw' => false,
        ],

        'public' => [
            'driver' => 'local',
            'root' => BASE_PATH . '/public_html/storage',
            'url' => $_ENV['APP_URL'] . '/storage',
            'visibility' => 'public',
            'throw' => false,
        ],

        's3' => [
            'driver' => 's3',
            'key' => $_ENV['AWS_ACCESS_KEY_ID'],
            'secret' => $_ENV['AWS_SECRET_ACCESS_KEY'],
            'region' => $_ENV['AWS_DEFAULT_REGION'] ?? 'us-east-1',
            'bucket' => $_ENV['AWS_BUCKET'],
            'url' => $_ENV['AWS_URL'],
            'endpoint' => $_ENV['AWS_ENDPOINT'],
            'use_path_style_endpoint' => (bool)($_ENV['AWS_USE_PATH_STYLE_ENDPOINT'] ?? false),
            'throw' => false,
            'cache' => [
                'enabled' => true,
                'ttl' => 3600,
            ],
        ],

        'ftp' => [
            'driver' => 'ftp',
            'host' => $_ENV['FTP_HOST'],
            'username' => $_ENV['FTP_USERNAME'],
            'password' => $_ENV['FTP_PASSWORD'],
            'port' => (int)($_ENV['FTP_PORT'] ?? 21),
            'root' => $_ENV['FTP_ROOT'] ?? '/',
            'passive' => true,
            'ssl' => true,
            'timeout' => 30,
        ],

        'sftp' => [
            'driver' => 'sftp',
            'host' => $_ENV['SFTP_HOST'],
            'username' => $_ENV['SFTP_USERNAME'],
            'password' => $_ENV['SFTP_PASSWORD'],
            'port' => (int)($_ENV['SFTP_PORT'] ?? 22),
            'root' => $_ENV['SFTP_ROOT'] ?? '/',
            'privateKey' => $_ENV['SFTP_PRIVATE_KEY'],
            'timeout' => 30,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Symbolic Links
    |--------------------------------------------------------------------------
    |
    | Here you may configure the symbolic links that will be created when the
    | `storage:link` command is executed. The array keys should be
    | the locations of the links and the values should be their targets.
    */
    'links' => [
        BASE_PATH . '/public_html/storage' => BASE_PATH . '/private/storage/public',
    ],

    /*
    |--------------------------------------------------------------------------
    | Upload Configuration
    |--------------------------------------------------------------------------
    |
    | Configure file upload settings including maximum sizes, allowed types,
    | and validation rules.
    */
    'upload' => [
        'max_size' => 10 * 1024 * 1024, // 10MB
        'allowed_types' => [
            'image' => ['jpg', 'jpeg', 'png', 'gif', 'webp'],
            'document' => ['pdf', 'doc', 'docx', 'xls', 'xlsx'],
            'archive' => ['zip', 'rar', '7z'],
        ],
        'image' => [
            'max_width' => 2048,
            'max_height' => 2048,
            'quality' => 90,
        ],
        'sanitize' => true,
        'validate_mime' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Configuration
    |--------------------------------------------------------------------------
    |
    | Configure caching settings for file storage operations including
    | metadata caching and file content caching.
    */
    'cache' => [
        'enabled' => true,
        'ttl' => 3600,
        'prefix' => 'storage_',
        'store' => 'redis',
    ],

    /*
    |--------------------------------------------------------------------------
    | Backup Configuration
    |--------------------------------------------------------------------------
    |
    | Configure backup settings including backup schedule, retention,
    | and storage location.
    */
    'backup' => [
        'enabled' => true,
        'schedule' => '0 0 * * *', // Daily at midnight
        'retention' => [
            'daily' => 7,
            'weekly' => 4,
            'monthly' => 3,
        ],
        'disk' => 's3',
        'path' => 'backups',
    ],

    /*
    |--------------------------------------------------------------------------
    | Temporary Storage
    |--------------------------------------------------------------------------
    |
    | Configure temporary storage settings for handling uploads and
    | processing files.
    */
    'temp' => [
        'path' => BASE_PATH . '/private/storage/temp',
        'cleanup_after' => 24, // hours
        'max_size' => 100 * 1024 * 1024, // 100MB
    ],

    /*
    |--------------------------------------------------------------------------
    | Security
    |--------------------------------------------------------------------------
    |
    | Configure security settings for file storage including encryption
    | and access control.
    */
    'security' => [
        'encrypt_files' => false,
        'encryption_key' => $_ENV['STORAGE_ENCRYPTION_KEY'] ?? $_ENV['APP_KEY'],
        'signed_urls' => [
            'enabled' => true,
            'expiry' => 3600,
        ],
    ],
];
