<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Game Settings
    |--------------------------------------------------------------------------
    |
    | General game settings that apply to all games in the application.
    | These settings control basic game functionality and behavior.
    */
    'settings' => [
        'maintenance_mode' => (bool)($_ENV['GAME_MAINTENANCE'] ?? false),
        'debug_mode' => (bool)($_ENV['GAME_DEBUG'] ?? false),
        'max_players_per_game' => (int)($_ENV['MAX_PLAYERS_PER_GAME'] ?? 4),
        'default_currency' => $_ENV['GAME_CURRENCY'] ?? 'USD',
        'min_bet_amount' => (float)($_ENV['MIN_BET_AMOUNT'] ?? 1.00),
        'max_bet_amount' => (float)($_ENV['MAX_BET_AMOUNT'] ?? 1000.00),
    ],

    /*
    |--------------------------------------------------------------------------
    | Aviator Game Settings
    |--------------------------------------------------------------------------
    |
    | Configuration specific to the Aviator game including multipliers,
    | timing, and game-specific rules.
    */
    'aviator' => [
        'enabled' => true,
        'min_multiplier' => 1.00,
        'max_multiplier' => 100.00,
        'round_time' => 30, // seconds
        'preparation_time' => 5, // seconds
        'result_time' => 3, // seconds
        'auto_cashout' => [
            'enabled' => true,
            'min_multiplier' => 1.01,
            'max_multiplier' => 100.00,
        ],
        'house_edge' => 0.01, // 1%
        'crash_points' => [
            'min' => 1.00,
            'max' => 100.00,
            'precision' => 2,
        ],
        'limits' => [
            'min_bet' => 1.00,
            'max_bet' => 1000.00,
            'max_profit' => 10000.00,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Ludo Game Settings
    |--------------------------------------------------------------------------
    |
    | Configuration specific to the Ludo game including board settings,
    | piece movement, and game rules.
    */
    'ludo' => [
        'enabled' => true,
        'board_size' => 8,
        'pieces_per_player' => 4,
        'dice' => [
            'sides' => 6,
            'roll_time' => 2, // seconds
        ],
        'turn_time' => 30, // seconds
        'game_modes' => [
            'classic' => [
                'enabled' => true,
                'min_players' => 2,
                'max_players' => 4,
                'entry_fee' => 10.00,
                'prize_pool' => 38.00, // 95% of total entry fees
            ],
            'quick' => [
                'enabled' => true,
                'min_players' => 2,
                'max_players' => 2,
                'entry_fee' => 5.00,
                'prize_pool' => 9.50, // 95% of total entry fees
            ],
        ],
        'matchmaking' => [
            'timeout' => 60, // seconds
            'rating_range' => 200,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Room Management
    |--------------------------------------------------------------------------
    |
    | Settings for game room management including creation, joining,
    | and cleanup of game rooms.
    */
    'rooms' => [
        'cleanup_interval' => 300, // 5 minutes
        'inactive_timeout' => 1800, // 30 minutes
        'max_spectators' => 100,
        'chat_enabled' => true,
        'chat_cooldown' => 3, // seconds between messages
        'private_rooms' => [
            'enabled' => true,
            'code_length' => 6,
            'expiry_time' => 3600, // 1 hour
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Matchmaking Settings
    |--------------------------------------------------------------------------
    |
    | Configuration for the matchmaking system including queues,
    | ratings, and timeouts.
    */
    'matchmaking' => [
        'enabled' => true,
        'algorithm' => 'elo',
        'queue_timeout' => 60,
        'rating' => [
            'initial' => 1200,
            'k_factor' => 32,
            'min' => 0,
            'max' => 3000,
        ],
        'regions' => [
            'auto' => true,
            'available' => ['eu', 'us', 'asia'],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Rewards and Achievements
    |--------------------------------------------------------------------------
    |
    | Configuration for game rewards, achievements, and progression
    | systems.
    */
    'rewards' => [
        'daily_bonus' => [
            'enabled' => true,
            'amount' => 10.00,
            'streak_multiplier' => 1.5,
            'max_streak' => 7,
        ],
        'achievements' => [
            'enabled' => true,
            'categories' => ['wins', 'bets', 'multipliers', 'streaks'],
        ],
        'levels' => [
            'enabled' => true,
            'max_level' => 100,
            'xp_per_bet' => 1,
            'xp_per_win' => 5,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Anti-Cheat Settings
    |--------------------------------------------------------------------------
    |
    | Configuration for anti-cheat measures and game integrity
    | protection.
    */
    'anti_cheat' => [
        'enabled' => true,
        'verify_client' => true,
        'max_ping' => 500, // milliseconds
        'suspicious_patterns' => [
            'max_wins_per_hour' => 50,
            'max_bets_per_minute' => 10,
            'min_time_between_bets' => 1, // seconds
        ],
        'action_triggers' => [
            'warning' => 3,
            'temporary_ban' => 5,
            'permanent_ban' => 10,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Game Server Settings
    |--------------------------------------------------------------------------
    |
    | Configuration for game servers including regions, capacity,
    | and performance settings.
    */
    'servers' => [
        'regions' => [
            'eu' => [
                'host' => $_ENV['GAME_SERVER_EU_HOST'] ?? 'localhost',
                'port' => (int)($_ENV['GAME_SERVER_EU_PORT'] ?? 8080),
                'capacity' => 1000,
            ],
            'us' => [
                'host' => $_ENV['GAME_SERVER_US_HOST'] ?? 'localhost',
                'port' => (int)($_ENV['GAME_SERVER_US_PORT'] ?? 8081),
                'capacity' => 1000,
            ],
            'asia' => [
                'host' => $_ENV['GAME_SERVER_ASIA_HOST'] ?? 'localhost',
                'port' => (int)($_ENV['GAME_SERVER_ASIA_PORT'] ?? 8082),
                'capacity' => 1000,
            ],
        ],
        'performance' => [
            'tick_rate' => 64,
            'max_latency' => 100,
            'buffer_size' => 1024,
        ],
    ],
];
