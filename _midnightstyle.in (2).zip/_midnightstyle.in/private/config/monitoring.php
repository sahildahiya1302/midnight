<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Monitoring Status
    |--------------------------------------------------------------------------
    |
    | Enable or disable different types of monitoring. This allows you to turn
    | off specific monitoring features in different environments.
    */
    'enabled' => [
        'performance' => (bool)($_ENV['MONITOR_PERFORMANCE'] ?? true),
        'errors' => (bool)($_ENV['MONITOR_ERRORS'] ?? true),
        'security' => (bool)($_ENV['MONITOR_SECURITY'] ?? true),
        'uptime' => (bool)($_ENV['MONITOR_UPTIME'] ?? true),
        'database' => (bool)($_ENV['MONITOR_DATABASE'] ?? true),
        'queue' => (bool)($_ENV['MONITOR_QUEUE'] ?? true),
        'cache' => (bool)($_ENV['MONITOR_CACHE'] ?? true),
        'websocket' => (bool)($_ENV['MONITOR_WEBSOCKET'] ?? true),
    ],

    /*
    |--------------------------------------------------------------------------
    | Performance Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure performance monitoring settings including thresholds and
    | metrics collection.
    */
    'performance' => [
        'metrics' => [
            'response_time' => [
                'enabled' => true,
                'threshold' => 500, // milliseconds
                'alert' => true,
            ],
            'memory_usage' => [
                'enabled' => true,
                'threshold' => 128, // MB
                'alert' => true,
            ],
            'cpu_usage' => [
                'enabled' => true,
                'threshold' => 80, // percentage
                'alert' => true,
            ],
        ],
        'profiling' => [
            'enabled' => (bool)($_ENV['ENABLE_PROFILING'] ?? false),
            'sample_rate' => 0.1, // 10% of requests
            'max_traces' => 1000,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Error Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure error tracking and reporting settings including which errors
    | to track and how to handle them.
    */
    'errors' => [
        'tracking' => [
            'levels' => [
                E_ERROR,
                E_WARNING,
                E_PARSE,
                E_NOTICE,
            ],
            'ignore' => [
                'NotFoundHttpException',
                'ValidationException',
            ],
        ],
        'reporting' => [
            'email' => $_ENV['ADMIN_EMAIL'] ?? null,
            'slack' => $_ENV['SLACK_WEBHOOK_URL'] ?? null,
            'sentry' => [
                'dsn' => $_ENV['SENTRY_DSN'] ?? null,
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Security Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure security monitoring including suspicious activity detection
    | and intrusion detection.
    */
    'security' => [
        'login_attempts' => [
            'track' => true,
            'threshold' => 5,
            'window' => 300, // seconds
        ],
        'request_rate' => [
            'track' => true,
            'threshold' => 100, // requests per minute
            'window' => 60, // seconds
        ],
        'suspicious_ips' => [
            'track' => true,
            'threshold' => 10, // suspicious actions
            'window' => 3600, // seconds
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Uptime Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure uptime monitoring settings including health checks and
    | availability tracking.
    */
    'uptime' => [
        'checks' => [
            'interval' => 60, // seconds
            'timeout' => 5, // seconds
            'endpoints' => [
                '/' => 200,
                '/api/health' => 200,
                '/api/ping' => 200,
            ],
        ],
        'notifications' => [
            'downtime' => true,
            'recovery' => true,
            'channels' => ['email', 'slack'],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Database Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure database monitoring settings including query logging and
    | performance tracking.
    */
    'database' => [
        'query_log' => [
            'enabled' => true,
            'threshold' => 1000, // milliseconds
            'ignore_patterns' => [
                '/^SELECT \* FROM `sessions`/',
            ],
        ],
        'connections' => [
            'track' => true,
            'max' => 100,
            'alert_threshold' => 80,
        ],
        'deadlocks' => [
            'track' => true,
            'alert' => true,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Queue Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure queue monitoring settings including job processing and
    | failure tracking.
    */
    'queue' => [
        'jobs' => [
            'track' => true,
            'retention' => 7, // days
            'alert_on_failure' => true,
        ],
        'workers' => [
            'track' => true,
            'max_runtime' => 3600, // seconds
            'memory_limit' => 128, // MB
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Cache Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure cache monitoring settings including hit rates and
    | storage usage.
    */
    'cache' => [
        'hits' => [
            'track' => true,
            'threshold' => 0.8, // 80% hit rate
        ],
        'storage' => [
            'track' => true,
            'max_size' => 1024, // MB
            'alert_threshold' => 0.9, // 90% usage
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | WebSocket Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure WebSocket monitoring settings including connection tracking
    | and message rates.
    */
    'websocket' => [
        'connections' => [
            'track' => true,
            'max' => 1000,
            'alert_threshold' => 900,
        ],
        'messages' => [
            'track' => true,
            'rate_limit' => 100, // per second
            'log_size' => 1000,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Metrics Storage
    |--------------------------------------------------------------------------
    |
    | Configure how and where monitoring metrics are stored.
    */
    'storage' => [
        'driver' => $_ENV['MONITOR_STORAGE'] ?? 'redis',
        'retention' => [
            'metrics' => 30, // days
            'logs' => 7, // days
            'traces' => 3, // days
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Alerting
    |--------------------------------------------------------------------------
    |
    | Configure alerting settings including notification channels and
    | alert thresholds.
    */
    'alerting' => [
        'channels' => [
            'email' => [
                'enabled' => true,
                'recipients' => explode(',', $_ENV['ALERT_EMAILS'] ?? ''),
            ],
            'slack' => [
                'enabled' => true,
                'webhook' => $_ENV['SLACK_WEBHOOK_URL'] ?? null,
                'channel' => $_ENV['SLACK_CHANNEL'] ?? '#monitoring',
            ],
        ],
        'throttling' => [
            'enabled' => true,
            'frequency' => 300, // seconds
        ],
    ],
];
