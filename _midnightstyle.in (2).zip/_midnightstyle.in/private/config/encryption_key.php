<?php
// Generate a secure encryption key for session data and sensitive information
$key = base64_encode(random_bytes(32));

// Return the encryption key
return base64_decode($key);

// Store the key securely - DO NOT COMMIT THIS VALUE
// Key: {$key}
