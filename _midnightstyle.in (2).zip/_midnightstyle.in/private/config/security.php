<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Authentication
    |--------------------------------------------------------------------------
    |
    | Here you may configure authentication settings for your application.
    | These settings control how users are authenticated and managed.
    */
    'auth' => [
        // Default authentication guard
        'default' => 'web',

        // Authentication guards
        'guards' => [
            'web' => [
                'driver' => 'session',
                'provider' => 'users',
            ],
            'api' => [
                'driver' => 'jwt',
                'provider' => 'users',
                'expires' => 60, // minutes
            ],
        ],

        // User providers
        'providers' => [
            'users' => [
                'driver' => 'database',
                'table' => 'users',
                'model' => App\Models\User::class,
            ],
        ],

        // Password reset settings
        'passwords' => [
            'timeout' => 60, // minutes
            'throttle' => 60, // minutes
        ],

        // Session authentication settings
        'session' => [
            'expire_on_close' => false,
            'expire_after' => 120, // minutes
            'rotate_after' => 30, // minutes
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | CSRF Protection
    |--------------------------------------------------------------------------
    |
    | CSRF token settings and exclusions. These protect your application from
    | cross-site request forgery attacks.
    */
    'csrf' => [
        'enabled' => true,
        'token_length' => 40,
        'token_lifetime' => 120, // minutes
        'same_site' => 'lax',
        
        // Paths that should be excluded from CSRF verification
        'excluded_paths' => [
            'api/*',
            'webhooks/*',
        ],

        // HTTP methods that don't require CSRF verification
        'excluded_methods' => [
            'GET',
            'HEAD',
            'OPTIONS',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Rate Limiting
    |--------------------------------------------------------------------------
    |
    | Configure rate limiting settings to prevent abuse of your application.
    | Limits are defined as attempts per time period.
    */
    'rate_limit' => [
        'enabled' => true,
        'storage' => 'redis', // redis, file, database

        // Default limits
        'default' => [
            'attempts' => 60,
            'decay_minutes' => 1,
        ],

        // Custom limits for specific routes
        'limits' => [
            'auth' => [
                'attempts' => 5,
                'decay_minutes' => 10,
            ],
            'api' => [
                'attempts' => 60,
                'decay_minutes' => 1,
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Cross-Origin Resource Sharing (CORS)
    |--------------------------------------------------------------------------
    |
    | Configure CORS settings for your application's API endpoints.
    */
    'cors' => [
        'enabled' => true,
        'allowed_origins' => ['*'],
        'allowed_methods' => ['*'],
        'allowed_headers' => ['*'],
        'exposed_headers' => [],
        'max_age' => 0,
        'supports_credentials' => false,
    ],

    /*
    |--------------------------------------------------------------------------
    | Content Security Policy (CSP)
    |--------------------------------------------------------------------------
    |
    | Configure Content Security Policy headers to prevent XSS attacks.
    */
    'csp' => [
        'enabled' => true,
        'report_only' => false,
        'report_uri' => null,
        
        // CSP directives
        'directives' => [
            'default-src' => ["'self'"],
            'script-src' => ["'self'", "'unsafe-inline'", "'unsafe-eval'"],
            'style-src' => ["'self'", "'unsafe-inline'"],
            'img-src' => ["'self'", 'data:', 'https:'],
            'font-src' => ["'self'", 'data:', 'https:'],
            'connect-src' => ["'self'"],
            'media-src' => ["'self'"],
            'object-src' => ["'none'"],
            'frame-src' => ["'self'"],
            'frame-ancestors' => ["'none'"],
            'form-action' => ["'self'"],
            'base-uri' => ["'self'"],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Security Headers
    |--------------------------------------------------------------------------
    |
    | Configure additional security headers for your application.
    */
    'headers' => [
        'x-frame-options' => 'DENY',
        'x-content-type-options' => 'nosniff',
        'x-xss-protection' => '1; mode=block',
        'referrer-policy' => 'strict-origin-when-cross-origin',
        'strict-transport-security' => 'max-age=31536000; includeSubDomains',
        'permissions-policy' => 'accelerometer=(), camera=(), geolocation=(), gyroscope=(), magnetometer=(), microphone=(), payment=(), usb=()',
    ],

    /*
    |--------------------------------------------------------------------------
    | Encryption
    |--------------------------------------------------------------------------
    |
    | Configure encryption settings for your application.
    */
    'encryption' => [
        'key' => $_ENV['APP_KEY'],
        'cipher' => 'AES-256-CBC',
        'hash_algo' => 'sha256',
        'hash_length' => 32,
    ],

    /*
    |--------------------------------------------------------------------------
    | JWT Settings
    |--------------------------------------------------------------------------
    |
    | Configure JSON Web Token settings for API authentication.
    */
    'jwt' => [
        'secret' => $_ENV['JWT_SECRET'] ?? $_ENV['APP_KEY'],
        'algo' => 'HS256',
        'expire' => 60, // minutes
        'refresh_expire' => 20160, // minutes (14 days)
        'leeway' => 0, // seconds
    ],
];
