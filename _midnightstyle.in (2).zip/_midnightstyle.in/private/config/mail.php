<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Default Mailer
    |--------------------------------------------------------------------------
    |
    | This option controls the default mailer that is used to send any email
    | messages sent by your application. Alternative mailers may be setup
    | and used as needed; however, this mailer will be used by default.
    */
    'default' => $_ENV['MAIL_MAILER'] ?? 'smtp',

    /*
    |--------------------------------------------------------------------------
    | Mailer Configurations
    |--------------------------------------------------------------------------
    |
    | Here you may configure all of the mailers used by your application plus
    | their respective settings. Several examples have been configured for
    | you and you're free to add your own as your application requires.
    |
    | Supported: "smtp", "sendmail", "mailgun", "ses", "postmark",
    |            "log", "array", "failover"
    */
    'mailers' => [
        'smtp' => [
            'transport' => 'smtp',
            'host' => $_ENV['MAIL_HOST'] ?? 'smtp.mailgun.org',
            'port' => $_ENV['MAIL_PORT'] ?? 587,
            'encryption' => $_ENV['MAIL_ENCRYPTION'] ?? 'tls',
            'username' => $_ENV['MAIL_USERNAME'],
            'password' => $_ENV['MAIL_PASSWORD'],
            'timeout' => null,
            'local_domain' => $_ENV['MAIL_EHLO_DOMAIN'] ?? null,
            'verify_peer' => true,
        ],

        'ses' => [
            'transport' => 'ses',
            'key' => $_ENV['AWS_ACCESS_KEY_ID'],
            'secret' => $_ENV['AWS_SECRET_ACCESS_KEY'],
            'region' => $_ENV['AWS_DEFAULT_REGION'] ?? 'us-east-1',
        ],

        'mailgun' => [
            'transport' => 'mailgun',
            'domain' => $_ENV['MAILGUN_DOMAIN'],
            'secret' => $_ENV['MAILGUN_SECRET'],
            'endpoint' => $_ENV['MAILGUN_ENDPOINT'] ?? 'api.mailgun.net',
            'scheme' => 'https',
        ],

        'postmark' => [
            'transport' => 'postmark',
            'token' => $_ENV['POSTMARK_TOKEN'],
        ],

        'sendmail' => [
            'transport' => 'sendmail',
            'path' => '/usr/sbin/sendmail -bs -i',
        ],

        'log' => [
            'transport' => 'log',
            'channel' => $_ENV['MAIL_LOG_CHANNEL'] ?? 'stack',
        ],

        'array' => [
            'transport' => 'array',
        ],

        'failover' => [
            'transport' => 'failover',
            'mailers' => [
                'smtp',
                'log',
            ],
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Global "From" Address
    |--------------------------------------------------------------------------
    |
    | You may wish for all e-mails sent by your application to be sent from
    | the same address. Here, you may specify a name and address that is
    | used globally for all e-mails that are sent by your application.
    */
    'from' => [
        'address' => $_ENV['MAIL_FROM_ADDRESS'] ?? 'noreply@midnightstyle.in',
        'name' => $_ENV['MAIL_FROM_NAME'] ?? 'MidnightStyle',
    ],

    /*
    |--------------------------------------------------------------------------
    | Global "Reply To" Address
    |--------------------------------------------------------------------------
    |
    | Here you may specify the "reply to" address that is used for all e-mails
    | sent by your application where one is not otherwise explicitly specified.
    */
    'reply_to' => [
        'address' => $_ENV['MAIL_REPLY_TO_ADDRESS'] ?? 'support@midnightstyle.in',
        'name' => $_ENV['MAIL_REPLY_TO_NAME'] ?? 'MidnightStyle Support',
    ],

    /*
    |--------------------------------------------------------------------------
    | Email Templates
    |--------------------------------------------------------------------------
    |
    | Here you may specify the paths to your email templates. These templates
    | can be used when sending emails from your application.
    */
    'templates' => [
        'path' => BASE_PATH . '/public_html/views/emails',
        'cache' => BASE_PATH . '/private/storage/cache/emails',
    ],

    /*
    |--------------------------------------------------------------------------
    | Email Queue
    |--------------------------------------------------------------------------
    |
    | Configure email queue settings including the queue name and connection.
    | Queued emails can improve application performance by sending emails
    | in the background.
    */
    'queue' => [
        'enabled' => (bool)($_ENV['MAIL_QUEUE_ENABLED'] ?? false),
        'connection' => $_ENV['MAIL_QUEUE_CONNECTION'] ?? 'redis',
        'queue' => $_ENV['MAIL_QUEUE_NAME'] ?? 'emails',
        'tries' => 3,
        'retry_after' => 60,
    ],

    /*
    |--------------------------------------------------------------------------
    | Email Rate Limiting
    |--------------------------------------------------------------------------
    |
    | Configure rate limiting for email sending to prevent abuse and ensure
    | fair usage of the email service.
    */
    'rate_limit' => [
        'enabled' => true,
        'max_per_minute' => 60,
        'max_per_hour' => 1000,
        'max_per_day' => 10000,
    ],

    /*
    |--------------------------------------------------------------------------
    | Email Tracking
    |--------------------------------------------------------------------------
    |
    | Configure email tracking settings including open tracking and click
    | tracking. This helps monitor email engagement.
    */
    'tracking' => [
        'opens' => [
            'enabled' => true,
            'pixel' => true,
        ],
        'clicks' => [
            'enabled' => true,
            'track_plain_text' => false,
        ],
        'unsubscribe' => [
            'enabled' => true,
            'header' => true,
            'link' => true,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Email Testing
    |--------------------------------------------------------------------------
    |
    | Configure email testing settings including test mode and test recipients.
    | This is useful for testing email functionality in development.
    */
    'testing' => [
        'enabled' => (bool)($_ENV['MAIL_TESTING_ENABLED'] ?? false),
        'forward_to' => $_ENV['MAIL_TESTING_FORWARD_TO'] ?? null,
        'intercept' => (bool)($_ENV['MAIL_TESTING_INTERCEPT'] ?? true),
    ],
];
