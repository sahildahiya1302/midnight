<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Default Queue Connection Name
    |--------------------------------------------------------------------------
    |
    | The framework's queue API supports a variety of back-ends via a single
    | API, giving you convenient access to each back-end using the same
    | syntax for every one. Here you may define a default connection.
    */
    'default' => $_ENV['QUEUE_CONNECTION'] ?? 'redis',

    /*
    |--------------------------------------------------------------------------
    | Queue Connections
    |--------------------------------------------------------------------------
    |
    | Here you may configure the connection information for each server that
    | is used by your application. A default configuration has been added
    | for each back-end shipped with the framework. You're free to add more.
    |
    | Drivers: "sync", "database", "redis", "beanstalkd", "sqs", "null"
    */
    'connections' => [
        'sync' => [
            'driver' => 'sync',
        ],

        'database' => [
            'driver' => 'database',
            'table' => 'jobs',
            'queue' => 'default',
            'retry_after' => 90,
            'after_commit' => false,
        ],

        'redis' => [
            'driver' => 'redis',
            'connection' => 'default',
            'queue' => $_ENV['REDIS_QUEUE'] ?? 'default',
            'retry_after' => 90,
            'block_for' => null,
            'after_commit' => false,
        ],

        'beanstalkd' => [
            'driver' => 'beanstalkd',
            'host' => $_ENV['BEANSTALKD_HOST'] ?? 'localhost',
            'queue' => 'default',
            'retry_after' => 90,
            'block_for' => 0,
            'after_commit' => false,
        ],

        'sqs' => [
            'driver' => 'sqs',
            'key' => $_ENV['AWS_ACCESS_KEY_ID'],
            'secret' => $_ENV['AWS_SECRET_ACCESS_KEY'],
            'prefix' => $_ENV['SQS_PREFIX'] ?? 'https://sqs.us-east-1.amazonaws.com/your-account-id',
            'queue' => $_ENV['SQS_QUEUE'] ?? 'default',
            'suffix' => $_ENV['SQS_SUFFIX'] ?? null,
            'region' => $_ENV['AWS_DEFAULT_REGION'] ?? 'us-east-1',
            'after_commit' => false,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Job Batching
    |--------------------------------------------------------------------------
    |
    | The following options configure the database and table that store job
    | batching information. These options may be updated to any database
    | connection and table which has been defined by your application.
    */
    'batching' => [
        'database' => $_ENV['DB_CONNECTION'] ?? 'mysql',
        'table' => 'job_batches',
    ],

    /*
    |--------------------------------------------------------------------------
    | Failed Queue Jobs
    |--------------------------------------------------------------------------
    |
    | These options configure the behavior of failed queue job logging so you
    | can control which database and table are used to store the jobs that
    | have failed. You may change them to any database / table you wish.
    */
    'failed' => [
        'driver' => $_ENV['QUEUE_FAILED_DRIVER'] ?? 'database',
        'database' => $_ENV['DB_CONNECTION'] ?? 'mysql',
        'table' => 'failed_jobs',
    ],

    /*
    |--------------------------------------------------------------------------
    | Queue Worker Configuration
    |--------------------------------------------------------------------------
    |
    | Here you may configure the queue worker settings. These determine how
    | jobs are processed and various timeouts for both the worker and job.
    */
    'worker' => [
        'sleep' => 3,
        'tries' => 3,
        'timeout' => 60,
        'memory' => 128,
        'nice' => 0,
        'rest' => 0,
    ],

    /*
    |--------------------------------------------------------------------------
    | Queue Priorities
    |--------------------------------------------------------------------------
    |
    | Configure queue priorities and their respective settings. Higher priority
    | queues will be processed before lower priority ones.
    */
    'priorities' => [
        'high' => [
            'timeout' => 30,
            'tries' => 5,
            'memory' => 256,
        ],
        'default' => [
            'timeout' => 60,
            'tries' => 3,
            'memory' => 128,
        ],
        'low' => [
            'timeout' => 120,
            'tries' => 1,
            'memory' => 64,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Queue Events
    |--------------------------------------------------------------------------
    |
    | Configure queue event handling including success, failure, and retry
    | events. This helps monitor and debug queue processing.
    */
    'events' => [
        'enabled' => true,
        'handlers' => [
            'success' => App\Queue\Handlers\JobSuccessHandler::class,
            'failure' => App\Queue\Handlers\JobFailureHandler::class,
            'retry' => App\Queue\Handlers\JobRetryHandler::class,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Queue Monitoring
    |--------------------------------------------------------------------------
    |
    | Configure queue monitoring settings including metrics collection
    | and alerting thresholds.
    */
    'monitoring' => [
        'enabled' => true,
        'metrics' => [
            'jobs' => true,
            'memory' => true,
            'duration' => true,
        ],
        'thresholds' => [
            'failed_jobs' => 10,
            'queue_size' => 1000,
            'processing_time' => 300,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Queue Rate Limiting
    |--------------------------------------------------------------------------
    |
    | Configure rate limiting for queue processing to prevent overload
    | and ensure fair resource usage.
    */
    'rate_limit' => [
        'enabled' => true,
        'max_jobs_per_minute' => 60,
        'max_jobs_per_hour' => 1000,
        'decay_minutes' => 1,
    ],
];
