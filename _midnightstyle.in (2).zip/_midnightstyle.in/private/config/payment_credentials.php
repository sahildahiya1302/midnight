<?php
class PaymentConfig {
    // Payment Gateway Status (true = active, false = inactive)
    private static $GATEWAY_STATUS = [
        'razorpay' => true,
        'payu' => true,
        'stripe' => true
    ];

    // Test Mode Configuration
    private static $TEST_MODE = true; // Set to false in production

    // Razorpay Credentials
    private static $RAZORPAY = [
        'test' => [
            'key_id' => 'rzp_test_key',
            'key_secret' => 'rzp_test_secret',
            'webhook_secret' => 'rzp_test_webhook_secret'
        ],
        'live' => [
            'key_id' => 'rzp_live_key',
            'key_secret' => 'rzp_live_secret',
            'webhook_secret' => 'rzp_live_webhook_secret'
        ]
    ];

    // PayU Credentials
    private static $PAYU = [
        'test' => [
            'merchant_key' => 'payu_test_merchant_key',
            'merchant_salt' => 'payu_test_merchant_salt',
            'auth_header' => 'payu_test_auth_header'
        ],
        'live' => [
            'merchant_key' => 'payu_live_merchant_key',
            'merchant_salt' => 'payu_live_merchant_salt',
            'auth_header' => 'payu_live_auth_header'
        ]
    ];

    // Stripe Credentials
    private static $STRIPE = [
        'test' => [
            'publishable_key' => 'pk_test_key',
            'secret_key' => 'sk_test_secret',
            'webhook_secret' => 'whsec_test'
        ],
        'live' => [
            'publishable_key' => 'pk_live_key',
            'secret_key' => 'sk_live_secret',
            'webhook_secret' => 'whsec_live'
        ]
    ];

    // Currency Configuration
    private static $CURRENCY = 'INR';
    private static $CURRENCY_SYMBOL = '₹';

    // Payment Limits
    private static $LIMITS = [
        'min_deposit' => 10.00,
        'max_deposit' => 50000.00,
        'min_withdrawal' => 100.00,
        'max_withdrawal' => 10000.00
    ];

    // Get Gateway Status
    public static function isGatewayActive($gateway) {
        return self::$GATEWAY_STATUS[$gateway] ?? false;
    }

    // Get Test Mode Status
    public static function isTestMode() {
        return self::$TEST_MODE;
    }

    // Get Razorpay Credentials
    public static function getRazorpayConfig() {
        $mode = self::$TEST_MODE ? 'test' : 'live';
        return self::$RAZORPAY[$mode];
    }

    // Get PayU Credentials
    public static function getPayUConfig() {
        $mode = self::$TEST_MODE ? 'test' : 'live';
        return self::$PAYU[$mode];
    }

    // Get Stripe Credentials
    public static function getStripeConfig() {
        $mode = self::$TEST_MODE ? 'test' : 'live';
        return self::$STRIPE[$mode];
    }

    // Get Currency Details
    public static function getCurrency() {
        return [
            'code' => self::$CURRENCY,
            'symbol' => self::$CURRENCY_SYMBOL
        ];
    }

    // Get Payment Limits
    public static function getLimits() {
        return self::$LIMITS;
    }

    // Get Active Gateways
    public static function getActiveGateways() {
        return array_filter(
            self::$GATEWAY_STATUS,
            function($status) { return $status === true; },
            ARRAY_FILTER_USE_BOTH
        );
    }

    // Validate Amount for Transaction
    public static function validateAmount($amount, $type = 'deposit') {
        $limits = self::$LIMITS;
        
        if ($type === 'deposit') {
            return $amount >= $limits['min_deposit'] && $amount <= $limits['max_deposit'];
        } elseif ($type === 'withdrawal') {
            return $amount >= $limits['min_withdrawal'] && $amount <= $limits['max_withdrawal'];
        }
        
        return false;
    }

    // Format Amount with Currency
    public static function formatAmount($amount) {
        return self::$CURRENCY_SYMBOL . ' ' . number_format($amount, 2);
    }

    // Get Gateway Display Name
    public static function getGatewayDisplayName($gateway) {
        $names = [
            'razorpay' => 'Razorpay',
            'payu' => 'PayU',
            'stripe' => 'Stripe'
        ];
        return $names[$gateway] ?? $gateway;
    }

    // Get Gateway Logo URL
    public static function getGatewayLogo($gateway) {
        $logos = [
            'razorpay' => '/assets/images/payment/razorpay-logo.png',
            'payu' => '/assets/images/payment/payu-logo.png',
            'stripe' => '/assets/images/payment/stripe-logo.png'
        ];
        return $logos[$gateway] ?? '';
    }

    // Get Gateway Success URL
    public static function getSuccessUrl($gateway) {
        $baseUrl = 'https://midnightstyle.in';
        return $baseUrl . "/payment/success/$gateway";
    }

    // Get Gateway Failure URL
    public static function getFailureUrl($gateway) {
        $baseUrl = 'https://midnightstyle.in';
        return $baseUrl . "/payment/failure/$gateway";
    }

    // Get Gateway Webhook URL
    public static function getWebhookUrl($gateway) {
        $baseUrl = 'https://midnightstyle.in';
        return $baseUrl . "/api/webhooks/$gateway";
    }

    // Generate Transaction Reference
    public static function generateTransactionRef($prefix = 'TXN') {
        return $prefix . '_' . time() . '_' . bin2hex(random_bytes(4));
    }

    // Verify Gateway Response Signature
    public static function verifySignature($gateway, $data, $signature) {
        switch ($gateway) {
            case 'razorpay':
                return self::verifyRazorpaySignature($data, $signature);
            case 'payu':
                return self::verifyPayUSignature($data, $signature);
            case 'stripe':
                return self::verifyStripeSignature($data, $signature);
            default:
                return false;
        }
    }

    private static function verifyRazorpaySignature($data, $signature) {
        $config = self::getRazorpayConfig();
        $expectedSignature = hash_hmac('sha256', $data['order_id'] . '|' . $data['payment_id'], $config['key_secret']);
        return hash_equals($expectedSignature, $signature);
    }

    private static function verifyPayUSignature($data, $signature) {
        $config = self::getPayUConfig();
        $hashString = $config['merchant_key'] . '|' . $data['txnid'] . '|' . $data['amount'] . '|' . $data['productinfo'] . '|' . $data['firstname'] . '|' . $data['email'] . '|||||||||||' . $config['merchant_salt'];
        $hash = strtolower(hash('sha512', $hashString));
        return hash_equals($hash, $signature);
    }

    private static function verifyStripeSignature($payload, $sigHeader) {
        $config = self::getStripeConfig();
        try {
            \Stripe\Webhook::constructEvent(
                $payload,
                $sigHeader,
                $config['webhook_secret']
            );
            return true;
        } catch (\Exception $e) {
            return false;
        }
    }
}
