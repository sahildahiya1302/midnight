<?php

return [
    /*
    |--------------------------------------------------------------------------
    | View Storage Paths
    |--------------------------------------------------------------------------
    |
    | Most templating systems load templates from disk. Here you may specify
    | an array of paths that should be checked for your views.
    */
    'paths' => [
        BASE_PATH . '/public_html/views',
        BASE_PATH . '/public_html/views/layouts',
        BASE_PATH . '/public_html/views/components',
        BASE_PATH . '/public_html/views/partials',
    ],

    /*
    |--------------------------------------------------------------------------
    | Compiled View Path
    |--------------------------------------------------------------------------
    |
    | This option determines where all the compiled templates will be
    | stored for your application. Typically, this is within the storage
    | directory. However, as usual, you are free to change this value.
    */
    'compiled' => BASE_PATH . '/private/storage/cache/views',

    /*
    |--------------------------------------------------------------------------
    | View Cache
    |--------------------------------------------------------------------------
    |
    | Configure view caching options. When enabled, views will be cached
    | until they are modified. This can significantly improve performance
    | in production environments.
    */
    'cache' => [
        'enabled' => (bool)($_ENV['VIEW_CACHE'] ?? false),
        'lifetime' => (int)($_ENV['VIEW_CACHE_LIFETIME'] ?? 3600), // seconds
        'driver' => $_ENV['VIEW_CACHE_DRIVER'] ?? 'file', // file, redis
    ],

    /*
    |--------------------------------------------------------------------------
    | Default View Extensions
    |--------------------------------------------------------------------------
    |
    | Define the file extensions that should be treated as views.
    | The engine will look for these extensions when resolving views.
    */
    'extensions' => [
        'php',
        'html',
        'tpl',
    ],

    /*
    |--------------------------------------------------------------------------
    | View Composers
    |--------------------------------------------------------------------------
    |
    | View composers allow you to attach data to views whenever they're rendered.
    | Register composers for specific views or patterns here.
    */
    'composers' => [
        // Attach data to all views
        '*' => [
            App\View\Composers\GlobalComposer::class,
        ],

        // Attach data to specific layouts
        'layouts.*' => [
            App\View\Composers\LayoutComposer::class,
        ],

        // Attach data to specific views
        'user.profile' => [
            App\View\Composers\UserProfileComposer::class,
        ],
        'games.*' => [
            App\View\Composers\GameComposer::class,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | View Creators
    |--------------------------------------------------------------------------
    |
    | View creators are similar to view composers, but they are executed
    | immediately when the view is instantiated. Register creators here.
    */
    'creators' => [
        'admin.*' => [
            App\View\Creators\AdminViewCreator::class,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | View Directives
    |--------------------------------------------------------------------------
    |
    | Custom Blade-style directives for your views. These are compiled into
    | regular PHP when the view is rendered.
    */
    'directives' => [
        // Authentication directives
        'auth' => App\View\Directives\AuthDirective::class,
        'guest' => App\View\Directives\GuestDirective::class,
        'role' => App\View\Directives\RoleDirective::class,

        // Asset directives
        'asset' => App\View\Directives\AssetDirective::class,
        'style' => App\View\Directives\StyleDirective::class,
        'script' => App\View\Directives\ScriptDirective::class,

        // Form directives
        'csrf' => App\View\Directives\CsrfDirective::class,
        'method' => App\View\Directives\MethodDirective::class,
        'error' => App\View\Directives\ErrorDirective::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Shared Data
    |--------------------------------------------------------------------------
    |
    | Data that should be available to all views. This is useful for
    | application-wide data that doesn't change often.
    */
    'shared' => [
        'app_name' => $_ENV['APP_NAME'] ?? 'MidnightStyle',
        'app_url' => $_ENV['APP_URL'] ?? 'http://localhost',
        'app_version' => $_ENV['APP_VERSION'] ?? '1.0.0',
    ],

    /*
    |--------------------------------------------------------------------------
    | View Engine Configuration
    |--------------------------------------------------------------------------
    |
    | Configuration options for the view engine including debugging,
    | error handling, and template inheritance settings.
    */
    'engine' => [
        'debug' => (bool)($_ENV['APP_DEBUG'] ?? false),
        'strict_variables' => true,
        'strict_templates' => true,
        'auto_reload' => true,
        'template_inheritance' => true,
    ],

    /*
    |--------------------------------------------------------------------------
    | Error Views
    |--------------------------------------------------------------------------
    |
    | Define custom error views for different HTTP status codes.
    | These will be used when an error occurs during view rendering.
    */
    'errors' => [
        '403' => 'errors.403',
        '404' => 'errors.404',
        '419' => 'errors.419',
        '429' => 'errors.429',
        '500' => 'errors.500',
        '503' => 'errors.maintenance',
    ],
];
