<?php

return [
    /*
    |--------------------------------------------------------------------------
    | Application Name
    |--------------------------------------------------------------------------
    |
    | This value is the name of your application. This value is used when the
    | framework needs to place the application's name in a notification or
    | any other location as required by the application or its packages.
    */
    'name' => $_ENV['APP_NAME'] ?? 'MidnightStyle',

    /*
    |--------------------------------------------------------------------------
    | Application Environment
    |--------------------------------------------------------------------------
    |
    | This value determines the "environment" your application is currently
    | running in. This may determine how you prefer to configure various
    | services the application utilizes. Set this in your ".env" file.
    */
    'env' => $_ENV['APP_ENV'] ?? 'production',

    /*
    |--------------------------------------------------------------------------
    | Application Debug Mode
    |--------------------------------------------------------------------------
    |
    | When your application is in debug mode, detailed error messages with
    | stack traces will be shown on every error that occurs within your
    | application. If disabled, a simple generic error page is shown.
    */
    'debug' => (bool)($_ENV['APP_DEBUG'] ?? false),

    /*
    |--------------------------------------------------------------------------
    | Application URL
    |--------------------------------------------------------------------------
    |
    | This URL is used by the console to properly generate URLs when using
    | the Artisan command line tool. You should set this to the root of
    | your application so that it is used when running Artisan tasks.
    */
    'url' => $_ENV['APP_URL'] ?? 'http://localhost',

    /*
    |--------------------------------------------------------------------------
    | Application Timezone
    |--------------------------------------------------------------------------
    |
    | Here you may specify the default timezone for your application, which
    | will be used by the PHP date and date-time functions. We have gone
    | ahead and set this to a sensible default for you out of the box.
    */
    'timezone' => $_ENV['APP_TIMEZONE'] ?? 'UTC',

    /*
    |--------------------------------------------------------------------------
    | Application Locale Configuration
    |--------------------------------------------------------------------------
    |
    | The application locale determines the default locale that will be used
    | by the translation service provider. You are free to set this value
    | to any of the locales which will be supported by the application.
    */
    'locale' => $_ENV['APP_LOCALE'] ?? 'en',

    /*
    |--------------------------------------------------------------------------
    | Application Fallback Locale
    |--------------------------------------------------------------------------
    |
    | The fallback locale determines the locale to use when the current one
    | is not available. You may change the value to correspond to any of
    | the language folders that are provided through your application.
    */
    'fallback_locale' => 'en',

    /*
    |--------------------------------------------------------------------------
    | Encryption Key
    |--------------------------------------------------------------------------
    |
    | This key is used by the encryption service and should be set
    | to a random, 32 character string, otherwise these encrypted strings
    | will not be safe. Please do this before deploying an application!
    */
    'key' => $_ENV['APP_KEY'],

    /*
    |--------------------------------------------------------------------------
    | Service Providers
    |--------------------------------------------------------------------------
    |
    | The service providers listed here will be automatically loaded on the
    | request to your application. Feel free to add your own services to
    | this array to grant expanded functionality to your applications.
    */
    'providers' => [
        // Framework Service Providers
        App\Core\Config\ConfigServiceProvider::class,
        App\Core\Database\DatabaseServiceProvider::class,
        App\Core\Session\SessionServiceProvider::class,
        App\Core\Security\SecurityServiceProvider::class,
        App\Core\Middleware\MiddlewareServiceProvider::class,
        App\Core\Routing\RouterServiceProvider::class,
        App\Core\View\ViewServiceProvider::class,

        // Application Service Providers
        App\Providers\AppServiceProvider::class,
        App\Providers\AuthServiceProvider::class,
        App\Providers\EventServiceProvider::class,
        App\Providers\RouteServiceProvider::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Class Aliases
    |--------------------------------------------------------------------------
    |
    | This array of class aliases will be registered when this application
    | is started. However, feel free to register as many as you wish as
    | the aliases are "lazy" loaded so they don't hinder performance.
    */
    'aliases' => [
        'App' => App\Core\Application::class,
        'Auth' => App\Core\Security\Auth\Authentication::class,
        'Config' => App\Core\Config\Configuration::class,
        'DB' => App\Core\Database\DatabaseManager::class,
        'Request' => App\Core\Http\Request::class,
        'Response' => App\Core\Http\Response::class,
        'Route' => App\Core\Routing\Router::class,
        'Session' => App\Core\Session\SessionManager::class,
        'View' => App\Core\View\ViewEngine::class,
    ],

    /*
    |--------------------------------------------------------------------------
    | Application Paths
    |--------------------------------------------------------------------------
    |
    | Here you may configure the paths used by your application.
    */
    'paths' => [
        'base' => BASE_PATH,
        'config' => BASE_PATH . '/private/config',
        'database' => BASE_PATH . '/private/database',
        'storage' => BASE_PATH . '/private/storage',
        'public' => BASE_PATH . '/public_html',
        'views' => BASE_PATH . '/public_html/views',
        'cache' => BASE_PATH . '/private/storage/cache',
        'logs' => BASE_PATH . '/private/logs',
    ],
];
