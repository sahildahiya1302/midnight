<?php

use App\Core\Routing\Router;

return [
    /*
    |--------------------------------------------------------------------------
    | Route Groups
    |--------------------------------------------------------------------------
    |
    | Define route groups with shared middleware and prefixes.
    | Each group can have its own middleware stack and route prefix.
    */
    'groups' => [
        // Web Routes Group
        'web' => [
            'prefix' => '',
            'middleware' => ['web'],
            'namespace' => 'App\\Controllers\\Web',
        ],

        // API Routes Group
        'api' => [
            'prefix' => 'api',
            'middleware' => ['api'],
            'namespace' => 'App\\Controllers\\API',
        ],

        // Admin Routes Group
        'admin' => [
            'prefix' => 'admin',
            'middleware' => ['web', 'auth', 'admin'],
            'namespace' => 'App\\Controllers\\Admin',
        ],

        // Game Routes Group
        'games' => [
            'prefix' => 'games',
            'middleware' => ['web', 'auth'],
            'namespace' => 'App\\Controllers\\Games',
        ],

        // WebSocket Routes Group
        'websocket' => [
            'prefix' => 'ws',
            'middleware' => ['websocket', 'auth'],
            'namespace' => 'App\\Controllers\\WebSocket',
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Route Patterns
    |--------------------------------------------------------------------------
    |
    | Define common route parameter patterns to be used across routes.
    | These patterns will be automatically applied to matching parameters.
    */
    'patterns' => [
        'id' => '[0-9]+',
        'slug' => '[a-z0-9-]+',
        'uuid' => '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}',
        'username' => '[a-zA-Z0-9_-]+',
        'year' => '[0-9]{4}',
        'month' => '[0-9]{2}',
        'day' => '[0-9]{2}',
    ],

    /*
    |--------------------------------------------------------------------------
    | Named Routes
    |--------------------------------------------------------------------------
    |
    | Register named routes that can be referenced by name throughout the
    | application. This makes route management and generation easier.
    */
    'named' => [
        // Authentication Routes
        'login' => ['GET|POST', '/login', 'Auth\\LoginController@index'],
        'logout' => ['POST', '/logout', 'Auth\\LoginController@logout'],
        'register' => ['GET|POST', '/register', 'Auth\\RegisterController@index'],
        'password.reset' => ['GET|POST', '/password/reset', 'Auth\\PasswordController@reset'],
        'password.email' => ['POST', '/password/email', 'Auth\\PasswordController@sendResetLink'],

        // User Routes
        'profile' => ['GET', '/profile', 'User\\ProfileController@show'],
        'profile.edit' => ['GET|PUT', '/profile/edit', 'User\\ProfileController@edit'],
        'wallet' => ['GET', '/wallet', 'User\\WalletController@show'],
        'transactions' => ['GET', '/transactions', 'User\\TransactionController@index'],

        // Game Routes
        'games.lobby' => ['GET', '/games', 'Games\\LobbyController@index'],
        'games.aviator' => ['GET', '/games/aviator', 'Games\\AviatorController@show'],
        'games.ludo' => ['GET', '/games/ludo', 'Games\\LudoController@show'],
        'games.leaderboard' => ['GET', '/games/leaderboard', 'Games\\LeaderboardController@index'],

        // Admin Routes
        'admin.dashboard' => ['GET', '/admin', 'Admin\\DashboardController@index'],
        'admin.users' => ['GET', '/admin/users', 'Admin\\UserController@index'],
        'admin.games' => ['GET', '/admin/games', 'Admin\\GameController@index'],
        'admin.transactions' => ['GET', '/admin/transactions', 'Admin\\TransactionController@index'],

        // API Routes
        'api.auth' => ['POST', '/api/auth', 'API\\AuthController@authenticate'],
        'api.user' => ['GET', '/api/user', 'API\\UserController@show'],
        'api.games' => ['GET', '/api/games', 'API\\GameController@index'],
        'api.transactions' => ['GET', '/api/transactions', 'API\\TransactionController@index'],

        // WebSocket Routes
        'ws.game' => ['GET', '/ws/game', 'WebSocket\\GameController@handle'],
        'ws.chat' => ['GET', '/ws/chat', 'WebSocket\\ChatController@handle'],
    ],

    /*
    |--------------------------------------------------------------------------
    | Route Middleware
    |--------------------------------------------------------------------------
    |
    | Define middleware aliases that can be referenced in route definitions.
    | These will be registered with the middleware stack.
    */
    'middleware' => [
        'web' => [
            \App\Core\Middleware\SessionMiddleware::class,
            \App\Core\Middleware\CSRFMiddleware::class,
            \App\Core\Middleware\SecurityHeadersMiddleware::class,
        ],
        'api' => [
            \App\Core\Middleware\CorsMiddleware::class,
            \App\Core\Middleware\RateLimitMiddleware::class,
        ],
        'auth' => [
            \App\Core\Middleware\AuthMiddleware::class,
        ],
        'guest' => [
            \App\Core\Middleware\GuestMiddleware::class,
        ],
        'admin' => [
            \App\Middleware\AdminMiddleware::class,
        ],
        'websocket' => [
            \App\Middleware\WebSocketMiddleware::class,
        ],
    ],

    /*
    |--------------------------------------------------------------------------
    | Error Pages
    |--------------------------------------------------------------------------
    |
    | Define custom error pages for different HTTP status codes.
    | These will be used when an error occurs during routing.
    */
    'errors' => [
        '403' => 'errors/403',
        '404' => 'errors/404',
        '419' => 'errors/419',
        '429' => 'errors/429',
        '500' => 'errors/500',
        '503' => 'errors/maintenance',
    ],
];
