<?php
// breadcrumbs snippet template
?>
<div class="breadcrumbs">
    <!-- content for breadcrumbs -->
</div>
